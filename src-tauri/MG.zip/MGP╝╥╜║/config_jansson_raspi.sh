#!/bin/sh

export TOOLS=arm-linux-gnueabihf
export ROOTFS=/home/mgpuser/toolchain/raspi/rasp_rootfs

cd jansson-2.7; ./configure --prefix=/home/mgpuser/test/build.raspi --host=${TOOLS} --with-sysroot=${ROOTFS}

