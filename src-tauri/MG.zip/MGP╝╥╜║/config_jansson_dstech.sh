#!/bin/sh

export TOOLS=arm-buildroot-linux-uclibcgnueabihf
export ROOTFS=/home/mgpuser/toolchain/dstech/usr/arm-buildroot-linux-uclibcgnueabihf/sysroot

cd jansson-2.7; ./configure --prefix=/home/mgpuser/test/build.dstech --host=${TOOLS} --with-sysroot=${ROOTFS}


