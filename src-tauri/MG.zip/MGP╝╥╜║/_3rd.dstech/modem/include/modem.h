#ifndef SRC_DST_APPS_LIBMODEM_MODEM_H_
#define SRC_DST_APPS_LIBMODEM_MODEM_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
	eDST_MODEM_OK=0,					/* 정상 동작 */
	eDST_MODEM_ERR,					/* 기타 에러 */
	eDST_MODEM_ERR_TIMEOUT,			/* MDMMGR 응답 Timeout */
	eDST_MODEM_ERR_SOCKET,			/* MDMMGR 연결용 소켓 에러 */
	eDST_MODEM_ERR_CONNECT,			/* MDMMGR 연결 커넥션 에러 */
	eDST_MODEM_ERR_PARSE,			/* STRING PARSE 에러 */

} DST_MODEM_RESULT;

#define ATCMD_GET_IMEI	"at%imei?\r\n"	/* IMEI */
#define ATCMD_GET_CNUM	"at+cnum\r\n"		/* 전화번호 */
#define ATCMD_GET_NSI	"at@nsi\r\n"		/* 개통 정보 */
#define ATCMD_GET_DBG	"at@dbg\r\n"		/* 모뎀 상태 디버깅 메세지 */
#define ATCMD_GET_CSQ	"at+csq\r\n"		/* RSSI 정보 */
#define ATCMD_GET_CGDCONT "at+cgdcont?\r\n"  /* APN 정보 */
#define ATCMD_GET_CGPADDR "at+cgpaddr\r\n" 	/* Modem 에서 수신한 IP 정보*/

/***********************************************
 * Name 		: modem_get_imei
 * Description: 모뎀의 IMEI 를 얻어온다.
 * Input 		: modem imei (문자열 15자리), len (버퍼 길이:100byte)
 * Output 		: success (0), fail : error code (>1)
************************************************/
DST_MODEM_RESULT modem_get_imei (char* imei, int len);

/***********************************************
 * Name 		: modem_get_cnum
 * Description: 유심의 전화번호를 얻어온다.
 * Input 		: cnum (문자열 11자리), len (버퍼 길이:100byte)
 * Output 		: success (0) , fail : error code (>1)
************************************************/
DST_MODEM_RESULT modem_get_cnum (char* cnum, int len);

/***********************************************
 * Name 		: modem_get_nsi
 * Description: 개통 정보를 얻어온다.
 * Input 		: nsi (문자열 버퍼), len (버퍼 길이:100byte)
 * 				  수신 예) @nsi:4,"IN SRV","olleh","Home","LTE"
 * Output 		: success (0) , fail : error code (>1)
************************************************/
DST_MODEM_RESULT modem_get_nsi (char* nsi, int len);

/***********************************************
 * Name 		: modem_get_csq
 * Description: RSSI 정보를 얻어온다.
 * Input 		: csq (정수) : dBm (-113 ~ -53)
 * Output 		: success (0) , fail : error code (>1)
************************************************/
DST_MODEM_RESULT modem_get_csq (int* csq);

/***********************************************
 * Name 		: modem_get_cgdcont
 * Description: APN 정보를 얻어온다.
 * Input 		: cgdcont (문자열 버퍼), len (버퍼 길이:100byte)
 * Output 		: success (0) , fail : error code (>1)
************************************************/
DST_MODEM_RESULT modem_get_cgdcont (char* cgdcont, int len);

/***********************************************
 * Name 		: modem_get_dbg
 * Description: 모뎀의 디버깅 정보를 얻어온다.
 * Input 		: dbg (문자열 버퍼), len (버퍼 길이: 512byte)
 * Output 		: success (0) , fail : error code (>1)
************************************************/
DST_MODEM_RESULT modem_get_dbg (char* dbg, int len);

/***********************************************
 * Name 		: modem_get_cgpaddr
 * Description: 모뎀에서 수신한 실제 IP 정보를 얻어온다.
 * Input 		: cgpaddr (문자열 버퍼), len (버퍼 길이: 100byte)
 * Output 		: success (0) , fail : error code (>1)
************************************************/
DST_MODEM_RESULT modem_get_cgpaddr (char* cgpaddr, int len);

/***********************************************
 * Name 		: modem_set_dbgmsg
 * Description: 라이브러리 디버그 메세지 Enable/Disable
 * Input 		: Enable (1), Disable (0)
 * Output 		: success (0), fail (error code (>1))
************************************************/
DST_MODEM_RESULT modem_set_dbgmsg (int onoff);


#ifdef __cplusplus
}
#endif

#endif /* SRC_DST_APPS_LIBMODEM_MODEM_H_ */
