// PTTMeta.h
#ifndef TI2ME_PTTMETA_H
#define TI2ME_PTTMETA_H

#if defined(__MINGW32__) || defined(_MSC_VER)
#ifdef PTT_EXPORT
#define PTT_API __declspec(dllexport)
#else
#define PTT_API __declspec(dllimport)
#endif
#else
#define PTT_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

/**
 * 미디어의 속성객체. 미디어 속성을 조회/세팅할 경우 사용합니다. 
 */
extern PTT_API const char *PTT_MIMETYPE_VIDEO_RAW;
extern PTT_API const char *PTT_MIMETYPE_VIDEO_MJPEG;
extern PTT_API const int PTT_CLR_FMT_I420;
extern PTT_API const int PTT_CLR_FMT_YUY2;
extern PTT_API const int PTT_CLR_FMT_RGB24;
extern PTT_API const int PTT_CLR_FMT_RGBA;


/**
 * @bref PTTMeta 구조체. 
 */
typedef void* HPTTMeta;

/**
 * PTTMeta 객체생성. 미디어 속성을 조회/세팅할 경우 사용합니다. 
 */
PTT_API HPTTMeta PTTMeta_new();

/**
 * PTTMeta 객체소멸. 속성을 조회/세팅할 경우 사용합니다.
 */
PTT_API void PTTMeta_delete(HPTTMeta pMeta);

/**
 * 미디어 MIMEType을 설정합니다. 
 * @param mime MIMEType 스트링
 * @return 
 * 		0 	:설정 성공 \n 
 * 		그외 :설정 실패 
 */
PTT_API int PTTMeta_setMIMEType(HPTTMeta pMeta, char* mime);

/**
 * 미디어 mimetype을 조회합니다. 
 * @param mime MIMEType 스트링
 * @return 
 * 		0	:설정 성공 \n 
 * 		그외 :설정 실패 
 */
PTT_API int PTTMeta_getMIMEType(HPTTMeta pMeta, char** mime);

/**
 * 오디오 샘플링 레이트를  설정합니다. 
 * @param sr 오디오 샘플링 레이트
 * @return 
 * 		0 	:설정 성공 \n 
 * 		그외 :설정 실패 
 */
PTT_API int PTTMeta_setAudSampleRate(HPTTMeta pMeta, int sr);

/**
 * 오디오 샘플링 레이트를 조회합니다. 
 * @param sr 오디오 샘플링 레이트
 * @return 
 * 		0 	:설정 성공 \n 
 * 		그외 :설정 실패 
 */
PTT_API int PTTMeta_getAudSampleRate(HPTTMeta pMeta, int* sr);

/**
 * 비디오 가로해상도를 설정합니다. 
 * @param width 비디오 가로해상도(pixel)
 * @return 
 * 		0 	:설정 성공 \n 
 * 		그외 :설정 실패 
 */
PTT_API int PTTMeta_setVidWidth(HPTTMeta pMeta, int width);

/**
 * 비디오 가로해상도를 조회합니다. 
 * @param width 비디오 가로해상도(pixel)
 * @return 
 * 		0 	:설정 성공 \n 
 * 		그외 :설정 실패 
 */
PTT_API int PTTMeta_getVidWidth(HPTTMeta pMeta, int* width);

/**
 * 비디오 세로해상도를 설정합니다. 
 * @param height 비디오 세로해상도
 * @return 
 * 		0 	:설정 성공 \n 
 * 		그외 :설정 실패 
 */
PTT_API int PTTMeta_setVidHeight(HPTTMeta pMeta, int height);

/**
 * 비디오 세로해상도를 조회합니다. 
 * @param height 비디오 세로해상도
 * @return 
 * 		0 	:설정 성공 \n 
 * 		그외 :설정 실패 
 */
PTT_API int PTTMeta_getVidHeight(HPTTMeta pMeta, int* height);

/**
 * 비디오 Frame Rate(fps)를 설정합니다. 
 * @param PTTMeta 포인터
 * @param fps 비디오 Frame Rate(fps)
 * @return 
 * 		0 	:설정 성공 \n 
 * 		그외 :설정 실패 
 */
PTT_API int PTTMeta_setVidFrameRate(HPTTMeta pMeta, int fps);

/**
 * 비디오 Frame Rate(fps)를  조회합니다. 
 * @param ti2meformat 포인터
 * @return 
 * 		0 	:설정 성공 \n 
 * 		그외 :설정 실패 
 */
PTT_API int PTTMeta_getVidFrameRate(HPTTMeta pMeta, int* fps);

/**
 * 비디오 Color Format을 설정합니다.
 * @param clr_fmt 컬러포멧
 * @return
 * 		0 	:설정 성공 \n
 * 		그외 :설정 실패
 */
PTT_API int PTTMeta_setColorFormat(HPTTMeta pMeta, int clr_fmt);

/**
 * 비디오 Color Format을 조회합니다.
 * @param clr_fmt 컬러포멧
 * @return
 * 		0 	:설정 성공 \n
 * 		그외 :설정 실패
 */
PTT_API int PTTMeta_getColorFormat(HPTTMeta pMeta, int* clr_fmt);


/**
 * 비디오 회전 각도를 설정합니다.
 * @param rotation 비디오 회전 각도 0,90,180,270
 * @return
 * 		0 	:설정 성공 \n
 * 		그외 :설정 실패
 */
PTT_API int PTTMeta_setVidRotation(HPTTMeta pMeta, int rotation);

/**
 * 비디오 회전 각도를 조회합니다.
 * @param rotation 비디오 회전 각도 0,90,180,270
 * @return
 * 		0 	:조회 성공 \n
 * 		그외 :설정되어 있는 값이 없음
 */
PTT_API int PTTMeta_getVidRotation(HPTTMeta pMeta, int* rotation);

#ifdef __cplusplus
} // extern "C"
#endif

#endif

