// PTTMbcp.h
#ifndef TI2ME_PPTMBCP_H
#define TI2ME_PPTMBCP_H

#include <stdint.h>
#include <stddef.h>
#include <hPTTMeta.h>

#ifdef __cplusplus
extern "C" {
#endif


	/**********************************************************
	 * Mbcp Listener
	 **********************************************************/

	/**
	 * Mbcp 이벤트 리스너 인터페이스
	 */
typedef struct {
	/**
  	* 미디어가 연결되었을때 수신됨.
		* @param type 
 		* @param isDispatch 
 		* @param members
		* @param callerId
		* @param callerNickName
		* @param groupName
		* @return
		*/
	int (*cbConnect)( void* user, int type, int isDispatch, int members, int callerId,
													int callerNickName, char* groupName);

	/**
	 * 미디어의 연결이 끊어 졌을때 수신됨.
	 * @param reason
	 * @return
	 */
	int (*cbDisconnect)( void* user, int resason);
	
	/**
	 * Talk Request를 요청했을때, 큐닝 상태이거나, 포지션이 변경되었을때 수신됨.
	 * @param priority 우선순위
	 * @param quePosition 대기열에서 자신보다 앞선 단말
	 * @return
	 */
	int (*cbMovedIntoQueue)( void* user, int priority, int quePosition);

	/**
	 * 큐닝 상태를 빠져 나왔을때 수신됨
	 * @param reason
	 * @return 수
	 */
	int (*cbMovedOutQueue)( void* user, int reason);

	/**
	 * onGranted()를 요청 했을때 grant 메세지를 수신했을때,
	 * @param members : 대화방 사용자 수
	 * @param maxTalkTime : 발언권 허락 후 최대 발언 시간(second)
	 * @return
	 */
	int (*cbGranted)( void* user, int members, int maxTalkTime, int alert_margin, int seq);

	/**
	 * idle 메세지를 수신했을때.
	 * @return
	 */
	int (*cbIdle)( void* user);

	/**
	 * revoke 메세지를 수신했을때.
	 * @param reason
	 * 	1 = Poc User Only 1명
	 * 	2 = MediaBurst Too long
	 * 	3 = 보내는 퍼미션 없음
	 * 	4 = PRE-EMPTED
	 * 	5 = FLOOR_TOO_LONG
	 * 	6 = No Resource available
	 * 	255 = other reason.
	 * @param strReason descripton
	 * @return
	 */
	int (*cbRevoked)( void* user, int reason, char* strReason);

	/**
	 * taken 메세지를 수신했을때.
	 * @param members				: 대화방 사용자 수
	 * @param talker_domain : john@samsumg.com
	 * @param talker_name		: john
	 * @param phone_num			: 030-xxx-xxxx
	 * @return
	 */
	int (*cbTaken)( void* user, int members, char* talker_domain, char* talker_name, char* phone_num);

	/**
	 * 발언권 요청에 대한 응답
	 * 
	 * @param permisson 
	 *     1 = 발언권 획득 성공, 곧바로 OnGranted 전달됨.
	 *     0 = 발언권 획득 실패,
	 * @param reason_code
	 *      1 = 누군가 발언권을 이미 획득함
	 *     2 = Server 내부 오류
	 *      3 = 오직 한 참가자
	 *      4 = 서버가 응답이 없음.
	 *     5 = Receive Only
	 *     6 = No Resurces
	 *     7 = Reserved
	 *     8 = Request Queuing Support
	 *     9 = Server 거절(Deny)
	 *     10= moving to queuing state. 곧바로 onMovedToQueuing 메시지 전달됨.
	 *   255 = other reason
	 * @return
	 */
	int (*cbResultTalkReq)( void* user, int permission, int reason_code);

	/*
	 * 발언권 Release 대해 릴리즈 완료됨
	 * 발언권 Release시 실제 릴리이지 싯점에서 모조건 호출됨
	 */
	int (*cbResultTalkRel)( void* user);

    /**
      *    묵시적인 발언권을 승인합니다.
      */
//    int (*cbImpGranted)( void* user);

} HMbcpCb;


	/**********************************************************
	 * Mbcp v2Listener
	 **********************************************************/

	/**
	 * Mbcp 이벤트 리스너 인터페이스
	 */
typedef struct {
	
    /**
       * Taken상태에서 Talk Request 를 요청했을때, 큐닝 상태이거나, 포지션이 변경되었을때 수신됨.
       * @param priority 우선 순위
       * @param quePosition 대기열에서 자신보다 앞선 단말 수
       * @return
       */
      int (*cbInQueuingMsg)(void * user, int priority, int quePosition);

      /**
        * 큐닝 상태를 빠져 나왔을때 수신됨
       * @param reason
       * 1 =  by user Cancel.
       * 2 =  by getting permission
       * 3 =  by server deny
       * @return수
       */
      int (*cbMovedOutQueuing)(void * user, int reason);


      /**
       *  onGranted() 를 요청 했을때 grant 메세지를 수신했을 때.
       * @param members : 대화방 사용자 수
       * @param maxTalkTime : 발언권 허락 후 최대 발언 시간(second)
       * @param alert_margin : 발언권 회수 경고 시
       * @param seq          :sequence number
       * @return
       */
      int (*cbGranted)(void * user, int members, int maxTalkTime, int alert_margin, int seq);

		/**
		* 발언권 종료 되었을 때(User or Revoke)
		* @param reason
		*   1 = Off-Granted by User
		*   2 = Off-Granted by Revoke(revoke_code 참)
		* @param revoke_code
		* 	1 = POC User Only 1명,
		*	2 = MediaBurst Too long
		*	3 = 보내는 퍼미션 없음 고
		*	4 = PRE-EMPTED
		*	5 = FLOOR_TOO_LONG
		*	6 = No Resource available
		*	255 = other reason.
		* @param seq
		*   onGranted와 동일한 sequence Number
		* @return
		*/
     int (*cbOffGranted)(void* user, int reason, int revoke_code, int seq);

      /**
       * taken 메세지를 수신했을때.(누군가 발언권 획득함)
       * @param members : 대화방 사용자 수
       * @param talker_domain : ex) john@samsung.com
       * @param talker_name : ex) john
       * @param phone_num   : ex) 030-xxx-xxxx
       * @param seq         : sequence number
       * @return
       */
     int (*cbTaken)(void * user, int members, char* talker_domain, char* talker_name, char* phone_num, int seq);

     /**
       * 발언권을 가진 단말의 발언권 종료됨.
      * @param seq         : onTaken과 동일한 sequence number
      * @return
      */
     int (*cbOffTaken)(void * user, int seq);

      /**
       * 발언권 요청에 대한 실패 응답
      * @param reason_code
       *      1 = 누군가 발언권을 이미 획득함(큐잉 안됨)
      *     2 = Server 내부 오류
       *      3 = 오직 한 참가자
       *      4 = 서버가 응답이 없음.
      *     5 = Receive Only
      *     6 = No Resurces
      *     7 = Reserved
      *     8 = Request Queuing Support
      *     9 = Server 거절(Deny)
      *     10= moving to queuing state. 곧바로 onMovedToQueuing 메시지 전달됨.
      *   255 = other reason
      * @return
       */
      int (*cbResultFailTalkReq)(void * user, int reason_code);

      /**
       *  Still-Alive 에 대한 응답수신 여부
       *
      * @param result
      *  1 = Still-Alive Ack 응답 수신.
      *  0 = Still-Alive Ack 수신 실패,
      * @return
       */
      int (*cbResultAliveAck)(void * user, int result);

} v2HMbcpCb;

/**********************************************************
 * MBCP
 **********************************************************/
/**
 * mbcp 스택 \n
 * 세션에서 mbcp 스택을 사용해야 할 경우 사용합니다. \n
 * Mbcp getMBCP() 를 호출 하여 스택 객체를 가져 옵니다. \n
 * 스택 시작시 수신먼저 시작 해야 할경우, 로컬 포트 설정후 시작하고, 리모트 설정은 송신 시작 전에 해도 됩니다. \n
 * 스택은 기본 api 는 동일하지만, 세부 api 는 추후에 추가/변경될 수 있습니다.\n
 */
typedef void* HPTTMbcp;

/**
 * 스택의 로컬 address 설정 합니다.
 * @param PTTMbcp 포인터
 * @param ip 아이피
 * @param port mbcp 수신 base 포트이며, base 포트 기준으로 할당된 포트를 리턴합니다.
 * @param int 할당된 포트를 리턴합니다. 0 일경우 포트할당 실패.
 */
PTT_API int PTTMbcp_getLocalPort(HPTTMbcp pPTTMbcp, char* ip, int port);
	
/**
 * 스택의 remote address 설정 합니다.
 * @param PTTMbcp 포인터
 * @param ip 리모트 아이피
 * @param port 송신할 상대방 포트.
 */
PTT_API void PTTMbcp_setRemotePort(HPTTMbcp pPTTMbcp, char* ip, int port);

/**
 * 스택을 시작 합니다.
 * @param PTTMbcp 포인터
 * @return
 */
PTT_API int PTTMbcp_start(HPTTMbcp pPTTMbcp);

/**
 * 스텍을 종료 합니다.
 * @param PTTMbcp 포인터
 * @return
 */
PTT_API void PTTMbcp_stop(HPTTMbcp pPTTMbcp);

PTT_API void PTTMbcp_setParameters(HPTTMbcp pPTTMbcp, HPTTMeta params);

/**
 * 미디어 송출 요청합니다.
 * @param PTTMbcp 포인터
 * @param priority 우선순위 \n
 * 		1: normal \n
 * 		2: high		\n
 * 		3: pre-emptive(가로채기) \n
 * @param reDuration 톡 타임. default : 30, 30초 동안 미디어 송출 요청
 * @param reqText : 송출 이유 - description.
 */
PTT_API void PTTMbcp_TalkReq(HPTTMbcp pPTTMbcp, int priority, int reDuration, char* reqText);

/**
 * 미디어 송출 중지를 통보 합니다.
 */
PTT_API void PTTMbcp_TalkRel(HPTTMbcp pPTTMbcp);

/**
 * 큐닝 상태를 요청 합니다. \n
 * 내 발언권의 위치 결과를 돌려 받습니다. : \n
 * size_t onMovedToQueing(int32_t priority, int32_t quePosition);
 */
PTT_API void PTTMbcp_QueStatusReq(HPTTMbcp pPTTMbcp);

/**
 * 시작전 묵시적인 발언권을 설정합니다.
 */
//PTT_API void PTTMbcp_setImpOnGranted();

/**
 * mbcp 리스너를 설정합니다.
 * @see MbcpListener
 */
//PTT_API void PTTMbcp_setListener(HPTTMbcp pPTTMbcp, void* user, HMbcpCb* mbcpCb);
PTT_API void PTTMbcp_setListener(HPTTMbcp pPTTMbcp, void* user, v2HMbcpCb* mbcpCb);
/**
 * SRTP 모드를 on/off 시킵니다.
 * @param mode 0:srtp off, 1:srtp on \n
 */
PTT_API void		PTTMbcp_setSRTPMode( HPTTMbcp pPTTMbcp, int mode);

/**
 * SRTP 암호화 방식을 설정 합니다.
 * @param type 0: TMRTP_AUTH_SHA1_80, 1:TMRTP_AUTH_SHA1_32
 * @return 0 : 성공.
 */
PTT_API int		PTTMbcp_setSRTPCryptoType( HPTTMbcp pPTTMbcp, int type);

/**
 * SRTP 키값을 설정 합니다.
 * @param localKey : 로컬키값 ( 전송시 암호화 키)
 * @param remoteKey : 리모트키 값 ( 수신시 복호화 키)
 * @return
 */
PTT_API int		PTTMbcp_setSRTP( HPTTMbcp pPTTMbcp, const char* localKey, const char* remoteKey);

/**
 * Mbcp UDP Hole을 유지하기 위해서 Still Alive를 주기적으로 전송합니다.
 * @param on  \n
 * 			true: on \n
 * 			false: off \n
 * @param period_sec 전송주기(seconds)
 */
PTT_API void 		PTTMbcp_setEnableStillAlive(HPTTMbcp pPTTMbcp, bool on , int period_sec);

/**
 * Mbcp Still Alive를 강제로 전송합니다.
 * @param
 * @param
 */
PTT_API void 		PTTMbcp_sendStillAlive(HPTTMbcp pPTTMbcp);

/**
 * MBCP SSRC값을 설정 합니다.
 * @param ssrc : SSRC(32bit)
 * @return
 */
PTT_API void		PTTMbcp_setSSRC( HPTTMbcp pPTTMbcp, unsigned int ssrc);

#ifdef __cplusplus
} // extern "C"
#endif

#endif

