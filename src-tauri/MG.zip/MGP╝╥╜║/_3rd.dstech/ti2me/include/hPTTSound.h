#ifndef TI2ME_PTTSOUND_H
#define TI2ME_PTTSOUND_H

#include <stddef.h>
#include <hPTTMeta.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void* HPTTSound;


/**
 * PTTSound 이벤트 콜백 인터페이스
 */
typedef void (*PTTSoundEventCb)( void* user, HPTTSound h, int event);

/**
 * PTTSound 콜백 이벤트 타입
 */
#define PTTSOUND_EVENT_EOS		0
#define PTTSOUND_EVENT_ERROR	1


/**
 * 재생할 사운드 파일을 지정한다.
 * @param filename 재생할 파일명
 * 지원되는 포멧 : signed 16bit PCM wave file, 8kHz~48kHz, mono/stereo
 * 실제출력은 16kHz, mono로 변환 되므로 품질을 위해 16kHz, mono wave 파일을 사용해야 한다.
 * @return
 * 		0 	:설정 성공
 * 		그외 :설정 실패
 */
PTT_API int PTTSound_setFilename(HPTTSound h, const char* filename);

/**
 * 사운드 재생 시작
 * setFilename을 먼저 사용해야 한
 * @return
 * 		0 	:설정 성공
 * 		그외 :설정 실패
 */
PTT_API int PTTSound_start(HPTTSound h);

/**
 * 사운드 재생 중지
 */
PTT_API void PTTSound_stop(HPTTSound h);

/**
 * 반복재생 여부를 설정한다. 초기값은 0
 * @param loop 0:반복안함 1:반복
 */
PTT_API void PTTSound_setLoop(HPTTSound h, int loop);

/**
 * 사운드 출력의 소프트 볼륨을 설정한다. 초기값은 100
 * @param vol 0 ~ 100
 * @return
 * 		0 	:설정 성공
 * 		그외 :설정 실패
 */
PTT_API int32_t PTTSound_setVolume(HPTTSound h, int32_t vol);

/**
 * 사운드를 출력할 스피커를 지정한다. 초기값은 3
 * @param mask 1:left, 2:right, 3:left&right
 * @return
 * 		0 	:설정 성공
 * 		그외 :설정 실패
 */
PTT_API int32_t PTTSound_setSpeakerMask(HPTTSound h, uint32_t mask);

/**
 * 리스너를 설정합니다.
 */
PTT_API void PTTSound_setListener(HPTTSound h, void* user, PTTSoundEventCb cb);


#ifdef __cplusplus
} // extern "C"
#endif

#endif

