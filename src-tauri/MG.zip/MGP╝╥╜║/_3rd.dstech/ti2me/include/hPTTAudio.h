// PTTAudio.h
#ifndef TI2ME_PTTAUDIO_H
#define TI2ME_PTTAUDIO_H

#include <stddef.h>
#include <hPTTMeta.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 * 세션의 오디오 객체. 오디오 송수신을 할 경우 사용합니다.
 */

/**
 * @bref 오디오 코덱의 종류.
 * AMR-WB, AMR-NB, PCMU, PCMA 를 지원 합니다.
 */
typedef enum {
	CODEC_AMR_NB_OA,
	CODEC_AMR_NB_BE,
	CODEC_AMR_WB_OA,
	CODEC_AMR_WB_BE,
	CODEC_PCMA,
	CODEC_PCMU,
	CODEC_OPUS_NB,
	CODEC_OPUS_WB,
	CODEC_OPUS_FB
} AudioCodec;

/**
 * @bref PTTAudio 구조체.
 */
typedef void* HPTTAudio;

/**
 * 오디오 코덱및 페이로드를 설정합니다.
 * @see AudioCodec 
 * @param PTTAUdio 포인터
 * @param codec 오디오 코덱 설정.
 * @param payload 오디오 페이로드
 * @return 
 * 		0 	:설정 성공 \n
 * 		그외 :설정 실패
 */
PTT_API int PTTAudio_setCodec(HPTTAudio pPTTAudio, AudioCodec codec, int payload);


/**
 * 오디오 객체 시작. \n
 * @return
 * 		0 	:설정 성공 \n
 * 		그외 :설정 실패
 */
PTT_API int PTTAudio_start(HPTTAudio pPTTAudio);

/**
 * 오디오 객체 중지
 */
PTT_API int PTTAudio_stop(HPTTAudio pPTTAudio);

/**
 * 오디오 객체를 생성직후 상태로 초기화 합니다.
 */
PTT_API void PTTAudio_reset(HPTTAudio pPTTVideo);

PTT_API void PTTAudio_setParameters(HPTTAudio pPTTAudio, HPTTMeta params);

/**
 * 오디오 객체의 default 설정을 가져 옵니다. (사용 불가)
 * @return PTTMeta 파라메터 설정 값. 조회한 후 PTTMeta_delete로 삭제해야 한다.
 * @see PTTMeta
 */
PTT_API HPTTMeta PTTAudio_getDefaultParameters(HPTTAudio pPTTAudio);

/**
 * 오디오 객체의 설정을 초기화 합니다. 최초 세션 생성시 1회 호출해야 합니다.
 */
PTT_API void PTTAudio_initParameters(HPTTAudio pPTTAudio);

/**
 * 로컬 address를 설정합니다.
 * @param ip 로컬 아이피
 * @param basePort base 포트 기준으로 설정을 시도합니다.
 * @return 
 * 		0 이상의 수	:설정된 포트번호를 리턴합니다. \n
 * 		0   :설정 실패
 */
PTT_API int PTTAudio_getLocalPort(HPTTAudio pPTTAudio, char* ip, int basePort);

/**
 * 리모트 address를 설정합니다.
 * @param ip 리모트 아이피
 * @param port 상대방 수신 포트를 설정합니다.
 */
PTT_API void PTTAudio_setRemotePort(HPTTAudio pPTTAudio, char* ip, int port);

/**
 * 오디오 세션의 입력을 활성화 한다.
 * @param activate 1:활성화 0:비활성화
 */
PTT_API void PTTAudio_setInputActive( HPTTAudio pPTTAudio, int activate);

/**
 * 오디오 세션의 출력을 활성화 한다.
 * @param activate 1:활성화 0:비활성화
 */
PTT_API void PTTAudio_setOutputActive( HPTTAudio pPTTAudio, int activate);

/**
 * 오디오 세션의 출력 볼륨을 설정한다.
 * @param vol 볼륨값 0~100
 */
PTT_API void PTTAudio_setVolume( HPTTAudio pPTTAudio, int vol);

PTT_API int		PTTAudio_getInputActive( HPTTAudio pPTTAudio);
PTT_API int		PTTAudio_getOutputActive( HPTTAudio pPTTAudio);

/**
 * SRTP 모드를 on/off 시킵니다.
 * @param mode 0:srtp off, 1:srtp on \n
 */
PTT_API void		PTTAudio_setSRTPMode( HPTTAudio pPTTAudio, int mode);

/**
 * SRTP 암호화 방식을 설정 합니다.
 * @param type 0: TMRTP_AUTH_SHA1_80, 1:TMRTP_AUTH_SHA1_32
 * @return 0 : 성공.
 */
PTT_API int		PTTAudio_setSRTPCryptoType( HPTTAudio pPTTAudio, int type);

/**
 * SRTP 키값을 설정 합니다.
 * @param localKey : 로컬키값 ( 전송시 암호화 키)
 * @param remoteKey : 리모트키 값 ( 수신시 복호화 키)
 * @return
 */
PTT_API int		PTTAudio_setSRTP( HPTTAudio pPTTAudio, const char* localKey, const char* remoteKey);

/**
 * Audio RTP SSRC값을 설정 합니다.
 * @param ssrc : SSRC(32bit)
 * @return
 */
PTT_API void		PTTAudio_setSSRC( HPTTAudio pPTTAudio, unsigned int ssrc);

#ifdef __cplusplus
} // extern "C"
#endif

#endif
