// PTTManager.h
#ifndef TI2ME_PTTMANAGER_H_
#define TI2ME_PTTMANAGER_H_

#include <stdint.h>
#include <stddef.h>
#include <hPTTMeta.h>
#include <hPTTSession.h>

#ifdef __cplusplus
extern "C" {
#endif


//typedef void* HPTTSession;


/**
 * PTTManager 는 PTTSession 을 생성하고, 관리 한다.\n
 *
 */

#define ENGINE_API_VER "201507210"



/**
 * @bref PTTManager 구조체.
 * 맴버변수 및 포인터를 가지고 있습니다.
 */
typedef void* HPTTManager;
/**
 * PTT매니져 객체생성. 오디오 스트림을 송수신 할때 사용합니다.
 */
PTT_API HPTTManager PTTManager_new();

/**
 *  PTT매니져 객체소멸. 오디오 스트림을 송수신 할때 사용합니다.
 */
PTT_API int PTTManager_delete(HPTTManager pPTTManager);

/**
 * PTTManager 를 사용하기 위한 준비 작업을 합니다.
 * @param pPTTManager 객체포인터
 * */
PTT_API void PTTManager_initialize(HPTTManager pPTTManager);


/**
 * 세션을 생성 합니다.
 * @return PTTSession 
 */
PTT_API HPTTSession  PTTManager_createSession(HPTTManager pPTTManager);

/**
 * 세션을 release 합니다.
 * @param s PTTSession 
 */
PTT_API void PTTManager_releaseSession(HPTTManager pPTTManager, HPTTSession s);


PTT_API int PTTManager_getSrtpKey( char* buf, int buf_size);

#ifdef __cplusplus
} // extern "C"
#endif

#endif 
