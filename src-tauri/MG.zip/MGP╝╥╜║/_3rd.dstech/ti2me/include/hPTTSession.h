// PTTSession.h
#ifndef TI2ME_PTTSESSION_H
#define TI2ME_PTTSESSION_H

#include <stddef.h>
#include <hPTTMbcp.h>
#include <hPTTAudio.h>

#ifdef __cplusplus
extern "C" {
#endif


/**********************************************************
 * Session Listener
 **********************************************************/

/**
 * 세션 이벤트 리스너 인터페이스
 */
typedef struct {
	void (*onNetworkError)( void* user);
	void (*onNoRtp)(void* user);
} hSessionListener;


/**
 * 세션의 생성은 PTTManager->createSession()을 통해 생성하며, \n
 * 세션 해제 시에는 PTTManager->releaseSession()을 이용한다. \n
 * @see PTTManager
 */
typedef void*  HPTTSession;

/**
 * 세션의 아이디를 가져옵니다.
 * @param PTTSession 포인터
 * @return int session id 값.
 */
PTT_API uint64_t PTTSession_getId(HPTTSession s);

/**
 * 오디오 객체를 가져옵니다. 음성 송수신을 할 경우 사용합니다.
Videoaram PTTSession 포인터
 * @return Audio 오디오 객체
 */
PTT_API HPTTAudio PTTSession_getAudio(HPTTSession s);

/**
 * Mbcp 스택 객체를 가져옵니다.
 * @param PTTSession 포인터
 * @see Mbcp
 * @return Mbcp 스택
 */
PTT_API HPTTMbcp PTTSession_getMBCP(HPTTSession s);

/**
 * 세션 이벤트 리스너를 설정합니다. \n
 * 세션에 대한 이벤트를 받아야 할 경우 설정합니다.
 * listener 구조체의 함수포인터는 엔진 내부에 복사되므로 listener구조체를 유지할 필요 없음.
 * @param PTTSession 포인터
 * @see SessionListener
 */
PTT_API void PTTSession_setListener(HPTTSession s, void* user, hSessionListener* listener);



#ifdef __cplusplus
} // extern "C"
#endif

#endif

