#include "libcom.h"

#define UDP_PORT_1 16728

typedef struct _magic {
	int    maxfd;
	fd_set rset;
	int    ufd[6];
} magic_t;

magic_t Magic;

int main(void)
{
	int  cc, index;
	char buff[100];
	sockaddr_in_t from_addr;

	fd_set rset;

	memset(&Magic    , 0x00, sizeof(Magic));
	memset(&from_addr, 0x00, sizeof(sockaddr_in_t));

	printf("Welcome~\n");

	if ((Magic.ufd[0] = comOpenUDPSocket((uchar *)NULL, UDP_PORT_1, 65535)) == -1) {
		perror("open");
		return -1;
	}

	printf("1----------\n");
	/* mask */
	comSetSelectMask(&Magic.maxfd, &Magic.rset, Magic.ufd[0]);
	printf("2----------\n");

	index = 0;
	while (1) {
		printf("3----------\n");
		memcpy(&rset, &Magic.rset, sizeof(fd_set));
		if ((cc == select(Magic.maxfd, &rset, NULL, NULL, NULL)) == -1) {
			perror("select");
			break;
		}

		/* UDP */
		printf("4----------\n");
		if (FD_ISSET(Magic.ufd[0], &rset)) {
			if ((cc = comReadUDPSocket(Magic.ufd[0], (uchar *)buff, sizeof(buff), &from_addr)) > 0) {
				printf("cc=%d,%s\n", cc, buff);
			}
			else { goto out; }
		}

		memset(buff, 0x00, sizeof(buff));
	}

out:

	printf("Bye~\n");

	return 0;
}
