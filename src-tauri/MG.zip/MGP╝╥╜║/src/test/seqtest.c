#include "libcom.h"
#include "libapp.h"
#include "libpath.h"

typedef struct _seqcntl {
	int pos;
	int length;
	unsigned int seq[MAX_SEQ_NUM]; 
} seqcntl_t;

void seqcntl_init(seqcntl_t *p_seqcntl)
{
	memset(p_seqcntl, 0x00, sizeof(seqcntl_t));
}

unsigned int seqcntl_expected(seqcntl_t *p_seqcntl)
{
	unsigned int minval = p_seqcntl->seq[p_seqcntl->pos];
	int i, tmppos;

	for (i = 1; i <= p_seqcntl->length; i++) {
		tmppos = (p_seqcntl->pos + i) % MAX_SEQ_NUM;
		if (p_seqcntl->seq[tmppos] != (minval + i)) {
			return (minval + i);
		}
	}

	return 1;
}

int seqcntl_put(seqcntl_t *p_seqcntl, unsigned int n)
{
	unsigned int minval = 0; //p_seqcntl->seq[p_seqcntl->spos];
	unsigned int maxval = 0;
	int tmppos, i;

	if (p_seqcntl->length == 0 || n == 1) {
		seqcntl_init(p_seqcntl);
		p_seqcntl->seq[0] = n;
		p_seqcntl->pos    = 0;
		p_seqcntl->length = 1;

		return 0;
	}
	minval =  p_seqcntl->seq[p_seqcntl->pos];
	tmppos = (p_seqcntl->pos + p_seqcntl->length - 1) % MAX_SEQ_NUM;
	maxval =  p_seqcntl->seq[tmppos];

	if (n <= minval) {
		return -1;
	}
	if (n >  minval + MAX_SEQ_NUM - 1) {
		return seqcntl_expected(p_seqcntl);
	}

	tmppos = (p_seqcntl->pos + n - minval) % MAX_SEQ_NUM;
	if (p_seqcntl->seq[tmppos] == n) {
		return seqcntl_expected(p_seqcntl);
	}
	p_seqcntl->seq[tmppos] = n;

	if (n > maxval) {
		p_seqcntl->length += (n - maxval);
	}

	for (i = 1; i <= p_seqcntl->length; i++) {
		tmppos = (p_seqcntl->pos + i) % MAX_SEQ_NUM;
		if (p_seqcntl->seq[tmppos] != (minval + i)) {
			p_seqcntl->pos     = (p_seqcntl->pos + i - 1) % MAX_SEQ_NUM;
			p_seqcntl->length -= (i - 1);
			break;
		}
	}


	return 0;
}

char *seqcntl_dump(seqcntl_t *p_seqcntl, char *s)
{
	unsigned int minval = p_seqcntl->seq[p_seqcntl->pos];
	int          i, j,  tmppos, n = 0;

	j = 0;
	for (i = 0; i < p_seqcntl->length; i++) {
		tmppos = (p_seqcntl->pos + i) % MAX_SEQ_NUM;
		if (p_seqcntl->seq[tmppos] == (minval + i)) {
			if (j == 0) n += sprintf(s + n,  "[%u]%u", tmppos, p_seqcntl->seq[tmppos]);
			else        n += sprintf(s + n, ",[%u]%u", tmppos, p_seqcntl->seq[tmppos]);
			j++;
		}
	}

	return s;
}

void seqcntl_print(seqcntl_t *p_seqcntl)
{
	char s[256];
	int  tmppos;

	printf("---------------------------------------\n");
	printf("%s\n", seqcntl_dump(p_seqcntl, s));
	tmppos = (p_seqcntl->pos + p_seqcntl->length - 1) % MAX_SEQ_NUM;
	printf("MIN[%d]=%d, MAX[%d]=%d, LEN=%d\n",
			p_seqcntl->pos,
			p_seqcntl->seq[p_seqcntl->pos],
			tmppos,
			p_seqcntl->seq[tmppos],
			p_seqcntl->length);

	return;
}

int proc_local()
{
	char line[128];

	printf("> "); fflush(stdout);
	if (fgets(line, sizeof(line), stdin) != NULL) {
		return atoi(line);
	}

	return 0;
}

int main(void)
{
	int n, cc;
	seqcntl_t seqcntl;

	seqcntl_init(&seqcntl);

	while ((n = proc_local()) != 0) {
		printf("process this ..... %d\n", n);
		if ((cc = seqcntl_put(&seqcntl, n)) != 0) {
			printf("error(%d)\n", cc);
		}
		seqcntl_print(&seqcntl);
	}

	return 0;
}


