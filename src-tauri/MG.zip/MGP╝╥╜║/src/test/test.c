#include "libcom.h"
#include "libapp.h"
#include "libcps.h"
#include "lcsmsg.h"
#include "cpsmsg.h"

#include <stdio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <linux/sockios.h>
//#include <linux/if.h>
#include <linux/ethtool.h>
#include <string.h>
#include <stdlib.h>

#include "libpath.h"


#define TO_CHR(cchh) ((cchh == 0x0a) ? '0' : ((cchh == 0x0d || cchh == 0x0b) ? '*' : ((cchh == 0x0e || cchh == 0x0c) ? '#' : cchh + '0')))

void convert(int key)
{
	int convkey;

	convkey = 0;
	convkey |= (key >> 24) & 0x000000ff;
	convkey |= (key << 24) & 0xff000000;
	convkey |= (key <<  8) & 0x00ff0000;
	convkey |= (key >>  8) & 0x0000ff00;

	printf("key    : H'%08x\n", key);
	printf("convkey: H'%08x\n", convkey);
}

void print(cpsaddr_t *p_addr)
{
	int i;

	for (i = 0; i < sizeof(cpsaddr_t); i++) {
		printf("%02x ", p_addr->d[i]);
	}
	printf("\n");
}

void encode(char *s, cpsaddr_t *p_addr)
{
	int  i, j, n = strlen(s);
	char ch;

	for (i = 0, j = 0; i < MAX_ADDRESS_LEN; i++) {
		if (i < n) { ch = s[i] - 0x30; }
		else       { ch = 0x0f;        }
		if ((i % 2) == 0) {
			p_addr->d[j] |= ch & 0x0f;
		}
		else {
			p_addr->d[j] |= ch << 4;
			j++;
		}
	}

	return ;
}

void decode(cpsaddr_t *p_addr, char *s)
{
	int  i, j;
	char ch;

	for (i = 0, j = 0; i < MAX_ADDRESS_LEN; i++) {
		if ((i % 2) == 0) {
			if ((ch = (p_addr->d[j] & 0x0f)) == 0x0f) {
				s[i] = 0x00;
			}
			else {
				s[i] = ch + 0x30;
			}
		}
		else {
			if ((ch = ((p_addr->d[j] >> 4) & 0x0f)) == 0x0f) {
				s[i] = 0x00;
			}
			else {
				s[i] = ch + 0x30;
			}
			j++;
		}
	}

	return ;
}

void parseline(char *cmdline)
{
	int    argc;
	char **argv;

	if ((argv = lp_alloc(cmdline, &argc)) == NULL) {
		printf("lp_alloc error\n");
		return ;
	}
	lp_print(argc, argv);
	lp_release(argv);

	return;
}

#if 0
int ifspeed(char *name)
{
	int sock;
	struct ifreq ifr;
	struct ethtool_cmd edata;
	int rc;

	sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_IP);
	if (sock < 0) {
		perror("socket");
		exit(1);
	}

	strncpy(ifr.ifr_name, name, sizeof(ifr.ifr_name));
	ifr.ifr_data = &edata;

	edata.cmd = ETHTOOL_GSET;

	rc = ioctl(sock, SIOCETHTOOL, &ifr);
	if (rc < 0) {
		perror("ioctl");
		exit(1);
	}
	switch (edata.speed) {
		case SPEED_10: printf("10Mbps\n"); break;
		case SPEED_100: printf("100Mbps\n"); break;
		case SPEED_1000: printf("1Gbps\n"); break;
		case SPEED_2500: printf("2.5Gbps\n"); break;
		case SPEED_10000: printf("10Gbps\n"); break;
		default: printf("Speed returned is %d\n", edata.speed);
	}

	return (0);
}

void ifspeed_main()
{
	ifspeed("em1");
	ifspeed("em2");
	ifspeed("em3");
	ifspeed("em4");
	ifspeed("em5");
}
#endif

void sighandler(int signo)
{
	printf("signo: %d\n", signo);
}

void kill_main()
{
	comInstallSignal(SIGTERM , sighandler);
	comInstallSignal(0       , sighandler);

	while (1) { pause(); }
}

void pathinfo()
{
	char *input = "/usr/timesten/java -Dabc jjj";
	char  cmdline[1024], cmdpath[255];

	_makeup_slave_path(input, cmdpath, cmdline);

	printf("input  : %s\n", input);
	printf("cmdpath: %s\n", cmdpath);
	printf("cmdline: %s\n", cmdline);

	return;
}

void pathmesg()
{
	printf("sizeof(ueheader_t)  .... %ld\n", sizeof(ueheader_t));
	printf("sizeof(cpsheader_t) .... %ld\n", sizeof(cpsheader_t));
	printf("........................\n");
	printf("sizeof(ueaddr_t) ....... %ld\n", sizeof(ueaddr_t));
	printf("sizeof(iuaddr_t) ....... %ld\n", sizeof(iuaddr_t));
	printf("sizeof(uesid_t)  ....... %ld\n", sizeof(uesid_t));
	printf("sizeof(iuid_t) ......... %ld\n", sizeof(iuid_t));
	printf("sizeof(ipport_t) ....... %ld\n", sizeof(ipport_t));
	printf("........................\n");
	printf("sizeof(uebindreq_t) .... %ld\n", sizeof(uebindreq_t));
	printf("sizeof(uebindres_t) .... %ld\n", sizeof(uebindres_t));
	printf("sizeof(ueleavereq_t) ... %ld\n", sizeof(ueleavereq_t));
	printf("sizeof(ueleaveres_t) ... %ld\n", sizeof(ueleaveres_t));
	printf("sizeof(ueeventreq_t) ... %ld\n", sizeof(ueeventreq_t));
	printf("sizeof(ueeventres_t) ... %ld\n", sizeof(ueeventres_t));
	printf("sizeof(uepingreq_t) .... %ld\n", sizeof(uepingreq_t));
	printf("sizeof(uepingres_t) .... %ld\n", sizeof(uepingres_t));
	printf("sizeof(ueinvkreq_t) .... %ld\n", sizeof(ueinvkreq_t));
	printf("sizeof(ueinvkres_t) .... %ld\n", sizeof(ueinvkres_t));
	printf("sizeof(ueallocreq_t) ... %ld\n", sizeof(ueallocreq_t));
	printf("sizeof(ueallocres_t) ... %ld\n", sizeof(ueallocres_t));
	printf("sizeof(uereleasereq_t) . %ld\n", sizeof(uereleasereq_t));
	printf("sizeof(uereleaseres_t) . %ld\n", sizeof(uereleaseres_t));
	printf("sizeof(uemsg_t) ........ %ld\n", sizeof(uemsg_t));
	return;
}

void ip2str()
{
	char      s[100];
	ueipaddr_t ipaddr;

	sprintf(s, "192.168.33.220");

	pathUeMesgStr2Ipaddr(s, &ipaddr);
	pathUeMesgIpaddr2Str(&ipaddr, s);

	printf("s .... %s\n", s);

}

int main(int argc, char **argv)
{
	char      s1[100], s2[100];;
	cpsaddr_t addr;

	sprintf(s1, "+82*10417+317#93");
	cpsMesgStr2Address(s1, &addr);
	cpsMesgAddress2Str(&addr, s2);

	printf("s1: %s\n", s1);
	printf("s2: %s\n", s2);

	pathinfo();
	pathmesg();
	ip2str();

#if 0
	int    i, svrkey, netkey;
	char   S[30], K[30], KK[30], *p;
	time_t T = comTime();

	double dd = 1223.982817;

	slaveholder_t slavelist;

	cpsaddr_t A;
	memset(&A, 0x00, sizeof(cpsaddr_t));

	sprintf(S, "01234567892");
	encode(S, &A);
	print(&A);
	decode(&A, K);
	printf("K=%s\n", K);
	printf("S=%s\n", S);

	printf("sizeof(header) =%ld\n", sizeof(lcsmsg_head_t));
	printf("sizeof(lcsmsg_path_t) =%ld\n", sizeof(lcsmsg_path_t));
	printf("sizeof(lcsmsg_path_ack_t) =%ld\n", sizeof(lcsmsg_path_ack_t));
	printf("sizeof(lcsmsg_bind_t) =%ld\n", sizeof(lcsmsg_bind_t));
	printf("sizeof(lcsmsg_bind_ack_t) =%ld\n", sizeof(lcsmsg_bind_ack_t));

	printf("dd = %.3f\n", dd);

	for (i = 0; i < 1000; i++) {
		printf("%s\n", comTimeTraceFormat(KK));
	}

	svrkey = onmGetServerKey(3, 6, 1);
	netkey = onmConvServerKey(svrkey);
	printf("ServerKey: H'%08x --> H'%08x\n", svrkey, netkey);

	appSlaveConfigLoad(&slavelist);
	appSlaveConfigPrint(&slavelist, TRUE);

	parseline("java -cp abcd cdee ddee tn.abcd.end");

	p = comGetHome();
	printf("p ... %s\n", p);

	printf("sizeof slave... %d\n", sizeof(slaveholder_t));

	kill_main();
	printf("sizeof(header) =%ld\n", sizeof(cpsheader_t));
	printf("PING_REQ_LEN   =%ld\n", PING_REQ_LEN);
	printf("INVOKE_REQ_LEN =%ld\n", INVOKE_REQ_LEN);
	printf("REPORT_REQ_LEN =%ld\n", REPORT_REQ_LEN);
	printf("EVENT_LEN      =%ld\n", EVENT_LEN);
	printf("LEAVE_REQ_LEN  =%ld\n", LEAVE_REQ_LEN);
	printf("PING_RES_LEN   =%ld\n", PING_RES_LEN);
	printf("INVOKE_RES_LEN =%ld\n", INVOKE_RES_LEN);
	printf("REPORT_RES_LEN =%ld\n", REPORT_RES_LEN);
	printf("LEAVE_RES_LEN  =%ld\n", LEAVE_RES_LEN);

	if (appInitialize(APP_SHM_KEY) == -1) {
		return -1;
	}
	appCodeMapPrint();

	comWelcome(argv[0]);
	comGoodbye(0);

	T = comTime();
	comLog(DG, "T:%d, S:%s", T, comTimeT2Str(S, sizeof(S), "%Y/%m/%d %H:%M:%S", T));

	T = comTimeStr2T(S, "%Y/%m/%d %H:%M:%S");
	comLog(DG, "T:%d, S:%s", T, comTimeT2Str(S, sizeof(S), "%Y/%m/%d %H:%M:%S", T));

	printf("sizeof lcsmsg_head_t....... %ld\n", sizeof(lcsmsg_head_t));
	printf("sizeof lcsmsg_bind_t....... %ld\n", sizeof(lcsmsg_bind_t));
	printf("sizeof lcsmsg_bind_ack_t... %ld\n", sizeof(lcsmsg_bind_ack_t));
	printf("sizeof lcsmsg_path_t....... %ld\n", sizeof(lcsmsg_path_t));
	printf("sizeof lcsmsg_path_ack_t... %ld\n", sizeof(lcsmsg_path_ack_t));
	printf("sizeof lcsmsg_close_t...... %ld\n", sizeof(lcsmsg_close_t));
	printf("sizeof lcsmsg_close_ack_t.. %ld\n", sizeof(lcsmsg_close_ack_t));
	printf("sizeof cpsudpmsg_t......... %ld\n", sizeof(cpsudpmsg_t));
#endif

	return 0;
}
