#include "libcom.h"
#include "libapp.h"
#include "librms.h"

#include <stdio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <linux/sockios.h>
#include <string.h>
#include <stdlib.h>

char *str = "HTTP/1.1 200 OK\r\n" \
			"Date: Sun, 18 Oct 2009 08:56:53 GMT\r\n" \
			"Server: Apache/2.2.14 (Win32)\r\n" \
			"Last-Modified: Sat, 20 Nov 2004 07:16:26 GMT\r\n" \
			"Accept-Ranges: bytes\r\n" \
			"Content-Length: 44\r\n" \
			"Connection: close\r\n" \
			"Content-Type: text/html\r\n" \
			"X-Pad: avoid browser bug\r\n" \
			"\r\n" \
			"<html><body><h1>It works!</h1></body></html>";

int main()
{
	httpconn_t  httpconn;
	httpresp_t *p_resp;

	json_t     *json = NULL;
	j_contact_t contact_list[10];
	int         i, count = 0;

	char test[1000];

	json_t *joinreq_json;

	j_joinreq_t joinreq;

	appLoadCode();

#if 0
	//rmsHttpInit(&httpconn, "114.202.2.14", 9090);
	//rmsHttpInit(&httpconn, "www.daum.net", 80);
	rmsHttpInit(&httpconn, "api.androidhive.info", 80);

	rmsHttpHeaderInit(&httpconn);
	rmsHttpHeaderPut_LU(&httpconn, HH_TN_IUID, 0);
	rmsHttpHeaderPut_S (&httpconn, HH_TN_AUTH_KEY, "");
	rmsHttpHeaderPut_S (&httpconn, HH_TN_APP_TYPE, "");

	while (1) {
		rmsHttpRequest(&httpconn, HM_GET, "/contacts/", NULL, 5);
		if ((p_resp = rmsHttpResponse(&httpconn, 5)) != NULL && p_resp != NULL) {
			if ((json = rmsHttpText2Json(p_resp->content)) != NULL) {
				count = rmsJsonUnpack_contact_array(json_object_get(json, "contacts"), contact_list, 10);
				//free
			}
		}
		comLog(DG, "count........ %d", count);
		for (i = 0; i < count; i++) {
			comLog(DG, "contacts... %s, %s, %s",
					contact_list[i].id, 
					contact_list[i].name, 
					contact_list[i].phone.mobile);
		}
		/* don't forget!! */
		if (json != NULL) rmsHttpFreeJson(&json);


		//
		json = rmsJsonPack_contact_array(contact_list, count);
		if (rmsHttpJson2Text(json, test, sizeof(test)) != NULL) {
			comLog(DG, "test.... %s", test);
		}
		else {
			comLog(DG, "test.... null");
		}
		/* don't forget!! */
		if (json != NULL) rmsHttpFreeJson(&json);

		sleep(1);

		break;
	}
#endif

	if (rmsGetISO8601(test, 100) == NULL) {
		comLog(DG, "datetime..... NULL");
	}
	else {
		comLog(DG, "datetime..... %s", test);
	}

	rmsGetUUID(test, 100);
	printf("uuid.......|%s|\n", test);

	//
	memset(&joinreq, 0x00, sizeof(j_joinreq_t));
	rmsGetISO8601(joinreq.datetime, sizeof(joinreq.datetime));
	rmsGetUUID   (joinreq.mesg_id , sizeof(joinreq.mesg_id));
	snprintf(joinreq.ctype, sizeof(joinreq.ctype), "%s", CTYPE_CHANNEL_JOIN);

	joinreq.from.iuid = 999;
	snprintf(joinreq.from.mdn , sizeof(joinreq.from.mdn ), "+821011112222");
	snprintf(joinreq.from.name, sizeof(joinreq.from.name), "kodeholic.9");

	joinreq.sid = 88;
	snprintf(joinreq.telecom_code, sizeof(joinreq.telecom_code), "45008");
	snprintf(joinreq.password    , sizeof(joinreq.password    ), "8899");
	snprintf(joinreq.timestamp   , sizeof(joinreq.timestamp   ), "20160729210000");
	snprintf(joinreq.src_ip      , sizeof(joinreq.src_ip      ), "114.202.2.14");
	joinreq.src_port =7788;
	joinreq.src_tbcp_port =7789;
	snprintf(joinreq.codec      , sizeof(joinreq.codec  ), "opus-wb");
	snprintf(joinreq.roaming    , sizeof(joinreq.roaming), "N");

	if ((joinreq_json = rmsJsonPack_joinreq(&joinreq)) != NULL) {
		rmsHttpJson2Text(joinreq_json, test, sizeof(test));
		printf("json.... %s\n", test);
	}


#if 0
		if ((p_resp = rmsHttpResponse(&httpconn, 5) != NULL)
				&& p_resp->content != NULL
				&& (json = rmsHttpText2Json(p_resp->content)) != NULL)
		{
		}
#endif


#if 0
	sockbuffer_t *p_buffer = &httpconn.ns.recvbuff;

	rmsHttpConnInit(&httpconn);
	sprintf(p_buffer->data, "%s", str);
	p_buffer->pos   = 0;
	p_buffer->limit = strlen(str);

	rmsHttpParseResponse(&httpconn);

	printf("code: %d, clen: %d, content: %s\n",
			httpconn.response.code,
			httpconn.response.clen,
			httpconn.response.content);
#endif

	return 0;
}
