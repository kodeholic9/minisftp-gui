#include "libcom.h"
#include "libapp.h"
#include "libcps.h"
#include "libonm.h"

int main(int argc, char **argv)
{
	sysbundle_t sysbundle;

	onmCollectInit(&sysbundle);
	while (TRUE) {
		onmCollectSysBundle(&sysbundle);
		onmCollectPrint(&sysbundle);

		sleep(1);
	}

	return 0;
}
