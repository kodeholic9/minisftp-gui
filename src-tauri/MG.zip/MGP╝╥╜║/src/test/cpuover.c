#include "libcom.h"
#include "libapp.h"
#include "libcps.h"
#include "libonm.h"

int main(int argc, char **argv)
{
	int i = 0;
	while (1) {
		i = i * 19 / 892872 * 38828 * 99292 / 29282;
	}

	return 0;
}


