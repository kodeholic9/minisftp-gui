#include "libcom.h"
#include "libapp.h"
#include "libpath.h"

#define TCP_PORT_1 19999

typedef struct _magic {
	int    maxfd;
	fd_set rset;
} magic_t;

magic_t Magic;
uemsg_t UeMesg, UeRaw;

int wait_for(fd_set *rset, int usec)
{
	struct timeval timeo;

	/* CHECK INPUT EVENT */
	timeo.tv_sec  =  usec / 1000;
	timeo.tv_usec = (usec % 1000) * 1000;
	memcpy(rset, &Magic.rset, sizeof(fd_set));

	return select(Magic.maxfd, rset, NULL, NULL, &timeo);
}

int server()
{
	int    n, lsnrfd = 0;
	fd_set rset;
	nonbsock_t nonbsock;

	char data[1024], raw[1024];

	printf("server started............\n");
	
	if ((lsnrfd = comOpenServerSocket(NULL, TCP_PORT_1, MAX_SOCKET_BUFFER_SZ, 1)) == -1) {
		perror("comOpenServerSocket failed");
		return -1;
	}
	comSetSelectMask(&Magic.maxfd, &Magic.rset, lsnrfd);

	while (wait_for(&rset, 10) == 0) {
		;
	}
	if (lsnrfd > 0 && FD_ISSET(lsnrfd, &rset)) {
		appNonbsockInit(&nonbsock, "", &Magic.maxfd, &Magic.rset, NULL);
		if (appNonbsockAccept(lsnrfd, &nonbsock) == -1) {
			perror("appNonbsockAccept failed");
			return -1;
		}
	}
	comUnsetSelectMask(&Magic.maxfd, &Magic.rset, lsnrfd);

	while (TRUE) {
		if (wait_for(&rset, 10) == 0) {
			continue;
		}

		memset(data, 0x00, 1024);
		memset(raw , 0x00, 1024);

		if ((n = appNonbsockRecv(&nonbsock, data, raw, 10)) == -1) {
			perror("appNonbsocRecv failed");
			break;
		}
		if (n > 0) {
			printf("READ[%d][%s][%s]\n", n, data, raw);

			if ((n = appNonbsockSend(&nonbsock, data, n)) == -1) {
				perror("appNonbsocRecv failed");
				break;
			}
			printf("SEND[%d][%s]\n", n, data);
		}
	}

	appNonbsockClose(&nonbsock);

	return 0;
}

int main(int argc, char **argv)
{
	return server();
}




