#include "libcom.h"

int main(void)
{
	comInstallSignal(SIGTERM, comIgnoreFunc);

	while (1) pause();
}

