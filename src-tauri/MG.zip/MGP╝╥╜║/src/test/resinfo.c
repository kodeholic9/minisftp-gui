#include "libcom.h"
#include "libapp.h"
#include "libcps.h"
#include "libonm.h"

int main(int argc, char **argv)
{
	resconfig_t resconf;

	//memset(&resconf, 0x00, sizeof(resconfig_t));

	appResInfoLoad(&resconf);
	appResInfoPrint(&resconf);

	return 0;
}


