
#include "libcom.h"
#include "sec/aes.h"
#include "sec/md5.h"

int aes_cbc_128_enc(unsigned char *sum, unsigned char *iv, unsigned char *in, unsigned char *out, int len)
{
	aes_context   ctx;
	unsigned char tmpiv[16];

	memcpy(tmpiv, iv, 16);
	aes_setkey_enc(&ctx, sum, 128);
	aes_crypt_cbc (&ctx, AES_ENCRYPT, len, tmpiv, in, out);

	return 0;
}

int aes_cbc_128_dec(unsigned char *sum, unsigned char *iv, unsigned char *in, unsigned char *out, int len)
{
	aes_context   ctx;
	unsigned char tmpiv[16];

	memcpy(tmpiv, iv, 16);
	aes_setkey_dec(&ctx, sum, 128);
	aes_crypt_cbc (&ctx, AES_DECRYPT, len, tmpiv, in, out);

	return 0;
}

int main(void)
{
	char s[32];
	unsigned char sum[16];
	unsigned char iv [16];
	unsigned char b1[128];
	unsigned char b2[128];
	unsigned char b3[128];

	printf("Hello AES\n");
	memset(sum, 0x00, sizeof(sum));
	memset(b1 , 0x00, sizeof(b1));
	memset(b2 , 0x00, sizeof(b2));
	memset(b3 , 0x00, sizeof(b3));
	memset(iv , 0x00, sizeof(iv));

	sprintf(s, "tisquare");
	md5((unsigned char *)s, strlen(s), sum);
	comDumpRaw(DG, sum, 16);

	sprintf(s, "cnt");
	md5((unsigned char *)s, strlen(s), iv);
	comDumpRaw(DG, iv, 16);

	sprintf((char *)b1, "123456789012345612345678901234561234567890123456");
	aes_cbc_128_enc(sum, iv, b1, b2, 48);
	aes_cbc_128_dec(sum, iv, b2, b3, 48);
#if 0
	aes_ecb_128_enc(sum, iv, b1, b2, 32);
	aes_ecb_128_dec(sum, iv, b2, b3, 32);
#endif

	comDumpRaw(DG, b1, 64);
	comDumpRaw(DG, b2, 64);
	comDumpRaw(DG, b3, 64);
	comDumpRaw(DG, sum, 16);

	return 0;
}


