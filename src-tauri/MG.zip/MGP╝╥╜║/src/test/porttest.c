#include "libmrs.h"

portrange_t   PortRange;
portrange_t *pPortRange = &PortRange;

int main(void)
{
	int i, fd, port;

	mrsCntlPortRangeInit(pPortRange, 20001, 21000);

	for (i = 0; i < 100000; i++) {
		if ((fd = mrsCntlStartPort(pPortRange, &port)) > 0) {
			;//mrsCntlStopPort(pPortRange, port, fd);
		}
		else {
			break;
		}
	}

	return 0;
}

