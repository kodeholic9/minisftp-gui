#include "libcom.h"
#include "libapp.h"
#include "librms.h"

#include <stdio.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <linux/sockios.h>
#include <string.h>
#include <stdlib.h>

void test4()
{
	json_t *json;
	char    text[8192];
	j_board_t board;

	board.process_count = appOmaGetJSProcInfo(board.process_list, MAX_SLAVE_PROC_NUM);
	appOmaGetJSConfigInfo(&board.config);

	snprintf(board.modem.imei   , sizeof(board.modem.imei), "354828072020569");
	snprintf(board.modem.cnum   , sizeof(board.modem.cnum), "01072020569");
	snprintf(board.modem.nsi    , sizeof(board.modem.nsi ), "4,IN SRV,olleh,Home,LTE");
	snprintf(board.modem.cgdcont, sizeof(board.modem.cgdcont), "privatelte.ktfwing.com");
	snprintf(board.modem.cgpaddr, sizeof(board.modem.cgpaddr), "10.146.6.61");
	board.modem.csq = -53;

#ifdef _DSTECH
	memset(p_modem, 0x00, sizeof(j_modem_t));
	modem_get_imei(p_modem->imei, sizeof(p_modem->imei));
	modem_get_cnum(p_modem->cnum, sizeof(p_modem->cnum));
	modem_get_nsi (p_modem->nsi , sizeof(p_modem->nsi ));
	modem_get_cgdcont (p_modem->cgdcont, sizeof(p_modem->cgdcont));
	modem_get_cgpaddr (p_modem->cgpaddr, sizeof(p_modem->cgpaddr));
	modem_get_csq(&p_modem->csq);
#endif


	if ((json = rmsJsonPack_board(&board)) != NULL) {
		rmsHttpJson2Text(json, text, sizeof(text));
		printf("\n%s", text);
	}
	printf("\n");

	return;
}

void test5()
{
	json_t *json;
	char    text[8192];
	j_statinfo_t statinfo;

	appOmaGetJSStatInfo(&statinfo);

	if ((json = rmsJsonPack_statinfo(&statinfo)) != NULL) {
		rmsHttpJson2Text(json, text, sizeof(text));
		printf("\n%s", text);
	}
	printf("\n");

	return;
}

int main()
{
	httpconn_t httpconn;

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		printf("can't initialize APP\n");
		return -1;
	}
	comLogLevelSet(VB);

#if 0
	rmsHttpInit(&httpconn, pProfile->RMSHttpHost, pProfile->RMSHttpPort);

	rmsHttpHeaderInit(&httpconn);
	rmsHttpHeaderPut_LU(&httpconn, HH_TN_IUID, pProfile->IUID);
	rmsHttpHeaderPut_S (&httpconn, HH_TN_AUTH_KEY, pProfile->AuthKey);
	rmsHttpHeaderPut_S (&httpconn, HH_TN_APP_TYPE, pProfile->AppType);

	if (rmsHttpRequest(&httpconn, HM_GET, "/contacts/", NULL, 5) != -1) {
		rmsHttpResponse(&httpconn, 5);
	}
#endif

#if 0
	appIpcSendMsg(MGPP, 1, "hello", 5);
#endif

	test4();
	test5();

	return 0;
}
