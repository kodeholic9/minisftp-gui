/**
 * @date   2012/07/20
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */
#include "liboma.h"

unsigned long _block2k(int size, int blocksize)
{
	unsigned long size64 = ((unsigned long)size & 0xffffffff);
	int           bshift;

	for (bshift = 0; blocksize > 1; blocksize >>= 1) {
		bshift += 1;
	}
	bshift -= U_LOG1024;

	return (bshift > 0) ? ((size64) << bshift) : ((size64) >> (-1*bshift));
}

long _calcpc(int *_new, int *_old, int *out, int *diff, int count)
{
	int   i, *lp;
	long  change, total_change;
	long  half_total;

	/* initialization */
	total_change = 0;
	lp = diff;

	/* calculate changes for each state and the overall change */
	for (i = 0; i < count; i++) {
		if ((change = *_new - *_old) < 0) {
			change  = 0xffffffff - *_old;
			change += *_new;
		}
		total_change += (*lp++ = change);

		/* backup the value */
		*_old++ = *_new++;
	}

	/* to avoid divide by zero */
	total_change = (!total_change) ? 1 : total_change;

	/* calculate percentages based on overall change, rounding up */
	half_total = total_change / 2l;
	for (i = 0; i < count; i++) {
		*out = (int)((*diff * 1000 + half_total) / total_change);
		out ++;
		diff++;
	}

	/* return the total in case the caller wants to use it */
	return(total_change);
}

double _calcav(int *_new, int *_old, int *diff, double elapsed)
{
	if (*_new < *_old) {
		*diff  =  0xffffffff - *_old;
		*diff += *_new;
	}
	else
		*diff = *_new - *_old;

	/* backup the value */
	*_old = *_new;

	return (double)(*diff / elapsed);
}

void omaCollectTimeInfo(timeinfo_t *p_timeinfo)
{
	double curr = comTimeGetU();

	p_timeinfo->delta = curr - p_timeinfo->prev;
	p_timeinfo->prev  = curr;

	return;
}

int omaCollectCpuInfo(sysbundle_t *p_sysbundle)
{
	FILE *fp;
	char  line[1024];
	unsigned long tmp[4];
	int   diff[NUMOF_CPUSTAT];
	int   ticks[NUMOF_CPUSTAT];
	int   found = FALSE;

	/* collect TimeInfo */
	omaCollectTimeInfo(&p_sysbundle->ticpu);

	/* collect CpuInfo */
	if ((fp = fopen("/proc/stat", "r")) == NULL) {
		comErr(ER, errno, "%s() fail to fopen(/proc/stat)", __func__);
		return -1;
	}
	while (fgets(line, sizeof(line), fp) != NULL) {
		if (strncmp(line, "cpu ", 4) == 0) {
			sscanf(line, "%*s %lu %lu %lu %lu %*s\n",
					tmp + 0, tmp + 1, tmp + 2, tmp + 3
			);
			p_sysbundle->cpuinfo.curr[V_CPUSTAT_USR] = (unsigned int)(tmp[0] & 0xffffffff); /* user   */
			p_sysbundle->cpuinfo.curr[V_CPUSTAT_ETC] = (unsigned int)(tmp[1] & 0xffffffff); /* nice   */
			p_sysbundle->cpuinfo.curr[V_CPUSTAT_SYS] = (unsigned int)(tmp[2] & 0xffffffff); /* system */
			p_sysbundle->cpuinfo.curr[V_CPUSTAT_IDLE]= (unsigned int)(tmp[3] & 0xffffffff); /* idle   */

			/* update the Fount */
			found = TRUE;
			break;
		}
	}
	fclose(fp);

	/* Found...? */
	if (!found) {
		comLog(WA, "%s() There is no such token(cpu)", __func__);
		return -1;
	}

	/* calculate the usage(%%) */
	_calcpc(p_sysbundle->cpuinfo.curr, p_sysbundle->cpuinfo.prev, ticks, diff, NUMOF_CPUSTAT);
	p_sysbundle->cpuinfo.usr  = (double)ticks[V_CPUSTAT_USR]  / 10.0;
	p_sysbundle->cpuinfo.sys  = (double)ticks[V_CPUSTAT_SYS]  / 10.0;
	p_sysbundle->cpuinfo.etc  = (double)ticks[V_CPUSTAT_ETC]  / 10.0;
	p_sysbundle->cpuinfo.idle = (double)ticks[V_CPUSTAT_IDLE] / 10.0;

	return 0;
}

int omaCollectMemInfo(sysbundle_t *p_sysbundle)
{
	FILE *fp;
	char *p, line[1024];

	/* collect TimeInfo */
	omaCollectTimeInfo(&p_sysbundle->timem);

	/* collect MemInfo */
	if ((fp = fopen("/proc/meminfo", "r")) == NULL) {
		comErr(ER, errno, "%s() fail to fopen(/proc/meminfo)", __func__);
		return -1;
	}
	while (fgets(line, sizeof(line), fp) != NULL) {
		if (strncmp(line, "MemTotal:", 9) == 0 && (p = comSkipToken(line)) != NULL) {
			p_sysbundle->meminfo.total = strtoul(p, &p, 0);
		}
		else if (strncmp(line, "MemFree:", 8) == 0 && (p = comSkipToken(line)) != NULL) {
			p_sysbundle->meminfo.freed = strtoul(p, &p, 0);
		}
		else if (strncmp(line, "Buffers:", 8) == 0 && (p = comSkipToken(line)) != NULL) {
			p_sysbundle->meminfo.buffers = strtoul(p, &p, 0);
		}
		else if (strncmp(line, "Cached:", 7) == 0 && (p = comSkipToken(line)) != NULL) {
			p_sysbundle->meminfo.cached = strtoul(p, &p, 0);
		}
	}
	fclose(fp);

	/* calculate the usage(%%) */
	if (p_sysbundle->meminfo.total > 0) {
		unsigned long         used = p_sysbundle->meminfo.total - p_sysbundle->meminfo.freed;
		p_sysbundle->meminfo.usage = (used / (double)p_sysbundle->meminfo.total) * 100.0;
	}

	return 0;
}

static int _lookupFsInfo(sysbundle_t *p_sysbundle, char *name)
{
	fsyinfo_t *p_fsyinfo;
	int       i;

	/* lookup the netinfo */
	for (i = 0; i < p_sysbundle->fsynum; i++) {
		p_fsyinfo = p_sysbundle->fsyinfo + i;
		if (strcmp(p_fsyinfo->name, name) == 0) {
			return i;
		}
	}

	return -1;
}

int omaCollectFsInfo(sysbundle_t *p_sysbundle)
{
	FILE  *fp;
	struct mntent *p_mntent;
	struct statfs vfs;
	fsyinfo_t *p_fsyinfo;
	long      total, used;

	int index;

	/* collect TimeInfo */
	omaCollectTimeInfo(&p_sysbundle->tifsy);

	/* collect FsInfo */
	if ((fp = setmntent(MOUNTED, "r")) == NULL) {
		comErr(ER, errno ,"%s() fail to setmntent (%s).", __func__, MOUNTED);
		return -1;
	}
	while ((p_mntent = getmntent(fp)) != NULL) {
		if (p_mntent->mnt_fsname[0] != '/' || strcmp(p_mntent->mnt_dir, "/proc") == 0) {
			continue;
		}

		/* derive each file system */
		if (statfs(p_mntent->mnt_dir, &vfs) == -1) {
			comErr(ER, errno, "%s() fail to statfs() for %s.", __func__, p_mntent->mnt_dir);
			continue;
		}

		/* lookup the FS */
		if ((index = _lookupFsInfo(p_sysbundle, p_mntent->mnt_dir)) == -1) {
			if ((index = p_sysbundle->fsynum) >= MAX_FSYINFO_NUM) {
				comLog(WA, "%s() FsyInfo is Overflowed.", __func__);
				break;
			}
			p_sysbundle->fsynum += 1;
		}
		p_fsyinfo = p_sysbundle->fsyinfo + index;

		/* calculate */
		snprintf(p_fsyinfo->name, sizeof(p_fsyinfo->name), "%s", p_mntent->mnt_dir);
		p_fsyinfo->total = _block2k(vfs.f_blocks, vfs.f_bsize);
		p_fsyinfo->freed = _block2k(vfs.f_bfree , vfs.f_bsize);
		p_fsyinfo->avail = _block2k(vfs.f_bavail, vfs.f_bsize);

		/* calculate the usage (%%) */
		used  = p_fsyinfo->total - p_fsyinfo->freed;
		total = p_fsyinfo->avail + used;
		if (total > 0) {
			p_fsyinfo->usage = (used / (double)total) * 100.0;
		}
		else {
			p_fsyinfo->usage = 0;
		}
	}
	endmntent(fp);

	return 0;
}

static int _lookupNetInfo(sysbundle_t *p_sysbundle, char *name)
{
	netinfo_t *p_netinfo;
	int        i;

	/* lookup the netinfo */
	for (i = 0; i < p_sysbundle->netnum; i++) {
		p_netinfo = p_sysbundle->netinfo + i;
		if (strcmp(p_netinfo->name, name) == 0) {
			return i;
		}
	}

	return -1;
}

int omaCollectNetInfo(sysbundle_t *p_sysbundle)
{
	FILE *fp;
	char *p, line[1024], name[32];
	unsigned long val[7];
	int   index;

	netinfo_t *p_netinfo;

	/* collect TimeInfo */
	omaCollectTimeInfo(&p_sysbundle->tinet);

	/* collect NetInfo */
	if ((fp = fopen("/proc/net/dev", "r")) == NULL) {
		comErr(ER, errno, "%s() fail to fopen(/proc/net/dev)", __func__);
		return -1;
	}
	while (fgets(line, sizeof(line), fp) != NULL) {
		if ((p = strstr(line, ":")) == NULL) {
			continue;
		}

		/* setup the netinfo */
		sscanf(line, "%[^:]:%lu %lu %lu %*s %*s %*s %*s %*s %lu %lu %lu %*s %*s %lu %*s %*s",
				name,
				val + 0, // &p_netinfo->iocts,
				val + 1, // &p_netinfo->ipkts,
				val + 2, // &p_netinfo->ierrs,
				val + 3, // &p_netinfo->oocts,
				val + 4, // &p_netinfo->opkts,
				val + 5, // &p_netinfo->oerrs,
				val + 6  // &p_netinfo->collisions
		);
		comTrim(name);
		if ((index = _lookupNetInfo(p_sysbundle, name)) == -1) {
			if ((index = p_sysbundle->netnum) >= MAX_NETINFO_NUM) {
				comLog(WA, "%s() NetInfo is Overflowed.", __func__);
				break;
			}
			p_sysbundle->netnum += 1;
		}
		p_netinfo = p_sysbundle->netinfo + index;

		/* setup each values */
		snprintf(p_netinfo->name, sizeof(p_netinfo->name), "%s", name);
		p_netinfo->curr.iocts      = val[0] & 0xffffffff;
		p_netinfo->curr.ipkts      = val[1] & 0xffffffff;
		p_netinfo->curr.ierrs      = val[2] & 0xffffffff;
		p_netinfo->curr.oocts      = val[3] & 0xffffffff;
		p_netinfo->curr.opkts      = val[4] & 0xffffffff;
		p_netinfo->curr.oerrs      = val[5] & 0xffffffff;
		p_netinfo->curr.collisions = val[6] & 0xffffffff;

		/* calculate.... */
		_calcav(&p_netinfo->curr.iocts, &p_netinfo->prev.iocts, &p_netinfo->delta.iocts, p_sysbundle->tinet.delta);
		_calcav(&p_netinfo->curr.ipkts, &p_netinfo->prev.ipkts, &p_netinfo->delta.ipkts, p_sysbundle->tinet.delta);
		_calcav(&p_netinfo->curr.ierrs, &p_netinfo->prev.ierrs, &p_netinfo->delta.ierrs, p_sysbundle->tinet.delta);
		_calcav(&p_netinfo->curr.oocts, &p_netinfo->prev.oocts, &p_netinfo->delta.oocts, p_sysbundle->tinet.delta);
		_calcav(&p_netinfo->curr.opkts, &p_netinfo->prev.opkts, &p_netinfo->delta.opkts, p_sysbundle->tinet.delta);
		_calcav(&p_netinfo->curr.oerrs, &p_netinfo->prev.oerrs, &p_netinfo->delta.oerrs, p_sysbundle->tinet.delta);
	}
	fclose(fp);

	return 0;
}

static int _lookupOdbInfo(sysbundle_t *p_sysbundle, char *name)
{
	odbinfo_t *p_odbinfo;
	int        i;

	/* lookup the netinfo */
	for (i = 0; i < p_sysbundle->odbnum; i++) {
		p_odbinfo = p_sysbundle->odbinfo + i;
		if (strcmp(p_odbinfo->name, name) == 0) {
			return i;
		}
	}

	return -1;
}

int omaCollectOdbInfo(sysbundle_t *p_sysbundle, char *cmdline)
{
	FILE *pipefp;
	char *p, line[1024], name[32];
	unsigned long val[4];
	int   index;

	odbinfo_t *p_odbinfo;

	if ((pipefp = popen(cmdline, "r")) == NULL) {
		comLog(ER, "%s() fail to execute [%s]", __func__, cmdline);
		return -1;
	}
	while (fgets(line, sizeof(line), pipefp) != NULL) {
		comTrim(line);
		if ((p = strstr(line, "ORA_STATUS")) != NULL) {
			p_sysbundle->livedown.odbflag = (strstr(line, "LIVE") != NULL) ? TRUE : FALSE;
		}
		else if ((p = strstr(line, "ORA_LSNR_STATUS")) != NULL) {
			p_sysbundle->livedown.odblsnrflag = (strstr(line, "LIVE") != NULL) ? TRUE : FALSE;
		}
		else if ((p = strstr(line, "TSINFO")) != NULL) {
			sscanf(line, "%*s %s %lu %lu %lu",
					name, 
					val + 0,
					val + 1,
					val + 2
			);
			if ((index = _lookupOdbInfo(p_sysbundle, name)) == -1) {
				if ((index = p_sysbundle->odbnum) >= MAX_ODBINFO_NUM) {
					comLog(WA, "%s() OdbInfo is Overflowed.", __func__);
					break;
				}
				p_sysbundle->odbnum += 1;
			}
			p_odbinfo = p_sysbundle->odbinfo + index;

			/* setup each values */
			snprintf(p_odbinfo->name, sizeof(p_odbinfo->name), "%s", name);
			p_odbinfo->total = val[0];
			p_odbinfo->used  = val[1];
			p_odbinfo->freed = val[2];

			/* calculate the usage (%%) */
			if (p_odbinfo->total > 0) {
				p_odbinfo->usage = (p_odbinfo->used / (double)p_odbinfo->total) * 100.0;
			}
			else {
				p_odbinfo->usage = 0;
			}
		}
	}
	pclose(pipefp);

	return 0;
}

int omaCollectTdbInfo(sysbundle_t *p_sysbundle, char *cmdline)
{
	FILE *pipefp;
	char *p, line[1024];

	tdbinfo_t *p_tdbinfo = &p_sysbundle->tdbinfo;

	if ((pipefp = popen(cmdline, "r")) == NULL) {
		comLog(ER, "%s() fail to execute [%s]", __func__, cmdline);
		return -1;
	}
	while (fgets(line, sizeof(line), pipefp) != NULL) {
		comTrim(line);
		if ((p = strstr(line, "TT_STATUS")) != NULL) {
			p_sysbundle->livedown.tdbflag = (strstr(line, "LIVE") != NULL) ? TRUE : FALSE;
		}
		else if ((p = strstr(line, "TT_LREP_STATUS")) != NULL) {
			p_sysbundle->livedown.tdblrepflag = (strstr(line, "LIVE") != NULL) ? TRUE : FALSE;
		}
		else if ((p = strstr(line, "TT_PREP_STATUS")) != NULL) {
			p_sysbundle->livedown.tdbprepflag = (strstr(line, "LIVE") != NULL) ? TRUE : FALSE;
		}
		else if ((p = strstr(line, "TT_BOOKMARK")) != NULL) {
			sscanf(line, "%*[^=]=%ld", &p_tdbinfo->bookmark);
		}
		else if ((p = strstr(line, "TT_PERMSIZE")) != NULL) {
			sscanf(line, "%*[^=]=%ld", &p_tdbinfo->perm_size);
		}
		else if ((p = strstr(line, "TT_PERMUSED")) != NULL) {
			sscanf(line, "%*[^=]=%ld", &p_tdbinfo->perm_used);
		}
		else if ((p = strstr(line, "TT_TEMPSIZE")) != NULL) {
			sscanf(line, "%*[^=]=%ld", &p_tdbinfo->temp_size);
		}
		else if ((p = strstr(line, "TT_TEMPUSED")) != NULL) {
			sscanf(line, "%*[^=]=%ld", &p_tdbinfo->temp_used);
		}
	}
	pclose(pipefp);

	/* calculate the usage (%%) */
	if (p_tdbinfo->perm_size > 0) {
		p_tdbinfo->perm_usage = (p_tdbinfo->perm_used / (double)p_tdbinfo->perm_size) * 100.0;
	}
	else {
		p_tdbinfo->perm_usage = 0;
	}
	if (p_tdbinfo->temp_size > 0) {
		p_tdbinfo->temp_usage = (p_tdbinfo->temp_used / (double)p_tdbinfo->temp_size) * 100.0;
	}
	else {
		p_tdbinfo->temp_usage = 0;
	}

	return 0;
}

int omaCollectYdbInfo(sysbundle_t *p_sysbundle, char *cmdline)
{
	FILE *pipefp;
	char *p, line[1024];

	if ((pipefp = popen(cmdline, "r")) == NULL) {
		comLog(ER, "%s() fail to execute [%s]", __func__, cmdline);
		return -1;
	}
	while (fgets(line, sizeof(line), pipefp) != NULL) {
		comTrim(line);
		if ((p = strstr(line, "MY_STATUS")) != NULL) {
			p_sysbundle->livedown.ydbflag = (strstr(line, "LIVE") != NULL) ? TRUE : FALSE;
		}
	}
	pclose(pipefp);

	return 0;
}


int omaCollectInit(sysbundle_t *p_sysbundle)
{
	memset(p_sysbundle, 0x00, sizeof(sysbundle_t));
	return 0;
}

int omaCollectSysBundle(sysbundle_t *p_sysbundle)
{
	omaCollectCpuInfo(p_sysbundle);
	omaCollectMemInfo(p_sysbundle);
	omaCollectFsInfo (p_sysbundle);
	omaCollectNetInfo(p_sysbundle);

	return 0;
}

int omaCollectPrint(sysbundle_t *p_sysbundle)
{
	int i;

	printf("====================================================\n");
	printf("----------------------------------------------------\n");

	/* CPU */
	printf("[CPU#  ] USR(%5.2f) SYS(%5.2f) ETC(%5.2f) IDLE(%5.2f)\n",
			p_sysbundle->cpuinfo.usr,
			p_sysbundle->cpuinfo.sys,
			p_sysbundle->cpuinfo.etc,
			p_sysbundle->cpuinfo.idle
	);

	/* MEMORY */
	printf("[MEM#  ] TOTAL(%lu) FREE(%lu) BUFFERS(%lu) CACHED(%lu) USAGE(%5.2f)\n",
			p_sysbundle->meminfo.total,
			p_sysbundle->meminfo.freed,
			p_sysbundle->meminfo.buffers,
			p_sysbundle->meminfo.cached,
			p_sysbundle->meminfo.usage
	);

	/* FILE SYSTEM */
	printf("----------------------------------------------------\n");
	for (i = 0; i < p_sysbundle->fsynum; i++) {
		printf("[FS #%02d] %-12s TOTAL(%10ld) FREE(%10ld) AVAIL(%10ld) USAGE(%5.2f)\n", 
				i,
				p_sysbundle->fsyinfo[i].name,
				p_sysbundle->fsyinfo[i].total,
				p_sysbundle->fsyinfo[i].freed,
				p_sysbundle->fsyinfo[i].avail,
				p_sysbundle->fsyinfo[i].usage
		);
	}

	/* NETWORK */
	printf("----------------------------------------------------\n");
	for (i = 0; i < p_sysbundle->netnum; i++) {
		printf("[NET#%02d] %-12s OCTS(%10.2f:%10.2f) PKTS(%7.2f:%7.2f) ERRS(%5.2f:%5.2f)\n",
				i,
				p_sysbundle->netinfo[i].name,
				p_sysbundle->netinfo[i].delta.iocts / p_sysbundle->tinet.delta,
				p_sysbundle->netinfo[i].delta.oocts / p_sysbundle->tinet.delta,
				p_sysbundle->netinfo[i].delta.ipkts / p_sysbundle->tinet.delta,
				p_sysbundle->netinfo[i].delta.opkts / p_sysbundle->tinet.delta,
				p_sysbundle->netinfo[i].delta.ierrs / p_sysbundle->tinet.delta,
				p_sysbundle->netinfo[i].delta.oerrs / p_sysbundle->tinet.delta
		);
	}

	/* ODBMS */
	printf("----------------------------------------------------\n");
	printf("[ODB#  ] ORA(%s) LSNR(%s)\n",
			p_sysbundle->livedown.odbflag     ? "LIVE" : "DOWN",
			p_sysbundle->livedown.odblsnrflag ? "LIVE" : "DOWN");
	for (i = 0; i < p_sysbundle->odbnum; i++) {
		printf("[ODB#%02d] %-12s TOTAL(%lu) USED(%lu) USAGE(%5.2f)\n",
				i,
				p_sysbundle->odbinfo[i].name,
				p_sysbundle->odbinfo[i].total,
				p_sysbundle->odbinfo[i].used,
				p_sysbundle->odbinfo[i].usage
		);
	}

	/* TDBMS */
	printf("----------------------------------------------------\n");
	printf("[TDB#  ] ST(%s) LREP(%s) PREP(%s)\n",
			p_sysbundle->livedown.tdbflag     ? "LIVE" : "DOWN",
			p_sysbundle->livedown.tdblrepflag ? "LIVE" : "DOWN",
			p_sysbundle->livedown.tdbprepflag ? "LIVE" : "DOWN");
	printf("[TDB#  ] PERMSIZE(%lu:%lu:%5.2f) TEMPSIZE(%lu:%lu:%5.2f) BOOKMARK(%ld)\n",
			p_sysbundle->tdbinfo.perm_size,
			p_sysbundle->tdbinfo.perm_used,
			p_sysbundle->tdbinfo.perm_usage,
			p_sysbundle->tdbinfo.temp_size,
			p_sysbundle->tdbinfo.temp_used,
			p_sysbundle->tdbinfo.temp_usage,
			p_sysbundle->tdbinfo.bookmark
	);

	/* YDBMS */
	printf("----------------------------------------------------\n");
	printf("[YDB#  ] ST(%s)\n", p_sysbundle->livedown.ydbflag ? "LIVE" : "DOWN");

	printf("\n");

	return 0;
}


