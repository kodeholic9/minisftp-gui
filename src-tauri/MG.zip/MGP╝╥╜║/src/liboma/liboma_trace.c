/**
 * @date   2012/08/16
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "liboma.h"

/** ----------------------------------------------------- */
int omaTracePutTarget(traceargs_t *p_traceargs, long target)
{
	if (p_traceargs->n >= (MAX_TRACEARGS_NUM - 1)) {
		comLog(WA, "%s() TARGET SLOT IS FULL!", __func__);
		return -1;
	}
	p_traceargs->target[p_traceargs->n] = target;
	p_traceargs->n += 1;

	return 0;
}

int omaTraceStart(tracelist_t *p_tracelist, omtraceon_t *p_traceon)
{
	int  i;
	long trace_id = comProtoI642Long(&p_traceon->trace_id);
	long iuid     = comProtoI642Long(&p_traceon->iuid);

	for (i = 0; i < MAX_TRACEINFO_NUM; i++) {
		if (!p_tracelist->traceinfo[i].occupied) {
			/* trace info */
			p_tracelist->traceinfo[i].detailed = p_traceon->detailed;
			p_tracelist->traceinfo[i].trace_id = trace_id;
			p_tracelist->traceinfo[i].strttime = comTime();
			p_tracelist->traceinfo[i].stoptime = p_tracelist->traceinfo[i].strttime + p_traceon->period;
			p_tracelist->traceinfo[i].occupied = OCCUPIED;

			/* condition */
			p_tracelist->traceinfo[i].iuid = iuid;
			snprintf(p_tracelist->traceinfo[i].mdn  , MAX_ADDRESS_LEN, "%s", p_traceon->mdn);
			snprintf(p_tracelist->traceinfo[i].block, MAX_TRBLOCK_LEN, "%s", p_traceon->block);

			/* update the used */
			p_tracelist->used += 1;

			comLog(TR, "START TRACE - TID(%lu) DETAIL(%s) PERIOD(%d) IUID(%lu) MDN(%s)",
					trace_id,
					p_traceon->detailed ? "true" : "false",
					p_traceon->period,
					iuid, 
					p_traceon->mdn
			);

			return 0;
		}
	}
	comLog(WA, "FAIL TO START TRACE(%lu) - OVERFLOWED", p_traceon->trace_id);

	return -1;
}

int omaTraceStop(tracelist_t *p_tracelist, long trace_id)
{
	int i;

	for (i = 0; i < MAX_TRACEINFO_NUM; i++) {
		if (p_tracelist->traceinfo[i].occupied) {
			if (p_tracelist->traceinfo[i].trace_id == trace_id) {
				p_tracelist->traceinfo[i].occupied = UNOCCUPIED;
				p_tracelist->used -= 1;

				comLog(TR, "STOP TRACE - TID(%lu)", trace_id);
				return 0;
			}
		}
	}
	comLog(WA, "FAIL TO STOP TRACE(%lu) - NOT FOUND", trace_id);

	return -1;
}

int omaTraceStopExpired(tracelist_t *p_tracelist, time_t current)
{
	int i, n;

	for (i = 0, n = 0; i < MAX_TRACEINFO_NUM; i++) {
		if (p_tracelist->traceinfo[i].occupied) {
			if (p_tracelist->traceinfo[i].stoptime < current) {
				p_tracelist->traceinfo[i].occupied = UNOCCUPIED;
				p_tracelist->used -= 1;

				comLog(TR, "EXPIRE TRACE - ID(%lu)", p_tracelist->traceinfo[i].trace_id);
				n++;
			}
		}
	}

	return n;
}

int omaTraceMatch(traceinfo_t *p_traceinfo, traceargs_t *p_traceargs)
{
	int i;

	if (!p_traceinfo->occupied) return -1;
	if ( strcmp(p_traceinfo->block, "cps") != 0) return -1;

	/* check Magic No */
	if (strcmp(p_traceinfo->mdn, TR_MAGIC_NO) == 0) {
		return 0;
	}
	for (i = 0; i < p_traceargs->n; i++) {
		if (p_traceinfo->iuid != 0 && p_traceinfo->iuid == p_traceargs->target[i]) {
			return 0;
		}
	}

	return -1;
}


