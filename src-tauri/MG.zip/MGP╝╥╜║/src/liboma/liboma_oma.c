/**
 * @date   2012/12/07
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "liboma.h"

omashm_t *omaP;

/** ----------------------------------------------------- */
int omaCreate(int shm_key)
{
	int shm_id;
	int shm_index;

	if ((shm_index = comGetIndex()) == -1) {
		comErr(ER, errno, "comGetIndex failed.");
		return -1;
	}

	shm_key += shm_index;
	if ((shm_id = shmget(shm_key, sizeof(omashm_t), IPC_CREAT | PERM)) < 0) {
		comErr(ER, errno, "shmget(0x%x,%d) failed.", shm_key, sizeof(omashm_t));
		return -1;
	}
	if ((omaP = (omashm_t *)shmat(shm_id, (void *) 0, 0)) == SHM_FAILED) {
		comErr(ER, errno, "shmat() failed.");
		return -1;
	}
	memset(omaP, 0x00, sizeof(omashm_t));

	/* init content-map */
	omaContentMapInit(&omaP->cmap);

	return 0;
}

int omaInitialize(int shm_key)
{
	int shm_id;
	int shm_index;

	if ((shm_index = comGetIndex()) == -1) {
		comErr(ER, errno, "comGetIndex failed.");
		return -1;
	}
	shm_key += shm_index;

	if ((shm_id = shmget(shm_key, sizeof(omashm_t), 0)) < 0) {
		comLog(ER, "shmget(0x%x,%d) failed.", shm_key, sizeof(omashm_t));
		return -1;
	}

	if ((omaP = (omashm_t *)shmat(shm_id, (void *) 0, 0)) == SHM_FAILED) {
		comLog(ER, "shmat() failed.");
		return -1;
	}

	return 0;
}

unsigned int omaGetServerKey(int svctype, int inst_id, int proc_id)
{
	unsigned int svrkey = 0;

	svrkey |= (svctype << 24) & 0xff000000;
	svrkey |= (inst_id <<  8) & 0x00ffff00;
	svrkey |=  proc_id        & 0x000000ff;

	return svrkey;
}

unsigned int omaConvServerKey(int svrkey)
{
	unsigned int convkey = 0;

	convkey |= (svrkey >> 24) & 0x000000ff;
	convkey |= (svrkey << 24) & 0xff000000;
	convkey |= (svrkey <<  8) & 0x00ff0000;
	convkey |= (svrkey >>  8) & 0x0000ff00;

	return convkey;
}
