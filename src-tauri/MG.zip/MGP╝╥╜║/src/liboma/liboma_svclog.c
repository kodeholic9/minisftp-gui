/**
 * @date   2012/09/01
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "liboma.h"

/** ----------------------------------------------------- */
int omaSvcLogInit(svclog_t *p_svclog, char *ltype, unsigned int server_key)
{
	/* init */
	memset(p_svclog, 0x00, sizeof(svclog_t));

	snprintf(p_svclog->logtype, MAX_SVCLOG_TYPE_LEN, "%s", ltype);
	p_svclog->server_key = server_key;

	return 0;
}

int omaSvcLogRecInit(svclogrec_t *p_record)
{
	memset(p_record, 0x00, sizeof(svclogrec_t));

	return 0;
}

int omaSvcLogRecPut(svclogrec_t *p_record, char *p_field)
{
	if ((p_record->n + strlen(p_field)) >= MAX_SVCLOG_REC_LEN - 1) {
		comLog(ER, "%s() the record is overflowed", __func__);
		return -1;
	}
	if (p_record->n == 0) {
		p_record->n = sprintf(p_record->s, "%s", p_field);
	}
	else {
		p_record->n += sprintf(p_record->s + p_record->n, ",%s", p_field);
	}

	return 0;
}

int omaSvcLogRecPutInt(svclogrec_t *p_record, int n)
{
	char s[20];

	sprintf(s, "%u", n);

	return omaSvcLogRecPut(p_record, s);
}

int omaSvcLogRecPutLong(svclogrec_t *p_record, long n)
{
	char s[20];

	sprintf(s, "%lu", n);

	return omaSvcLogRecPut(p_record, s);
}

int omaSvcLogRename(char *oldname, char *newext)
{
	char  newname[MAX_PATH_SIZE];
	char *p;
	int   len = strlen(newext);

	/* copy */
	strcpy(newname, oldname);

	/* replace with the newext */
	if ((p = strrchr(newname, '.')) == NULL) {
		comLog(ER, "%s() There is no such '.' character. (%s)", __func__, newname);
		return -1;
	}
	snprintf(p+1, len+1, "%s", newext);

	/* debug */
	comLog(TR, "%s() rename(%s --> %s)", __func__, oldname, newname);

	/* rename */
	if (rename(oldname, newname) == -1) {
		comErr(ER, errno, "%s() Fail to rename(%s --> %s)", __func__, oldname, newname);
		return -1;
	}

	return 0;
}

int omaSvcLogComplete(svclog_t *p_svclog, char *extend)
{
	if (p_svclog->fp == NULL) { return -1; }

	comLog(TR, "svclog(%s) is closed", p_svclog->fullpath);

	/* close */
	fflush(p_svclog->fp);
	fclose(p_svclog->fp);
	p_svclog->fp = NULL;

	/* rename */
	omaSvcLogRename(p_svclog->fullpath, extend);

	return 0;
}

time_t omaSvcLogRefresh(svclog_t *p_svclog, char *extend, int refresh_period)
{
	char   basepath[MAX_PATH_SIZE], logtime[20];
	time_t thistime = 0;

	/* prepare thistime */
	/* prepare */
	if (refresh_period <= 0) { refresh_period = 60; }
	thistime = comTime();
	thistime = thistime / refresh_period;
	thistime = thistime * refresh_period;

	/* check.. */
	if (p_svclog->fp != NULL && thistime == p_svclog->crtime) {
		return 0;
	}

	/* close FILE */
	if (p_svclog->fp != NULL) { omaSvcLogComplete(p_svclog, extend); }

	/* reopen FILE */
	if (p_svclog->logtype[0] == 'R' || p_svclog->logtype[0] == 'S') {
		snprintf(basepath, sizeof(basepath), "%s", pOmaProfile->LocalStatPath);
	}
	else {
		snprintf(basepath, sizeof(basepath), "%s", pOmaProfile->LocalSLogPath);
	}
	snprintf(p_svclog->fullpath, MAX_PATH_SIZE, "%s/%s_K%08x_T%s_V%02x.%s",
			basepath,
			p_svclog->logtype,
			p_svclog->server_key,
			comTimeT2Str(logtime, sizeof(logtime), "%Y%m%d%H%M", thistime),
			pOmaProfile->LogVersion,
			SVCLOG_EXT_ING);

	if ((p_svclog->fp = fopen(p_svclog->fullpath, "a")) == NULL) {
		comErr(ER, errno, "%s() Fail to fopen(%s)", __func__, p_svclog->fullpath);
		return -1;
	}
	comLog(TR, "svclog(%s) is opened", p_svclog->fullpath);

	/* update the create time.  */
	p_svclog->crtime = thistime;

	return p_svclog->crtime;
}

int omaSvcLogWrite(svclog_t *p_svclog, svclogrec_t *p_record)
{
	/* check */
	if (p_svclog->fp == NULL) {
		comLog(ER, "%s() Something wrong with the FILE_PTR", __func__);
		return -1;
	}

	/* write */
	fprintf(p_svclog->fp, "%s\n", p_record->s);

	/* debug */
	comLog(TR, "[%s] %s", p_svclog->logtype, p_record->s);

	return 0;
}

int omaSvcLogVectorInit(svclogvector_t *p_vector)
{
	memset(p_vector, 0x00, sizeof(svclogvector_t));
	return 0;
}

int omaSvcLogVectorPrepare(svclogvector_t *p_vector, char *ltype, unsigned int server_key)
{
	if (p_vector->used >= MAX_SVCLOG_NUM) {
		comLog(ER, "%s() SvcLogVector is overflowed!", __func__);
		return -1;
	}
	omaSvcLogInit(p_vector->svclog + p_vector->used, ltype, server_key);

	/* update the used count */
	p_vector->used += 1;

	return 0;
}

svclog_t *omaSvcLogVectorGet(svclogvector_t *p_vector, char *ltype)
{
	svclog_t *p_svclog;
	int       i;

	for (i = 0; i < p_vector->used; i++) {
		p_svclog = p_vector->svclog + i;
		if (strcmp(p_svclog->logtype, ltype) == 0) {
			return p_svclog;
		}
	}
	comLog(ER, "%s() no such SvcLog by LogType(%s)", __func__, ltype);

	return NULL;
}

#if 0
void omaSvcLogCpsMesg2Record(uemsg_t *p_uemsg, svclogrec_t *p_record, int key, int rescode)
{
	char from[MAX_ADDRESS_LEN+1];
	char ttoo[MAX_ADDRESS_LEN+1];
	char timestr[20];
	char svrKey [10];

	/* prepare */
	snprintf(svrKey, 10, "%08x", key);
	cpsMesgAddress2Str(&p_cpsmsg->invoke_req.from, from);
	cpsMesgAddress2Str(&p_cpsmsg->invoke_req.ttoo, ttoo);

	/* makeup the record */
	omaSvcLogRecInit(p_record);
	omaSvcLogRecPut    (p_record, comTimeT2Str(timestr, 20, "%Y%m%d%H%M%S", comTime()));
	omaSvcLogRecPutLong(p_record, p_cpsmsg->h.session_id);
	omaSvcLogRecPut    (p_record, svrKey);
	omaSvcLogRecPut    (p_record, from);
	omaSvcLogRecPut    (p_record, ttoo);
	omaSvcLogRecPutInt (p_record, p_cpsmsg->invoke_req.from_type);
	omaSvcLogRecPutInt (p_record, p_cpsmsg->invoke_req.service_id);
	omaSvcLogRecPutInt (p_record, p_cpsmsg->invoke_req.report_flag);
	omaSvcLogRecPutInt (p_record, 0);
	omaSvcLogRecPut    (p_record, comTimeT2Str(timestr, 20, "%Y%m%d%H%M%S", comTime()));
	omaSvcLogRecPut    (p_record, "-");
	omaSvcLogRecPut    (p_record, "-");
	omaSvcLogRecPutInt (p_record, rescode);
	omaSvcLogRecPutInt (p_record, CMR_EOK);
	omaSvcLogRecPutInt (p_record, CMR_EOK);

	return ;
}

void omaSvcLogCpsPool2Record(cmpool_t *p_cmpool, svclogrec_t *p_record, int key)
{
	char  timestr[20];
	char  svrKey [10];

	snprintf(svrKey, 10, "%08x", key);

	/* makeup the record */
	omaSvcLogRecInit(p_record);
	omaSvcLogRecPut    (p_record, comTimeT2Str(timestr, 20, "%Y%m%d%H%M%S", comTime()));
	omaSvcLogRecPutLong(p_record, p_cmpool->pooldata.sid);
	omaSvcLogRecPut    (p_record, svrKey);
	omaSvcLogRecPut    (p_record, p_cmpool->pooldata.from);
	omaSvcLogRecPut    (p_record, p_cmpool->pooldata.ttoo);
	omaSvcLogRecPutInt (p_record, p_cmpool->pooldata.from_type);
	omaSvcLogRecPutInt (p_record, p_cmpool->pooldata.service_id);
	omaSvcLogRecPutInt (p_record, p_cmpool->pooldata.report_flag);
	omaSvcLogRecPutInt (p_record, p_cmpool->pooldata.tries);
	if (p_cmpool->pooldata.rcvtime != 0) {
		omaSvcLogRecPut(p_record, comTimeT2Str(timestr, 20, "%Y%m%d%H%M%S", p_cmpool->pooldata.rcvtime));
	}
	else {
		omaSvcLogRecPut(p_record, "-");
	}

	if (p_cmpool->pooldata.invtime != 0) {
		omaSvcLogRecPut(p_record, comTimeT2Str(timestr, 20, "%Y%m%d%H%M%S", p_cmpool->pooldata.invtime));
	}
	else {
		omaSvcLogRecPut(p_record, "-");
	}
	if (p_cmpool->pooldata.rpttime != 0) {
		omaSvcLogRecPut(p_record, comTimeT2Str(timestr, 20, "%Y%m%d%H%M%S", p_cmpool->pooldata.rpttime));
	}
	else {
		omaSvcLogRecPut(p_record, "-");
	}
	omaSvcLogRecPutInt (p_record, CMR_EOK);
	omaSvcLogRecPutInt (p_record, p_cmpool->pooldata.rescode);
	omaSvcLogRecPutInt (p_record, CMR_EOK);

	return ;
}
#endif

