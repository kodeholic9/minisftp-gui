/**
 * @date   2018/08/19
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "liboma.h"

/** ----------------------------------------------------- */
content_t *CONTENT_PTR(contentmap_t *p_cmap, unsigned int idx)
{
	return p_cmap->data + idx;
}

unsigned int CONTENT_SLOT(char *key)
{
	return (unsigned int)(((double)comHashFuncJenkins(key, strlen(key)) / 0xffffffff) * MAX_CONTENT_NUM);
}

void omaContentMapInit(contentmap_t *p_cmap)
{
	memset(p_cmap, 0x00, sizeof(contentmap_t));
	p_cmap->used = CONTENT_START;

	/* for mutex */
	comMutexInit(&p_cmap->mutex);
}

unsigned int omaContentMapSearch(contentmap_t *p_cmap, unsigned int *hashslot, char *key)
{
	unsigned int next = 0;

	/* hash slot */
	*hashslot = CONTENT_SLOT(key);

	/* then, compare */
	for (next = p_cmap->slot[*hashslot]; next > 0; next = p_cmap->data[next].next) {
		if (strcmp(p_cmap->data[next].id, key) == 0) {
			return next;
		}
	}

	return 0;
}

int omaContentMapPut(contentmap_t *p_cmap, char *key, int part_id)
{
	unsigned int hashslot   = 0;
	unsigned int idx        = 0;
	unsigned int current    = 0, next = 0;
	content_t    *p_content = NULL;
	int          keylen     = strlen(key);

	if (keylen == 0 || keylen >= MAX_CONTENT_ID_LEN) {
		comLog(WA, "%s() the length(%d) of key is invalid", __func__, keylen);
		return -1;
	}

	/* LOCK */
	comMutexLock(&p_cmap->mutex);

	if ((idx = omaContentMapSearch(p_cmap, &hashslot, key)) == 0) {
		if ((current = p_cmap->used) >= MAX_CONTENT_NUM) {
			comMutexUnlock(&p_cmap->mutex);
			comLog(WA, "%s() content map is overflowed", __func__);
			return -1;
		}
		p_content = p_cmap->data + current;

		/* prepare */
		sprintf(p_content->id, "%s", key);
		p_content->comm = 0;
		p_content->talk = 0;

		/* update the link */
		if ((next = p_cmap->slot[hashslot]) > 0) {
			p_cmap->data[current].next = next;
		}
		p_cmap->slot[hashslot] = current;
		p_cmap->used++;
	}
	else {
		p_content = p_cmap->data + idx;
	}

	/* update the count */
	if (part_id == UTT_COMM) p_content->comm += 1;
	else                     p_content->talk += 1;

	/* UNLOCK */
	comMutexUnlock(&p_cmap->mutex);

	return 0;
}

void omaContentMapShow(contentmap_t *p_cmap)
{
	int i;

	if (p_cmap->used == CONTENT_START) {
		comLog(WA, "NO CONTENTs FOUND");
		return;
	}

	for (i = CONTENT_START; i < p_cmap->used; i++) {
		printf("[%04d] %s %8u %8u\n",
				i,
				p_cmap->data[i].id,
				p_cmap->data[i].comm,
				p_cmap->data[i].talk);
	}

	return;
}

