/**
 * @date   2012/11/14
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "liboma.h"

/** ----------------------------------------------------- */

int omaOmMesgValid(ommsg_t *p_ommsg)
{
	/* LENGTH */
	if (p_ommsg->h.oplength > MAX_OMDATA_LEN) {
		comLog(WA, "INVALID OMDATA LEN (%d > %d)", p_ommsg->h.opflag, MAX_OMDATA_LEN);
		return -1;
	}

	return 0;
}

void omaOmMesgNtohHead(ommsg_t *p_from, ommsg_t *p_ttoo)
{
	p_ttoo->h.opflag   = ntohs(p_from->h.opflag);
	p_ttoo->h.oplength = ntohs(p_from->h.oplength);
}

void omaOmMesgNtohData(ommsg_t *p_from, ommsg_t *p_ttoo)
{
	int i;

	switch (p_ttoo->h.opflag) {
		case OMT_BIND_REQ  :
			p_ttoo->bindreq.server_id     = ntohl(p_from->bindreq.server_id);
			p_ttoo->bindreq.server_status = ntohl(p_from->bindreq.server_status);
			break;

		case OMT_BIND_RES  :
			p_ttoo->bindres.result  = ntohl(p_from->bindres.result);
			break;

		case OMT_PROCLIST_REQ  :
			break;

		case OMT_PROCLIST_RES  :
			p_ttoo->plistres.nproc  = ntohl(p_from->plistres.nproc);
			for (i = 0; i < MAX_OMPROC_NUM && i < p_ttoo->plistres.nproc; i++) {
				p_ttoo->plistres.omproc[i].pid = ntohl(p_from->plistres.omproc[i].pid); 
				p_ttoo->plistres.omproc[i].key = ntohl(p_from->plistres.omproc[i].key); 
				p_ttoo->plistres.omproc[i].proc_status = ntohl(p_from->plistres.omproc[i].proc_status); 
			}
			break;

		case OMT_PROCACT_REQ  :
			p_ttoo->pactreq.key    = ntohl(p_from->pactreq.key);
			p_ttoo->pactreq.action = ntohl(p_from->pactreq.action);
			break;

		case OMT_PROCACT_RES  :
			p_ttoo->pactres.key    = ntohl(p_from->pactres.key);
			p_ttoo->pactres.action = ntohl(p_from->pactres.action);
			p_ttoo->pactres.result = ntohl(p_from->pactres.result);
			break;

		case OMT_LINK_REQ  :
		case OMT_LINK_RES  :
			break;

		case OMT_EVENT    : 
			p_ttoo->event.code  = ntohl(p_from->event.code);
			p_ttoo->event.clear = ntohl(p_from->event.clear);
			p_ttoo->event.level = ntohl(p_from->event.level);
			break;

		case OMT_RESOURCE    : 
			p_ttoo->resource.usage = ntohl(p_from->resource.usage);
			p_ttoo->resource.total = ntohl(p_from->resource.total);
			p_ttoo->resource.used  = ntohl(p_from->resource.used);
			break;

		case OMT_NOTI : 
			p_ttoo->noti.dlen = ntohl(p_from->noti.dlen);
			break;

		case OMT_TRACE_ON : 
			p_ttoo->traceon.period   = ntohl(p_from->traceon.period);
			p_ttoo->traceon.detailed = ntohl(p_from->traceon.detailed);
			break;

		case OMT_TRACE_OFF : 
			break;

		case OMT_TRACE_DATA : 
			p_ttoo->tracedata.dlen   = ntohl(p_from->tracedata.dlen);
			break;

		case OMT_CPSSTAT : 
			break;

		default : break;
	}

	return;
}

void omaOmMesgHtonHead(ommsg_t *p_from, ommsg_t *p_ttoo)
{
	p_ttoo->h.opflag   = htons(p_from->h.opflag);
	p_ttoo->h.oplength = htons(p_from->h.oplength);
}

void omaOmMesgHtonData(ommsg_t *p_from, ommsg_t *p_ttoo)
{
	int i;

	switch (p_from->h.opflag) {
		case OMT_BIND_REQ  :
			p_ttoo->bindreq.server_id     = htonl(p_from->bindreq.server_id);
			p_ttoo->bindreq.server_status = htonl(p_from->bindreq.server_status);
			break;

		case OMT_BIND_RES  :
			p_ttoo->bindres.result  = htonl(p_from->bindres.result);
			break;

		case OMT_PROCLIST_REQ  :
			break;

		case OMT_PROCLIST_RES  :
			p_ttoo->plistres.nproc  = htonl(p_from->plistres.nproc);
			for (i = 0; i < MAX_OMPROC_NUM && i < p_from->plistres.nproc; i++) {
				p_ttoo->plistres.omproc[i].pid = htonl(p_from->plistres.omproc[i].pid); 
				p_ttoo->plistres.omproc[i].key = htonl(p_from->plistres.omproc[i].key); 
				p_ttoo->plistres.omproc[i].proc_status = htonl(p_from->plistres.omproc[i].proc_status); 
			}
			break;

		case OMT_PROCACT_REQ  :
			p_ttoo->pactreq.key    = htonl(p_from->pactreq.key);
			p_ttoo->pactreq.action = htonl(p_from->pactreq.action);
			break;

		case OMT_PROCACT_RES  :
			p_ttoo->pactres.key    = htonl(p_from->pactres.key);
			p_ttoo->pactres.action = htonl(p_from->pactres.action);
			p_ttoo->pactres.result = htonl(p_from->pactres.result);
			break;

		case OMT_LINK_REQ  :
		case OMT_LINK_RES  :
			break;

		case OMT_EVENT : 
			p_ttoo->event.code  = htonl(p_from->event.code);
			p_ttoo->event.clear = htonl(p_from->event.clear);
			p_ttoo->event.level = htonl(p_from->event.level);
			break;

		case OMT_RESOURCE    : 
			p_ttoo->resource.usage = htonl(p_from->resource.usage);
			p_ttoo->resource.total = htonl(p_from->resource.total);
			p_ttoo->resource.used  = htonl(p_from->resource.used);
			break;

		case OMT_NOTI    : 
			p_ttoo->noti.dlen = htonl(p_from->noti.dlen);
			break;

		case OMT_TRACE_ON : 
			p_ttoo->traceon.period   = htonl(p_from->traceon.period);
			p_ttoo->traceon.detailed = htonl(p_from->traceon.detailed);
			break;

		case OMT_TRACE_OFF : 
			break;

		case OMT_TRACE_DATA : 
			p_ttoo->tracedata.dlen  = htonl(p_from->tracedata.dlen);
			break;

		case OMT_CPSSTAT : 
			break;

		default             : break;
	}

	return;
}

void omaOmMesgTrace(int lg, char *dst, char *dir, ommsgwrap_t *p_wrap)
{
	char trbuff[8192];
	int  i, n = 0;

	if (p_wrap->ommsg.h.opflag == OMT_LINK_REQ
			|| p_wrap->ommsg.h.opflag == OMT_LINK_RES)
	{
		return;
	}
	if (lg != TR && lg != DG) return;

	/* for debug */
	n = snprintf(trbuff, sizeof(trbuff), "%s %s %s(%04x) L(%3u) ",
			dst,
			dir,
			appCodeMap2Str(CC_OmType, p_wrap->ommsg.h.opflag),
			p_wrap->ommsg.h.opflag,
			p_wrap->ommsg.h.oplength);

	switch (p_wrap->ommsg.h.opflag) {
		case OMT_BIND_REQ  :
			n += snprintf(trbuff + n, sizeof(trbuff) - n, "ID(H'%08x) STAT(%x)",
					p_wrap->ommsg.bindreq.server_id,
					p_wrap->ommsg.bindreq.server_status);
			break;

		case OMT_BIND_RES  :
			n += snprintf(trbuff + n, sizeof(trbuff) - n, "RES(%d)", p_wrap->ommsg.bindres.result);
			break;

		case OMT_PROCLIST_REQ  :
			break;

		case OMT_PROCLIST_RES  :
			snprintf(trbuff + n, sizeof(trbuff) - n, "NPROC(%d)", p_wrap->ommsg.plistres.nproc);
			for (i = 0; i < p_wrap->ommsg.plistres.nproc; i++) {
				n += snprintf(trbuff + n, sizeof(trbuff) - n, "P%d(%u/%08x/%c), ",
						i+1, 
						p_wrap->ommsg.plistres.omproc[i].pid,
						p_wrap->ommsg.plistres.omproc[i].key,
						p_wrap->ommsg.plistres.omproc[i].proc_status);
			}
			break;

		case OMT_PROCACT_REQ  :
			n += snprintf(trbuff + n, sizeof(trbuff) - n, "KEY(%d) ACTION(%d)",
					p_wrap->ommsg.pactreq.key,
					p_wrap->ommsg.pactreq.action);
			break;

		case OMT_PROCACT_RES  :
			n += snprintf(trbuff + n, sizeof(trbuff) - n, "KEY(%d) ACTION(%d) RES(%d) %s",
					p_wrap->ommsg.pactres.key,
					p_wrap->ommsg.pactres.action,
					p_wrap->ommsg.pactres.result,
					p_wrap->ommsg.pactres.msg);
			break;

		case OMT_EVENT  :
			n += snprintf(trbuff + n, sizeof(trbuff) - n, "CODE(%d) CLEAR(%d) LEVEL(%d) TIME(%s) P1(%s) P2(%s) P3(%s)",
					p_wrap->ommsg.event.code,
					p_wrap->ommsg.event.clear,
					p_wrap->ommsg.event.level,
					p_wrap->ommsg.event.evtime,
					p_wrap->ommsg.event.param1,
					p_wrap->ommsg.event.param2,
					p_wrap->ommsg.event.param3);
			break;

		case OMT_RESOURCE  :
			n += snprintf(trbuff + n, sizeof(trbuff) - n, "TYPE(%s) NAME(%s) USAGE(%d) T(%u) U(%u)",
					p_wrap->ommsg.resource.type,
					p_wrap->ommsg.resource.name,
					p_wrap->ommsg.resource.usage,
					p_wrap->ommsg.resource.total,
					p_wrap->ommsg.resource.used);
			break;

		case OMT_TRACE_ON  :
			n += snprintf(trbuff + n, sizeof(trbuff) - n, "TID(%lu) P(%d) MDN(%s) IUID(%lu) B(%s) D(%d)",
					comProtoI642Long(&p_wrap->ommsg.traceon.trace_id),
					p_wrap->ommsg.traceon.period,
					p_wrap->ommsg.traceon.mdn,
					comProtoI642Long(&p_wrap->ommsg.traceon.iuid),
					p_wrap->ommsg.traceon.block,
					p_wrap->ommsg.traceon.detailed);
			break;

		case OMT_TRACE_OFF : 
			n += snprintf(trbuff + n, sizeof(trbuff) - n, "TID(%lu)", comProtoI642Long(&p_wrap->ommsg.traceoff.trace_id));
			break;

		case OMT_TRACE_DATA: 
			n += snprintf(trbuff + n, sizeof(trbuff) - n, "TID(%lu) DLEN(%d)",
					comProtoI642Long(&p_wrap->ommsg.tracedata.trace_id),
					p_wrap->ommsg.tracedata.dlen);
			break;

		case OMT_CPSSTAT: 
			n += snprintf(trbuff + n, sizeof(trbuff) - n, "TYPE(%s) TIME(%s) VALUE(%s)",
					p_wrap->ommsg.cpsstat.stype,
					p_wrap->ommsg.cpsstat.stime,
					p_wrap->ommsg.cpsstat.svalue);
			break;

		case OMT_NOTI :
			n += snprintf(trbuff + n, sizeof(trbuff) - n, "TID(%u) DLEN(%d)\n%s",
					p_wrap->ommsg.noti.noti_id,
					p_wrap->ommsg.noti.dlen,
					p_wrap->ommsg.noti.data);
			break;
	}

	comLog(lg, "%s", trbuff);
	/*comDumpRaw(DG, (unsigned char *)&p_wrap->omraw.data, p_wrap->limit);*/

	return;
}

int omaOmMesgRecvTcp(nonbsock_t *p_nonbsock, ommsgwrap_t *p_wrap)
{
	int n = 0;

	/* prepare */
	if (p_wrap->readdone) { p_wrap->readdone = FALSE; p_wrap->limit = 0; }

	/* for HEAD PART */
	if (p_wrap->limit < sizeof(omheader_t)) {
		if ((n = appNonbsockRecv(
						p_nonbsock,
						p_wrap->ommsg.data + p_wrap->limit,
						p_wrap->omraw.data + p_wrap->limit,
						sizeof(omheader_t) - p_wrap->limit)) == -1)
		{
			return -1;
		}
		if ((p_wrap->limit += n) != sizeof(omheader_t)) {
			return 0;
		}

		/* byte ordering */
		omaOmMesgNtohHead(&p_wrap->omraw, &p_wrap->ommsg);
	}

	/* for DATA PART */
	if (p_wrap->ommsg.h.oplength > MAX_OMDATA_LEN) {
		comLog(ER, "Too Long (%u)", p_wrap->ommsg.h.oplength);
		return -1;
	}
	if (p_wrap->ommsg.h.oplength > 0) {
		if ((n = appNonbsockRecv(
						p_nonbsock,
						p_wrap->ommsg.data + p_wrap->limit,
						p_wrap->omraw.data + p_wrap->limit,
						p_wrap->ommsg.h.oplength + sizeof(omheader_t) - p_wrap->limit)) == -1)
		{
			return -1;
		}
		if ((p_wrap->limit += n) != (p_wrap->ommsg.h.oplength + sizeof(omheader_t))) {
			return 0;
		}
		omaOmMesgNtohData(&p_wrap->omraw, &p_wrap->ommsg);
	}

	/* for debug */
	omaOmMesgTrace(DG, p_nonbsock->name, ">", p_wrap);

	/* update the limit for the next mesg */
	p_wrap->readdone = TRUE;

	return p_wrap->limit;
}

int omaOmMesgSendTcp(nonbsock_t *p_nonbsock, ommsgwrap_t *p_wrap)
{
	int cc;

	/* check */
	if (p_nonbsock->psockfd == 0) { return 0; }

	/* copy */
	memcpy(p_wrap->omraw.data, p_wrap->ommsg.data, sizeof(ommsg_t));

	/* byte ordering */
	omaOmMesgHtonHead(&p_wrap->ommsg, &p_wrap->omraw);
	omaOmMesgHtonData(&p_wrap->ommsg, &p_wrap->omraw);
	p_wrap->limit = sizeof(omheader_t) + p_wrap->ommsg.h.oplength;

	/* then send */
	if ((cc = appNonbsockSend(p_nonbsock, p_wrap->omraw.data, p_wrap->limit)) > 0) {
		omaOmMesgTrace(DG, p_nonbsock->name, "<", p_wrap);
	}

	return cc;
}

void omaOmMesgPackHead(ommsg_t *p_ommsg, int opflag, int oplength)
{
	memset(p_ommsg, 0x00, sizeof(ommsg_t));
	p_ommsg->h.opflag   = opflag;
	p_ommsg->h.oplength = oplength;

	return;
}

void omaOmMesgPackLinkReq(ommsg_t *p_ommsg)
{
	/* -------- header part */
	omaOmMesgPackHead(p_ommsg, OMT_LINK_REQ, 0);
	return;
}

void omaOmMesgPackBindReq(ommsg_t *p_ommsg, int svr_id, int svr_status)
{
	/* -------- header part */
	omaOmMesgPackHead(p_ommsg, OMT_BIND_REQ, sizeof(ombindreq_t) - sizeof(omheader_t));

	/* -------- data part */
	p_ommsg->bindreq.server_id = svr_id;
	p_ommsg->bindreq.server_status = svr_status;

	return;
}

void omaOmMesgPackBindRes(ommsg_t *p_ommsg, int result)
{
	/* -------- header part */
	omaOmMesgPackHead(p_ommsg, OMT_BIND_RES, sizeof(ombindres_t) - sizeof(omheader_t));

	/* -------- data part */
	p_ommsg->bindres.result = result;

	return;
}

void omaOmMesgPackProcListRes(ommsg_t *p_ommsg, omproc_t *p_omproc, int nproc)
{
	/* -------- header part */
	omaOmMesgPackHead(p_ommsg, OMT_PROCLIST_RES, 4 + (sizeof(omproc_t) * nproc));

	/* -------- data part */
	memcpy(p_ommsg->plistres.omproc, p_omproc, sizeof(omproc_t) * nproc);
	p_ommsg->plistres.nproc = nproc;

	return;
}

void omaOmMesgPackProcActRes(ommsg_t *p_ommsg, int key, int action, int result, char *p_msg)
{
	/* -------- header part */
	omaOmMesgPackHead(p_ommsg, OMT_PROCACT_RES, sizeof(ompactres_t) - sizeof(omheader_t));

	/* -------- data part */
	p_ommsg->pactres.key    = key;
	p_ommsg->pactres.action = action;
	p_ommsg->pactres.result = result;
	snprintf(p_ommsg->pactres.msg, sizeof(p_ommsg->pactres.msg), "%s", p_msg);

	return;
}

void omaOmMesgPackLinkRes(ommsg_t *p_ommsg)
{
	/* -------- header part */
	omaOmMesgPackHead(p_ommsg, OMT_LINK_RES, 0);

	return;
}

void omaOmMesgPackTraceOn(ommsg_t *p_ommsg, char *source,
		int period, long trace_id, char *mdn, long iuid, char *block, int detailed)
{
	/* -------- header part */
	omaOmMesgPackHead(p_ommsg, OMT_TRACE_ON, sizeof(omtraceon_t) - sizeof(omheader_t));

	/* -------- data part */
	p_ommsg->traceon.period    = period;
	p_ommsg->traceon.detailed  = detailed;

	comProtoLong2I64(trace_id, &p_ommsg->traceon.trace_id);
	comProtoLong2I64(iuid    , &p_ommsg->traceon.iuid);

	snprintf(p_ommsg->traceon.mdn  , MAX_ADDRESS_LEN, "%s", mdn);
	snprintf(p_ommsg->traceon.block, MAX_TRBLOCK_LEN, "%s", block);

	return;
}

void omaOmMesgPackTraceOff(ommsg_t *p_ommsg, long trace_id)
{
	/* -------- header part */
	omaOmMesgPackHead(p_ommsg, OMT_TRACE_OFF, sizeof(omtraceoff_t) - sizeof(omheader_t));

	/* -------- data part */
	comProtoLong2I64(trace_id, &p_ommsg->traceoff.trace_id);

	return;
}

void omaOmMesgPackTraceData(ommsg_t *p_ommsg, traceinfo_t *p_traceinfo, char *trtime, char *data, int dlen)
{
	if (dlen > (MAX_OMDATA_LEN - sizeof(omtracedata_t))) {
		dlen = MAX_OMDATA_LEN - sizeof(omtracedata_t);
	}

	/* -------- header part */
	omaOmMesgPackHead(p_ommsg, OMT_TRACE_DATA, sizeof(omtracedata_t) + dlen - sizeof(omheader_t));

	/* -------- data part */
	comProtoLong2I64(p_traceinfo->trace_id, &p_ommsg->tracedata.trace_id);
	snprintf(p_ommsg->tracedata.trtime , MAX_TRTIME_LEN  , "%s", trtime);
	snprintf(p_ommsg->tracedata.mdn    , MAX_ADDRESS_LEN , "%s", p_traceinfo->mdn);
	snprintf(p_ommsg->tracedata.block  , MAX_TRBLOCK_LEN , "%s", p_traceinfo->block);
	snprintf(p_ommsg->tracedata.source , MAX_TRSOURCE_LEN, "%s", p_traceinfo->source);

	/* for data */
	p_ommsg->tracedata.dlen = dlen;
	if (dlen != 0 && data != NULL) {
		snprintf(p_ommsg->tracedata.data, dlen, "%s", data);
	}

	return;
}

void omaOmMesgPackEvent(ommsg_t *p_ommsg, int code, int clear,
		int level, char *evtime, char *param1, char *param2, char *param3)
{
	/* -------- header part */
	omaOmMesgPackHead(p_ommsg, OMT_EVENT, sizeof(omevent_t) - sizeof(omheader_t));

	/* -------- data part */
	p_ommsg->event.code  = code;
	p_ommsg->event.clear = clear;
	p_ommsg->event.level = level;
	snprintf(p_ommsg->event.evtime, MAX_EVTIME_LEN, "%s", evtime);
	snprintf(p_ommsg->event.param1, MAX_EVPARA_LEN, "%s", (param1 == NULL || strlen(param1) == 0) ? "" : param1);
	snprintf(p_ommsg->event.param2, MAX_EVPARA_LEN, "%s", (param2 == NULL) ? "" : param2);
	snprintf(p_ommsg->event.param3, MAX_EVPARA_LEN, "%s", (param3 == NULL) ? "" : param3);

	return;
}

void omaOmMesgPackResource(ommsg_t *p_ommsg, char *type, char *name, int usage, int total, int used)
{
	/* -------- header part */
	omaOmMesgPackHead(p_ommsg, OMT_RESOURCE, sizeof(omresource_t) - sizeof(omheader_t));

	/* -------- data part */
	snprintf(p_ommsg->resource.type, MAX_OMRESTYPE_LEN, "%s", type);
	if (name != NULL) {
		snprintf(p_ommsg->resource.name, MAX_OMRESNAME_LEN, "%s", name);
	}
	p_ommsg->resource.usage = usage;
	p_ommsg->resource.total = total;
	p_ommsg->resource.used  = used;

	return;
}

void omaOmMesgPackNoti(ommsg_t *p_ommsg, int noti_id, char *data, int dlen)
{
	/* calculate */
	omaOmMesgPackHead(p_ommsg, OMT_NOTI, 8 + dlen);

	p_ommsg->noti.noti_id = noti_id;
	p_ommsg->noti.dlen    = dlen;
	if (dlen != 0 && data != NULL) {
		snprintf(p_ommsg->noti.data, MAX_OMMESG_LEN - sizeof(omnoti_t), "%s", data);
	}

	return;
}

void omaOmMesgPackCpsStat(ommsg_t *p_ommsg, char *type, char *time, char *values)
{
	/* -------- header part */
	omaOmMesgPackHead(p_ommsg, OMT_CPSSTAT, sizeof(omcpsstat_t) - sizeof(omheader_t));

	/* -------- data part */
	snprintf(p_ommsg->cpsstat.stype , MAX_STYPE_LEN , "%s", type);
	snprintf(p_ommsg->cpsstat.stime , MAX_STIME_LEN , "%s", time);
	snprintf(p_ommsg->cpsstat.svalue, MAX_SVALUE_LEN, "%s", values);

	return;
}

int omaOmMesgSendBindReq(nonbsock_t *p_nonb, ommsgwrap_t *p_wrap, int svr_id, int svr_status)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;
	int      n;

	/* init */
	memset(p_wrap, 0x00, sizeof(ommsgwrap_t));

	/* PACK MESG */
	omaOmMesgPackBindReq(p_ommsg, svr_id, svr_status);

	/* SEND */
	if ((n = omaOmMesgSendTcp(p_nonb, p_wrap)) == -1) {
		appNonbsockClose(p_nonb);
	}

	return n;
}

int omaOmMesgSendBindRes(nonbsock_t *p_nonb, ommsgwrap_t *p_wrap, int result)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;
	int      n;

	/* init */
	memset(p_wrap, 0x00, sizeof(ommsgwrap_t));

	/* PACK MESG */
	omaOmMesgPackBindRes(p_ommsg, result);

	/* SEND */
	if ((n = omaOmMesgSendTcp(p_nonb, p_wrap)) == -1) {
		appNonbsockClose(p_nonb);
	}

	return n;
}

int omaOmMesgSendLinkReq(nonbsock_t *p_nonb, ommsgwrap_t *p_wrap)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;
	int      n;

	/* init */
	memset(p_wrap, 0x00, sizeof(ommsgwrap_t));

	/* PACK MESG */
	omaOmMesgPackLinkReq(p_ommsg);

	/* SEND */
	if ((n = omaOmMesgSendTcp(p_nonb, p_wrap)) == -1) {
		appNonbsockClose(p_nonb);
	}

	return n;
}

int omaOmMesgSendLinkRes(nonbsock_t *p_nonb, ommsgwrap_t *p_wrap)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;
	int      n;

	/* init */
	memset(p_wrap, 0x00, sizeof(ommsgwrap_t));

	/* PACK MESG */
	omaOmMesgPackLinkRes(p_ommsg);

	/* SEND */
	if ((n = omaOmMesgSendTcp(p_nonb, p_wrap)) == -1) {
		appNonbsockClose(p_nonb);
	}

	return n;
}

int omaOmMesgSendNoti(nonbsock_t *p_nonb, ommsgwrap_t *p_wrap, int noti_id, char *data, int dlen)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;
	int      n;

	/* init */
	memset(p_wrap, 0x00, sizeof(ommsgwrap_t));

	/* PACK MESG */
	omaOmMesgPackNoti(p_ommsg, noti_id, data, dlen);

	/* SEND */
	if ((n = omaOmMesgSendTcp(p_nonb, p_wrap)) == -1) {
		appNonbsockClose(p_nonb);
	}

	return n;
}

int omaOmMesgSendTraceOn(nonbsock_t *p_nonb, ommsgwrap_t *p_wrap,
		char *source, int period, long trace_id, char *mdn, long iuid, char *block, int detailed)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;
	int      n;

	/* init */
	memset(p_wrap, 0x00, sizeof(ommsgwrap_t));

	/* PACK MESG */
	omaOmMesgPackTraceOn(p_ommsg, source, period, trace_id, mdn, iuid, block, detailed);

	/* SEND */
	if ((n = omaOmMesgSendTcp(p_nonb, p_wrap)) == -1) {
		appNonbsockClose(p_nonb);
	}

	return n;
}

int omaOmMesgSendTraceData(nonbsock_t *p_nonb, ommsgwrap_t *p_wrap, traceinfo_t *p_traceinfo, char *trtime, char *data, int dlen)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;
	int      n;

	/* init */
	memset(p_wrap, 0x00, sizeof(ommsgwrap_t));

	/* PACK MESG */
	omaOmMesgPackTraceData(p_ommsg, p_traceinfo, trtime, data, dlen);

	/* SEND */
	if ((n = omaOmMesgSendTcp(p_nonb, p_wrap)) == -1) {
		appNonbsockClose(p_nonb);
	}

	return n;
}

int omaOmMesgSendEvent(nonbsock_t *p_nonb, ommsgwrap_t *p_wrap, int code, int clear, char *param1, char *param2, char *param3)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;
	char     evtime[MAX_EVTIME_LEN];
	int      n = 0;

	/* init */
	memset(p_wrap, 0x00, sizeof(ommsgwrap_t));

	/* setup the event time */
	comTimeT2Str(evtime, MAX_EVTIME_LEN, "%Y%m%d%H%M%S", comTime());

	/* pack the event */
	omaOmMesgPackEvent(p_ommsg, code, clear, 0, evtime, param1, param2, param3);

	/* SEND */
	if ((n = omaOmMesgSendTcp(p_nonb, p_wrap)) == -1) {
		appNonbsockClose(p_nonb);
	}

	return n;
}

int omaOmMesgSendResource(nonbsock_t *p_nonb, ommsgwrap_t *p_wrap, char *type, char *name, int usage, int total, int used)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;
	int      n = 0;

	/* init */
	memset(p_wrap, 0x00, sizeof(ommsgwrap_t));

	/* pack the resource */
	omaOmMesgPackResource(p_ommsg, type, name, usage, total, used);

	/* SEND */
	if ((n = omaOmMesgSendTcp(p_nonb, p_wrap)) == -1) {
		appNonbsockClose(p_nonb);
	}

	return n;
}

int omaOmMesgSendCpsStat(nonbsock_t *p_nonb, ommsgwrap_t *p_wrap, char *type, char *time, char *values)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;
	int      n = 0;

	/* init */
	memset(p_wrap, 0x00, sizeof(ommsgwrap_t));

	/* pack the resource */
	omaOmMesgPackCpsStat(p_ommsg, type, time, values);

	/* SEND */
	if ((n = omaOmMesgSendTcp(p_nonb, p_wrap)) == -1) {
		appNonbsockClose(p_nonb);
	}

	return n;
}

int omaOmMesgSendProcListRes(nonbsock_t *p_nonb, ommsgwrap_t *p_wrap, omproc_t *p_omproc, int nproc)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;
	int      n = 0;

	/* init */
	memset(p_wrap, 0x00, sizeof(ommsgwrap_t));

	/* pack */
	omaOmMesgPackProcListRes(p_ommsg, p_omproc, nproc);

	/* send */
	if ((n = omaOmMesgSendTcp(p_nonb, p_wrap)) == -1) {
		appNonbsockClose(p_nonb);
	}

	return n;
}

int omaOmMesgSendProcActRes(nonbsock_t *p_nonb, ommsgwrap_t *p_wrap, int key, int action, int result, char *p_msg)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;
	int      n = 0;

	/* init */
	memset(p_wrap, 0x00, sizeof(ommsgwrap_t));

	/* pack */
	omaOmMesgPackProcActRes(p_ommsg, key, action, result, p_msg);

	/* send */
	if ((n = omaOmMesgSendTcp(p_nonb, p_wrap)) == -1) {
		appNonbsockClose(p_nonb);
	}

	return n;
}

