/**
 * @date   2013/04/07
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "liboma.h"

/** ----------------------------------------------------- */

int omaHaMesgValid(hamsg_t *p_hamsg)
{
	/* START-BIT */
	if (p_hamsg->h.start_bit != HA_START_BIT) {
		comLog(WA, "INVALID START-BIT (%d != %d)", p_hamsg->h.start_bit, HA_START_BIT);
		return -1;
	}

	/* OPFLAG */
	if (p_hamsg->h.opflag != HAT_HEARTBEAT && p_hamsg->h.opflag != HAT_BYE) {
		comLog(WA, "INVALID OPFLAG (%d)", p_hamsg->h.opflag);
		return -1;
	}

	return 0;
}

void omaHaMesgNtohHead(hamsg_t *p_from, hamsg_t *p_ttoo)
{
	p_ttoo->h.start_bit = ntohl(p_from->h.start_bit);
	p_ttoo->h.opflag    = ntohl(p_from->h.opflag);
	p_ttoo->h.key       = ntohl(p_from->h.key);
	p_ttoo->h.uptime    = ntohl(p_from->h.uptime);
	p_ttoo->h.seq       = ntohl(p_from->h.seq);
	p_ttoo->h.status    = ntohl(p_from->h.status);
}

void omaHaMesgHtonHead(hamsg_t *p_from, hamsg_t *p_ttoo)
{
	p_ttoo->h.start_bit = htonl(p_from->h.start_bit);
	p_ttoo->h.opflag    = htonl(p_from->h.opflag);
	p_ttoo->h.key       = htonl(p_from->h.key);
	p_ttoo->h.uptime    = htonl(p_from->h.uptime);
	p_ttoo->h.seq       = htonl(p_from->h.seq);
	p_ttoo->h.status    = htonl(p_from->h.status);
}

void omaHaMesgNtoh(hamsg_t *p_from, hamsg_t *p_ttoo)
{
	/* COPY-ALL */
	memcpy(p_ttoo, p_from, sizeof(hamsg_t));

	/* Then, BYTE-ORDERING */
	omaHaMesgNtohHead(p_from, p_ttoo);
}

void omaHaMesgHton(hamsg_t *p_from, hamsg_t *p_ttoo)
{
	/* COPY-ALL */
	memcpy(p_ttoo, p_from, sizeof(hamsg_t));

	/* Then, BYTE-ORDERING */
	omaHaMesgHtonHead(p_from, p_ttoo);
}

void omaHaMesgTrace(int lg, char *dir, udpaddr_t *p_udpaddr, hamsgwrap_t *p_wrap)
{
	char trbuff[8192];
	int  n = 0;

#if 1
	if (p_wrap->hamsg.h.opflag == HAT_HEARTBEAT) {
		return;
	}
#endif
	if (lg != TR && lg != DG) return;

	/* for debug */
	n = snprintf(trbuff, sizeof(trbuff), "HA %s %s(%04x) SEQ(%u) ",
			dir,
			appCodeMap2Str(CC_HaType, p_wrap->hamsg.h.opflag),
			p_wrap->hamsg.h.opflag,
			p_wrap->hamsg.h.seq);

	comLog    (lg, "%s", trbuff);
	comDumpRaw(lg, (unsigned char *)&p_wrap->haraw.data, p_wrap->limit);

	return;
}

int omaHaMesgRecvUdp(int ufd, udpaddr_t *p_udpaddr, hamsgwrap_t *p_wrap)
{
	/* RECV MESSAGE */
	p_wrap->limit = comReadUDPSocket(ufd, (uchar *)&p_wrap->haraw.data, sizeof(hamsg_t), p_udpaddr);
	if (p_wrap->limit == -1 || p_wrap->limit == 0) {
		return -1;
	}

	/* BYTE ORDERING */
	omaHaMesgNtoh(&p_wrap->haraw, &p_wrap->hamsg);

	/* TRACE */
	omaHaMesgTrace(TR, ">", p_udpaddr, p_wrap);

	/* VALIDATE */
	if (omaHaMesgValid(&p_wrap->hamsg) == -1) {
		return -1;
	}

	return p_wrap->limit;
}

int omaHaMesgSendUdp(int ufd, udpaddr_t *p_udpaddr, hamsgwrap_t *p_wrap)
{
	/* BYTE ORDERING */
	omaHaMesgHton(&p_wrap->hamsg, &p_wrap->haraw);

	/* TRACE */
	omaHaMesgTrace(TR, "<", p_udpaddr, p_wrap);

	return comWriteUDPSocket(ufd, p_udpaddr, p_wrap->haraw.data, p_wrap->limit);
}


void omaHaMesgPackHead(
		hamsg_t *p_hamsg, 
		unsigned int opflag,
		unsigned int key,
		unsigned int uptime,
		unsigned int seq,
		unsigned int status)
{
	memset(p_hamsg, 0x00, sizeof(hamsg_t));
	p_hamsg->h.start_bit = HA_START_BIT;
	p_hamsg->h.opflag    = opflag;
	p_hamsg->h.key       = key;
	p_hamsg->h.uptime    = uptime;
	p_hamsg->h.seq       = seq;
	p_hamsg->h.status    = status;

	return;
}

void omaHaMesgPackHeartbeat(
		hamsg_t *p_hamsg, 
		unsigned int key,
		unsigned int uptime,
		unsigned int seq,
		unsigned int status)
{
	/* -------- header part */
	omaHaMesgPackHead(p_hamsg, HAT_HEARTBEAT, key, uptime, seq, status);

	return;
}

void omaHaMesgPackBye(
		hamsg_t *p_hamsg, 
		unsigned int key,
		unsigned int uptime,
		unsigned int seq,
		unsigned int status)
{
	/* -------- header part */
	omaHaMesgPackHead(p_hamsg, HAT_BYE, key, uptime, seq, status);

	return;
}

int omaHaMesgSendHeartbeat(
		int ufd, 
		udpaddr_t *p_udpaddr, 
		hamsgwrap_t *p_wrap, 
		unsigned int key,
		unsigned int uptime,
		unsigned int seq,
		unsigned int status)
{
	/* PACK MESG */
	omaHaMesgPackHeartbeat(&p_wrap->hamsg, key, uptime, seq, status);

	/* SETUP SEND LEN */
	p_wrap->limit = sizeof(haheartbeat_t);

	return omaHaMesgSendUdp(ufd, p_udpaddr, p_wrap);
}

int omaHaMesgSendBye(
		int ufd, 
		udpaddr_t *p_udpaddr, 
		hamsgwrap_t *p_wrap, 
		unsigned int key,
		unsigned int uptime,
		unsigned int seq,
		unsigned int status)
{
	/* PACK MESG */
	omaHaMesgPackBye(&p_wrap->hamsg, key, uptime, seq, status);

	/* SETUP SEND LEN */
	p_wrap->limit = sizeof(habye_t);

	return omaHaMesgSendUdp(ufd, p_udpaddr, p_wrap);
}

