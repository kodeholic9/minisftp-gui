/**
 * @date   2012/12/07
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "liboma.h"
#include "libapp.h"

/* for debug */
#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_OMA, __LINE__)

/** ----------------------------------------------------- */
void *omAgent(void *arg)
{
	omaproc_t   *p_omaproc   = (omaproc_t *)arg;
	omshandle_t *p_omshandle = &p_omaproc->omshandle;
	nonbsock_t  *p_nonb      = &p_omshandle->nonb;
	fd_set rset;
	int    n;

	sleep(2);
	comLog(WA, "%s - Started", __func__);

	FNDEBUG(TASK_OMA);
	while (p_omaproc->running) {
		/* for socket */
		FNDEBUG(TASK_OMA);
		if (p_nonb->psockfd > 0) {
			if ((n = oma_wait(p_omaproc, p_nonb, &rset, 10 * 1000)) > 0) {
				oma_proc(p_omaproc, p_nonb, &rset);
			}
		}
		else { usleep(10 * 1000); }

		/* for timer */
		FNDEBUG(TASK_OMA);
		oma_timer(p_omaproc, p_nonb);

		/* for ring */
		FNDEBUG(TASK_OMA);
		oma_ring(p_omaproc, p_nonb);
	}
	comLog(WA, "%s - Stoped", __func__);

	FNDEBUG(TASK_OMA);
	pthread_exit(NULL);

	return NULL;
}

int omAgentStart(omaproc_t *p_omaproc, int key, char *host, int port)
{
	memset(p_omaproc, 0x00, sizeof(omaproc_t));

	/* for svrkey */
	p_omaproc->key = key;

	/* for target host */
	sprintf(p_omaproc->omshandle.omshost, "%s", host);
	p_omaproc->omshandle.omsport = port;

	/* for ring */
	if (comRingBufferInit(&p_omaproc->rb, p_omaproc->rbdata, MAX_RBDATA_SIZE) == -1) {
		comLog(ER, "RingBuffer Init Failed.");
		return -1;
	}

	/* for thread */
	p_omaproc->running = TRUE;
	if (comThreadCreate(&p_omaproc->thread, omAgent, p_omaproc) == -1) {
		comErr(ER, errno, "Thread Init Failed.");
		return -1;
	}

	return 0;
}

int omTraceEnqueue(omaproc_t *p_omaproc, traceinfo_t *p_traceinfo, char *data, int dlen)
{
	ommsg_t ommsg;
	char    trtime[MAX_TRTIME_LEN];

	/* init */
	memset(&ommsg, 0x00, sizeof(ommsg_t));

	comTimeT2Str(trtime, sizeof(trtime), "%Y-%m-%d %H:%M:%S", comTime());

	/* pack */
	omaOmMesgPackTraceData(&ommsg, p_traceinfo, trtime, data, dlen);

	/* enqueue */
	return comRingBufferEnqueue(&p_omaproc->rb, (char *)&ommsg, sizeof(ommsg_t));
}

int omResourceEnqueue(omaproc_t *p_omaproc, char *type, char *name, int usage, int total, int used)
{
	ommsg_t ommsg;

	/* init */
	memset(&ommsg, 0x00, sizeof(ommsg_t));

	/* pack */
	omaOmMesgPackResource(&ommsg, type, name, usage, total, used);

	/* enqueue */
	return comRingBufferEnqueue(&p_omaproc->rb, (char *)&ommsg, sizeof(ommsg_t));
}

int omEventEnqueue(omaproc_t *p_omaproc, int code, int clear, char *param1, char *param2, char *param3)
{
	ommsg_t ommsg;
	char    evtime[MAX_EVTIME_LEN];

	/* init */
	memset(&ommsg, 0x00, sizeof(ommsg_t));

	/* pack */
	comTimeT2Str(evtime, MAX_EVTIME_LEN, "%Y%m%d%H%M%S", comTime());
	omaOmMesgPackEvent(&ommsg, code, clear, 0, evtime, param1, param2, param3);

	/* enqueue */
	return comRingBufferEnqueue(&p_omaproc->rb, (char *)&ommsg, sizeof(ommsg_t));
}

int omStatEnqueue(omaproc_t *p_omaproc, char *type, char *values)
{
	ommsg_t ommsg;
	char    sttime[MAX_EVTIME_LEN];

	/* init */
	memset(&ommsg, 0x00, sizeof(ommsg_t));

	/* pack */
	comTimeT2Str(sttime, MAX_EVTIME_LEN, "%Y%m%d%H%M%S", comTime());
	omaOmMesgPackCpsStat(&ommsg, type, sttime, values);

	/* enqueue */
	return comRingBufferEnqueue(&p_omaproc->rb, (char *)&ommsg, sizeof(ommsg_t));
}

int oma_wait(omaproc_t *p_omaproc, nonbsock_t *p_nonb, fd_set *rset, int usec)
{
	struct timeval timeo;
	
	FNDEBUG(TASK_OMA);
	if (p_nonb->pstatus == TST_CONNECTING) {
		if (comWritableTimeo(p_nonb->psockfd, 0) > 0) {
			appNonbsockUpdate(p_nonb, TST_CONNECTED);
		}
	}

	FNDEBUG(TASK_OMA);
	timeo.tv_sec  = 0;
	timeo.tv_usec = usec;
	memcpy(rset, &p_omaproc->rmask, sizeof(fd_set));

	FNDEBUG(TASK_OMA);
	return select(p_omaproc->maxfd, rset, NULL, NULL, &timeo);
}

int oma_proc(omaproc_t *p_omaproc, nonbsock_t *p_nonb, fd_set *rset)
{
	omshandle_t *p_omshandle = &p_omaproc->omshandle;
	ommsgwrap_t *p_wrap      = &p_omshandle->recvwrap;
	int n;

	FNDEBUG(TASK_OMA);
	if (!FD_ISSET(p_nonb->psockfd, rset)) { return 0; }

	FNDEBUG(TASK_OMA);
	while ((n = omaOmMesgRecvTcp(p_nonb, p_wrap)) > 0) {
		switch (p_wrap->ommsg.h.opflag) {
			case OMT_BIND_RES  : proc_bindres (p_omaproc, p_nonb, p_wrap); break;
			case OMT_LINK_RES  : break;
			case OMT_TRACE_ON  : proc_traceon (p_omaproc, p_nonb, p_wrap); break;
			case OMT_TRACE_OFF : proc_traceoff(p_omaproc, p_nonb, p_wrap); break;
			default            :
				comLog(WA, "%s() INVALID MESSAGE - MID(%04x) n(%d)", __func__, p_wrap->ommsg.h.opflag, n);
				break;
		}
	}

	FNDEBUG(TASK_OMA);
	if (n == -1) { appNonbsockClose(p_nonb); }

	return 0;
}

/* PROC */
void proc_bindres(omaproc_t *p_omaproc, nonbsock_t *p_nonb, ommsgwrap_t *p_wrap)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;

	FNDEBUG(TASK_OMA);
	if (p_ommsg->bindres.result != OMR_EOK) {
		comLog(WA, "%s() BIND FAILED (%d)", __func__, p_ommsg->bindres.result);
		appNonbsockClose(p_nonb);
		return;
	}

	FNDEBUG(TASK_OMA);
	appNonbsockUpdate(p_nonb, TST_KIN);

	return;
}

void proc_traceon(omaproc_t *p_omaproc, nonbsock_t *p_nonb, ommsgwrap_t *p_wrap)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;

	FNDEBUG(TASK_OMA);
	omaTraceStart(&p_omaproc->tracelist, &p_ommsg->traceon);

	return;
}

void proc_traceoff(omaproc_t *p_omaproc, nonbsock_t *p_nonb, ommsgwrap_t *p_wrap)
{
	ommsg_t *p_ommsg = &p_wrap->ommsg;

	FNDEBUG(TASK_OMA);
	omaTraceStop(&p_omaproc->tracelist, comProtoI642Long(&p_ommsg->traceoff.trace_id));

	return;
}

int oma_timer(omaproc_t *p_omaproc, nonbsock_t *p_nonb)
{
	FNDEBUG(TASK_OMA);
	timer_check_nonbsock(p_omaproc, p_nonb);

	FNDEBUG(TASK_OMA);
	if (p_nonb->psockfd > 0) {
		FNDEBUG(TASK_OMA);
		if (appNonbsockCheckCurrW(p_nonb) > 0
				&& comWritableTimeo(p_nonb->psockfd, 0) > 0
				&& appNonbsockFlush(p_nonb) == -1)
		{
			appNonbsockClose(p_nonb);
		}
	}

	return 0;
}

void timer_check_nonbsock(omaproc_t *p_omaproc, nonbsock_t *p_nonb)
{
	time_t current = comTime();

	FNDEBUG(TASK_OMA);
	switch (p_nonb->pstatus) {
		case TST_CLOSED     : FNDEBUG(TASK_OMA);
			if ((current - p_nonb->chgtime) >= pOmaProfile->OnmLinkIdleSec) {
				/* init sock */
				appNonbsockInit(p_nonb, "PMON", &p_omaproc->maxfd, &p_omaproc->rmask, &p_omaproc->wmask);

				/* init wrap */
				memset(&p_omaproc->omshandle.recvwrap, 0x00, sizeof(ommsgwrap_t));

				/* then, connect */
				appNonbsockConnect(p_nonb, p_omaproc->omshandle.omshost, p_omaproc->omshandle.omsport);
			}
			break;

		case TST_CONNECTED  : FNDEBUG(TASK_OMA);
			if (omaOmMesgSendBindReq(p_nonb, &p_omaproc->omshandle.sendwrap, p_omaproc->key, p_omaproc->svr_status) != -1) {
				appNonbsockUpdate(p_nonb, TST_BINDING);
			}
			break;

		case TST_CONNECTING : FNDEBUG(TASK_OMA);
			if (comWritableTimeo(p_nonb->psockfd, 0) > 0) {
				appNonbsockUpdate(p_nonb, TST_CONNECTED);
			}
			else if ((current - p_nonb->chgtime) >= pOmaProfile->OnmLinkIdleSec) {
				comLog(TR, "%s() BORED......", __func__);
				appNonbsockClose(p_nonb);
			}
			break;

		case TST_BINDING    : FNDEBUG(TASK_OMA);
			if ((current - p_nonb->chgtime) >= pOmaProfile->OnmLinkIdleSec) {
				comLog(TR, "%s() BORED......", __func__);
				appNonbsockClose(p_nonb);
			}
			break;

		case TST_KIN        : FNDEBUG(TASK_OMA);
			if ((current - p_nonb->rcvtime) >= pOmaProfile->OnmLinkLostSec) {
				comLog(ER, "%s() IDLE OMS FOUND...", __func__);
				appNonbsockClose(p_nonb);
				break;
			}
			if ((current - p_nonb->pngtime) >= pOmaProfile->OnmLinkIdleSec) {
				omaOmMesgSendLinkReq(p_nonb, &p_omaproc->omshandle.sendwrap);
				p_nonb->pngtime = current;
			}
			break;
	}

	return ;
}

int oma_ring(omaproc_t *p_omaproc, nonbsock_t *p_nonb)
{
	ommsgwrap_t *p_wrap  = &p_omaproc->omshandle.sendwrap;
	ommsg_t     *p_ommsg = &p_wrap->ommsg;
	int          cc;

	FNDEBUG(TASK_OMA);
	cc = comRingBufferDequeue(&p_omaproc->rb, (char *)p_ommsg, sizeof(ommsg_t));
	if (cc != sizeof(ommsg_t)) {
		if (cc != 0) {
			comLog(ER, "%s() RING FAILED - CC(%d)", __func__, cc);
			return -1;
		}
		return 0;
	}

	FNDEBUG(TASK_OMA);
	if (p_nonb->pstatus != TST_KIN) {
		comLog(WA, "NO CONNECTION WITH OMS. DISCARD THIS...");
		return 0;
	}

	FNDEBUG(TASK_OMA);
	if ((cc = omaOmMesgSendTcp(p_nonb, p_wrap)) == -1) {
		appNonbsockClose(p_nonb);
	}

	return cc;
}

