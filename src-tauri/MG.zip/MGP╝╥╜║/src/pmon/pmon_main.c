/**
 * @date   2012/08/23
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */
#include "pmon.h"

/* for debug */
#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_MAIN, __LINE__)

/* for PMON main */
pmonmagic_t   Oz;
pmonmagic_t *pOz = &Oz;

int    sHealthChecked = 0;
time_t sHealthCheckTime = 0;

/* main.. */
int main(int argc, char **argv)
{
	fd_set rset;
	time_t currtime = 0;
	int    cc, usec = 100000;

	/* init LogLevel */
	comLogLevelSet(IN);

	/* INITIALIZE */
	if (initialize(argc, argv) == -1) {
		comLog(ER, "fail to initialize.");
		exit(1);
	}

	/* NEVER DIE!! */
	FNDEBUG(TASK_MAIN);
	while (Oz.running) {
		currtime = comTime();

		/* PROC WITH SOCK */
		FNDEBUG(TASK_MAIN);
		cc = wait_for(&rset, usec);
		switch (cc) {
			case 0 : break;
			case -1:
				FNDEBUG(TASK_MAIN);
				if (errno != EINTR) {
					FNDEBUG(TASK_MAIN);
					comErr(ER, errno, "fail to select.");
					terminate(98);
				}
				break;

			default :
				FNDEBUG(TASK_MAIN);
				proc_with(&rset, currtime);
				break;
		}

		/* PROC WITH TIMER */
		FNDEBUG(TASK_MAIN);
		proc_timer(currtime);
	}

	/* TERMINATE */
	FNDEBUG(TASK_MAIN);
	terminate(99);

	return 0;
}

int wait_for(fd_set *rset, int usec)
{
	struct timeval timeo;

	/* CHECK INPUT EVENT */
	FNDEBUG(TASK_MAIN);
	timeo.tv_sec  = 0;
	timeo.tv_usec = usec;
	memcpy(rset, &Oz.rmask, sizeof(fd_set));

	FNDEBUG(TASK_MAIN);
	return select(pOz->maxfd, rset, NULL, NULL, &timeo);
}

int proc_with(fd_set *rset, time_t currtime)
{
	FNDEBUG(TASK_MAIN);
	if (FD_ISSET(pOz->np.pipefd[0], rset)) {
		comLog(DG, "%s() - ready to process with pipe!!", __func__);
		appPipeSignalled(&pOz->np);
	}

	return 0;
}

void proc_health_check(time_t currtime)
{
	FNDEBUG(TASK_MAIN);
	if ((currtime - sHealthCheckTime) < 5) {
		return;
	}
	sHealthCheckTime = currtime;

	FNDEBUG(TASK_MAIN);
	pProfile->SCFTcpFaultDuration = appProfileGetFaultDuration();

	FNDEBUG(TASK_MAIN);
	if (sHealthChecked || pProfile->AutoRecoveryPeriodSec < 60) {
		return;
	}

	FNDEBUG(TASK_MAIN);
	if (pProfile->SCFTcpFaultDuration > pProfile->AutoRecoveryPeriodSec) {
		sHealthChecked = 1;
		comLog(ER, "%s() - run autoDiscovery... duration: %d[%d]",
				__func__, pProfile->SCFTcpFaultDuration, pProfile->AutoRecoveryPeriodSec);

		/* reboot!! */
		appCLI_reboot();
	}

	return;
}

int proc_timer(time_t currtime)
{
	FNDEBUG(TASK_MAIN);
	comLogLevelSet(pProfile->LogLevel);

	FNDEBUG(TASK_MAIN);
	proc_slave_check(currtime);

	FNDEBUG(TASK_MAIN);
	proc_health_check(currtime);

	return 0;
}

void sighandler(int signo)
{
	Oz.running = FALSE;
}
void sigignore(int signo)
{
	;
}

/* parse */
int parse_args(int argc, char **argv)
{
	return 0;
}

int pmonmagic_init()
{
	int lsnrfd = 0;

	/* init Oz */
	memset(pOz, 0x00, sizeof(pmonmagic_t));

	/* check running?? */
	if ((lsnrfd = appNonbsockListen(NULL, PMON_TCP_PORT)) == -1 || lsnrfd == 0) {
		comLog(ER, "fail to appNonbsockListen() - error:%d(%s)", errno, strerror(errno));
		return -1;
	}

	/* running... */
	pOz->running = TRUE;

    //
	appPipeOpen(&pOz->np, "PMON", &pOz->maxfd, &pOz->rmask, &pOz->wmask);

	return 0;
}

int initialize(int argc, char **argv)
{
	/* parse args */
	if (parse_args(argc, argv) == -1) {
		comErr(ER, errno, "fail to parse.");
		return -1;
	}

	/* init appP */
	if (appInitialize(APP_SHM_KEY, PMON, 0) == -1) {
		comErr(ER, errno, "fail to appInitialize.");
		return -1;
	}

#if 0
	if (comPidFileLock("PMON", ApInstId, (int)getpid()) == -1) {
		comLog(ER, "%s() ALREADY RUNNING.", __func__);
		return -1;
	}
#endif
	if (appDaemonInit("PMON", TRUE) == -1) {
		comErr(ER, errno, "fail to appDaemonInit.");
		return -1;
	}
	if (pmonmagic_init() == -1) {
		comErr(ER, errno, "fail to pmonmagic_init.");
		return -1;
	}

	/* Install signal */
	/*comInstallSignal(SIGINT , sigignore);*/
	comInstallSignal(SIGTERM, sigignore);
	comInstallSignal(SIGCHLD, sigignore);

	/* Welcome... */
	appWelcome(argv[0]);
	appP->slaveholder.mpid     = getpid();
	appP->slaveholder.strttime = comTime();

	/* init IUID */
	pProfile->IUID = 0;

	return 0;
}

int terminate(int code)
{
	sleep(1);

	/* update mpid */
	appP->slaveholder.mpid = 0;

	/* terminate self.. */
	comGoodbye(code);
	exit(code);

	return 0;
}

