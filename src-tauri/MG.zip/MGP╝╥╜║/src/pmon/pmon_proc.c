/**
 * @date   2012/07/20
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */
#include "pmon.h"

/* for debug */
#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_PROC, __LINE__)

int proc_slave_check(time_t currtime)
{
	static time_t prevtime;

	/* every 1 seconds... */
	FNDEBUG(TASK_MAIN);
	if (currtime == prevtime) { return 0; }
	prevtime = currtime;

	/* check stopflag */
	FNDEBUG(TASK_MAIN);
	if (appP->slaveholder.stopflag) {
		FNDEBUG(TASK_MAIN);
		int passed  = currtime - appP->slaveholder.stoptime;
		int running = appSlaveCountLive(&appP->slaveholder);

		/* :( ... */
		comLog(WA, "stop request is procssing..... (%d sec passed, %d slaves are running)", passed, running);
		if (passed > 120 || running == 0) {
			Oz.running = FALSE;
			return -1;
		}
	}

	/* check slave */
	FNDEBUG(TASK_MAIN);
	if (slave_watchout(&appP->slaveholder, currtime) == -1) {
		Oz.running = FALSE;
		return -1;
	}

	return 0;
}
