/**
 * @date   2012/08/23
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "pmon.h"

#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_SLAVE, __LINE__)

int slave_load(slaveinfo_t *p_slaveinfo, time_t currtime)
{
	int   pid;
	char *runningdir = NULL;
	char  logfile[128], path[128];

	FNDEBUG(TASK_MAIN);
	if (strlen(p_slaveinfo->runningdir) != 0) { runningdir = p_slaveinfo->runningdir; }
	else                                      { runningdir = comGetHome();            }

	FNDEBUG(TASK_MAIN);
	memset(path, 0x00, sizeof(path));
	if (pProfile->Logging != 0) {
		sprintf      (logfile, "%s.out", p_slaveinfo->alias);
		comGetLogPath(logfile, path); 
	}

	FNDEBUG(TASK_MAIN);
	if ((pid = lp_load(p_slaveinfo->cmdpath, p_slaveinfo->cmdline, runningdir, path)) == -1) {
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	appSlaveUpdateStatus(p_slaveinfo, SL_ST_LIVE, pid, currtime);

	return 0;
}

int slave_stop(slaveinfo_t *p_slaveinfo, time_t currtime)
{
	int   pid;
	char *runningdir = NULL;

	FNDEBUG(TASK_MAIN);
	if (p_slaveinfo->pid <= 0) {
		return 0;
	}

	FNDEBUG(TASK_MAIN);
	if (strlen(p_slaveinfo->runningdir) != 0) { runningdir = p_slaveinfo->runningdir; }
	else                                      { runningdir = comGetHome();            }

	FNDEBUG(TASK_MAIN);
	if (strlen(p_slaveinfo->stopline) > 1) {
		FNDEBUG(TASK_MAIN);
		if ((pid = lp_load(p_slaveinfo->stoppath, p_slaveinfo->stopline, runningdir, NULL)) == -1) {
			comErr(ER, errno, "%s() fail to Stop(%s) slave(%d, %s)",
					__func__, p_slaveinfo->stopline, p_slaveinfo->pid, p_slaveinfo->alias);
		}
	}
	else {
		FNDEBUG(TASK_MAIN);
		if (kill(p_slaveinfo->pid, SIGTERM) == -1) {
			comErr(ER, errno, "%s() fail to kill(SIGTERM) slave(%d, %s)", __func__, p_slaveinfo->pid, p_slaveinfo->alias);
		}
	}

	FNDEBUG(TASK_MAIN);
	appSlaveUpdateStatus(p_slaveinfo, SL_ST_STOP, 0, currtime);

	return 0;
}

int slave_kill(slaveinfo_t *p_slaveinfo, time_t currtime)
{
	FNDEBUG(TASK_MAIN);
	if (p_slaveinfo->pid <= 0) {
		return 0;
	}

	FNDEBUG(TASK_MAIN);
	if (kill(p_slaveinfo->pid, SIGKILL) == -1) {
		comErr(ER, errno, "%s() fail to kill(SIGKILL) slave(%d, %s)",
				__func__, p_slaveinfo->pid, p_slaveinfo->alias);
	}

	FNDEBUG(TASK_MAIN);
	appSlaveUpdateStatus(p_slaveinfo, SL_ST_KILL, 0, currtime);

	return 0;
}

int slave_wait(slaveholder_t *p_slaveholder, time_t currtime)
{
	slaveinfo_t *p_slaveinfo;
	int          deadpid, statloc = 0;

	FNDEBUG(TASK_MAIN);
	while ((deadpid = waitpid(-1, &statloc, WNOHANG)) > 0) {
		/* show the dead status */
		comLog(WA, "Child Dead PID(%d) WIFEXITED(%d) WEXITSTATUS(%d) WIFSIGNALED(%d) WTERMSIG(%d)",
				deadpid, WIFEXITED(statloc), WEXITSTATUS(statloc), WIFSIGNALED(statloc), WTERMSIG(statloc));

		/* search the dead */
		if ((p_slaveinfo = appSlaveSearchByPid(p_slaveholder, deadpid)) != NULL) {
			FNDEBUG(TASK_MAIN);
			p_slaveinfo->statloc = statloc;
			appSlaveUpdateStatus(p_slaveinfo, SL_ST_DOWN, 0, currtime);
		}
	}

	return 0;
}

int slave_watchout(slaveholder_t *p_slaveholder, time_t currtime)
{
	int          i;
	slaveinfo_t *p_slaveinfo = NULL;

	/* check dead */
	FNDEBUG(TASK_MAIN);
	slave_wait(p_slaveholder, currtime);

	/* down --> live */
	FNDEBUG(TASK_MAIN);
	if (!p_slaveholder->stopflag) {
		FNDEBUG(TASK_MAIN);
		for (i = 0; i < p_slaveholder->used; i++) {
			p_slaveinfo = p_slaveholder->slaveinfo + i;
			if (appSlaveCheckLoad(p_slaveinfo, currtime) == LC_RES_OK) {
				FNDEBUG(TASK_MAIN);
				if (slave_load(p_slaveinfo, currtime) != 0) {
					comLog(ER, "Can't Load Process..... How come?");
					return -1;
				}

				/* only one in every seconds */
				break;
			}
		}
	}

	/* live --> down */
	FNDEBUG(TASK_MAIN);
	for (i = p_slaveholder->used; i >= 0; i--) {
		p_slaveinfo = p_slaveholder->slaveinfo + i;

		/* to down.... */
		if ((p_slaveholder->stopflag
					|| p_slaveinfo->blocked)
					&& p_slaveinfo->status == SL_ST_LIVE)
		{
			slave_stop(p_slaveinfo, currtime);
			break;
		}
		if (p_slaveinfo->status == SL_ST_STOP
				&& (currtime - p_slaveinfo->chgtime) >= p_slaveinfo->stoptimeo)
		{
			slave_kill(p_slaveinfo, currtime);
			break;
		}
	}

	return 0;
}
