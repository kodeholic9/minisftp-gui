/**
 * @date   2016/07/27
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "librms.h"

/** ----------------------------------------------------- */
int rmsScMesgValid(scmsg_t *p_scmsg)
{
	/* START BIT */
	if (p_scmsg->h.start_bit != SCM_STRT_BIT) {
		comLog(WA, "INVALID START BIT (0x%04x != 0x%04x)", p_scmsg->h.start_bit, SCM_STRT_BIT);
		return -1;
	}

	/* VERION */
	if (p_scmsg->h.version > SCM_VVER_BIT) {
		comLog(WA, "INVALID VERSION BIT (0x%04x > 0x%04x)", p_scmsg->h.version, SCM_VVER_BIT);
		return -1;
	}

	/* LENGTH */
	if (p_scmsg->h.command_length > MAX_SCDATA_LEN) {
		comLog(WA, "INVALID UEDATA LEN (%d > %d)", p_scmsg->h.command_length, MAX_SCDATA_LEN);
		return -1;
	}

	return 0;
}

void rmsScMesgNtohHead(scmsg_t *p_from, scmsg_t *p_ttoo)
{
	p_ttoo->h.command_id     = ntohs(p_from->h.command_id); 
	p_ttoo->h.command_length = ntohl(p_from->h.command_length);
	p_ttoo->h.payload_id     = ntohl(p_from->h.payload_id);
}

void rmsScMesgNtohData(scmsg_t *p_from, scmsg_t *p_ttoo)
{
	switch (p_ttoo->h.command_id) {
		case SCM_BIND_REQ  : break;
		case SCM_LEAV_REQ : break;
		case SCM_DATA_REQ:
			p_ttoo->datareq.fid    = ntohl(p_from->datareq.fid);
			p_ttoo->datareq.action = ntohl(p_from->datareq.action);
			break;

		case SCM_DATA_RES:
			p_ttoo->datares.action_ack = ntohl(p_from->datares.action_ack);
			break;
	}
}

void rmsScMesgHtonHead(scmsg_t *p_from, scmsg_t *p_ttoo)
{
	p_ttoo->h.command_id     = htons(p_from->h.command_id); 
	p_ttoo->h.command_length = htonl(p_from->h.command_length);
	p_ttoo->h.payload_id     = htonl(p_from->h.payload_id);
}

void rmsScMesgHtonData(scmsg_t *p_from, scmsg_t *p_ttoo)
{
	switch (p_from->h.command_id) {
		case SCM_BIND_REQ  : break;
		case SCM_LEAV_REQ : break;
		case SCM_DATA_REQ  :
			p_ttoo->datareq.fid    = htonl(p_from->datareq.fid);
			p_ttoo->datareq.action = htonl(p_from->datareq.action);
			break;

		case SCM_DATA_RES  : 
			p_ttoo->datares.action_ack = htonl(p_from->datares.action_ack);
			break;
	}
}

#if 0
static int decode(psockbuffer_t *p_psbuffer, void *data)
{
	int         current  = p_psbuffer->d.limit - p_psbuffer->d.pos;
	ueheader_t *p_header = NULL;
	int         oplength = 0;

	/* check more header */
	if (current >= sizeof(ueheader_t)) {
		/* check more data */
		p_header = (ueheader_t *)(p_psbuffer->d.data);
		oplength = ntohs(p_header->command_length);
		if (oplength > MAX_UEDATA_LEN) {
			comLog(WA, "%s() Too Long (%u)", __func__, oplength);
			return -1;
		}

		/* check more data */
		if (current >= sizeof(ueheader_t) + oplength) {
			memcpy(data, p_psbuffer->d.data, sizeof(ueheader_t) + oplength);
			return sizeof(ueheader_t) + oplength;
		}
	}

	return 0;
}

int rmsScMesgRecvTcp(psock_t *p_psock, scmsgwrap_t *p_wrap)
{
	/* init */
	memset(p_wrap, 0x00, sizeof(scmsgwrap_t));

	/* read */
	if ((p_wrap->limit = pathPSockBufferedRead(p_psock, decode, &p_wrap->ueraw)) > 0) {
		/* makeup the replica */
		memcpy(p_wrap->scmsg.data, p_wrap->ueraw.data, p_wrap->limit);
	}

	return p_wrap->limit;
}

int rmsScMesgSendTcp(psockctl_t *p_psockctl, psock_t *p_psock, scmsgwrap_t *p_wrap)
{
	return pathPSockBufferedWrite(p_psockctl, p_psock, &p_wrap->ueraw, p_wrap->limit);
}
#endif

int rmsScMesgRecvTcp(nonbsock_t *p_nonbsock, scmsgwrap_t *p_wrap)
{
	int n = 0;

	/* prepare */
	if (p_wrap->readdone) {
		p_wrap->readdone = FALSE;
		memset(p_wrap, 0x00, sizeof(scmsgwrap_t));
	}

	/* for HEAD PART */
	if (p_wrap->limit < sizeof(scheader_t)) {
		if ((n = appNonbsockRecv(
						p_nonbsock,
						p_wrap->uemsg.data + p_wrap->limit,
						p_wrap->ueraw.data + p_wrap->limit,
						sizeof(scheader_t) - p_wrap->limit)) == -1)
		{
			return -1;
		}

		if ((p_wrap->limit += n) != sizeof(scheader_t)) {
			return 0;
		}

		rmsScMesgNtohHead(&p_wrap->ueraw, &p_wrap->uemsg);
	}

	/* for DATA PART */
	if (p_wrap->uemsg.h.command_length > MAX_SCDATA_LEN) {
		comLog(ER, "Too Long (%u)", p_wrap->uemsg.h.command_length);
		return -1;
	}
	if (p_wrap->uemsg.h.command_length > 0) {
		if ((n = appNonbsockRecv(
						p_nonbsock,
						p_wrap->uemsg.data + p_wrap->limit,
						p_wrap->ueraw.data + p_wrap->limit,
						p_wrap->uemsg.h.command_length + sizeof(scheader_t) - p_wrap->limit)) == -1)
		{
			return -1;
		}
		if ((p_wrap->limit += n) != (p_wrap->uemsg.h.command_length + sizeof(scheader_t))) {
			return 0;
		}
		rmsScMesgNtohData(&p_wrap->ueraw, &p_wrap->uemsg);
	}

	/* for debug */
	rmsScMesgTrace(DG, p_nonbsock->name, ">", p_wrap);

	/* update the limit for the next mesg */
	p_wrap->readdone = TRUE;

	return p_wrap->limit;
}

int rmsScMesgSendTcp(nonbsock_t *p_nonbsock, scmsgwrap_t *p_wrap)
{
	int cc;

	/* check */
	if (p_nonbsock->psockfd == 0) {
		comLog(ER, "%s() - not connected!!", __func__);
		return -1;
	}

	/* copy */
	memcpy(p_wrap->ueraw.data, p_wrap->uemsg.data, sizeof(scmsg_t));

	/* byte ordering */
	rmsScMesgHtonHead(&p_wrap->uemsg, &p_wrap->ueraw);
	rmsScMesgHtonData(&p_wrap->uemsg, &p_wrap->ueraw);
	p_wrap->limit = sizeof(scheader_t) + p_wrap->uemsg.h.command_length;

	/* then send */
	if ((cc = appNonbsockSend(p_nonbsock, p_wrap->ueraw.data, p_wrap->limit)) > 0) {
		rmsScMesgTrace(DG, p_nonbsock->name, "<", p_wrap);
	}

	return cc;
}

void rmsScMesgTrace(int lg, char *name, char *dir, scmsgwrap_t *p_wrap)
{
	char buff[8192];
	int  n = 0;

#if 0
	if (p_wrap->uemsg.h.command_id == SCM_PING_REQ
			|| p_wrap->uemsg.h.command_id == SCM_PING_RES)
	{
		return;
	}
#endif

	/* HEAD PART */
	n = snprintf(buff, sizeof(buff), "[%s] %s %s(0x%04x) V(%02x:%02x) P(%u) L(%d) | R(%u)",
			name,
			dir,
			appCodeMap2Str(CC_CmCmdId, p_wrap->uemsg.h.command_id),
			p_wrap->uemsg.h.command_id,
			p_wrap->uemsg.h.start_bit,
			p_wrap->uemsg.h.version,
			p_wrap->uemsg.h.payload_id,
			p_wrap->uemsg.h.command_length,
			p_wrap->uemsg.h.result);

	/* DATA PART */
	switch (p_wrap->uemsg.h.command_id) {
		case SCM_BIND_REQ :
			n = snprintf(buff + n, sizeof(buff), " | %lu %s %s %s",
						comProtoIuid2Long(&p_wrap->uemsg.bindreq.from),
						p_wrap->uemsg.bindreq.from_mdn,
						p_wrap->uemsg.bindreq.app_type,
						p_wrap->uemsg.bindreq.auth_key);
			break;

		case SCM_BIND_RES : 
			break;

		case SCM_DATA_REQ :
			n = snprintf(buff + n, sizeof(buff), " | A(%u) D(%s)", p_wrap->uemsg.datareq.action, p_wrap->uemsg.datareq.data);
			break;

		case SCM_DATA_RES :
			n = snprintf(buff + n, sizeof(buff), " | D(%s)", p_wrap->uemsg.datares.ack_data);
			break;
	}

	comLog    (IN, "%s", buff);
	comDumpRaw(DG, (unsigned char *)&p_wrap->ueraw.data, p_wrap->limit);

	return;
}


void rmsScMesgPackPingReq(scmsg_t *p_scmsg, long uid, int pid)
{
	memset(p_scmsg, 0x00, sizeof(scmsg_t));

	/* -------- header part */
	p_scmsg->h.start_bit      = SCM_STRT_BIT;
	p_scmsg->h.version        = SCM_VVER_BIT;
	p_scmsg->h.command_id     = SCM_PING_REQ;
	p_scmsg->h.command_length = sizeof(scpingreq_t) - sizeof(scheader_t);
	p_scmsg->h.payload_id     = pid;
	p_scmsg->h.acctype        = SCM_AC_LTE;
	comProtoLong2Iuid(uid, &p_scmsg->h.uid);

	return ;
}

void rmsScMesgPackPingRes(scmsg_t *p_scmsg, long uid, int pid, int result)
{
	memset(p_scmsg, 0x00, sizeof(scmsg_t));

	/* -------- header part */
	p_scmsg->h.start_bit      = SCM_STRT_BIT;
	p_scmsg->h.version        = SCM_VVER_BIT;
	p_scmsg->h.command_id     = SCM_PING_RES;
	p_scmsg->h.command_length = sizeof(scpingres_t) - sizeof(scheader_t);
	p_scmsg->h.payload_id     = pid;
	p_scmsg->h.acctype        = SCM_AC_LTE;
	p_scmsg->h.result         = result;
	comProtoLong2Iuid(uid, &p_scmsg->h.uid);

	/* -------- data part */

	return ;
}

void rmsScMesgPackBindReq(scmsg_t *p_scmsg, long uid, int pid, char *from_mdn, char *app_type, char *auth_key)
{
	memset(p_scmsg, 0x00, sizeof(scmsg_t));

	/* -------- header part */
	p_scmsg->h.start_bit      = SCM_STRT_BIT;
	p_scmsg->h.version        = SCM_VVER_BIT;
	p_scmsg->h.command_id     = SCM_BIND_REQ;
	p_scmsg->h.command_length = sizeof(scbindreq_t) - sizeof(scheader_t);
	p_scmsg->h.payload_id     = pid;
	p_scmsg->h.acctype        = SCM_AC_LTE;
	comProtoLong2Iuid(uid, &p_scmsg->h.uid);

	/* -------- data part */
	comProtoLong2Iuid(uid, &p_scmsg->bindreq.from);
	strncpy(p_scmsg->bindreq.from_mdn, from_mdn, MAX_MDN_LEN);
	strncpy(p_scmsg->bindreq.app_type, app_type, MAX_APPTYPE_LEN);
	strncpy(p_scmsg->bindreq.auth_key, auth_key, MAX_AUTHKEY_LEN);
	strncpy(p_scmsg->bindreq.region_code, "KR" , MAX_REGIONCODE_LEN);
	p_scmsg->bindreq.app_market = 0;

	return ;
}


void rmsScMesgPackBindRes(scmsg_t *p_scmsg, long uid, int pid, int status, int result)
{
	memset(p_scmsg, 0x00, sizeof(scmsg_t));

	/* -------- header part */
	p_scmsg->h.start_bit      = SCM_STRT_BIT;
	p_scmsg->h.version        = SCM_VVER_BIT;
	p_scmsg->h.command_id     = SCM_BIND_RES;
	p_scmsg->h.command_length = sizeof(scbindres_t) - sizeof(scheader_t);
	p_scmsg->h.payload_id     = pid;
	p_scmsg->h.acctype        = SCM_AC_LTE;
	p_scmsg->h.result         = result;
	comProtoLong2Iuid(uid, &p_scmsg->h.uid);

	/* -------- data part */

	return ;
}

void rmsScMesgPackLeavReq(scmsg_t *p_scmsg, long uid, int pid)
{
	memset(p_scmsg, 0x00, sizeof(scmsg_t));

	/* -------- header part */
	p_scmsg->h.start_bit      = SCM_STRT_BIT;
	p_scmsg->h.version        = SCM_VVER_BIT;
	p_scmsg->h.command_id     = SCM_LEAV_REQ;
	p_scmsg->h.command_length = sizeof(scleavereq_t) - sizeof(scheader_t);
	p_scmsg->h.payload_id     = pid;
	p_scmsg->h.acctype        = SCM_AC_LTE;
	comProtoLong2Iuid(uid, &p_scmsg->h.uid);

	/* -------- data part */
	comProtoLong2Iuid(uid, &p_scmsg->leavereq.from);

	return ;
}

void rmsScMesgPackLeavRes(scmsg_t *p_scmsg, long uid, int pid, int result)
{
	memset(p_scmsg, 0x00, sizeof(scmsg_t));

	/* -------- header part */
	p_scmsg->h.start_bit      = SCM_STRT_BIT;
	p_scmsg->h.version        = SCM_VVER_BIT;
	p_scmsg->h.command_id     = SCM_LEAV_RES;
	p_scmsg->h.command_length = sizeof(scleaveres_t) - sizeof(scheader_t);
	p_scmsg->h.payload_id     = pid;
	p_scmsg->h.acctype        = SCM_AC_LTE;
	p_scmsg->h.result         = result;
	comProtoLong2Iuid(uid, &p_scmsg->h.uid);

	/* -------- data part */

	return ;
}

void rmsScMesgPackDataReq(scmsg_t *p_scmsg, long uid, int pid, long ttoo, long sid, int action, char *data)
{
	int cmdlen;

	/* init */
	memset(p_scmsg, 0x00, sizeof(scmsg_t));

	//
	cmdlen = sizeof(scdatareq_t) - sizeof(scheader_t);
	if (data != NULL) {
		cmdlen += strlen(data);
	}

	/* -------- header part */
	p_scmsg->h.start_bit      = SCM_STRT_BIT;
	p_scmsg->h.version        = SCM_VVER_BIT;
	p_scmsg->h.command_id     = SCM_DATA_REQ;
	p_scmsg->h.command_length = cmdlen;
	p_scmsg->h.payload_id     = pid;
	p_scmsg->h.acctype        = SCM_AC_LTE;
	comProtoLong2Iuid(uid, &p_scmsg->h.uid);

	/* -------- data part */
	comProtoLong2Iuid(uid , &p_scmsg->datareq.from);
	comProtoLong2Iuid(ttoo, &p_scmsg->datareq.ttoo);
	comProtoLong2Sid (sid , &p_scmsg->datareq.sid);

	p_scmsg->datareq.fid    = SCM_SERVICE_FEATURE_ID; 
	p_scmsg->datareq.action = action; 
	p_scmsg->datareq.comm_flag   = 0; 
	p_scmsg->datareq.group_flag  = 0; 
	p_scmsg->datareq.store_flag  = 0; 
	p_scmsg->datareq.pending_flag= 0; 

	comProtoLong2Datetime(comTime(), &p_scmsg->datareq.incoming_time);

	/* -------- payload part */
	if (data != NULL && strlen(data) != 0) {
		memcpy(p_scmsg->datareq.data, data, strlen(data));
	}

	return;
}

void rmsScMesgPackDataRes(scmsg_t *p_scmsg, long uid, int pid, int result, char *ack_data)
{
	int cmdlen;

	memset(p_scmsg, 0x00, sizeof(scmsg_t));

	//
	cmdlen = sizeof(scdatares_t) - sizeof(scheader_t);
	if (ack_data != NULL) {
		cmdlen = strlen(ack_data);
	}

	/* -------- header part */
	p_scmsg->h.start_bit      = SCM_STRT_BIT;
	p_scmsg->h.version        = SCM_VVER_BIT;
	p_scmsg->h.command_id     = SCM_DATA_RES;
	p_scmsg->h.command_length = cmdlen;
	p_scmsg->h.payload_id     = pid;
	p_scmsg->h.acctype        = SCM_AC_LTE;
	p_scmsg->h.result         = result;
	comProtoLong2Iuid(uid, &p_scmsg->h.uid);

	/* -------- data part */
	p_scmsg->datares.action_ack = 0;
	p_scmsg->datares.displayed  = 0;
	comProtoLong2Datetime(comTime(), &p_scmsg->datares.incoming_time);

	/* -------- payload part */
	if (ack_data != NULL && strlen(ack_data) != 0) {
		memcpy(p_scmsg->datares.ack_data, ack_data, strlen(ack_data));
	}

	return ;
}

