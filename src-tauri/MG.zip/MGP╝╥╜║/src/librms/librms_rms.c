/**
 * @date   2016/07/25
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "librms.h"
#include <sys/time.h>

char *replace(char *str)
{
	char *ibuf, *obuf;

	//printf("str: %s\n", str);

	ibuf = obuf = str;
	if (str) {
		while (*ibuf) {
			//printf("ibuf: %c, obuf: %c\n", *ibuf, *obuf);
		   	if (!isspace((int)*ibuf) && *ibuf != '-') {
				*obuf = *ibuf;
				obuf++;
			}
			ibuf++;
		}
		*obuf = '\0';
	}

	return (str);
}

char *rmsGetISO8601(char *s, size_t len)
{
	struct timeval Tv;
	struct tm      Tm;
	int  millis;
	char tmp1[24], tmp2[24];

	gettimeofday(&Tv, NULL);

	strftime(tmp1, sizeof(tmp1), "%FT%T", localtime_r(&Tv.tv_sec, &Tm));
	strftime(tmp2, sizeof(tmp2), "%z"   , localtime_r(&Tv.tv_sec, &Tm));

	millis = Tv.tv_usec / 1000;

	snprintf(s, len, "%s.%03d%s", tmp1, millis, tmp2);

	return s;
}

char *rmsGetTimestamp(char *s, size_t len)
{
	struct timeval Tv;
	struct tm Tm;
	int  millis;
	char tmp1[24];

	gettimeofday(&Tv, NULL);

	strftime(tmp1, sizeof(tmp1), "%Y%m%d%H%M%S", localtime_r(&Tv.tv_sec, &Tm));

	millis = Tv.tv_usec / 1000;

	snprintf(s, len, "%s%03d", tmp1, millis);

	return s;
}

static char sCHARs[]     = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";    
static int  sCHAR_SZ     = (int) (sizeof(sCHARs) -1);
static int  sRAND_INITED = 0;

char *rmsGetUUID(char *s, size_t len)
{
	struct timeval Tv;
	int  i;
	char tmp[40 + 1];

	gettimeofday(&Tv, NULL);

	if (!sRAND_INITED) {
		srand(Tv.tv_sec);
		sRAND_INITED = 1;
	}

	for (i = 0 ; i < (sizeof(tmp) - 1); i++) {
		tmp[i] = sCHARs[rand() % sCHAR_SZ];
	}
	tmp[sizeof(tmp) - 1] = '\0';

	snprintf(s, len, "%s%05x", tmp, (int)Tv.tv_usec);

	return s;
}

