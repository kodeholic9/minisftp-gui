/**
 * @date   2016/07/28
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "librms.h"

static int EMPTY(char *s) 
{
	return (s == NULL || strlen(s) == 0) ? TRUE : FALSE;
}

/*****************************************************************/
/*                                                               */
/* phone                                                         */
/*                                                               */
/*****************************************************************/
json_t *rmsJsonPack_phone(j_phone_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	if (!EMPTY(obj->mobile)) json_object_set_new(json, "mobile", json_string(obj->mobile));
	if (!EMPTY(obj->home  )) json_object_set_new(json, "home"  , json_string(obj->home));
	if (!EMPTY(obj->office)) json_object_set_new(json, "office", json_string(obj->office));

	return json;
}

int rmsJsonUnpack_phone(json_t *json, j_phone_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (!json_is_object(json)) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "mobile" ) == 0) { rmsHttpGetJChar(value, "mobile" , obj->mobile, sizeof(obj->mobile)); }
		else if (strcmp(key, "home"   ) == 0) { rmsHttpGetJChar(value, "home"   , obj->home  , sizeof(obj->home));   }
		else if (strcmp(key, "office" ) == 0) { rmsHttpGetJChar(value, "office" , obj->office, sizeof(obj->office)); }
	}

	return 0;
}

/*****************************************************************/
/*                                                               */
/* contact                                                       */
/*                                                               */
/*****************************************************************/
json_t *rmsJsonPack_contact(j_contact_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	if (!EMPTY(obj->id     )) json_object_set_new(json, "id"     , json_string(obj->id));
	if (!EMPTY(obj->name   )) json_object_set_new(json, "name"   , json_string(obj->name));
	if (!EMPTY(obj->email  )) json_object_set_new(json, "email"  , json_string(obj->email));
	if (!EMPTY(obj->address)) json_object_set_new(json, "address", json_string(obj->address));
	if (!EMPTY(obj->gender )) json_object_set_new(json, "gender" , json_string(obj->gender));
	json_object_set_new(json, "phone"  , rmsJsonPack_phone(&obj->phone));
	
	return json;
}

int rmsJsonUnpack_contact(json_t *json, j_contact_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "id"     ) == 0) { rmsHttpGetJChar(value, "id"     , obj->id     , sizeof(obj->id)); }
		else if (strcmp(key, "name"   ) == 0) { rmsHttpGetJChar(value, "name"   , obj->name   , sizeof(obj->name)); }
		else if (strcmp(key, "email"  ) == 0) { rmsHttpGetJChar(value, "email"  , obj->email  , sizeof(obj->email)); }
		else if (strcmp(key, "address") == 0) { rmsHttpGetJChar(value, "address", obj->address, sizeof(obj->address)); }
		else if (strcmp(key, "gender" ) == 0) { rmsHttpGetJChar(value, "gender" , obj->gender , sizeof(obj->gender)); }
		else if (strcmp(key, "phone"  ) == 0) { rmsJsonUnpack_phone(value, &obj->phone); }
	}

	return 0;
}

/*****************************************************************/
/*                                                               */
/* contact array                                                 */
/*                                                               */
/*****************************************************************/
json_t *rmsJsonPack_contact_array(j_contact_t *obj, int size)
{
	json_t *json;
	int i;

	if ((json = json_array()) == NULL) {
		comLog(ER, "%s() failed to json_array()", __func__);
		return NULL;
	}

	for (i = 0; i < size; i++) {
		json_array_append_new(json, rmsJsonPack_contact(obj + i));
	}
	
	return json;
}

int rmsJsonUnpack_contact_array(json_t *json, j_contact_t *obj, int size)
{
	size_t  index;
	json_t *value;
	int     count;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_ARRAY) == -1) {
		comLog(WA, "%s() !array type", __func__);
		return -1;
	}
	
	count = 0;
	json_array_foreach(json, index, value) {
		comLog(DG, "%s() index........ %d", __func__, index);
		if (index < size) {
			rmsJsonUnpack_contact(value, obj + index);
			count++;
		}
	}

	return count;
}

/*****************************************************************/
/*                                                               */
/* user                                                          */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_user(j_user_t *obj, char *name)
{
	comLog(DG, "%s.iuid : %lu", name, obj->iuid);
	comLog(DG, "%s.name : %s" , name, obj->name);
	comLog(DG, "%s.mdn  : %s" , name, obj->mdn);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_user(j_user_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	json_object_set_new(json, "iuid", json_integer(obj->iuid));
	if (!EMPTY(obj->name)) json_object_set_new(json, "name", json_string(obj->name));
	if (!EMPTY(obj->mdn )) json_object_set_new(json, "mdn" , json_string(obj->mdn));
	
	return json;
}

int rmsJsonUnpack_user(json_t *json, j_user_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}

	memset(obj, 0x00, sizeof(j_user_t));
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "iuid") == 0) { obj->iuid = rmsHttpGetJLong(value, "iuid"); }
		else if (strcmp(key, "name") == 0) { rmsHttpGetJChar(value, "name", obj->name, sizeof(obj->name)); }
		else if (strcmp(key, "mdn" ) == 0) { rmsHttpGetJChar(value, "mdn" , obj->mdn , sizeof(obj->mdn)); }
	}

	return 0;
}

/*****************************************************************/
/*                                                               */
/* joinreq                                                       */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_joinreq(j_joinreq_t *obj, char *name)
{
	rmsJsonPrint_user(&obj->from, "joinreq.from");
	comLog(DG, "%s.ctype        : %s" , name, obj->ctype);
	comLog(DG, "%s.datetime     : %s" , name, obj->datetime);
	comLog(DG, "%s.mesg_id      : %s" , name, obj->mesg_id);
	comLog(DG, "%s.sid          : %lu", name, obj->sid);
	comLog(DG, "%s.telecom_code : %s" , name, obj->telecom_code);
	comLog(DG, "%s.password     : %s" , name, obj->password);
	comLog(DG, "%s.timestamp    : %s" , name, obj->timestamp);
	comLog(DG, "%s.src_ip       : %s" , name, obj->src_ip);
	comLog(DG, "%s.src_port     : %d" , name, obj->src_port);
	comLog(DG, "%s.src_tbcp_port: %d" , name, obj->src_tbcp_port);
	comLog(DG, "%s.codec        : %s" , name, obj->codec);
	comLog(DG, "%s.roaming      : %s" , name, obj->roaming);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_joinreq(j_joinreq_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	if (!EMPTY(obj->ctype    )) json_object_set_new(json, "content_type" , json_string(obj->ctype));
	if (!EMPTY(obj->datetime )) json_object_set_new(json, "datetime"     , json_string(obj->datetime));
	if (!EMPTY(obj->mesg_id  )) json_object_set_new(json, "message_id"   , json_string(obj->mesg_id));
	json_object_set_new(json, "from"         , rmsJsonPack_user(&obj->from));
	json_object_set_new(json, "sid"          , json_integer(obj->sid));
	if (!EMPTY(obj->telecom_code)) json_object_set_new(json, "telecom_code" , json_string(obj->telecom_code));
	if (!EMPTY(obj->password )) json_object_set_new(json, "password"     , json_string(obj->password));
	if (!EMPTY(obj->timestamp)) json_object_set_new(json, "timestamp"    , json_string(obj->timestamp));
	if (!EMPTY(obj->src_ip   )) json_object_set_new(json, "src_ip"       , json_string(obj->src_ip));
	json_object_set_new(json, "src_port"     , json_integer(obj->src_port));
	json_object_set_new(json, "src_tbcp_port", json_integer(obj->src_tbcp_port));
	if (!EMPTY(obj->codec    )) json_object_set_new(json, "codec"        , json_string(obj->codec));
	if (!EMPTY(obj->roaming  )) json_object_set_new(json, "roaming"      , json_string(obj->roaming));
	
	return json;
}

int rmsJsonUnpack_joinreq(json_t *json, j_joinreq_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}

	memset(obj, 0x00, sizeof(j_joinreq_t));
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "datetime")     == 0) { rmsHttpGetJChar(value, "datetime"    , obj->datetime, sizeof(obj->datetime)); }
		else if (strcmp(key, "content_type") == 0) { rmsHttpGetJChar(value, "content_type", obj->ctype   , sizeof(obj->ctype)); }
		else if (strcmp(key, "message_id"  ) == 0) { rmsHttpGetJChar(value, "message_id"  , obj->mesg_id , sizeof(obj->mesg_id)); }
		else if (strcmp(key, "from"        ) == 0) { rmsJsonUnpack_user(value, &obj->from); }
		else if (strcmp(key, "sid"         ) == 0) { obj->sid = rmsHttpGetJLong(value, "sid"); }
		else if (strcmp(key, "telecom_code") == 0) { rmsHttpGetJChar(value, "telecom_code", obj->telecom_code , sizeof(obj->telecom_code)); }
		else if (strcmp(key, "password" ) == 0) { rmsHttpGetJChar(value, "password" , obj->password , sizeof(obj->password));  }
		else if (strcmp(key, "timestamp") == 0) { rmsHttpGetJChar(value, "timestamp", obj->timestamp, sizeof(obj->timestamp)); }
		else if (strcmp(key, "src_ip")    == 0) { rmsHttpGetJChar(value, "src_ip", obj->src_ip, sizeof(obj->src_ip)); }
		else if (strcmp(key, "src_port")      == 0) { obj->src_port      = rmsHttpGetJInt(value, "src_port"); }
		else if (strcmp(key, "src_tbcp_port") == 0) { obj->src_tbcp_port = rmsHttpGetJInt(value, "src_tbcp_port"); }
		else if (strcmp(key, "codec")    == 0) { rmsHttpGetJChar(value, "codec"  , obj->codec  , sizeof(obj->codec)); }
		else if (strcmp(key, "roaming")  == 0) { rmsHttpGetJChar(value, "roaming", obj->roaming, sizeof(obj->roaming)); }
	}

	return 0;
}

/*****************************************************************/
/*                                                               */
/* profile                                                       */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_profile(j_profile_t *obj, char *name)
{
	comLog(DG, "%s.type     : %d" , name, obj->type);
	comLog(DG, "%s.iuid     : %lu", name, obj->iuid);
	comLog(DG, "%s.phone_no : %s" , name, obj->phone_no);
	comLog(DG, "%s.e164     : %s" , name, obj->e164);
	comLog(DG, "%s.nickname : %s" , name, obj->nickname);
	comLog(DG, "%s.message  : %s" , name, obj->message);
	comLog(DG, "%s.email    : %s" , name, obj->email);
	comLog(DG, "%s.din      : %d" , name, obj->din);
	comLog(DG, "%s.dcn      : %d" , name, obj->dcn);
	comLog(DG, "%s.pic_type : %d" , name, obj->pic_type);
	comLog(DG, "%s.image    : %s" , name, obj->image);
	comLog(DG, "%s.thumbnail: %s" , name, obj->thumbnail);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_profile(j_profile_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	json_object_set_new(json, "type", json_integer(obj->type));
	json_object_set_new(json, "iuid", json_integer(obj->iuid));
	if (!EMPTY(obj->phone_no )) json_object_set_new(json, "phone-number", json_string(obj->phone_no));
	if (!EMPTY(obj->e164     )) json_object_set_new(json, "e164"        , json_string(obj->e164));
	if (!EMPTY(obj->nickname )) json_object_set_new(json, "nickname"      , json_string(obj->nickname));
	if (!EMPTY(obj->message  )) json_object_set_new(json, "status-message", json_string(obj->message));
	if (!EMPTY(obj->email    )) json_object_set_new(json, "e-mail"        , json_string(obj->email));
	json_object_set_new(json, "default-img-num"  , json_integer(obj->din));
	json_object_set_new(json, "default-color-num", json_integer(obj->dcn));
	json_object_set_new(json, "pic-type" , json_integer(obj->pic_type));
	if (!EMPTY(obj->image    )) json_object_set_new(json, "image"    , json_string(obj->image));
	if (!EMPTY(obj->thumbnail)) json_object_set_new(json, "thumbnail", json_string(obj->thumbnail));
	
	return json;
}

int rmsJsonUnpack_profile(json_t *json, j_profile_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}

	memset(obj, 0x00, sizeof(j_profile_t));
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "type") == 0) { obj->type = rmsHttpGetJInt (value, "type"); }
		else if (strcmp(key, "iuid") == 0) { obj->iuid = rmsHttpGetJLong(value, "iuid"); }
		else if (strcmp(key, "phone-number") == 0) { rmsHttpGetJChar(value, "phone-number", obj->phone_no, sizeof(obj->phone_no)); }
		else if (strcmp(key, "e164"    ) == 0) { rmsHttpGetJChar(value, "e164"    , obj->e164 , sizeof(obj->e164)); }
		else if (strcmp(key, "nickname") == 0) { rmsHttpGetJChar(value, "nickname", obj->nickname , sizeof(obj->nickname)); }
		else if (strcmp(key, "status-message" ) == 0) { rmsHttpGetJChar(value, "status-message" , obj->message , sizeof(obj->message)); }
		else if (strcmp(key, "e-mail"  ) == 0) { rmsHttpGetJChar(value, "e-mail" , obj->email , sizeof(obj->email)); }
		else if (strcmp(key, "default-img-num"  ) == 0) { obj->din = rmsHttpGetJInt(value, "default-img-num"); }
		else if (strcmp(key, "default-color-num") == 0) { obj->dcn = rmsHttpGetJInt(value, "default-colorimg-num"); }
		else if (strcmp(key, "pic-type" ) == 0) { obj->pic_type = rmsHttpGetJInt(value, "pic-type"); }
		else if (strcmp(key, "image"    ) == 0) { rmsHttpGetJChar(value, "image"    , obj->image    , sizeof(obj->image)); }
		else if (strcmp(key, "thumbnail") == 0) { rmsHttpGetJChar(value, "thumbnail", obj->thumbnail, sizeof(obj->thumbnail)); }
	}

	return 0;
}

/*****************************************************************/
/*                                                               */
/* scfcause                                                      */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_scfcause(j_scfcause_t *obj, char *name)
{
	comLog(DG, "%s.ctype  : %d", name, obj->code);
	comLog(DG, "%s.message: %s", name, obj->message);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_scfcause(j_scfcause_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	json_object_set_new(json, "code"   , json_integer(obj->code));
	json_object_set_new(json, "message", json_string (obj->message));
	
	return json;
}

int rmsJsonUnpack_scfcause(json_t *json, j_scfcause_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "code"   ) == 0) { obj->code = rmsHttpGetJInt(value, "code"); }
		else if (strcmp(key, "message") == 0) { rmsHttpGetJChar(value, "message", obj->message, sizeof(obj->message)); }
	}

	return 0;
}

/*****************************************************************/
/*                                                               */
/* result                                                        */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_result(j_result_t *obj, char *name)
{
	comLog(DG, "%s.code: %d", name, obj->code);
	comLog(DG, "%s.desc: %s", name, obj->desc);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_result(j_result_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	json_object_set_new(json, "result_code", json_integer(obj->code));
	if (!EMPTY(obj->desc)) json_object_set_new(json, "result_desc", json_string (obj->desc));
	
	return json;
}

int rmsJsonUnpack_result(json_t *json, j_result_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "result_code") == 0) { obj->code = rmsHttpGetJInt(value, "result_code"); }
		else if (strcmp(key, "result_desc") == 0) { rmsHttpGetJChar(value, "result_desc", obj->desc, sizeof(obj->desc)); }
	}

	return 0;
}

/*****************************************************************/
/*                                                               */
/* connection                                                    */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_connection(j_connection_t *obj, char *name)
{
	comLog(DG, "%s.protocol: %s", name, obj->protocol);
	comLog(DG, "%s.ip      : %s", name, obj->ip);
	comLog(DG, "%s.port    : %d", name, obj->port);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_connection(j_connection_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	if (!EMPTY(obj->protocol)) json_object_set_new(json, "protocol", json_string (obj->protocol));
	if (!EMPTY(obj->ip      )) json_object_set_new(json, "ip"      , json_string (obj->ip));
	json_object_set_new(json, "port", json_integer(obj->port));
	
	return json;
}

int rmsJsonUnpack_connection(json_t *json, j_connection_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "protocol") == 0) { rmsHttpGetJChar(value, "protocol", obj->protocol, sizeof(obj->protocol)); }
		else if (strcmp(key, "ip"      ) == 0) { rmsHttpGetJChar(value, "ip"      , obj->ip      , sizeof(obj->ip)); }
		else if (strcmp(key, "port"    ) == 0) { obj->port = rmsHttpGetJInt(value, "port"); }
	}

	return 0;
}

json_t *rmsJsonPack_connection_array(j_connection_t *obj, int size)
{
	json_t *json;
	int i;

	if ((json = json_array()) == NULL) {
		comLog(ER, "%s() failed to json_array()", __func__);
		return NULL;
	}

	for (i = 0; i < size; i++) {
		json_array_append_new(json, rmsJsonPack_connection(obj + i));
	}
	
	return json;
}

int rmsJsonUnpack_connection_array(json_t *json, j_connection_t *obj, int size)
{
	size_t  index;
	json_t *value;
	int     count;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_ARRAY) == -1) {
		comLog(WA, "%s() !array type", __func__);
		return -1;
	}

	count = 0;
	json_array_foreach(json, index, value) {
		comLog(DG, "%s() index........ %d", __func__, index);
		if (index < size) {
			rmsJsonUnpack_connection(value, obj + index);
			count++;
		}
	}

	return count;
}

/*****************************************************************/
/*                                                               */
/* serverinfo                                                    */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_serverinfo(j_serverinfo_t *obj, char *name)
{
	int i;

	for (i = 0; i < obj->connection_count && i < MAX_SERVERCONN_NUM; i++) {
		rmsJsonPrint_connection(obj->connections + i, "server.connection");
	}
	comLog(DG, "%s.id   : %s", name, obj->id);
	comLog(DG, "%s.name : %s", name, obj->name);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_serverinfo(j_serverinfo_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	if (!EMPTY(obj->id  )) json_object_set_new(json, "id"  , json_string (obj->id));
	if (!EMPTY(obj->name)) json_object_set_new(json, "name", json_string (obj->name));
	json_object_set_new(json, "connections", rmsJsonPack_connection_array(obj->connections, MAX_SERVERCONN_NUM));
	
	return json;
}

int rmsJsonUnpack_serverinfo(json_t *json, j_serverinfo_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "id"         ) == 0) { rmsHttpGetJChar(value, "id"  , obj->id  , sizeof(obj->id)); }
		else if (strcmp(key, "name"       ) == 0) { rmsHttpGetJChar(value, "name", obj->name, sizeof(obj->name)); }
		else if (strcmp(key, "connections") == 0) { obj->connection_count = rmsJsonUnpack_connection_array(value, obj->connections, MAX_SERVERCONN_NUM); }
	}

	return 0;
}

json_t *rmsJsonPack_serverinfo_array(j_serverinfo_t *obj, int size)
{
	json_t *json;
	int i;

	if ((json = json_array()) == NULL) {
		comLog(ER, "%s() failed to json_array()", __func__);
		return NULL;
	}

	for (i = 0; i < size; i++) {
		json_array_append_new(json, rmsJsonPack_serverinfo(obj + i));
	}
	
	return json;
}

int rmsJsonUnpack_serverinfo_array(json_t *json, j_serverinfo_t *obj, int size)
{
	size_t  index;
	json_t *value;
	int     count;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_ARRAY) == -1) {
		comLog(WA, "%s() !array type", __func__);
		return -1;
	}

	count = 0;
	json_array_foreach(json, index, value) {
		comLog(DG, "%s() index........ %d", __func__, index);
		if (index < size) {
			rmsJsonUnpack_serverinfo(value, obj + index);
			count++;
		}
	}

	return count;
}

/*****************************************************************/
/*                                                               */
/* deviceinfo                                                    */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_deviceinfo(j_deviceinfo_t *obj, char *name)
{
	int i;

	for (i = 0; i < obj->server_count && i < MAX_SERVERINFO_NUM; i++) {
		rmsJsonPrint_serverinfo(obj->servers + i, "deviceinfo.servers");
	}
	comLog(DG, "%s.iuid     : %lu", name, obj->iuid);
	comLog(DG, "%s.auth_key : %s" , name, obj->auth_key);
	comLog(DG, "%s.subs_type: %d" , name, obj->subs_type);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_deviceinfo(j_deviceinfo_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	if (!EMPTY(obj->auth_key)) json_object_set_new(json, "auth-key", json_string (obj->auth_key));
	json_object_set_new(json, "iuid"     , json_integer(obj->iuid));
	json_object_set_new(json, "subs-type", json_integer(obj->subs_type));
	json_object_set_new(json, "servers"  , rmsJsonPack_serverinfo_array(obj->servers, MAX_SERVERINFO_NUM));

	return json;
}

int rmsJsonUnpack_deviceinfo(json_t *json, j_deviceinfo_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "auth-key" ) == 0) { rmsHttpGetJChar(value, "auth-key", obj->auth_key, sizeof(obj->auth_key)); }
		else if (strcmp(key, "iuid"     ) == 0) { obj->iuid         = rmsHttpGetJInt(value, "iuid"); }
		else if (strcmp(key, "subs-type") == 0) { obj->subs_type    = rmsHttpGetJInt(value, "subs-type"); }
		else if (strcmp(key, "servers"  ) == 0) { obj->server_count = rmsJsonUnpack_serverinfo_array(value, obj->servers, MAX_SERVERINFO_NUM); }
	}

	rmsJsonPrint_deviceinfo(obj, "deviceinfo");

	return 0;
}

/*****************************************************************/
/*                                                               */
/* leavereq                                                      */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_leavereq(j_leavereq_t *obj, char *name)
{
	rmsJsonPrint_user    (&obj->from , "leavereq.from" );
	rmsJsonPrint_scfcause(&obj->cause, "leavereq.cause");
	comLog(DG, "%s.ctype        : %s" , name, obj->ctype);
	comLog(DG, "%s.datetime     : %s" , name, obj->datetime);
	comLog(DG, "%s.mesg_id      : %s" , name, obj->mesg_id);
	comLog(DG, "%s.sid     : %lu", name, obj->sid);
	comLog(DG, "%s.roaming : %s" , name, obj->roaming);
	comLog(DG, "%s.call_id : %s" , name, obj->call_id);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_leavereq(j_leavereq_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	if (!EMPTY(obj->ctype   )) json_object_set_new(json, "content_type" , json_string(obj->ctype));
	if (!EMPTY(obj->datetime)) json_object_set_new(json, "datetime"     , json_string(obj->datetime));
	if (!EMPTY(obj->mesg_id )) json_object_set_new(json, "message_id"   , json_string(obj->mesg_id));
	json_object_set_new(json, "sid"    , json_integer(obj->sid));
	json_object_set_new(json, "from"   , rmsJsonPack_user    (&obj->from));
	json_object_set_new(json, "cause"  , rmsJsonPack_scfcause(&obj->cause)); 
	if (!EMPTY(obj->roaming )) json_object_set_new(json, "roaming", json_string (obj->roaming));
	if (!EMPTY(obj->call_id )) json_object_set_new(json, "call_id", json_string (obj->call_id));
	
	return json;
}

int rmsJsonUnpack_leavereq(json_t *json, j_leavereq_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "datetime")     == 0) { rmsHttpGetJChar(value, "datetime"    , obj->datetime, sizeof(obj->datetime)); }
		else if (strcmp(key, "content_type") == 0) { rmsHttpGetJChar(value, "content_type", obj->ctype   , sizeof(obj->ctype)); }
		else if (strcmp(key, "message_id"  ) == 0) { rmsHttpGetJChar(value, "message_id"  , obj->mesg_id , sizeof(obj->mesg_id)); }
		else if (strcmp(key, "sid"    ) == 0) { obj->sid = rmsHttpGetJInt(value, "sid"); }
		else if (strcmp(key, "from"   ) == 0) { rmsJsonUnpack_user    (value, &obj->from); }
		else if (strcmp(key, "cause"  ) == 0) { rmsJsonUnpack_scfcause(value, &obj->cause); }
		else if (strcmp(key, "roaming") == 0) { rmsHttpGetJChar(value, "roaming", obj->roaming, sizeof(obj->roaming)); }
		else if (strcmp(key, "call_id") == 0) { rmsHttpGetJChar(value, "call_id", obj->call_id, sizeof(obj->call_id)); }
	}

	return 0;
}

/*****************************************************************/
/*                                                               */
/* showmylistreq                                                 */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_showmylistreq(j_room_showmylistreq_t *obj, char *name)
{
	comLog(DG, "%s.ctype      : %s", name, obj->ctype);
	comLog(DG, "%s.search_type: %d", name, obj->search_type);
	comLog(DG, "%s.start_row  : %d", name, obj->start_row);
	comLog(DG, "%s.end_row    : %d", name, obj->end_row);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_showmylistreq(j_room_showmylistreq_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	if (!EMPTY(obj->ctype)) json_object_set_new(json, "content_type", json_string (obj->ctype));
	json_object_set_new(json, "search_type" , json_integer(obj->search_type));
	json_object_set_new(json, "start_row"   , json_integer(obj->start_row)); 
	json_object_set_new(json, "end_row"     , json_integer(obj->end_row));
	
	return json;
}

int rmsJsonUnpack_showmylistreq(json_t *json, j_room_showmylistreq_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "content_type") == 0) { rmsHttpGetJChar(value, "content_type", obj->ctype, sizeof(obj->ctype)); }
		else if (strcmp(key, "search_type" ) == 0) { obj->search_type = rmsHttpGetJInt(value, "search_type"); }
		else if (strcmp(key, "start_row"   ) == 0) { obj->start_row   = rmsHttpGetJInt(value, "start_row"); }
		else if (strcmp(key, "end_row"     ) == 0) { obj->end_row     = rmsHttpGetJInt(value, "end_row"); }
	}

	return 0;
}

/*****************************************************************/
/*                                                               */
/* roomlistvalue                                                 */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_roomlistvalue(j_roomlistvalue_t *obj, char *name)
{
	rmsJsonPrint_user(&obj->owner  , "roomlistvalue.owner");
	rmsJsonPrint_user(&obj->inviter, "roomlistvalue.inviter");
    comLog(DG, "%s.sid         : %lu", name, obj->sid);
    comLog(DG, "%s.room_no     : %s" , name, obj->room_no);
    comLog(DG, "%s.text        : %s" , name, obj->text);
    comLog(DG, "%s.create_time : %s" , name, obj->create_time);
    comLog(DG, "%s.change_time : %s" , name, obj->change_time);
    comLog(DG, "%s.start_time  : %s" , name, obj->start_time);
    comLog(DG, "%s.stop_time   : %s" , name, obj->stop_time);    
    comLog(DG, "%s.nr_member   : %d" , name, obj->nr_member);    
    comLog(DG, "%s.status      : %d" , name, obj->status);      
    comLog(DG, "%s.member_limit: %d" , name, obj->member_limit); 
    comLog(DG, "%s.room_type   : %d" , name, obj->room_type);        
    comLog(DG, "%s.expose      : %d" , name, obj->expose);      
    comLog(DG, "%s.password    : %s" , name, obj->password);      
    comLog(DG, "%s.password_required: %d", name, obj->password_required);   
    comLog(DG, "%s.notice           : %s", name, obj->notice);      
    comLog(DG, "%s.invited          : %d", name, obj->invited);     
    comLog(DG, "%s.invited_time     : %s", name, obj->invited_time);
    comLog(DG, "%s.connect_member   : %d", name, obj->connect_member); 
    comLog(DG, "%s.last_floor_time  : %s", name, obj->last_floor_time); 
    comLog(DG, "%s.banned           : %d", name, obj->banned);          
    comLog(DG, "%s.thumbnail        : %s", name, obj->thumbnail); 
    comLog(DG, "%s.image            : %s", name, obj->image); 
    comLog(DG, "%s.desc             : %s", name, obj->desc);     
    comLog(DG, "%s.color_type       : %d", name, obj->color_type); 
    comLog(DG, "%s.tags             : %s", name, obj->tags); 
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_roomlistvalue(j_roomlistvalue_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	json_object_set_new(json, "sid"         , json_integer(obj->sid));
	if (!EMPTY(obj->room_no    )) json_object_set_new(json, "room_no"     , json_string (obj->room_no));
	if (!EMPTY(obj->text       )) json_object_set_new(json, "text"        , json_string (obj->text)); 
	if (!EMPTY(obj->create_time)) json_object_set_new(json, "create_time" , json_string (obj->create_time));
	if (!EMPTY(obj->change_time)) json_object_set_new(json, "change_time" , json_string (obj->change_time));
	if (!EMPTY(obj->start_time )) json_object_set_new(json, "start_time"  , json_string (obj->start_time));
	if (!EMPTY(obj->stop_time  )) json_object_set_new(json, "stop_time"   , json_string (obj->stop_time));
	json_object_set_new(json, "nr_member"   , json_integer(obj->nr_member));
	json_object_set_new(json, "status"      , json_integer(obj->status));
	json_object_set_new(json, "member_limit", json_integer(obj->member_limit));
	json_object_set_new(json, "room_type"   , json_integer(obj->room_type));
	json_object_set_new(json, "expose"      , json_integer(obj->expose));
	if (!EMPTY(obj->password   )) json_object_set_new(json, "password"    , json_string (obj->password));
	json_object_set_new(json, "password_required", json_integer(obj->password_required));
	if (!EMPTY(obj->notice     )) json_object_set_new(json, "notice"           , json_string(obj->notice));
	json_object_set_new(json, "owner"            , rmsJsonPack_user(&obj->owner));
	json_object_set_new(json, "invited"          , json_integer(obj->invited));
	if (!EMPTY(obj->invited_time)) json_object_set_new(json, "invited_time"     , json_string (obj->invited_time));
	json_object_set_new(json, "inviter"          , rmsJsonPack_user(&obj->inviter));
	json_object_set_new(json, "connect_member"   , json_integer(obj->connect_member));
	if (!EMPTY(obj->last_floor_time)) json_object_set_new(json, "last_floor_time"  , json_string (obj->last_floor_time));
	json_object_set_new(json, "banned"           , json_integer(obj->banned));
	if (!EMPTY(obj->thumbnail)) json_object_set_new(json, "thumbnail_url"    , json_string (obj->thumbnail));
	if (!EMPTY(obj->image    )) json_object_set_new(json, "image_url"        , json_string (obj->image));
	if (!EMPTY(obj->desc     )) json_object_set_new(json, "description"      , json_string (obj->desc));
	json_object_set_new(json, "color_type"       , json_integer(obj->color_type));
	if (!EMPTY(obj->tags     )) json_object_set_new(json, "tags"             , json_string (obj->tags));
	
	return json;
}

int rmsJsonUnpack_roomlistvalue(json_t *json, j_roomlistvalue_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "sid"         ) == 0) { obj->sid = rmsHttpGetJLong(value, "sid"); }
		else if (strcmp(key, "room_no"     ) == 0) { rmsHttpGetJChar(value, "room_no", obj->room_no, sizeof(obj->room_no)); }
		else if (strcmp(key, "text"        ) == 0) { rmsHttpGetJChar(value, "text"   , obj->text   , sizeof(obj->text)); }
		else if (strcmp(key, "create_time" ) == 0) { rmsHttpGetJChar(value, "create_time", obj->create_time, sizeof(obj->create_time)); }
		else if (strcmp(key, "change_time" ) == 0) { rmsHttpGetJChar(value, "change_time", obj->change_time, sizeof(obj->change_time)); }
		else if (strcmp(key, "start_time"  ) == 0) { rmsHttpGetJChar(value, "start_time", obj->start_time, sizeof(obj->start_time)); }
		else if (strcmp(key, "stop_time"   ) == 0) { rmsHttpGetJChar(value, "stop_time" , obj->stop_time , sizeof(obj->stop_time )); }
		else if (strcmp(key, "nr_member"   ) == 0) { obj->nr_member   = rmsHttpGetJInt(value, "nr_member"); }
		else if (strcmp(key, "status"      ) == 0) { obj->status      = rmsHttpGetJInt(value, "status"); }
		else if (strcmp(key, "member_limit") == 0) { obj->member_limit= rmsHttpGetJInt(value, "member_limit"); }
		else if (strcmp(key, "room_type"   ) == 0) { obj->room_type   = rmsHttpGetJInt(value, "room_type"); }
		else if (strcmp(key, "expose"      ) == 0) { obj->expose      = rmsHttpGetJInt(value, "expose"); }
		else if (strcmp(key, "password"    ) == 0) { rmsHttpGetJChar(value, "password", obj->password, sizeof(obj->password)); }
		else if (strcmp(key, "password_required") == 0) { obj->password_required = rmsHttpGetJInt(value, "password_required"); }
		else if (strcmp(key, "notice"      ) == 0) { rmsHttpGetJChar(value, "notice", obj->notice, sizeof(obj->notice)); }
		else if (strcmp(key, "owner"       ) == 0) { rmsJsonUnpack_user(value, &obj->owner); }
		else if (strcmp(key, "invited"     ) == 0) { obj->invited = rmsHttpGetJInt(value, "invited"); }
		else if (strcmp(key, "invited_time") == 0) { rmsHttpGetJChar(value, "invited_time", obj->invited_time, sizeof(obj->invited_time)); }
		else if (strcmp(key, "inviter"     ) == 0) { rmsJsonUnpack_user(value, &obj->inviter); }
		else if (strcmp(key, "connect_member" ) == 0) { obj->connect_member     = rmsHttpGetJInt(value, "connect_member"); }
		else if (strcmp(key, "last_floor_time") == 0) { rmsHttpGetJChar(value, "last_floor_time", obj->last_floor_time, sizeof(obj->last_floor_time)); }
		else if (strcmp(key, "banned"       ) == 0) { obj->banned     = rmsHttpGetJInt(value, "banned"); }
		else if (strcmp(key, "thumbnail_url") == 0) { rmsHttpGetJChar(value, "thumbnail_url", obj->thumbnail, sizeof(obj->thumbnail)); }
		else if (strcmp(key, "image_url"    ) == 0) { rmsHttpGetJChar(value, "image_url"  , obj->image, sizeof(obj->image)); }
		else if (strcmp(key, "desc"         ) == 0) { rmsHttpGetJChar(value, "description", obj->desc , sizeof(obj->desc)); }
		else if (strcmp(key, "color_type"   ) == 0) { obj->color_type = rmsHttpGetJInt(value, "color_type"); }
		else if (strcmp(key, "tags"         ) == 0) { rmsHttpGetJChar(value, "tags", obj->tags, sizeof(obj->tags)); }
	}

	return 0;
}

json_t *rmsJsonPack_roomlistvalue_array(j_roomlistvalue_t *obj, int size)
{
	json_t *json;
	int i;

	if ((json = json_array()) == NULL) {
		comLog(ER, "%s() failed to json_array()", __func__);
		return NULL;
	}

	for (i = 0; i < size; i++) {
		json_array_append_new(json, rmsJsonPack_roomlistvalue(obj + i));
	}
	
	return json;
}

int rmsJsonUnpack_roomlistvalue_array(json_t *json, j_roomlistvalue_t *obj, int size)
{
	size_t  index;
	json_t *value;
	int     count;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_ARRAY) == -1) {
		comLog(WA, "%s() !array type", __func__);
		return -1;
	}

	count = 0;
	json_array_foreach(json, index, value) {
		comLog(DG, "%s() index........ %d", __func__, index);
		if (index < size) {
			rmsJsonUnpack_roomlistvalue(value, obj + index);
			count++;
		}
	}

	return count;
}

/*****************************************************************/
/*                                                               */
/* showmylistres                                                 */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_showmylistres(j_room_showmylistres_t *obj, char *name)
{
	int i;
	
	for (i = 0; i < obj->avail_count && i < MAX_MY_CHANNEL_NUM; i++) {
		rmsJsonPrint_roomlistvalue(obj->room_list + i, "showmylistres.room_list");
	}
	comLog(DG, "%s.ctype      : %s", name, obj->ctype);
	comLog(DG, "%s.total_count: %d", name, obj->total_count);
	comLog(DG, "%s.avail_count: %d", name, obj->avail_count);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_showmylistres(j_room_showmylistres_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	if (!EMPTY(obj->ctype)) json_object_set_new(json, "content_type", json_string (obj->ctype));
	json_object_set_new(json, "total_count" , json_integer(obj->total_count));
	json_object_set_new(json, "room_list"   , rmsJsonPack_roomlistvalue_array(obj->room_list, MAX_MY_CHANNEL_NUM));
	
	return json;
}

int rmsJsonUnpack_showmylistres(json_t *json, j_room_showmylistres_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}

	//
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "content_type") == 0) { rmsHttpGetJChar(value, "content_type", obj->ctype, sizeof(obj->ctype)); }
		else if (strcmp(key, "total_count" ) == 0) { obj->total_count = rmsHttpGetJInt(value, "total_count"); }
		else if (strcmp(key, "room_list"   ) == 0) { obj->avail_count = rmsJsonUnpack_roomlistvalue_array(value, obj->room_list, MAX_MY_CHANNEL_NUM); }
	}

	rmsJsonPrint_showmylistres(obj, "showmylistres");

	return 0;
}

/*****************************************************************/
/*                                                               */
/* additional_info                                               */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_addinfo(j_addinfo_t *obj, char *name)
{
	comLog(DG, "%s.volume           : %d" , name, obj->volume);
	comLog(DG, "%s.version          : %s" , name, obj->version);
	comLog(DG, "%s.installer_url    : %s" , name, obj->installer_url);
	comLog(DG, "%s.download_file_url: %s" , name, obj->download_file_url);
	comLog(DG, "%s.request_key      : %s" , name, obj->request_key);
	comLog(DG, "%s.method           : %s" , name, obj->method);
	comLog(DG, "%s.destination_ip   : %s" , name, obj->dst_ip);
	comLog(DG, "%s.destination_port : %d" , name, obj->dst_port);
	comLog(DG, "%s.destination_url  : %s" , name, obj->dst_url);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_addinfo(j_addinfo_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	//Volume
	json_object_set_new(json, "value" , json_integer(obj->volume));
	//Firmware Update
	if (!EMPTY(obj->version          )) json_object_set_new(json, "version"      , json_string(obj->version));
	if (!EMPTY(obj->installer_url    )) json_object_set_new(json, "installer_url", json_string(obj->installer_url));
	if (!EMPTY(obj->download_file_url)) json_object_set_new(json, "download_file_url", json_string(obj->download_file_url));
	//Request
	if (!EMPTY(obj->request_key)) json_object_set_new(json, "request_key"    , json_string(obj->request_key));
	if (!EMPTY(obj->method     )) json_object_set_new(json, "method"         , json_string(obj->method));
	if (!EMPTY(obj->dst_ip     )) json_object_set_new(json, "destination_ip" , json_string(obj->dst_ip));
	json_object_set_new(json, "destination_port", json_integer(obj->dst_port));
	if (!EMPTY(obj->dst_url    )) json_object_set_new(json, "destination_url", json_string(obj->dst_url));
	
	return json;
}

int rmsJsonUnpack_addinfo(json_t *json, j_addinfo_t *obj)
{
	const char *key;
	json_t *value;
	char dst_port[10];

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	memset(obj, 0x00, sizeof(j_addinfo_t));
	
	json_object_foreach(json, key, value) {
		//Volume
		if      (strcmp(key, "volume") == 0) { obj->volume = rmsHttpGetJInt(value, "volume"); }
		//Firmware Update
		else if (strcmp(key, "version") == 0) { rmsHttpGetJChar(value, "version", obj->version , sizeof(obj->version)); }
		else if (strcmp(key, "installer_url"    ) == 0) { rmsHttpGetJChar(value, "installer_url"    , obj->installer_url, sizeof(obj->installer_url)); }
		else if (strcmp(key, "download_file_url") == 0) { rmsHttpGetJChar(value, "download_file_url", obj->download_file_url  , sizeof(obj->download_file_url)); }
		//Request
		else if (strcmp(key, "request_key"     ) == 0) { rmsHttpGetJChar(value, "request_key", obj->request_key, sizeof(obj->request_key)); }
		else if (strcmp(key, "method"          ) == 0) { rmsHttpGetJChar(value, "method"        , obj->method , sizeof(obj->method)); }
		else if (strcmp(key, "destination_ip"  ) == 0) { rmsHttpGetJChar(value, "destination_ip", obj->dst_ip , sizeof(obj->dst_ip)); }
		else if (strcmp(key, "destination_port") == 0) { 
			rmsHttpGetJChar(value, "destination_port", dst_port, sizeof(dst_port));
			obj->dst_port = atoi(dst_port);
		}
		else if (strcmp(key, "destination_url" ) == 0) { rmsHttpGetJChar(value, "destination_url", obj->dst_url , sizeof(obj->dst_url)); }
	}

	return 0;
}


/*****************************************************************/
/*                                                               */
/* datarcv                                                       */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_datarcv(j_datarcv_t *obj, char *name)
{
	rmsJsonPrint_profile      (&obj->profile, "datarcv.profile");
	rmsJsonPrint_user         (&obj->from   , "datarcv.from");
	rmsJsonPrint_roomlistvalue(&obj->room   , "datarcv.room");
	rmsJsonPrint_result       (&obj->result , "datarcv.result");
	rmsJsonPrint_addinfo      (&obj->addinfo, "datarcv.addinfo");
	comLog(DG, "%s.ctype         : %s" , name, obj->ctype);
	comLog(DG, "%s.sid           : %lu", name, obj->sid);
	comLog(DG, "%s.pay           : %d" , name, obj->pay);
	comLog(DG, "%s.datetime      : %s" , name, obj->datetime);
	comLog(DG, "%s.timestamp     : %s" , name, obj->timestamp);
	comLog(DG, "%s.mesg_id       : %s" , name, obj->mesg_id);
	comLog(DG, "%s.text          : %s" , name, obj->text);
	comLog(DG, "%s.dst_ip        : %s" , name, obj->dst_ip);
	comLog(DG, "%s.dst_port      : %d" , name, obj->dst_port);
	comLog(DG, "%s.dst_tbcp_port : %d" , name, obj->dst_tbcp_port);
	comLog(DG, "%s.codec         : %s" , name, obj->codec);
	comLog(DG, "%s.ptype         : %d" , name, obj->ptype);
	comLog(DG, "%s.old_call_id   : %s" , name, obj->old_call_id);
	comLog(DG, "%s.call_id       : %s" , name, obj->call_id);
	comLog(DG, "%s.conf_id       : %ld", name, obj->conf_id);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_datarcv(j_datarcv_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	if (!EMPTY(obj->ctype      )) json_object_set_new(json, "content_type" , json_string (obj->ctype));
	json_object_set_new(json, "sid"     , json_integer(obj->sid));
	json_object_set_new(json, "profile" , rmsJsonPack_profile(&obj->profile));
	json_object_set_new(json, "room"    , rmsJsonPack_roomlistvalue(&obj->room));
	json_object_set_new(json, "result"  , rmsJsonPack_result(&obj->result));
	json_object_set_new(json, "additional_info", rmsJsonPack_addinfo(&obj->addinfo));
	json_object_set_new(json, "pay_channel", json_integer(obj->pay));
	if (!EMPTY(obj->datetime   )) json_object_set_new(json, "datetime"     , json_string (obj->datetime));
	if (!EMPTY(obj->timestamp  )) json_object_set_new(json, "timestamp"    , json_string (obj->timestamp));
	if (!EMPTY(obj->mesg_id    )) json_object_set_new(json, "message_id"   , json_string (obj->mesg_id));
	json_object_set_new(json, "from"         , rmsJsonPack_user(&obj->from));
	if (!EMPTY(obj->text       )) json_object_set_new(json, "text"         , json_string (obj->text));
	if (!EMPTY(obj->dst_ip     )) json_object_set_new(json, "dst_ip"       , json_string (obj->dst_ip));
	json_object_set_new(json, "dst_port"     , json_integer(obj->dst_port));
	json_object_set_new(json, "dst_tbcp_port", json_integer(obj->dst_tbcp_port));
	if (!EMPTY(obj->codec      )) json_object_set_new(json, "codec"        , json_string (obj->codec));
	json_object_set_new(json, "payload_type" , json_integer(obj->ptype));
	if (!EMPTY(obj->old_call_id)) json_object_set_new(json, "old_call_id"  , json_string (obj->old_call_id));
	if (!EMPTY(obj->call_id    )) json_object_set_new(json, "call_id"      , json_string (obj->call_id));
	json_object_set_new(json, "conference_id", json_integer(obj->conf_id));
	
	return json;
}

int rmsJsonUnpack_datarcv(json_t *json, j_datarcv_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	memset(obj, 0x00, sizeof(j_datarcv_t));
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "content_type" ) == 0) { rmsHttpGetJChar(value, "content_type", obj->ctype , sizeof(obj->ctype)); }
		else if (strcmp(key, "sid"          ) == 0) { obj->sid = rmsHttpGetJLong(value, "sid"); }
		else if (strcmp(key, "profile"      ) == 0) { rmsJsonUnpack_profile(value, &obj->profile); }
		else if (strcmp(key, "room"         ) == 0) { rmsJsonUnpack_roomlistvalue(value, &obj->room); }
		else if (strcmp(key, "result"       ) == 0) { rmsJsonUnpack_result(value, &obj->result); }
		else if (strcmp(key, "additional_info") == 0) { rmsJsonUnpack_addinfo(value, &obj->addinfo); }
		else if (strcmp(key, "pay_channel"  ) == 0) { obj->pay = rmsHttpGetJInt(value, "pay_channel"); }

		else if (strcmp(key, "datetime"     ) == 0) { rmsHttpGetJChar(value, "datetime"  , obj->datetime , sizeof(obj->datetime)); }
		else if (strcmp(key, "timestamp"    ) == 0) { rmsHttpGetJChar(value, "timestamp" , obj->timestamp, sizeof(obj->dst_ip)); }
		else if (strcmp(key, "message_id"   ) == 0) { rmsHttpGetJChar(value, "message_id", obj->mesg_id  , sizeof(obj->mesg_id)); }
		else if (strcmp(key, "text"         ) == 0) { rmsHttpGetJChar(value, "text"      , obj->text     , sizeof(obj->text)); }
		else if (strcmp(key, "from"         ) == 0) { rmsJsonUnpack_user(value, &obj->from); }

		else if (strcmp(key, "dst_ip"       ) == 0) { rmsHttpGetJChar(value, "dst_ip"    , obj->dst_ip , sizeof(obj->dst_ip)); }
		else if (strcmp(key, "dst_port"     ) == 0) { obj->dst_port      = rmsHttpGetJInt(value, "dst_port"); }
		else if (strcmp(key, "dst_tbcp_port") == 0) { obj->dst_tbcp_port = rmsHttpGetJInt(value, "dst_tbcp_port"); }
		else if (strcmp(key, "codec"        ) == 0) { rmsHttpGetJChar(value, "codec" , obj->codec , sizeof(obj->codec)); }
		else if (strcmp(key, "payload_type" ) == 0) { obj->ptype = rmsHttpGetJInt(value, "payload_type"); }
		else if (strcmp(key, "old_call_id"  ) == 0) { rmsHttpGetJChar(value, "old_call_id", obj->old_call_id , sizeof(obj->old_call_id)); }
		else if (strcmp(key, "call_id"      ) == 0) { rmsHttpGetJChar(value, "call_id", obj->call_id, sizeof(obj->call_id)); }
		else if (strcmp(key, "conference_id") == 0) { obj->conf_id = rmsHttpGetJLong(value, "conference_id"); }
	}

	rmsJsonPrint_datarcv(obj, "datarcv");

	return 0;
}

/*****************************************************************/
/*                                                               */
/* j_process_t                                                   */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_process(j_process_t *obj, char *name)
{
	comLog(DG, "%s.alias            : %s" , name, obj->alias);
	comLog(DG, "%s.pid              : %d" , name, obj->pid);
	comLog(DG, "%s.ppid             : %d" , name, obj->ppid);
	comLog(DG, "%s.ipc_send         : %d" , name, obj->ipc_send);
	comLog(DG, "%s.ipc_recv         : %d" , name, obj->ipc_recv);
	comLog(DG, "%s.debug_point      : %d" , name, obj->debug_point);
	comLog(DG, "%s.debug_count      : %d" , name, obj->debug_count);
	comLog(DG, "%s.start_time       : %lu", name, obj->start_time);
	comLog(DG, "%s.stop_time        : %lu", name, obj->stop_time);
	comLog(DG, "%s.total_down_count : %d" , name, obj->total_down_count);
	comLog(DG, "%s.recent_down_count: %d" , name, obj->recent_down_count);
	comLog(DG, "%s.status           : %s" , name, obj->status);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_process(j_process_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	if (!EMPTY(obj->alias)) json_object_set_new(json, "alias" , json_string (obj->alias));
	json_object_set_new(json, "pid"          , json_integer(obj->pid));
	json_object_set_new(json, "ppid"         , json_integer(obj->ppid));
	json_object_set_new(json, "ipc_send"     , json_integer(obj->ipc_send));
	json_object_set_new(json, "ipc_recv"     , json_integer(obj->ipc_recv));
	json_object_set_new(json, "debug_point"  , json_integer(obj->debug_point));
	json_object_set_new(json, "debug_count"  , json_integer(obj->debug_count));
	json_object_set_new(json, "start_time"   , json_integer(obj->start_time));
	json_object_set_new(json, "stop_time"    , json_integer(obj->stop_time));
	if (!EMPTY(obj->status)) json_object_set_new(json, "status" , json_string (obj->status));
	
	return json;
}

int rmsJsonUnpack_process(json_t *json, j_process_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	memset(obj, 0x00, sizeof(j_process_t));
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "alias"      ) == 0) { rmsHttpGetJChar(value, "alias", obj->alias , sizeof(obj->alias)); }
		else if (strcmp(key, "pid"        ) == 0) { obj->pid         = rmsHttpGetJInt(value, "pid"); }
		else if (strcmp(key, "ppid"       ) == 0) { obj->ppid        = rmsHttpGetJInt(value, "ppid"); }
		else if (strcmp(key, "ipc_send"   ) == 0) { obj->ipc_send    = rmsHttpGetJInt(value, "ipc_send"); }
		else if (strcmp(key, "ipc_recv"   ) == 0) { obj->ipc_recv    = rmsHttpGetJInt(value, "ipc_recv"); }
		else if (strcmp(key, "debug_point") == 0) { obj->debug_point = rmsHttpGetJInt(value, "debug_point"); }
		else if (strcmp(key, "debug_count") == 0) { obj->debug_count = rmsHttpGetJInt(value, "debug_count"); }
		else if (strcmp(key, "start_time" ) == 0) { obj->start_time  = rmsHttpGetJInt(value, "start_time"); }
		else if (strcmp(key, "stop_time"  ) == 0) { obj->stop_time   = rmsHttpGetJInt(value, "stop_time"); }
		else if (strcmp(key, "status"     ) == 0) { rmsHttpGetJChar(value, "status", obj->status , sizeof(obj->status)); }
	}

	rmsJsonPrint_process(obj, "process");

	return 0;
}

json_t *rmsJsonPack_process_array(j_process_t *obj, int size)
{
	json_t *json;
	int i;

	if ((json = json_array()) == NULL) {
		comLog(ER, "%s() failed to json_array()", __func__);
		return NULL;
	}

	for (i = 0; i < size; i++) {
		json_array_append_new(json, rmsJsonPack_process(obj + i));
	}
	
	return json;
}

int rmsJsonUnpack_process_array(json_t *json, j_process_t *obj, int size)
{
	size_t  index;
	json_t *value;
	int     count;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_ARRAY) == -1) {
		comLog(WA, "%s() !array type", __func__);
		return -1;
	}
	
	count = 0;
	json_array_foreach(json, index, value) {
		comLog(DG, "%s() index........ %d", __func__, index);
		if (index < size) {
			rmsJsonUnpack_process(value, obj + index);
			count++;
		}
	}

	return count;
}

/*****************************************************************/
/*                                                               */
/* j_config_t                                                    */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_config(j_config_t *obj, char *name)
{
	comLog(DG, "%s.version          : %s"  , name, obj->version);
	comLog(DG, "%s.e164             : %s"  , name, obj->e164);
	comLog(DG, "%s.app_type         : %s"  , name, obj->app_type);
	comLog(DG, "%s.iuid             : %lu" , name, obj->iuid);
	comLog(DG, "%s.auth_key         : %s"  , name, obj->auth_key);
	comLog(DG, "%s.acs_http_server_addr: %s", name, obj->acs_http_server_addr);
	comLog(DG, "%s.rms_http_server_addr: %s", name, obj->rms_http_server_addr);
	comLog(DG, "%s.scf_tcp_server_addr : %s", name, obj->scf_tcp_server_addr);
	comLog(DG, "%s.scf_tcp_source_ip   : %s", name, obj->scf_tcp_source_ip);
	comLog(DG, "%s.scf_tcp_status      : %s", name, obj->scf_tcp_status);
	comLog(DG, "%s.scf_tcp_fault_time  : %lu" , name, obj->scf_tcp_fault_time);
	comLog(DG, "%s.scf_tcp_fault_duration: %d", name, obj->scf_tcp_fault_duration);
	comLog(DG, "%s.webi_listen_port          : %d", name, obj->webi_listen_port);
	comLog(DG, "%s.channel_sid               : %lu" , name, obj->channel_sid);
	comLog(DG, "%s.channel_status_change_time: %lu" , name, obj->channel_status_change_time);
	comLog(DG, "%s.channel_status            : %s"  , name, obj->channel_status);
	comLog(DG, "%s.voip_audio_volume         : %d"  , name, obj->voip_audio_volume);
	comLog(DG, "%s.voip_dest_ip              : %s"  , name, obj->voip_dest_ip);
	comLog(DG, "%s.voip_dest_audio_port      : %d"  , name, obj->voip_dest_audio_port);
	comLog(DG, "%s.voip_dest_mbcp_port       : %d"  , name, obj->voip_dest_mbcp_port);
	comLog(DG, "%s.voip_audio_codec          : %s"  , name, obj->voip_audio_codec);
	comLog(DG, "%s.voip_call_id              : %s"  , name, obj->voip_call_id);
	comLog(DG, "%s.mbcp_status               : %s"  , name, obj->mbcp_status);
	comLog(DG, "%s.mbcp_status_change_time   : %lu" , name, obj->mbcp_status_change_time);
	comLog(DG, "%s.mbcp_still_alive_time     : %lu" , name, obj->mbcp_still_alive_time);
	comLog(DG, "%s.scf_tcp_idle_sec          : %d"  , name, obj->scf_tcp_idle_sec);
	comLog(DG, "%s.scf_tcp_lost_sec          : %d"  , name, obj->scf_tcp_lost_sec);
	comLog(DG, "%s.auto_recovery_period_sec  : %d"  , name, obj->auto_recovery_period_sec);
	comLog(DG, "%s.firmware_update_enabled   : %d"  , name, obj->firmware_update_enabled);
	comLog(DG, "%s.usering_period_sec        : %d"  , name, obj->usering_period_sec);
	comLog(DG, "%s.rooming_period_sec        : %d"  , name, obj->rooming_period_sec);
	comLog(DG, "%s.joining_period_sec        : %d"  , name, obj->joining_period_sec);
	comLog(DG, "%s.logging                   : %d"  , name, obj->logging);
	comLog(DG, "%s.log_level                 : %s"  , name, obj->log_level);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_config(j_config_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}

	if (!EMPTY(obj->version )) json_object_set_new(json, "version", json_string (obj->version));
	if (!EMPTY(obj->e164    )) json_object_set_new(json, "e164"   , json_string (obj->e164));
	if (!EMPTY(obj->app_type)) json_object_set_new(json, "app_type" , json_string (obj->app_type));
	json_object_set_new(json, "iuid", json_integer(obj->iuid));
	if (!EMPTY(obj->auth_key)) json_object_set_new(json, "auth_key" , json_string (obj->auth_key));

	if (!EMPTY(obj->acs_http_server_addr)) json_object_set_new(json, "acs_http_server_addr" , json_string (obj->acs_http_server_addr));
	if (!EMPTY(obj->rms_http_server_addr)) json_object_set_new(json, "rms_http_server_addr" , json_string (obj->rms_http_server_addr));
	if (!EMPTY(obj->scf_tcp_server_addr )) json_object_set_new(json, "scf_tcp_server_addr"  , json_string (obj->scf_tcp_server_addr));
	if (!EMPTY(obj->scf_tcp_source_ip   )) json_object_set_new(json, "scf_tcp_source_ip", json_string (obj->scf_tcp_source_ip));
	if (!EMPTY(obj->scf_tcp_status      )) json_object_set_new(json, "scf_tcp_status"   , json_string (obj->scf_tcp_status));
	json_object_set_new(json, "scf_tcp_fault_time"    , json_integer(obj->scf_tcp_fault_time));
	json_object_set_new(json, "scf_tcp_fault_duration", json_integer(obj->scf_tcp_fault_duration));
	json_object_set_new(json, "webi_listen_port" , json_integer(obj->webi_listen_port));

	json_object_set_new(json, "channel_sid", json_integer(obj->channel_sid));
	json_object_set_new(json, "channel_status_change_time", json_integer(obj->channel_status_change_time));
	if (!EMPTY(obj->channel_status)) json_object_set_new(json, "channel_status", json_string (obj->channel_status));

	json_object_set_new(json, "voip_audio_volume", json_integer(obj->voip_audio_volume));
	if (!EMPTY(obj->voip_dest_ip    )) json_object_set_new(json, "voip_dest_ip" , json_string (obj->voip_dest_ip));
	json_object_set_new(json, "voip_dest_audio_port", json_integer(obj->voip_dest_audio_port));
	json_object_set_new(json, "voip_dest_mbcp_port" , json_integer(obj->voip_dest_mbcp_port));
	if (!EMPTY(obj->voip_audio_codec)) json_object_set_new(json, "voip_audio_codec" , json_string (obj->voip_audio_codec));
	if (!EMPTY(obj->voip_call_id    )) json_object_set_new(json, "voip_call_id"     , json_string (obj->voip_call_id    ));

	if (!EMPTY(obj->mbcp_status)) json_object_set_new(json, "mbcp_status" , json_string (obj->mbcp_status));
	json_object_set_new(json, "mbcp_status_change_time", json_integer(obj->mbcp_status_change_time));
	json_object_set_new(json, "mbcp_still_alive_time"  , json_integer(obj->mbcp_still_alive_time));

	json_object_set_new(json, "auto_recovery_period_sec", json_integer(obj->auto_recovery_period_sec));
	json_object_set_new(json, "firmware_update_enabled" , json_integer(obj->firmware_update_enabled));

	json_object_set_new(json, "scf_tcp_idle_sec"  , json_integer(obj->scf_tcp_idle_sec));
	json_object_set_new(json, "scf_tcp_lost_sec"  , json_integer(obj->scf_tcp_lost_sec));

	json_object_set_new(json, "usering_period_sec", json_integer(obj->usering_period_sec));
	json_object_set_new(json, "rooming_period_sec", json_integer(obj->rooming_period_sec));
	json_object_set_new(json, "joining_period_sec", json_integer(obj->joining_period_sec));

	json_object_set_new(json, "logging", json_integer(obj->logging));
	if (!EMPTY(obj->log_level)) json_object_set_new(json, "log_level" , json_string (obj->log_level));

	return json;
}

int rmsJsonUnpack_config(json_t *json, j_config_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	memset(obj, 0x00, sizeof(j_config_t));
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "version" ) == 0) { rmsHttpGetJChar(value, "version" , obj->version , sizeof(obj->version)); }
		else if (strcmp(key, "e164"    ) == 0) { rmsHttpGetJChar(value, "e164"    , obj->e164    , sizeof(obj->e164)); }
		else if (strcmp(key, "app_type") == 0) { rmsHttpGetJChar(value, "app_type", obj->app_type, sizeof(obj->app_type)); }
		else if (strcmp(key, "iuid"    ) == 0) { obj->iuid = rmsHttpGetJLong(value, "iuid"); }
		else if (strcmp(key, "auth_key") == 0) { rmsHttpGetJChar(value, "auth_key", obj->auth_key , sizeof(obj->auth_key)); }

		else if (strcmp(key, "acs_http_server_addr") == 0) { rmsHttpGetJChar(value, "acs_http_server_addr", obj->acs_http_server_addr , sizeof(obj->acs_http_server_addr)); }
		else if (strcmp(key, "rms_http_server_addr") == 0) { rmsHttpGetJChar(value, "rms_http_server_addr", obj->rms_http_server_addr , sizeof(obj->rms_http_server_addr)); }
		else if (strcmp(key, "scf_tcp_server_addr") == 0) { rmsHttpGetJChar(value, "scf_tcp_server_addr", obj->scf_tcp_server_addr , sizeof(obj->scf_tcp_server_addr)); }
		else if (strcmp(key, "scf_tcp_source_ip") == 0) { rmsHttpGetJChar(value, "scf_tcp_source_ip", obj->scf_tcp_source_ip , sizeof(obj->scf_tcp_source_ip)); }
		else if (strcmp(key, "scf_tcp_status"   ) == 0) { rmsHttpGetJChar(value, "scf_tcp_status", obj->scf_tcp_status , sizeof(obj->scf_tcp_status)); }
		else if (strcmp(key, "scf_tcp_fault_time") == 0) { obj->scf_tcp_fault_time = rmsHttpGetJInt(value, "scf_tcp_fault_time"); }
		else if (strcmp(key, "scf_tcp_fault_duration") == 0) { obj->scf_tcp_fault_duration = rmsHttpGetJInt(value, "scf_tcp_fault_duration"); }
		else if (strcmp(key, "webi_listen_port") == 0) { obj->webi_listen_port = rmsHttpGetJInt(value, "webi_listen_port"); }

		else if (strcmp(key, "channel_sid"    ) == 0) { obj->channel_sid = rmsHttpGetJLong(value, "channel_sid"); }
		else if (strcmp(key, "channel_status_change_time") == 0) { obj->channel_status_change_time = rmsHttpGetJLong(value, "channel_status_change_time"); }
		else if (strcmp(key, "channel_status"   ) == 0) { rmsHttpGetJChar(value, "channel_status", obj->channel_status , sizeof(obj->channel_status)); }

		else if (strcmp(key, "voip_audio_volume") == 0) { obj->voip_audio_volume = rmsHttpGetJInt(value, "voip_audio_volume"); }
		else if (strcmp(key, "voip_running"     ) == 0) { obj->voip_running      = rmsHttpGetJInt(value, "voip_running"); }
		else if (strcmp(key, "voip_dest_ip"     ) == 0) { rmsHttpGetJChar(value, "voip_dest_ip", obj->voip_dest_ip , sizeof(obj->voip_dest_ip)); }
		else if (strcmp(key, "voip_dest_audio_port") == 0) { obj->voip_dest_audio_port = rmsHttpGetJInt(value, "voip_dest_audio_port"); }
		else if (strcmp(key, "voip_dest_mbcp_port" ) == 0) { obj->voip_dest_mbcp_port  = rmsHttpGetJInt(value, "voip_dest_mbcp_port" ); }
		else if (strcmp(key, "voip_audio_codec") == 0) { rmsHttpGetJChar(value, "voip_audio_codec", obj->voip_audio_codec , sizeof(obj->voip_audio_codec)); }
		else if (strcmp(key, "voip_call_id"    ) == 0) { rmsHttpGetJChar(value, "voip_call_id"    , obj->voip_call_id     , sizeof(obj->voip_call_id)); }

		else if (strcmp(key, "mbcp_status"     ) == 0) { rmsHttpGetJChar(value, "mbcp_status", obj->mbcp_status , sizeof(obj->mbcp_status)); }
		else if (strcmp(key, "mbcp_status_change_time") == 0) { obj->mbcp_status_change_time= rmsHttpGetJLong(value, "mbcp_status_change_time" ); }
		else if (strcmp(key, "mbcp_still_alive_time"  ) == 0) { obj->mbcp_still_alive_time  = rmsHttpGetJLong(value, "mbcp_still_alive_time" ); }

		else if (strcmp(key, "auto_recovery_period_sec") == 0) { obj->auto_recovery_period_sec = rmsHttpGetJInt(value, "auto_recovery_period_sec" ); }
		else if (strcmp(key, "firmware_update_enabled") == 0) { obj->firmware_update_enabled = rmsHttpGetJInt(value, "firmware_update_enabled" ); }
		else if (strcmp(key, "scf_tcp_idle_sec") == 0) { obj->scf_tcp_idle_sec = rmsHttpGetJInt(value, "scf_tcp_idle_sec" ); }
		else if (strcmp(key, "scf_tcp_lost_sec") == 0) { obj->scf_tcp_lost_sec = rmsHttpGetJInt(value, "scf_tcp_lost_sec" ); }

		else if (strcmp(key, "usering_period_sec") == 0) { obj->usering_period_sec = rmsHttpGetJInt(value, "usering_period_sec" ); }
		else if (strcmp(key, "rooming_period_sec") == 0) { obj->rooming_period_sec = rmsHttpGetJInt(value, "rooming_period_sec" ); }
		else if (strcmp(key, "joining_period_sec") == 0) { obj->joining_period_sec = rmsHttpGetJInt(value, "joining_period_sec" ); }

		else if (strcmp(key, "logging"  ) == 0) { obj->logging = rmsHttpGetJInt(value, "logging" ); }
		else if (strcmp(key, "log_level") == 0) { rmsHttpGetJChar(value, "log_level", obj->log_level , sizeof(obj->log_level)); }
	}

	rmsJsonPrint_config(obj, "config");

	return 0;
}

/*****************************************************************/
/*                                                               */
/* j_modem_t                                                     */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_modem(j_modem_t *obj, char *name)
{
	comLog(DG, "%s.imei    : %s" , name, obj->imei);
	comLog(DG, "%s.cnum    : %s" , name, obj->cnum);
	comLog(DG, "%s.nsi     : %s" , name, obj->nsi);
	comLog(DG, "%s.csq     : %d" , name, obj->csq);
	comLog(DG, "%s.cgdcont : %s" , name, obj->cgdcont);
	comLog(DG, "%s.cgpaddr : %s" , name, obj->cgpaddr);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_modem(j_modem_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	if (!EMPTY(obj->imei)) json_object_set_new(json, "imei", json_string(obj->imei));
	if (!EMPTY(obj->cnum)) json_object_set_new(json, "cnum", json_string(obj->cnum));
	if (!EMPTY(obj->nsi )) json_object_set_new(json, "nsi" , json_string(obj->nsi));
	json_object_set_new(json, "csq"          , json_integer(obj->csq));
	if (!EMPTY(obj->cgdcont)) json_object_set_new(json, "cgdcont" , json_string(obj->cgdcont));
	if (!EMPTY(obj->cgpaddr)) json_object_set_new(json, "cgpaddr" , json_string(obj->cgpaddr));

	return json;
}

int rmsJsonUnpack_modem(json_t *json, j_modem_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	memset(obj, 0x00, sizeof(j_modem_t));
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "imei"   ) == 0) { rmsHttpGetJChar(value, "imei", obj->imei, sizeof(obj->imei)); }
		else if (strcmp(key, "cnum"   ) == 0) { rmsHttpGetJChar(value, "cnum", obj->cnum, sizeof(obj->cnum)); }
		else if (strcmp(key, "nsi"    ) == 0) { rmsHttpGetJChar(value, "nsi" , obj->nsi , sizeof(obj->nsi)); }
		else if (strcmp(key, "csq"    ) == 0) { obj->csq         = rmsHttpGetJInt(value, "csq"); }
		else if (strcmp(key, "cgdcont") == 0) { rmsHttpGetJChar(value, "cgdcont", obj->cgdcont , sizeof(obj->cgdcont)); }
		else if (strcmp(key, "cgpaddr") == 0) { rmsHttpGetJChar(value, "cgpaddr", obj->cgpaddr , sizeof(obj->cgpaddr)); }
	}

	rmsJsonPrint_modem(obj, "modem");

	return 0;
}


/*****************************************************************/
/*                                                               */
/* j_uname_t                                                     */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_uname(j_uname_t *obj, char *name)
{
	comLog(DG, "%s.sysname : %s" , name, obj->sysname);
	comLog(DG, "%s.nodename: %s" , name, obj->nodename);
	comLog(DG, "%s.release : %s" , name, obj->release);
	comLog(DG, "%s.version : %d" , name, obj->version);
	comLog(DG, "%s.machine : %s" , name, obj->machine);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_uname(j_uname_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	if (!EMPTY(obj->sysname )) json_object_set_new(json, "sysname" , json_string(obj->sysname));
	if (!EMPTY(obj->nodename)) json_object_set_new(json, "nodename", json_string(obj->nodename));
	if (!EMPTY(obj->release )) json_object_set_new(json, "release" , json_string(obj->release));
	if (!EMPTY(obj->version )) json_object_set_new(json, "version" , json_string(obj->version));
	if (!EMPTY(obj->machine )) json_object_set_new(json, "machine" , json_string(obj->machine));

	return json;
}

int rmsJsonUnpack_uname(json_t *json, j_uname_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	memset(obj, 0x00, sizeof(j_uname_t));
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "sysname" ) == 0) { rmsHttpGetJChar(value, "sysname" , obj->sysname, sizeof(obj->sysname)); }
		else if (strcmp(key, "nodename") == 0) { rmsHttpGetJChar(value, "nodename", obj->nodename, sizeof(obj->nodename)); }
		else if (strcmp(key, "release" ) == 0) { rmsHttpGetJChar(value, "release" , obj->release , sizeof(obj->release)); }
		else if (strcmp(key, "version" ) == 0) { rmsHttpGetJChar(value, "version" , obj->version , sizeof(obj->version)); }
		else if (strcmp(key, "machine" ) == 0) { rmsHttpGetJChar(value, "machine" , obj->machine , sizeof(obj->machine)); }
	}

	rmsJsonPrint_uname(obj, "uname");

	return 0;
}


/*****************************************************************/
/*                                                               */
/* cpustat                                                       */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_cpustat(j_cpustat_t *obj, char *name)
{
	comLog(DG, "%s.user: %f", name, obj->user);
	comLog(DG, "%s.sys : %f", name, obj->sys);
	comLog(DG, "%s.etc : %f", name, obj->etc);
	comLog(DG, "%s.idle: %f", name, obj->idle);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_cpustat(j_cpustat_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	json_object_set_new(json, "user", json_real(obj->user));
	json_object_set_new(json, "sys" , json_real(obj->sys)); 
	json_object_set_new(json, "etc" , json_real(obj->etc));
	json_object_set_new(json, "idle", json_real(obj->idle));
	
	return json;
}

int rmsJsonUnpack_cpustat(json_t *json, j_cpustat_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "user") == 0) { obj->user = rmsHttpGetJReal(value, "user"); }
		else if (strcmp(key, "sys" ) == 0) { obj->sys  = rmsHttpGetJReal(value, "sys" ); }
		else if (strcmp(key, "etc" ) == 0) { obj->etc  = rmsHttpGetJReal(value, "etc" ); }
		else if (strcmp(key, "idle") == 0) { obj->idle = rmsHttpGetJReal(value, "idle"); }
	}

	return 0;
}

/*****************************************************************/
/*                                                               */
/* memstat                                                       */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_memstat(j_memstat_t *obj, char *name)
{
	comLog(DG, "%s.total  : %lu", name, obj->total);
	comLog(DG, "%s.avail  : %lu", name, obj->avail);
	comLog(DG, "%s.freed  : %lu", name, obj->freed);
	comLog(DG, "%s.buffers: %lu", name, obj->buffers);
	comLog(DG, "%s.cached : %lu", name, obj->cached);
	comLog(DG, "%s.usage  : %f" , name, obj->usage);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_memstat(j_memstat_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	json_object_set_new(json, "total"  , json_integer(obj->total));
	json_object_set_new(json, "avail"  , json_integer(obj->avail)); 
	json_object_set_new(json, "freed"  , json_integer(obj->freed));
	json_object_set_new(json, "buffers", json_integer(obj->buffers));
	json_object_set_new(json, "cached" , json_integer(obj->cached));
	json_object_set_new(json, "usage"  , json_real(obj->usage));
	
	return json;
}

int rmsJsonUnpack_memstat(json_t *json, j_memstat_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "total"  ) == 0) { obj->total   = rmsHttpGetJLong(value, "total"); }
		else if (strcmp(key, "avail"  ) == 0) { obj->avail   = rmsHttpGetJLong(value, "avail" ); }
		else if (strcmp(key, "freed"  ) == 0) { obj->freed   = rmsHttpGetJLong(value, "freed" ); }
		else if (strcmp(key, "buffers") == 0) { obj->buffers = rmsHttpGetJLong(value, "buffers"); }
		else if (strcmp(key, "cached" ) == 0) { obj->cached  = rmsHttpGetJLong(value, "cached"); }
		else if (strcmp(key, "usage"  ) == 0) { obj->usage   = rmsHttpGetJReal(value, "usage"); }
	}

	return 0;
}

/*****************************************************************/
/*                                                               */
/* fsystat                                                       */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_fsystat(j_fsystat_t *obj, char *name)
{
	comLog(DG, "%s.name : %s" , name, obj->name);
	comLog(DG, "%s.total: %lu", name, obj->total);
	comLog(DG, "%s.freed: %lu", name, obj->freed);
	comLog(DG, "%s.avail: %lu", name, obj->avail);
	comLog(DG, "%s.usage: %f" , name, obj->usage);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_fsystat(j_fsystat_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	json_object_set_new(json, "name" , json_string (obj->name));
	json_object_set_new(json, "total", json_integer(obj->total)); 
	json_object_set_new(json, "freed", json_integer(obj->freed));
	json_object_set_new(json, "avail", json_integer(obj->avail));
	json_object_set_new(json, "usage", json_real(obj->usage));
	
	return json;
}

int rmsJsonUnpack_fsystat(json_t *json, j_fsystat_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "name" ) == 0) { rmsHttpGetJChar(value, "name", obj->name, sizeof(obj->name)); }
		else if (strcmp(key, "total") == 0) { obj->total = rmsHttpGetJLong(value, "total" ); }
		else if (strcmp(key, "freed") == 0) { obj->freed = rmsHttpGetJLong(value, "freed" ); }
		else if (strcmp(key, "avail") == 0) { obj->avail = rmsHttpGetJLong(value, "avail"); }
		else if (strcmp(key, "usage") == 0) { obj->usage = rmsHttpGetJReal(value, "usage"); }
	}

	return 0;
}

json_t *rmsJsonPack_fsystat_array(j_fsystat_t *obj, int size)
{
	json_t *json;
	int i;

	if ((json = json_array()) == NULL) {
		comLog(ER, "%s() failed to json_array()", __func__);
		return NULL;
	}

	for (i = 0; i < size; i++) {
		json_array_append_new(json, rmsJsonPack_fsystat(obj + i));
	}
	
	return json;
}

int rmsJsonUnpack_fsystat_array(json_t *json, j_fsystat_t *obj, int size)
{
	size_t  index;
	json_t *value;
	int     count;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_ARRAY) == -1) {
		comLog(WA, "%s() !array type", __func__);
		return -1;
	}
	
	count = 0;
	json_array_foreach(json, index, value) {
		comLog(DG, "%s() index........ %d", __func__, index);
		if (index < size) {
			rmsJsonUnpack_fsystat(value, obj + index);
			count++;
		}
	}

	return count;
}

/*****************************************************************/
/*                                                               */
/* netstat                                                       */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_netstat(j_netstat_t *obj, char *name)
{
	comLog(DG, "%s.name      : %s", name, obj->name);
	comLog(DG, "%s.ipkts     : %f", name, obj->ipkts);
	comLog(DG, "%s.opkts     : %f", name, obj->opkts);
	comLog(DG, "%s.iocts     : %f", name, obj->iocts);
	comLog(DG, "%s.oocts     : %f", name, obj->oocts);
	comLog(DG, "%s.ierrs     : %f", name, obj->ierrs);
	comLog(DG, "%s.oerrs     : %f", name, obj->oerrs);
	comLog(DG, "%s.collisions: %f", name, obj->collisions);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_netstat(j_netstat_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	json_object_set_new(json, "name" , json_string(obj->name));
	json_object_set_new(json, "ipkts", json_real(obj->ipkts)); 
	json_object_set_new(json, "opkts", json_real(obj->opkts));
	json_object_set_new(json, "iocts", json_real(obj->iocts));
	json_object_set_new(json, "occts", json_real(obj->oocts));
	json_object_set_new(json, "ierrs", json_real(obj->ierrs));
	json_object_set_new(json, "oerrs", json_real(obj->oerrs));
	json_object_set_new(json, "collisions", json_real(obj->collisions));
	
	return json;
}

int rmsJsonUnpack_netstat(json_t *json, j_netstat_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "name"      ) == 0) { rmsHttpGetJChar(value, "name", obj->name, sizeof(obj->name)); }
		else if (strcmp(key, "ipkts"     ) == 0) { obj->ipkts      = rmsHttpGetJReal(value, "ipkts" ); }
		else if (strcmp(key, "opkts"     ) == 0) { obj->opkts      = rmsHttpGetJReal(value, "opkts" ); }
		else if (strcmp(key, "iocts"     ) == 0) { obj->iocts      = rmsHttpGetJReal(value, "iocts"); }
		else if (strcmp(key, "oocts"     ) == 0) { obj->oocts      = rmsHttpGetJReal(value, "oocts"); }
		else if (strcmp(key, "ierrs"     ) == 0) { obj->ierrs      = rmsHttpGetJReal(value, "ierrs"); }
		else if (strcmp(key, "oerrs"     ) == 0) { obj->oerrs      = rmsHttpGetJReal(value, "oerrs"); }
		else if (strcmp(key, "collisions") == 0) { obj->collisions = rmsHttpGetJReal(value, "collisions"); }
	}

	return 0;
}

json_t *rmsJsonPack_netstat_array(j_netstat_t *obj, int size)
{
	json_t *json;
	int i;

	if ((json = json_array()) == NULL) {
		comLog(ER, "%s() failed to json_array()", __func__);
		return NULL;
	}

	for (i = 0; i < size; i++) {
		json_array_append_new(json, rmsJsonPack_netstat(obj + i));
	}
	
	return json;
}

int rmsJsonUnpack_netstat_array(json_t *json, j_netstat_t *obj, int size)
{
	size_t  index;
	json_t *value;
	int     count;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_ARRAY) == -1) {
		comLog(WA, "%s() !array type", __func__);
		return -1;
	}
	
	count = 0;
	json_array_foreach(json, index, value) {
		comLog(DG, "%s() index........ %d", __func__, index);
		if (index < size) {
			rmsJsonUnpack_netstat(value, obj + index);
			count++;
		}
	}

	return count;
}

/*****************************************************************/
/*                                                               */
/* j_statinfo_t                                                  */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_statinfo(j_statinfo_t *obj, char *name)
{
	int i;

	for (i = 0; i < obj->fsystat_count && i < MAX_FSYSTAT_NUM; i++) {
		rmsJsonPrint_fsystat(obj->fsystat_list + i, "stat.fsy");
	}
	for (i = 0; i < obj->netstat_count && i < MAX_NETSTAT_NUM; i++) {
		rmsJsonPrint_netstat(obj->netstat_list + i, "stat.net");
	}
	rmsJsonPrint_cpustat(&obj->cpustat, "stat.cpu");
	rmsJsonPrint_memstat(&obj->memstat, "stat.mem");
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_statinfo(j_statinfo_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}

	json_object_set_new(json, "fsystat_list", rmsJsonPack_fsystat_array(obj->fsystat_list, obj->fsystat_count));
	json_object_set_new(json, "netstat_list", rmsJsonPack_netstat_array(obj->netstat_list, obj->netstat_count));
	json_object_set_new(json, "cpustat"     , rmsJsonPack_cpustat(&obj->cpustat));
	json_object_set_new(json, "memstat"     , rmsJsonPack_memstat(&obj->memstat));

	return json;
}

int rmsJsonUnpack_statinfo(json_t *json, j_statinfo_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	memset(obj, 0x00, sizeof(j_statinfo_t));
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "fsystat_list") == 0) { obj->fsystat_count = rmsJsonUnpack_fsystat_array(value, obj->fsystat_list, MAX_FSYSTAT_NUM); }
		else if (strcmp(key, "netstat_list") == 0) { obj->netstat_count = rmsJsonUnpack_netstat_array(value, obj->netstat_list, MAX_NETSTAT_NUM); }
		else if (strcmp(key, "cpustat"     ) == 0) { rmsJsonUnpack_cpustat(value, &obj->cpustat); }
		else if (strcmp(key, "memstat"     ) == 0) { rmsJsonUnpack_memstat(value, &obj->memstat); }
	}

	rmsJsonPrint_statinfo(obj, "stat");

	return 0;
}

/*****************************************************************/
/*                                                               */
/* j_board_t                                                     */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_board(j_board_t *obj, char *name)
{
	int i;

	comLog(DG, "%s.request_key    : %s", name, obj->request_key);
	for (i = 0; i < obj->process_count && i < MAX_SLAVE_PROC_NUM; i++) {
		rmsJsonPrint_process(obj->process_list + i, "board.process");
	}
	rmsJsonPrint_config (&obj->config , "board.config");
	rmsJsonPrint_modem  (&obj->modem  , "board.modem");
	rmsJsonPrint_uname  (&obj->uname  , "board.uname");
	rmsJsonPrint_cpustat(&obj->cpustat, "board.cpu");
	rmsJsonPrint_memstat(&obj->memstat, "board.mem");
	for (i = 0; i < obj->fsystat_count && i < MAX_FSYSTAT_NUM; i++) {
		rmsJsonPrint_fsystat(obj->fsystat_list + i, "board.fsy");
	}
	for (i = 0; i < obj->netstat_count && i < MAX_NETSTAT_NUM; i++) {
		rmsJsonPrint_netstat(obj->netstat_list + i, "board.net");
	}
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_board(j_board_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}

	json_object_set_new(json, "request_key" , json_string(obj->request_key));
	json_object_set_new(json, "process_list", rmsJsonPack_process_array(obj->process_list, obj->process_count));
	json_object_set_new(json, "config"      , rmsJsonPack_config(&obj->config));
	json_object_set_new(json, "modem"       , rmsJsonPack_modem (&obj->modem));
	json_object_set_new(json, "uname"       , rmsJsonPack_uname (&obj->uname));
	json_object_set_new(json, "fsystat_list", rmsJsonPack_fsystat_array(obj->fsystat_list, obj->fsystat_count));
	json_object_set_new(json, "netstat_list", rmsJsonPack_netstat_array(obj->netstat_list, obj->netstat_count));
	json_object_set_new(json, "cpustat"     , rmsJsonPack_cpustat(&obj->cpustat));
	json_object_set_new(json, "memstat"     , rmsJsonPack_memstat(&obj->memstat));

	return json;
}

int rmsJsonUnpack_board(json_t *json, j_board_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	memset(obj, 0x00, sizeof(j_board_t));
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "request_key" ) == 0) { rmsHttpGetJChar(value, "request_key", obj->request_key, sizeof(obj->request_key)); }
		else if (strcmp(key, "process_list") == 0) { obj->process_count = rmsJsonUnpack_process_array(value, obj->process_list, MAX_SLAVE_PROC_NUM); }
		else if (strcmp(key, "config"      ) == 0) { rmsJsonUnpack_config(value, &obj->config); }
		else if (strcmp(key, "modem"       ) == 0) { rmsJsonUnpack_modem (value, &obj->modem ); }
		else if (strcmp(key, "uname"       ) == 0) { rmsJsonUnpack_uname (value, &obj->uname ); }
		else if (strcmp(key, "fsystat_list") == 0) { obj->fsystat_count = rmsJsonUnpack_fsystat_array(value, obj->fsystat_list, MAX_FSYSTAT_NUM); }
		else if (strcmp(key, "netstat_list") == 0) { obj->netstat_count = rmsJsonUnpack_netstat_array(value, obj->netstat_list, MAX_NETSTAT_NUM); }
		else if (strcmp(key, "cpustat"     ) == 0) { rmsJsonUnpack_cpustat(value, &obj->cpustat); }
		else if (strcmp(key, "memstat"     ) == 0) { rmsJsonUnpack_memstat(value, &obj->memstat); }
	}

	rmsJsonPrint_board(obj, "board");

	return 0;
}

/*****************************************************************/
/*                                                               */
/* omsres                                                        */
/*                                                               */
/*****************************************************************/
void rmsJsonPrint_omsres(j_omsres_t *obj, char *name)
{
	comLog(DG, "%s.result     : %d", name, obj->result);
	comLog(DG, "%s.volume     : %d", name, obj->volume);
	comLog(DG, "%s.request_key: %s", name, obj->request_key);
	comLog(DG, "************************************************************");
}

json_t *rmsJsonPack_omsres(j_omsres_t *obj)
{
	json_t *json;

	if ((json = json_object()) == NULL) {
		comLog(ER, "%s() failed to json_object()", __func__);
		return NULL;
	}
	json_object_set_new(json, "result", json_integer(obj->result));
	json_object_set_new(json, "volume", json_integer(obj->volume)); 
	json_object_set_new(json, "request_key", json_string(obj->request_key)); 
	
	return json;
}

int rmsJsonUnpack_omsres(json_t *json, j_omsres_t *obj)
{
	const char *key;
	json_t *value;

	rmsHttpPrintJ(json, __func__);

	//
	if (rmsHttpCheckJ(json, JSON_OBJECT) == -1) {
		comLog(WA, "%s() !object type", __func__);
		return -1;
	}
	
	json_object_foreach(json, key, value) {
		if      (strcmp(key, "result") == 0) { obj->result = rmsHttpGetJReal(value, "result"); }
		else if (strcmp(key, "volume") == 0) { obj->volume = rmsHttpGetJReal(value, "volume"); }
		else if (strcmp(key, "request_key" ) == 0) { rmsHttpGetJChar(value, "request_key", obj->request_key, sizeof(obj->request_key)); }
	}

	return 0;
}



