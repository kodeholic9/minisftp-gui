/**
 * @date   2016/07/25
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "librms.h"
#include "libapp.h"
#include <ctype.h>

static char info[256]; /* not thread safe!! */

static char *skip_token(char *p)
{
	while (*p != '\0' && !isspace(*p)) { p++; }
	while (*p != '\0' &&  isspace(*p)) { p++; }

	return p;
}

#if 0
static char *skip_space(char *p)
{
	while (*p != '\0' &&  isspace(*p)) { p++; }

	return p;
}
#endif

static char *http_conn_info(httpconn_t *p_hc)
{
	snprintf(info, sizeof(info), "HC/%s:%d/%s",
			p_hc->host,
			p_hc->port,
			appCodeMap2Str(CC_TcpStatus, p_hc->status));

	return info;
}

static char *http_next_line(char *p, char *line, int size)
{
	char *sp  = p;
	int   len = 0;

	memset(line, 0x00, size);

	if ((p = strstr(p, CRLF)) != NULL) {
		if ((len = p - sp) >= size) {
			len = size - 1;
		}
		if (len > 0) {
			strncpy(line, sp, len);
		}

		p += 2;
	}
	//comLog(DG, "[%s:%s]\n===============================================", line, p);

	return p;
}

static httpresp_t *http_parse_response(httpconn_t *p_hc)
{
	char  line[MAX_HTTP_HEAD_LINE_LEN];
	char *cp = p_hc->recvbuff.data;
	char *tmp;
	int   i, clen, code;

	comLog(VB, "%s() - %s", __func__, http_conn_info(p_hc));

	memset(&p_hc->response, 0x00, sizeof(httpresp_t));

	i = 0;
	while ((cp = http_next_line(cp, line, MAX_HTTP_HEAD_LINE_LEN)) != NULL) {
		comLog(DG, "[HEAD, %ld, %s]", strlen(line), line);
		/* START LINE */
		if (i == 0) {
			code = 0;
			tmp  = skip_token(line);
			while (*tmp != '\0' && isdigit(*tmp)) {
				code *= 10;
				code += ((int)(*tmp - 0x30));
				tmp++;
			}
			comLog(DG, "[STATUS_CODE, %d]", code);

			p_hc->response.code = code;
		}
		/* END OF HEAD */
		else if (strlen(line) == 0) {
			//comLog(DG, "[BODY, %ld, %s]\n", strlen(cp), cp);
			p_hc->response.content = cp;

			comLog(DG, "%s() - code: %d, clen: %d, content: 0x%08x(%d)", __func__,
					p_hc->response.code, 
					p_hc->response.clen, 
					p_hc->response.content, 
					strlen(p_hc->response.content));

			return &p_hc->response;
		}
		/* CONTENT-LENGTH */
		else if (strncasecmp(HH_CONTENT_LENGTH, line, strlen(HH_CONTENT_LENGTH)) == 0) {
			if ((tmp = strstr(line, ":")) != NULL) {
				clen = 0;
				tmp  = skip_token(tmp);
				while (*tmp != '\0' && isdigit(*tmp)) {
					clen *= 10;
					clen += ((int)(*tmp - 0x30));
					tmp++;
				}
				comLog(DG, "[%s, %d]", HH_CONTENT_LENGTH, clen);

				p_hc->response.clen = clen;
			}
		}

		i++;
	}
	comLog(ER, "%s() - fail to validate the http response!", __func__);

	return NULL;
}

static void http_update_status(httpconn_t *p_hc, int status)
{
	/* logging */
	comLog(DG, "%s() %s - new status:%s", __func__,
			http_conn_info(p_hc), appCodeMap2Str(CC_TcpStatus, status));

	p_hc->status = status;

	return;
}

static int http_connect_timeo(httpconn_t *p_hc, int timeo) 
{
	int sockfd = 0;

	comLog(VB, "%s() - %s", __func__, http_conn_info(p_hc));
	http_update_status(p_hc, TST_CONNECTING);
	
	if ((sockfd = comOpenClientSocketTimeout(p_hc->host, p_hc->port, MAX_SOCKET_BUFFER_SZ, timeo)) == -1) {
		comLog(ER, "%s() fail to comOpenClientSocketTimeout() host=%s, port=%d", __func__, p_hc->host, p_hc->port);
		http_update_status(p_hc, TST_CLOSED);
		return -1;
	}

	p_hc->sockfd = sockfd;
	http_update_status(p_hc, TST_CONNECTED);

	return sockfd;
}

static void http_close(httpconn_t *p_hc)
{
	comLog(VB, "%s() - %s", __func__, http_conn_info(p_hc));

	if (p_hc->sockfd > 0) {
		close(p_hc->sockfd);
		p_hc->sockfd = 0;

		http_update_status(p_hc, TST_CLOSED);
	}

	return;
}

static int http_write_timeo(httpconn_t *p_hc, int timeo) 
{
	sockbuffer_t *p_buffer = &p_hc->sendbuff;
	int dlen, n;

	comLog(VB, "%s() - %s", __func__, http_conn_info(p_hc));

	while ((dlen = p_buffer->limit - p_buffer->pos) > 0) {
		if ((n = comWritableTimeo(p_hc->sockfd, timeo)) == -1) {
			if (errno == EINTR) {
				continue;
			}
			comLog(ER, "%s() %s - fail to comWritableTimeo() error=%d(%s)", __func__,
					http_conn_info(p_hc), errno, strerror(errno));
			return -1;
		}
		if (n == 0) {
			comLog(ER, "%s() %s - Writable Timeout!", __func__, http_conn_info(p_hc));
			return -1;
		}

		if ((n = write(p_hc->sockfd, p_buffer->data + p_buffer->pos, dlen)) == -1) {
			if (errno == EINTR || errno == EAGAIN) {
				continue;
			}
			comLog(ER, "%s() %s - fail to write() error=%d(%s)", __func__,
					http_conn_info(p_hc), errno, strerror(errno));
			return -1;
		}

		p_buffer->pos += n;
	}

	return p_buffer->pos;
}

static int http_read_timeo(httpconn_t *p_hc, int timeo) 
{
	sockbuffer_t *p_buffer = &p_hc->recvbuff;
	int n, dlen;

	comLog(VB, "%s() - %s", __func__, http_conn_info(p_hc));

	while ((dlen = MAX_SOCKBUFF_LEN - p_buffer->limit) > 0) {
		comLog(DG, "%s() - %s - limit: %d, dlen: %d", __func__, http_conn_info(p_hc), p_buffer->limit, dlen);
		if ((n = comReadableTimeo(p_hc->sockfd, timeo)) == -1) {
			if (errno == EINTR) {
				continue;
			}
			comLog(ER, "%s() %s - fail to comReadableTimeo() error=%d(%s)", __func__,
					http_conn_info(p_hc), errno, strerror(errno));
			return -1;
		}
		if (n == 0) {
			comLog(ER, "%s() Readable Timeout!", __func__, http_conn_info(p_hc));
			return -1;
		}

		if ((n = read(p_hc->sockfd, p_buffer->data + p_buffer->limit, dlen)) == -1) {
			if (errno == EINTR || errno == EAGAIN) {
				continue;
			}
			comLog(ER, "%s() %s - fail to read() error=%d(%s)", __func__,
					http_conn_info(p_hc), errno, strerror(errno));
			return -1;
		}
		else if (n == 0) { /* EOF */
			comLog(DG, "%s() %s - read() meats EOF - error=%d(%s)", __func__,
					http_conn_info(p_hc), errno, strerror(errno));
			break;
		}
		p_buffer->limit += n;
	}

	return p_buffer->limit;
}

void rmsHttpInit(httpconn_t *p_hc, char *host, int port)
{
	memset(p_hc, 0x00, sizeof(httpconn_t));
	//
	sprintf(p_hc->host, "%s", host);
	p_hc->port = port;

	return;
}

void rmsHttpHeaderInit(httpconn_t *p_hc)
{
	memset(&p_hc->header, 0x00, sizeof(httpheader_t));
}

void rmsHttpHeaderPut(httpconn_t *p_hc, char *s)
{
	comLog(VB, "%s() - %s - %s", __func__, http_conn_info(p_hc), s);

	if (p_hc->header.count >= MAX_HTTP_HEAD_NUM) {
		comLog(ER, "%s() - Overflowed! - current: %d", __func__, p_hc->header.count);
		return;
	}
	sprintf(p_hc->header.h[p_hc->header.count], "%s", s);
	p_hc->header.count++;

	return;
}

void rmsHttpHeaderPut_LU(httpconn_t *p_hc, char *name, long value)
{
	char s[MAX_HTTP_HEAD_LINE_LEN];

	snprintf(s, MAX_HTTP_HEAD_LINE_LEN, "%s: %lu", name, value);

	rmsHttpHeaderPut(p_hc, s);
}

void rmsHttpHeaderPut_S(httpconn_t *p_hc, char *name, char *value)
{
	char s[MAX_HTTP_HEAD_LINE_LEN];

	snprintf(s, MAX_HTTP_HEAD_LINE_LEN, "%s: %s", name, value);

	rmsHttpHeaderPut(p_hc, s);
}

void rmsHttpHeaderPut_D(httpconn_t *p_hc, char *name, int value)
{
	char s[MAX_HTTP_HEAD_LINE_LEN];

	snprintf(s, MAX_HTTP_HEAD_LINE_LEN, "%s: %d", name, value);

	rmsHttpHeaderPut(p_hc, s);
}

void rmsHttpHeaderPut_U(httpconn_t *p_hc, char *name, int value)
{
	char s[MAX_HTTP_HEAD_LINE_LEN];

	snprintf(s, MAX_HTTP_HEAD_LINE_LEN, "%s: %u", name, value);

	rmsHttpHeaderPut(p_hc, s);
}

int rmsHttpRequest(httpconn_t *p_hc, char *method, char *url, char *data, int timeo)
{
	sockbuffer_t *p_buffer = &p_hc->sendbuff;
	int cc, n, i;

	comLog(VB, "%s() - %s", __func__, http_conn_info(p_hc));

	//init buffer
	memset(p_buffer, 0x00, sizeof(sockbuffer_t));

	//connect
	if (http_connect_timeo(p_hc, timeo) == -1) {
		comLog(ER, "%s() - fail to http_connect_timeo()", __func__);
		return -1;
	}

	//pack http-request
	n = snprintf(p_buffer->data, MAX_SOCKBUFF_LEN,
			"%s %s HTTP/1.1\r\n"
			"host: %s:%d\r\n"
			"connection: close\r\n"
			"content-type: application/json\r\n"
			"user-agent: %s\r\n",
			method,
			url,
			p_hc->host, p_hc->port,
			HHV_USER_AGENT);

	//headers...
	for (i = 0; i < p_hc->header.count; i++) {
		n += snprintf(p_buffer->data + n, MAX_SOCKBUFF_LEN, "%s\r\n", p_hc->header.h[i]);
	}

	//data
	n += snprintf(p_buffer->data + n, MAX_SOCKBUFF_LEN, 
			"content-length: %d\r\n\r\n"
			"%s",
			(data != NULL) ? (int)strlen(data) : 0,
			(data != NULL) ?             data  : "");

	p_buffer->pos   = 0;
	p_buffer->limit = n;

	//write to...
	if ((cc = http_write_timeo(p_hc, timeo)) == -1) {
		comLog(ER, "%s() - fail to http_write_timeo()", __func__);
		http_close(p_hc);
		return -1;
	}

	comLog(IN, "[REQUEST]\n%s", p_buffer->data);

	return cc;
}

httpresp_t *rmsHttpResponse(httpconn_t *p_hc, int timeo)
{
	sockbuffer_t *p_buffer = &p_hc->recvbuff;
	int n = 0;

	if ((n = http_read_timeo(p_hc, timeo)) > 0) {
		comLog(IN, "[RESPONSE]\n%s", p_buffer->data);
	}
	http_close(p_hc);

	return (n > 0) ? http_parse_response(p_hc) : NULL;
}


/*********************************************************/
/*                                                       */
/*------- JSON module                                    */
/*                                                       */
/*********************************************************/
void print_json(json_t *root);
void print_json_aux(json_t *element, int indent);
void print_json_indent(int indent);
const char *json_plural(int count);
void print_json_object(json_t *element, int indent);
void print_json_array(json_t *element, int indent);
void print_json_string(json_t *element, int indent);
void print_json_integer(json_t *element, int indent);
void print_json_real(json_t *element, int indent);
void print_json_true(json_t *element, int indent);
void print_json_false(json_t *element, int indent);
void print_json_null(json_t *element, int indent);

/** convert Text --> Json */
json_t *rmsHttpText2Json(const char *text)
{
	json_t *root;
	json_error_t error;

	comLog(VB, "%s() - text: %s", __func__, text);

	if ((root = json_loads(text, 0, &error)) == NULL) {
		comLog(ER, "%s() - fail to json_loads() - %s(%d)", __func__, error.text, error.line);
		return NULL;
	}

	return root;
}

/** convert Json --> Text */
char *rmsHttpJson2Text(const json_t *json, char *text, size_t len)
{
	char *s;

	if ((s = json_dumps(json, JSON_ENCODE_ANY)) == NULL) {
		comLog(ER, "%s() - fail to json_dumps()", __func__);
		return NULL;
	}
	snprintf(text, len, "%s", s);

	/* s should be freed!! */
	free(s);

	return text;
}

void rmsHttpFreeJson(json_t **json)
{
	if (*json != NULL) {
		json_decref(*json);
		*json = NULL;
	}
}

int rmsHttpCheckJ(json_t *json, int expected)
{
	if (json == NULL) {
		comLog(ER, "%s() - json is NULL!", __func__);
		return -1;
	}

	if (json_typeof(json) != expected) {
		comLog(ER, "%s() - typeof json is not expected!", __func__);
		return -1;
	}

	return 0;
}

void rmsHttpPrintJ(json_t *json, const char *func)
{
#ifdef __TRACE__
	print_json_aux(json, 0);
#endif
}

int rmsHttpGetJChar(json_t *json, char *name, char *text, size_t len)
{
	const char *s = json_string_value(json);
	if (s == NULL) {
		comLog(ER, "%s() value of %s: null", __func__, name);
		return -1;
	}
	comLog(VB, "%s() value of %s: %s", __func__, name, s);
	snprintf(text, len, "%s", s);

	return 0;
}

int rmsHttpGetJInt(json_t *json, char *name)
{
	int n = json_integer_value(json);

	comLog(VB, "%s() value of %s: %d", __func__, name, n);

	return n;
}

long rmsHttpGetJLong(json_t *json, char *name)
{
	long n = json_integer_value(json);

	comLog(VB, "%s() value of %s: %ld", __func__, name, n);

	return n;
}

double rmsHttpGetJReal(json_t *json, char *name)
{
	double n = json_real_value(json);

	comLog(VB, "%s() value of %s: %f", __func__, name, n);

	return n;
}

void print_json_aux(json_t *element, int indent)
{
	switch (json_typeof(element)) {
		case JSON_OBJECT : print_json_object(element , indent); break;
		case JSON_ARRAY  : print_json_array(element  , indent); break;
		case JSON_STRING : print_json_string(element , indent); break;
		case JSON_INTEGER: print_json_integer(element, indent); break;
		case JSON_REAL   : print_json_real(element   , indent); break;
		case JSON_TRUE   : print_json_true(element   , indent); break;
		case JSON_FALSE  : print_json_false(element  , indent); break;
		case JSON_NULL   : print_json_null(element   , indent); break;
		default:
			comLog(ER, "%s() - unrecognized JSON type %d", __func__, json_typeof(element));
	}
}

void print_json_indent(int indent)
{
#if 0
	int i;
	for (i = 0; i < indent; i++) { putchar(' '); }
#endif
}

const char *json_plural(int count)
{
	return count == 1 ? "" : "s";
}

void print_json_object(json_t *element, int indent)
{
	size_t size;
	const char *key;
	json_t *value;

	print_json_indent(indent);
	size = json_object_size(element);

	comLog(VB, "JSON Object of %ld pair%s:", size, json_plural(size));
	json_object_foreach(element, key, value) {
		print_json_indent(indent + 2);
		comLog(VB, "JSON Key: \"%s\"", key);
		print_json_aux(value, indent + 2);
	}

}

void print_json_array(json_t *element, int indent)
{
	size_t i;
	size_t size = json_array_size(element);
	print_json_indent(indent);

	comLog(VB, "JSON Array of %ld element%s:", size, json_plural(size));
	for (i = 0; i < size; i++) {
		print_json_aux(json_array_get(element, i), indent + 2);
	}
}

void print_json_string(json_t *element, int indent)
{
	print_json_indent(indent);
	comLog(VB, "JSON String: \"%s\"", json_string_value(element));
}

void print_json_integer(json_t *element, int indent)
{
	print_json_indent(indent);
	comLog(VB, "JSON Integer: \"%" JSON_INTEGER_FORMAT "\"", json_integer_value(element));
}

void print_json_real(json_t *element, int indent)
{
	print_json_indent(indent);
	comLog(VB, "JSON Real: %f", json_real_value(element));
}

void print_json_true(json_t *element, int indent)
{
	(void)element;
	print_json_indent(indent);
	comLog(VB, "JSON True");
}

void print_json_false(json_t *element, int indent)
{
	(void)element;
	print_json_indent(indent);
	comLog(VB, "JSON False");
}

void print_json_null(json_t *element, int indent)
{
	(void)element;
	print_json_indent(indent);
	comLog(VB, "JSON Null");
}






