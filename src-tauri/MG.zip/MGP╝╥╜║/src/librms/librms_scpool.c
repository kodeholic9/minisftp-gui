/**
 * @date   2016/08/22
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "librms.h"

/** ----------------------------------------------------- */

/** @private */
scpool_t *SCPOOL_PTR(scbase_t *p_base, int pool_id, const char *f)
{
	scpool_t *p_pool;

	comLog(VB, "%s()", __func__);

	if (pool_id >= MAX_SCPOOL_NUM || pool_id <= 0) {
		comLog(ER, "%s/%s() - INVALID POOL_ID(%d)", f, __func__, pool_id);
		return NULL;
	}
	p_pool = p_base->pool + pool_id;

	if (p_pool->id != pool_id) {
		comLog(ER, "%s/%s() - MISMATCHED(%d != %d) POOL_ID(%d)", f, __func__, pool_id, p_pool->id, pool_id);
		return NULL;
	}

	return p_pool;
}

/** @private */
int _scpool_init(scbase_t *p_base)
{
	int i;
	scpool_t *p_pool;
	pqlink_t *p_qlink;

	comLog(VB, "%s()", __func__);

	/* init queue */
	p_base->freeQ.qname = PQNAME_FREE;
	p_base->pendQ.qname = PQNAME_PEND;
	p_base->sendQ.qname = PQNAME_SEND;

	/* prepare for the links.. */
	for (i = DATA_START; i < MAX_SCPOOL_NUM; i++) {
		/* for shortcut */
		p_pool  = p_base->pool  + i;
		p_qlink = p_pool->qlink + PQNAME_FREE;

		/* for the first and last */
		if (i != (MAX_SCPOOL_NUM - 1)) { p_qlink->R = i + 1; }
		if (i !=  DATA_START         ) { p_qlink->L = i - 1; }

		/* update the pool metas */
		p_pool->status = PST_FREED;
		p_pool->id     = i;

		/* update the mesgFreeQ... */
		p_base->freeQ.qnum += 1;
	}

	/* assign the queue H/T */
	p_base->freeQ.H = DATA_START;
	p_base->freeQ.T = MAX_SCPOOL_NUM - 1;

	return 0;
}

/** @private */
int _scpool_update_status(scpool_t *p_pool, int status, const char *f)
{
	comLog(DG, "%s/%s() -  POOL_ID(%d) %s --> %s",
			f, __func__,
			p_pool->id,
			appCodeMap2Str(CC_MpStatus, p_pool->status),
			appCodeMap2Str(CC_MpStatus, status));

	/* update.. */
	p_pool->status = status;

	return 0;
}

/** @private */
scpool_t *_scpool_rmque(scbase_t *p_base, pqueue_t *p_mqueue, int pool_id, const char *f)
{
	scpool_t *p_pool, *Rp, *Lp;
	int       qname = p_mqueue->qname;

	comLog(VB, "%s/%s() - POOL_ID(%d), qname: %d", f, __func__, pool_id, qname);

	/* ---- check ERROR */
	if ((p_pool = SCPOOL_PTR(p_base, pool_id, __func__)) == NULL) {
		comLog(ER, "%s/%s() - fail to SCPOOL_PTR() - POOL_ID(%d)", f, __func__, pool_id);
		return NULL;
	}
	
	/* ---- for H/T and R/L things */
	if (p_pool->qlink[qname].R > 0
			&& (Rp = SCPOOL_PTR(p_base, p_pool->qlink[qname].R, __func__)) != NULL)
	{
		Rp->qlink[qname].L = p_pool->qlink[qname].L;
	}
	if (p_pool->qlink[qname].L > 0
		   	&& (Lp = SCPOOL_PTR(p_base, p_pool->qlink[qname].L, __func__)) != NULL)
	{
		Lp->qlink[qname].R = p_pool->qlink[qname].R;
	}

	/* -- */
	if (pool_id == p_mqueue->H) { p_mqueue->H = p_pool->qlink[qname].R; }
	if (pool_id == p_mqueue->T) { p_mqueue->T = p_pool->qlink[qname].L; }

	/* update the mpool itself */
	p_pool->qlink[qname].R = 0;
	p_pool->qlink[qname].L = 0;

	/* update the qnum */
	p_mqueue->qnum -= 1;

	return p_pool;
}

/** @private */
scpool_t *_scpool_enque(scbase_t *p_base, pqueue_t *p_mqueue, scpool_t *p_pool, const char *f)
{
	scpool_t *p_tail;
	int       qname = p_mqueue->qname;

	comLog(VB, "%s/%s() - POOL_ID(%d), qname: %d", f, __func__, p_pool->id, qname);

	/* ---- for H/T and R/L things */
	if (p_mqueue->T == 0) {
		p_mqueue->H = p_pool->id;
		p_mqueue->T = p_pool->id;
		p_pool->qlink[qname].R = 0;
		p_pool->qlink[qname].L = 0;
	}
	else {
		/* for T */
		p_tail = p_base->pool + p_mqueue->T;
		p_tail->qlink[qname].R = p_pool->id;

		/* for R and L */
		p_pool->qlink[qname].L = p_mqueue->T;
		p_pool->qlink[qname].R = 0;
		p_mqueue->T = p_pool->id;
	}
	
	/* ---- update the queue number */
	p_mqueue->qnum += 1;

	return SCPOOL_PTR(p_base, p_mqueue->H, __func__);
}

/** @private */
scpool_t *_scpool_deque(scbase_t *p_base, pqueue_t *p_mqueue, const char *f)
{
	comLog(VB, "%s()", __func__);

	if (p_mqueue->H == 0) {
		return NULL;
	}

	return _scpool_rmque(p_base, p_mqueue, p_mqueue->H, f);
}

/** @private */
scpool_t *_scpool_qscan(scbase_t *p_base, pqueue_t *p_mqueue, int Rflag, scpoolCallback *proc, void *p_args)
{
	scpool_t *p_pool;
	int       current, i, cc;
	int       qname = p_mqueue->qname;

	comLog(VB, "%s()", __func__);

	/* qstart */
	current = (Rflag) ? p_mqueue->H : p_mqueue->T;

	/* qscan */
	for (i = 0; current > 0 && i < MAX_SCPOOL_NUM; i++) {
		if ((p_pool = SCPOOL_PTR(p_base, current, __func__)) == NULL) {
			return NULL;
		}
		if ((cc = proc(p_base, p_mqueue, p_pool, p_args)) == RET_ERROR) {
			comLog(WA, "%s() Meets RET_ERROR while processing queue(%s). POOL_ID(%d)",
					__func__, appCodeMap2Str(CC_MpQName, qname), current);
			return NULL;
		}
		else if (cc == RET_FOUND) {
			//comLog(DG, "%s() Meets RET_FOUND while procession Cmqueue(%s).CmpoolId(%d)",
			//		__func__, appCodeMap2Str(CC_CpsPoolQName, qname), current);
			return p_pool;
		}
		else if (cc == RET_NOTFOUND) {
			;
			//comLog(DG, "%s() Meets RET_NOTFOUND while procession Cmqueue(%s).CmpoolId(%d)",
			//		__func__, appCodeMap2Str(CC_CpsPoolQName, qname), current);
		}

		/* qnext */
		current = (Rflag) ? p_pool->qlink[qname].R : p_pool->qlink[qname].L;
	}

	return NULL;
}

/** mCallback */
int _sccallback_expired(scbase_t *p_base, pqueue_t *p_mqueue, scpool_t *p_pool, void *p_args)
{
	time_t exptime  = *(time_t *)p_args;

	/*comLog(VB, "check expiring(%f < %f) for MPOOL(%d)", p_mpool->meta.nexttime, exptime, p_mpool->meta.id);*/

	if (p_pool->nexttime < exptime) {
#if 0
		if (_mpool_rmque(p_magic, p_mqueue, p_mpool->meta.id, __func__, __LINE__) == NULL) {
			return RET_ERROR;
		}
#endif
		return RET_FOUND;
	}

	return RET_NOTFOUND;
}

/** @private */
int _sccallback_responsed(scbase_t *p_base, pqueue_t *p_mqueue, scpool_t *p_pool, void *p_args)
{
	unsigned int pid = *(unsigned int *)p_args;

	if (p_pool->id == pid) {
		return RET_FOUND;
	}

	return RET_NOTFOUND;
}

/************************************************************************/
/* QUEUE INIT                                                           */
/************************************************************************/
void rmsScpoolInit(scbase_t *p_base)
{
	comLog(VB, "%s()", __func__);

	memset(p_base, 0x00, sizeof(scbase_t));

	_scpool_init(p_base);
}

/************************************************************************/
/* FREE QUEUE                                                           */
/************************************************************************/
scpool_t *rmsScpoolAlloc(scbase_t *p_base)
{
	scpool_t *p_pool = NULL;

	comLog(VB, "%s()", __func__);

	if ((p_pool = _scpool_deque(p_base, &p_base->freeQ, __func__)) == NULL) {
		return NULL;
	}
	_scpool_update_status(p_pool, PST_USING, __func__);

	/* init datapart */
	memset(&p_pool->_d, 0x00, sizeof(scpooldata_t));

	return p_pool;
}

scpool_t *rmsScpoolRelease(scbase_t *p_base, scpool_t *p_pool)
{
	comLog(VB, "%s()", __func__);

	if (p_pool->status == PST_FREED) {
		comLog(ER, "%s() INVALID POOL STATUS(%d) - POOL_ID(%d)", __func__, p_pool->status, p_pool->id);
		return NULL;
	}
	if (_scpool_enque(p_base, &p_base->freeQ, p_pool, __func__) == NULL) {
		return NULL;
	}
	_scpool_update_status(p_pool, PST_FREED, __func__);

	return p_pool;
}

/************************************************************************/
/* PENDING QUEUE                                                        */
/************************************************************************/
scpool_t *rmsScpoolPutPending(scbase_t *p_base, scpool_t *p_pool, time_t exprtime)
{
	comLog(VB, "%s()", __func__);

	/* enqueue */
	if (_scpool_enque(p_base, &p_base->pendQ, p_pool, __func__) != NULL) {
		_scpool_update_status(p_pool, PST_PENDING, __func__);
		p_pool->nexttime = exprtime;
		return p_pool;
	}

	return NULL;
}

/************************************************************************/
/* SENDING QUEUE                                                        */
/************************************************************************/
scpool_t *rmsScpoolPutSending(scbase_t *p_base, int winsz)
{
	scpool_t *p_pool  = NULL;

	comLog(VB, "%s()", __func__);

	if (p_base->sendQ.qnum < winsz) {
		if ((p_pool = _scpool_deque(p_base, &p_base->pendQ, __func__)) != NULL
				&& _scpool_enque(p_base, &p_base->sendQ, p_pool, __func__) != NULL)
		{
			_scpool_update_status(p_pool, PST_SENDING, __func__);
			return p_pool;
		}
	}

	return NULL;
}

scpool_t *rmsScpoolGetResponsed(scbase_t *p_base, int pid)
{
	scpool_t  *p_pool  = NULL;

	comLog(VB, "%s() - POOL_ID(%d)", __func__, pid);

	/* scan mqueue */
	if ((p_pool = _scpool_qscan(p_base, &p_base->sendQ, TRUE, _sccallback_responsed, &pid)) == NULL) {
		comLog(WA, "%s() - NOT IN sendQ - POOL_ID(%d)", __func__, pid);
		return NULL;
	}
	if (p_pool->status != PST_SENDING) {
		comLog(WA, "%s() - MISMATCHED STATUS(%d != %d) - POOL_ID(%d)", __func__, p_pool->status, PST_SENDING, pid);
		return NULL;
	}

	/* remove from mqueue */
	if (_scpool_rmque(p_base, &p_base->sendQ, pid, __func__) == NULL) {
		return NULL;
	}

	/* update status */
	_scpool_update_status(p_pool, PST_USING, __func__);

	return p_pool;
}

scpool_t *rmsScpoolGetExpired(scbase_t *p_base, time_t currtime)
{
	scpool_t *p_pool  = NULL;

	comLog(VB, "%s()", __func__);

	/* scan from sendingQ */
	if ((p_pool = _scpool_qscan(p_base, &p_base->sendQ, TRUE, _sccallback_expired, &currtime)) != NULL) {
		if (_scpool_rmque(p_base, &p_base->sendQ, p_pool->id, __func__) == NULL) {
			return NULL;
		}

		/* update status */
		_scpool_update_status(p_pool, PST_USING, __func__);

		return p_pool;
	}

	/* scan from pendingQ */
	if ((p_pool = _scpool_qscan(p_base, &p_base->pendQ, TRUE, _sccallback_expired, &currtime)) != NULL) {
		if (_scpool_rmque(p_base, &p_base->pendQ, p_pool->id, __func__) == NULL) {
			return NULL;
		}

		/* update status */
		_scpool_update_status(p_pool, PST_USING, __func__);

		return p_pool;
	}

	return NULL;
}

scpool_t **rmsScpoolAllocArray(scbase_t *p_base, pqueue_t *p_mqueue)
{
	scpool_t  *p_pool;
	scpool_t **pp_pool;
	int current, i;
	int qname = p_mqueue->qname;
	int qnum  = p_mqueue->qnum;

	if ((pp_pool= (scpool_t **)malloc(sizeof(scpool_t *) * (qnum + 1))) == NULL) {
		comLog(ER, "%s() - fail to malloc() error=%d(%s)", __func__, errno, strerror(errno));
		return NULL;
	}

	/* LOOP */
	current = p_mqueue->H;
	for (i = 0; i < qnum && current > 0; i++) {
		if ((p_pool = SCPOOL_PTR(p_base, current, __func__)) == NULL) {
			break;
		}
		*(pp_pool + i) = p_pool;
		current = p_pool->qlink[qname].R;
	}	
	*(pp_pool + i) = NULL;

	return pp_pool;
}

int rmsScpoolReleaseArray(scpool_t **pp_pool)
{
	if (pp_pool!= NULL) {
		free(pp_pool);
	}

	return 0;
}

