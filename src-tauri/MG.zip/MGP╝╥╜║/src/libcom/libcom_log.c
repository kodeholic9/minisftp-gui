#include "libcom.h"

int gLogLevel = DG;

char *__tty_color[] = {
	"\033[0;40;30m",       /* 0   black on black */
	"\033[0;40;31m",       /* 1   red */
	"\033[0;40;32m",       /* 2   green */
	"\033[0;40;33m",       /* 3   brown */    
	"\033[0;40;34m",       /* 4   blue */           
	"\033[0;40;35m",       /* 5   magenta */              
	"\033[0;40;36m",       /* 6   cyan */                       
	"\033[0;40;37m",       /* 7   light gray */                       
	"\033[1;40;30m",       /* 0   gray */                                   
	"\033[1;40;31m",       /* 1   brightred */                                    
	"\033[1;40;32m",       /* 2   brightgreen */                                        
	"\033[1;40;33m",       /* 3   yellow */
	"\033[1;40;34m",       /* 4   brightblue */                                               
	"\033[1;40;35m",       /* 5   brighmagenta */
	"\033[1;40;36m",       /* 6   brightcyan */                                                     
	"\033[1;40;37m",       /* 7   white */
};

int comLogLevelSet(int lv)
{
	if     (lv < ER) { lv = ER; }
	else if(lv > VB) { lv = VB; }

	if (gLogLevel != lv) {
		gLogLevel = lv;
	}

	return 0;
}

int comLogLevelGet() 
{
	return gLogLevel;
}

/** @private */
char *comLogTimeFormat(char *s)
{
	struct timeval tmval;
	struct tm tm;
	int    usec;

	gettimeofday(&tmval, NULL);
	localtime_r(&tmval.tv_sec, &tm);
	usec = (int)tmval.tv_usec / 1000;
#if 1
	sprintf(s, "%.2d-%.2d %.2d:%.2d:%.2d.%.3d",
			tm.tm_mon + 1, tm.tm_mday,
			tm.tm_hour, tm.tm_min, tm.tm_sec, usec);
#else
	sprintf(s, "%.2d:%.2d:%.2d.%.6d",
			tm.tm_hour, tm.tm_min, tm.tm_sec, (int)tmval.tv_usec);
#endif

	return s;
}

/** @private */
void comLogFunc(int lv, const char *f, const int l, int error, char *format, ...)
{
	va_list ap;
	char    tms[30];
	char    fmt[256];
	char    buffer[8192];

	if (lv > gLogLevel) { return; }

	/* makeup format */
	if (error) {
		snprintf(fmt, sizeof(fmt), "%s %d %s %s: (%d)%s %s\n",
				comLogTimeFormat(tms),
				getpid(),
				comLogLevel2Str(lv),
				appName(ApId),
				error,
				strerror(error),
				format);
	}
	else {
		snprintf(fmt, sizeof(fmt), "%s %d %s %s: %s\n",
				comLogTimeFormat(tms),
				getpid(),
				comLogLevel2Str(lv),
				appName(ApId),
				format);
	}

	/* dynamic logging */
	va_start(ap, format);
	vsnprintf(buffer, sizeof(buffer), fmt, ap);
	va_end(ap);

	/* flush.. */
	fprintf(stdout, "%s", buffer);
	fflush (stdout);

	/* for trace */
	//comLogFifoWrite(buffer);

	return;
}

void comWelcome(char *pname)
{
	comLog(ER, "=============================================================");
	comLog(ER, "\t\tWelcome to...[%s]", pname);
	comLog(ER, "=============================================================");

	return ;
}

void comGoodbye(int code)
{
	comLog(ER, "=============================================================");
	comLog(ER, "\t\tGood Bye (%d)", code);
	comLog(ER, "=============================================================");

	return ;
}

char *comLogLevel2Str(int lv)
{
	switch (lv) {
		case ER: return "E"; break;
		case WA: return "W"; break;
		case IN: return "I"; break;
		case DG: return "D"; break;
		case VB:
		default:
				 return "V";
	}
}

int comLogTraceCreate()
{
	char   path[128];
	struct stat sb;

	comGetTmpPath(TRACE_F, path);

	if (stat(path, &sb) == -1 || !S_ISFIFO(sb.st_mode)) {
		unlink(path);
		if (mkfifo(path, 0666) == -1) {
			fprintf(stderr, "%s() - fail to mkfifo(%s) error=%s(%d)\n", __func__, path, strerror(errno), errno);
			return -1;
		}
	}

	return 0;
}

int comLogRedirect(const char *path, const char *opt, int nonb)
{
	comLog(IN, "%s() - path: %s", __func__, path);

	/* redirect to ... */
	if (path == NULL || freopen(path, opt, stdout) == NULL) {
		if (freopen("/dev/null", opt, stdout) == NULL) {
			; // nothing to do!
		}
	}
	if (path == NULL || freopen(path, opt, stderr) == NULL) {
		if (freopen("/dev/null", opt, stderr) == NULL) {
			; // nothing to do!
		}
	}

	/* flush when it meets newline */
	setvbuf(stdout, 0, _IOLBF, 0);
	setvbuf(stderr, 0, _IOLBF, 0);

	/* set non-blocking mode */
	if (nonb) {
		fcntl(fileno(stdout), F_SETFL, fcntl(fileno(stdout), F_GETFL, 0) | O_NONBLOCK);
		fcntl(fileno(stderr), F_SETFL, fcntl(fileno(stderr), F_GETFL, 0) | O_NONBLOCK);
	}

	/* EPIPE */
	comInstallSignal(SIGPIPE, comIgnoreFunc);

	return 0;
}



