#include "libcom.h"
#include <ctype.h>
#include <wchar.h>
#if 0
#include <wctype.h>
#endif

uint comHashFuncJenkins(char *key, int klen)
{
	unsigned int hash = 0;
	int          i;

	for (i = 0; i < klen; i++) {
		hash += key[i];
		hash += (hash << 10);
		hash ^= (hash >> 6);
	}
	hash += (hash << 3);
	hash ^= (hash >> 11);
	hash += (hash << 15);

	return hash;
}

Sigfunc *comInstallSignal(int signo, Sigfunc *func)
{
	struct sigaction act, oact;
	act.sa_handler = func;
	sigemptyset(&act.sa_mask);
	act.sa_flags = 0;

#ifdef SA_INTERRUPT
	act.sa_flags |= SA_INTERRUPT;
#endif

	act.sa_flags |= SA_RESTART;

	if(sigaction(signo, &act, &oact) < 0) {
		return (SIG_ERR);
	}
	return  (oact.sa_handler);
}

void comIgnoreFunc(int signo)
{
	; // empty handler 
}

int comAscii2Int(char *s)
{
	int x;

	if (strncmp(s, "0x", 2) == 0) {
		x  = 0;
		s += 2;
		while (*s) {
			if (*s >= 'a' && *s <= 'f')
				x = x * 16 + *s - 'a' + 10;
			else if (*s >= 'A' && *s <= 'F')
				x = x * 16 + *s - 'A' + 10;
			else if (*s >= '0' && *s <= '9')
				x = x * 16 + *s - '0';
			else
				break;
			s++;
		} 

		return x;
	}

	return atoi(s);
}

void comDumpRaw(int lv, unsigned char *msg, int len)
{
	int            i, offset, n, dumped = 0, saved = 0, offset2 = 0;
	char           line[MAX_LINE_SIZE] = {0, };
	unsigned char *p = msg;
	unsigned char *q;

	if (lv > WA && lv > gLogLevel) return;

	offset = printf("----- D'%d(H'%x) bytes ", len, len);
	printf("%.*s\n", 80-offset, "----------------------------------------------------------------------\n");
	printf("       0    2    4    6    8    10   12   14   16   18     01234567890123456789\n");
	printf("--------------------------------------------------------------------------------\n");

	while (1) {
		q = p;
		saved = dumped;

		n += sprintf(line+n, "%04d : ", offset2++ * 20);
		for (i=0; i<20 && dumped<len; i++, dumped++) {
			n += sprintf(line+n, "%02x", q[i]);
			if ((i+1) % 2 == 0) {
				n += sprintf(line+n, " ");
			}
		}
		for (; i<20; i++) {
			n += sprintf(line+n, "  ");
			if ((i+1) % 2 == 0) {
				n += sprintf(line+n, " ");
			}
		}
		n += sprintf(line+n, "| ");

		q = p;
		dumped = saved;
		for (i=0; i<20 && dumped<len; i++, dumped++) {
			if (0x20 <= q[i] && q[i] <= 0x7e) {
				n += sprintf(line+n, "%c", q[i]);
			}
			else {
				n += sprintf(line+n, ".");
			}
		}
		fprintf(stdout, "%s\n", line);

		if (dumped == len) break;
		p += 20;
		n = 0;
		//memset(line, 0, sizeof(line));
	}
	fprintf(stdout, "================================================================================\n");
	fflush (stdout);
}

int comDumpRaw2Buff(unsigned char *msg, int len, char *buff, int buflen)
{
	int            i, offset, n, dumped = 0, saved = 0, offset2 = 0;
	unsigned char *p = msg;
	unsigned char *q;

	n  = offset = snprintf(buff, buflen, "----- D'%d(H'%x) bytes ", len, len);
	n += snprintf(buff + n, buflen - n,
			"%.*s\n", 80-offset, "----------------------------------------------------------------------\n");
	n += snprintf(buff + n, buflen - n,
			"       0    2    4    6    8    10   12   14   16   18     01234567890123456789\n");
	n += snprintf(buff + n, buflen - n,
			"--------------------------------------------------------------------------------\n");

	while (n < buflen) {
		q = p;
		saved = dumped;

		n += snprintf(buff + n, buflen - n, "%04d : ", offset2++ * 20);
		for (i=0; i<20 && dumped<len; i++, dumped++) {
			n += snprintf(buff + n, buflen - n, "%02x", q[i]);
			if ((i+1) % 2 == 0) {
				n += snprintf(buff + n, buflen - n, " ");
			}
		}
		for (; i<20; i++) {
			n += snprintf(buff + n, buflen - n, "  ");
			if ((i+1) % 2 == 0) {
				n += snprintf(buff + n, buflen - n, " ");
			}
		}
		n += snprintf(buff + n, buflen - n, "| ");

		q = p;
		dumped = saved;
		for (i=0; i<20 && dumped<len; i++, dumped++) {
			if (0x20 <= q[i] && q[i] <= 0x7e) {
				n += snprintf(buff + n, buflen - n, "%c", q[i]);
			}
			else {
				n += snprintf(buff + n, buflen - n, ".");
			}
		}
		n += snprintf(buff + n, buflen - n, "\n");

		if (dumped == len) break;
		p += 20;
	}
	n += snprintf(buff + n, buflen - n, "================================================================================\n");

	return n;
}

char *comTrim(char *str)
{
	char *ibuf, *obuf;

	if (str) {
		for (ibuf = obuf = str; *ibuf; ) {
			while (*ibuf && (isspace((int)*ibuf)))
				ibuf++;
			if (*ibuf && (obuf != str))
				*(obuf++) = ' ';
			while (*ibuf && (!isspace((int)*ibuf)))
				*(obuf++) = *(ibuf++);
		}
		*obuf = '\0';
	}

	return (str);
}

char *comSkipToken(const char *p)
{
	while (isspace((int)(*p)))
		p++;
	while (*p && !isspace((int)(*p)))
		p++;

	return (char *)p;
}

char *comSkipWS(const char *p)
{
	while (isspace((int)(*p)))
		p++;

	return (char *)p;
}

#if 0
static unsigned int hex2int(char *s)
{
	unsigned int i, v = 0;

	for (i = 0; i < 2; i++) {
		v <<= 4;

		switch (s[i]) {
			case 'A': case 'a': v += 10        ; break;
			case 'B': case 'b': v += 11        ; break;
			case 'C': case 'c': v += 12        ; break;
			case 'D': case 'd': v += 13        ; break;
			case 'E': case 'e': v += 14        ; break;
			case 'F': case 'f': v += 15        ; break;
			default           : v += s[i] - '0'; break;
		}
	}

	return v;
}

int comHexLine2Bin(char *from, char *to, int limit)
{
	int i;

	i = 0;
	while (*from && i < limit) {
		if (iswalnum((wint_t)*from)) {
			*to = (unsigned char)hex2int(from);
			from++; to++;
			i++;
		}
		from++;
	}

	return i;
}
#endif
