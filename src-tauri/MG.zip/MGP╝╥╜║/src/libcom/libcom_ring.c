#include <libcom.h>

// Internal function (do not use in direct!!)
/** @private */
int __rb_clear(variable_ringbuffer_t *p_rb)
{
	memset(p_rb, 0x00, sizeof(variable_ringbuffer_t));

	return 0;
}

/** @private */
int __rb_used(variable_ringbuffer_t *p_rb)
{
	int u;

	if ((u = p_rb->w - p_rb->r) < 0) {
		u = p_rb->datalen - p_rb->r + p_rb->w;
	}

	return u;
}

/** @private */
int __rb_free(variable_ringbuffer_t *p_rb)
{
	return p_rb->datalen - 1 - __rb_used(p_rb);
}

/** @private */
int __rb_size(int datalen)
{
	return datalen + sizeof(variable_ringbuffer_t);
}

/** @private */
int __rb_rewind(variable_ringbuffer_t *p_rb)
{
	if (p_rb->r < sizeof(variable_ringbuffer_t)) {
		p_rb->r  = p_rb->datalen - (sizeof(variable_ringbuffer_t) - p_rb->r);
	}
	else {
		p_rb->r -= sizeof(variable_ringbuffer_t);
	}

	return 0;
}

/** @private */
int __rb_enqueue(variable_ringbuffer_t *p_rb, char *p_data, int datalen)
{
	int i;

	i = p_rb->w;
	if (i + datalen > p_rb->datalen) {
		memcpy(p_rb->data + i, p_data, p_rb->datalen - i);
		p_data  += p_rb->datalen - i;
		datalen -= p_rb->datalen - i;
		i = 0;
	}
	memcpy(p_rb->data + i, p_data, datalen);
	p_rb->w = i + datalen;

	return 0;
}

/** @private */
int __rb_dequeue(variable_ringbuffer_t *p_rb, char *p_data, int datalen)
{
	int i;

	i = p_rb->r;
	if (i + datalen > p_rb->datalen) {
		memcpy(p_data, p_rb->data + i, p_rb->datalen - i);
		p_data  += p_rb->datalen - i;
		datalen -= p_rb->datalen - i;
		i = 0;
	}
	memcpy(p_data, p_rb->data + i, datalen);
	p_rb->r = i + datalen;

	return 0;
}

/** @private */
int comRingBufferInit(variable_ringbuffer_t *p_rb, char *data, int datalen)
{
	/* initialze */
	memset(p_rb, 0x00, sizeof(variable_ringbuffer_t));
	memset(data, 0x00, datalen);

	/* lock */
	comMutexInit(&p_rb->mutex);

	/* data buffer */
	p_rb->data    = data;
	p_rb->datalen = datalen;

	return 0;
}

/** @private */
int comRingBufferEnqueue(variable_ringbuffer_t *p_rb, char *p_data, int datalen)
{
	ringbuffer_item_t item;
	int fbytes;

	/* lock first */
	comMutexLock(&p_rb->mutex);

	/* checkout the validities */
	if ((fbytes = __rb_free(p_rb)) < datalen + sizeof(ringbuffer_item_t)) {
		comLog(ER, "%s: RingBuffer Overflowed! - free=%d, requested=%d",
				__func__, fbytes, datalen + sizeof(ringbuffer_item_t));
		comMutexUnlock(&p_rb->mutex);

		return -1;
	}

	/* enqueue item */
	item.magic  = RINGBUFF_MAGIC;
	item.length = datalen;
	__rb_enqueue(p_rb, (char *)&item, sizeof(ringbuffer_item_t));

	/* enqueue data */
	__rb_enqueue(p_rb, p_data, datalen);

	/* update the count */
	p_rb->count++;

	/* debug */
	comRingBufferDebug(p_rb, __func__);

	/* unlock last */
	comMutexUnlock(&p_rb->mutex);

	return datalen;
}

/** @private */
int comRingBufferDequeue(variable_ringbuffer_t *p_rb, char *p_data, int maxlen)
{
	ringbuffer_item_t item;

	/* lock first */
	comMutexLock(&p_rb->mutex);

	/* checkout the validities */
	if (p_rb->r == p_rb->w) {
		//fprintf(stderr, "%s: RingBuffer No-data - (r=%d, w=%d)\n", __func__, p_rb->r, p_rb->w);
		comMutexUnlock(&p_rb->mutex);
		return 0;
	}

	/* dequeue item */
	__rb_dequeue(p_rb, (char *)&item, sizeof(ringbuffer_item_t));
	if (item.magic != RINGBUFF_MAGIC) {
		comLog(ER, "%s: RingBuffer Magic mismatched - (r=%d, w=%d, m=[0x%08x, 0x%08x])",
				__func__, p_rb->r, p_rb->w, item.magic, RINGBUFF_MAGIC);

		/* clear the R,W offset */
		__rb_clear(p_rb);

		comMutexUnlock(&p_rb->mutex);

		return -1;
	}
	if (item.length > maxlen) {
		comLog(ER, "%s: RingBuffer Item too big - (r=%d, w=%d, m=[0x%d, 0x%d])",
				__func__, p_rb->r, p_rb->w, item.length, maxlen);

		/* clear the R,W offset */
		__rb_clear(p_rb);

		comMutexUnlock(&p_rb->mutex);

		return -1;
	}

	/* dequeue data */
	__rb_dequeue(p_rb, p_data, item.length);

	/* update the count */
	p_rb->count--;

	/* debug */
	comRingBufferDebug(p_rb, __func__);

	/* unlock last */
	comMutexUnlock(&p_rb->mutex);

	return item.length;
}

void comRingBufferDebug(variable_ringbuffer_t *p_rb, const char *f)
{
	/* debug */
	comLog(DG, "%s() r:%d, w:%d, count:%d, free:%d",
			f, p_rb->r, p_rb->w, p_rb->count, __rb_free(p_rb));
}


