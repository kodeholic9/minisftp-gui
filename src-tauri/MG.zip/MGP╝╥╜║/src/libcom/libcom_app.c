#include "libcom.h"

#define APP_HOME  "MGP_HOME"
#if 0
#define APP_INDEX "MGP_INDEX"
#endif

/* default */
#define DEFAULT_APP_HOME "/root/MGP"

/* AP / ApInst */
unsigned int ApId;
unsigned int ApInstId;

char *comGetHome()
{
	char *p = NULL;
	struct stat sb;

	if ((p = getenv(APP_HOME)) == NULL) {
		comLog(ER, "%s() fail to getenv(%s)", __func__, APP_HOME);
		p = DEFAULT_APP_HOME;
	}

	if (stat(p, &sb) == -1 || !S_ISDIR(sb.st_mode)) {
		comLog(ER, "%s() file(%s) not exist!", __func__, APP_HOME);
		return NULL;
	}

	return p;
}

int comGetIndex()
{
#if 0
	char *p = NULL;

	if ((p = getenv(APP_INDEX)) == NULL) {
		comLog(ER, "%s() fail to getenv(%s)", __func__, APP_INDEX);
		return -1;
	}

	return atoi(p);
#endif
	return (int)(geteuid() & 0x000000ff);
}

char *comGetPath(char *p1, char *p2, char *path)
{
	char *p_home = comGetHome();

	if (p_home == NULL) return NULL;

	if (p2) { sprintf(path, "%s%s/%s", p_home, p1, p2); }
	else    { sprintf(path, "%s%s"   , p_home, p1);     }

	return path;
}

char *comGetBinPath   (char *p, char *path) { return comGetPath(BIN_D, p, path); }
char *comGetCmdPath   (char *p, char *path) { return comGetPath(CMD_D, p, path); }
char *comGetTmpPath   (char *p, char *path) { return comGetPath(TMP_D, p, path); }
char *comGetLogPath   (char *p, char *path) { return comGetPath(LOG_D, p, path); }
char *comGetPidPath   (char *p, char *path) { return comGetPath(PID_D, p, path); }
char *comGetConfPath  (char *p, char *path) { return comGetPath(CONF_D, p, path); }
char *comGetScriptPath(char *p, char *path) { return comGetPath(SCRIPT_D, p, path); }
char *comGetCmdlogPath(char *p, char *path) { return comGetPath(CMDLOG_D, p, path); }

char *comGetUName(char *name, int len)
{
	struct passwd *pw;
	uid_t  uid;

	if (name != NULL) {
		memset(name, 0x00, len);

		uid = geteuid ();
		pw  = getpwuid(uid);
		if (pw != NULL) {
			snprintf(name, len, "%s", pw->pw_name);
			return name;
		}
	}

	return NULL;
}

/** @private */
int __FILE_LOCK(int fd, int cmd, const char *f, int l)
{
	struct flock lock;

	lock.l_type   = F_WRLCK;
	lock.l_start  = 0;
	lock.l_whence = SEEK_SET;
	lock.l_len    = 0;

	if (fcntl(fd, F_SETLK, &lock) == -1) {
		comErr(ER, errno, "[%s:%d] %s() fail to lock.", f, l, __func__);
		return -1;
	}

	return 0;
}

int FILE_LOCK(int fd, const char *f, int l)
{
	return __FILE_LOCK(fd, F_SETLK, f, l);
}

int FILE_LOCKW(int fd, const char *f, int l)
{
	return __FILE_LOCK(fd, F_SETLKW, f, l);
}

int FILE_UNLOCK(int fd, const char *f, int l)
{
	struct flock lock;

	lock.l_type   = F_UNLCK;
	lock.l_start  = 0;
	lock.l_whence = SEEK_SET;
	lock.l_len    = 0;

	if (fcntl(fd, F_SETLKW, &lock) == -1) {
		comErr(ER, errno, "[%s:%d] %s() fail to lock.", f, l, __func__);
		return -1;
	}

	return 0;
}

int comPidFileLock(char *pcmd, int index, int pid)
{
	char file[64], path[128], pidstr[10];
	int  fd;

	if (index > 0) { snprintf(file, sizeof(file), "%s_%04d.pid", pcmd, index); }
	else           { snprintf(file, sizeof(file), "%s.pid"     , pcmd);        }

	comGetPidPath(file, path);
	if ((fd = open(path, O_RDWR | O_CREAT, 0666)) == -1) {
		comErr(ER, errno, "%s() fail to open PID_FILE(%s).", __func__, path);
		return -1;
	}

	/* lock the path */
	if (FILE_LOCK(fd, __func__, __LINE__) == -1) {
		close(fd);
		return -1;
	}

	if (ftruncate(fd, 0) == -1) {
		comErr(ER, errno, "%s() fail to ftruncate PID_FILE(%s).", __func__, path);
		close(fd);
		return -1;
	}

	snprintf(pidstr, sizeof(pidstr), "%d\n", pid);
	if (write(fd, pidstr, strlen(pidstr)) == -1) {
		comErr(ER, errno, "%s() fail to write PID_FILE(%s).", __func__, path);
		close(fd);
		return -1;
	}

	return fd;
}

int comPidFileCheck(char *pcmd, int index)
{
	char file[64], path[128];
	int  fd;

	if (index > 0) { snprintf(file, sizeof(file), "%s_%04d.pid", pcmd, index); }
	else           { snprintf(file, sizeof(file), "%s.pid"     , pcmd);        }

	comGetPidPath(file, path);
	if ((fd = open(path, O_RDWR | O_CREAT, 0666)) == -1) {
		comErr(ER, errno, "%s() fail to open PID_FILE(%s).", __func__, path);
		return -1;
	}

	/* lock the path */
	if (FILE_LOCK(fd, __func__, __LINE__) == -1) {
		close(fd);
		return -1;
	}
	close(fd);

	return 0;
}


char *appName(int ap_id)
{
	switch (ap_id) {
		case MMIM: return "MMIM";
		case PMON: return "PMON";
		case CHNL: return "CHNL";
		case MGPP: return "MGPP";
		case WEBI: return "WEBI";
		case HOOK: return "HOOK";
	}

	return "UNDEF";
}

int appId(char *apname)
{
	if (apname != NULL) {
		if      (strcmp("MMIM", apname) == 0) { return MMIM; }
		else if (strcmp("PMON", apname) == 0) { return PMON; }
		else if (strcmp("CHNL", apname) == 0) { return CHNL; }
		else if (strcmp("MGPP", apname) == 0) { return MGPP; }
		else if (strcmp("WEBI", apname) == 0) { return WEBI; }
		else if (strcmp("HOOK", apname) == 0) { return HOOK; }
	}

	return MMIM;
}

