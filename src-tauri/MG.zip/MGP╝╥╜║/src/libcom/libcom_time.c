#include "libcom.h"

/* for missings */
#define _XOPEN_SOURCE /* glibc2 needs this */
#include <time.h>
extern char *strptime(const char *s, const char *format, struct tm *tm);

time_t comTime()
{
	return time(NULL);
}

double comTimeGetU()
{
	struct timeval  curr;

	gettimeofday(&curr, NULL);

	return curr.tv_sec + ((float)curr.tv_usec * 1e-6); /* 1 / 1000000.0; */
}

long comTimeGetMillis()
{
	struct timeval  curr;

	gettimeofday(&curr, NULL);

	return curr.tv_sec * 1000 + (curr.tv_usec / 1000); 
}

double comTimeGetUElapsed()
{
	static struct timeval prev;
	struct timeval  curr;
	struct timezone timez;
	double elapsed;

	gettimeofday(&curr, &timez);
	elapsed = (curr.tv_sec - prev.tv_sec)
		+ (double) (curr.tv_usec - prev.tv_usec) * 1e-6; /* / 1000000.0; */

	prev.tv_sec  = curr.tv_sec;
	prev.tv_usec = curr.tv_usec;

	return (elapsed);
}

/* sample : comTimeT2Str(S, sizeof(S), "%Y/%m/%d %H:%M:%S", T) */
char *comTimeT2Str(char *S, size_t MAXSIZE, const char* FORMAT, time_t T)
{
	struct tm Tm;

	if (localtime_r(&T, &Tm) == NULL)
		return NULL;

	strftime(S, MAXSIZE, FORMAT, &Tm);
	
	return S;
}

/* sample : comTimeT2Str(S, "%Y/%m/%d %H:%M:%S") */
time_t comTimeStr2T(char *S, const char* FORMAT)
{
	struct tm Tm;

	strptime(S, FORMAT, &Tm);

	return mktime(&Tm);
}

char *comTimeUP2Str(time_t T, char *S)
{
	int ss, mm, hh, dd;

	ss = T % 60;
	if ((T - ss) > 0) {
		mm = (T - ss) / 60;

		if ((mm - (mm % 60)) > 0) {
			hh = (mm - (mm % 60)) / 60;
			mm = mm % 60;

			if ((hh - (hh % 24)) > 0) {
				dd = (hh - (hh % 24)) / 24;
				hh = hh % 24;
				sprintf(S, "%d days %02d:%02d:%02d", dd, hh, mm, ss);
			}
			else 
				sprintf(S, "%02d:%02d:%02d", hh, mm, ss);
		}
		else 
			sprintf(S, "%02d:%02d", mm, ss);
	}
	else 
		sprintf(S, "%02d", ss);

	return S;
}

/** @private */
char *comTimeTraceFormat(char *s)
{
	struct timeval tmval;
	struct tm tm;

	gettimeofday(&tmval, NULL);
	localtime_r(&tmval.tv_sec, &tm);
	sprintf(s, "%.2d:%.2d:%.2d.%03d",
			tm.tm_hour, tm.tm_min, tm.tm_sec, (int)(tmval.tv_usec * 1e-6 * 1000));

	return s;
}


