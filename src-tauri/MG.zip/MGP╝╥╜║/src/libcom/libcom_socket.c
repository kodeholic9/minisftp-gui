#include "libcom.h"


/** @private */
void get_host_by_addr(sockaddr_in_t *addr, uchar **r_host)
{
	hostent_t   *rhost; // ptr to host info for remote host
	if ((rhost = gethostbyaddr((char *)&addr->sin_addr, sizeof(struct in_addr), addr->sin_family)) == NULL) {
		*r_host = inet_ntoa(addr->sin_addr);
	} else {
		*r_host = rhost->h_name;
	}
}

/** @private */
int set_local_server(uint port, sockaddr_in_t *serv_addr)
{
	serv_addr->sin_family        = AF_INET;
	serv_addr->sin_addr.s_addr   = htonl(INADDR_ANY);
	serv_addr->sin_port          = htons(port);

	comLog(DG,"host IP[%s] Port[%d]", inet_ntoa(serv_addr->sin_addr),port);

	return 0;
}

/** @private */
int set_dedicate_server(uchar *host, uint port, sockaddr_in_t *serv_addr)
{
	hostent_t *hp;
	long int  *add;

	serv_addr->sin_family = AF_INET;

	if (inet_addr(host) == (in_addr_t) -1) { //using host name
		if ((hp = gethostbyname(host)) == NULL) {
			comLog(ER,"gethostbyname fail[%s]", host);
			return -1;
		}
		if(*hp->h_addr_list != NULL ) {
			add = (long int *)*hp->h_addr_list;
			serv_addr->sin_addr.s_addr = *add;
		} else {
			comLog(ER,"Fatal Error: Wrong Host Name[%s]", host);
			return -1;
		}
	}
	else { //using ip address
		serv_addr->sin_addr.s_addr = inet_addr(host);
	}

	serv_addr->sin_port = htons(port);

	comLog(DG,"host IP[%s] Port[%d]", inet_ntoa(serv_addr->sin_addr), port);

	return 0;
}

/** @private */
int set_server_address(uchar *host, uint port, sockaddr_in_t *serv_addr)
{
	if (port < 0) {
		comLog(ER,"Invalid port number(%d)", port);
		return -1;
	}

	if (host == NULL) {
		return set_local_server(port, serv_addr);
	} else {
		return set_dedicate_server(host,port,  serv_addr);
	}
}

/** @private */
int set_socket_option(sint fd, uint buff_sz, sint BMode, sint serverMode, sint tcpLayer)
{
	struct linger   lng;
	sint            flag = TRUE;

	if (setsockopt(fd, SOL_SOCKET, SO_SNDBUF, (char *) &buff_sz, sizeof(buff_sz)) < 0) {
		comLog(ER,"(,, SO_SNDBUF, %d, ...) failed. %s(%d)", buff_sz, strerror(errno), errno);
		return -1;
	}
	if (setsockopt(fd, SOL_SOCKET, SO_RCVBUF, (char *) &buff_sz, sizeof(buff_sz)) < 0) {
		comLog(ER,"(,, SO_RCVBUF, %d, ...) failed. %s(%d)", buff_sz, strerror(errno), errno);
		return -1;
	}
	if (tcpLayer == L3_LAYER_TCP) {
		if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (char *) &flag, sizeof(flag)) < 0) {
			comLog(ER,"(,, SO_REUSEADDR, ...) failed. %s(%d)", strerror(errno), errno);
			return -1;
		}
		lng.l_onoff = BMode; lng.l_linger = 0;
		if (setsockopt(fd, SOL_SOCKET, SO_LINGER, (char *) &lng, sizeof(lng)) < 0) {
			comLog(ER,"(,, SO_LINGER, ...) failed. %s(%d)", strerror(errno), errno);
			return -1;
		}
	}

	return 0;

}

int comGetSockName(int sockfd, char *name, int namelen)
{
	sockaddr_in_t addr;
	socklen_t     addr_len = sizeof(addr);

	if (getsockname(sockfd, (sockaddr_t *)&addr, &addr_len) == -1) {
		comLog(ER,"getsockname() for sockfd %d failed. %s(%d)", sockfd, strerror(errno), errno);
		return -1;
	}
	snprintf(name, namelen, "%s", inet_ntoa(addr.sin_addr));

	return 0;
}

int comGetPeerName(int sockfd, char *name, int namelen)
{
	sockaddr_in_t addr;
	socklen_t     addr_len = sizeof(addr);

	if (getpeername(sockfd, (sockaddr_t *)&addr, &addr_len) == -1) {
		comLog(ER,"getpeername() for sockfd %d failed. %s(%d)", sockfd, strerror(errno), errno);
		return -1;
	}
	snprintf(name, namelen, "%s", inet_ntoa(addr.sin_addr));

	return 0;
}

int comOpenServerSocket(uchar *host ,uint port, uint buf_size, uint BMode)
{
	sint            fd;
	int             rValue;
	sockaddr_in_t   serv_addr;

	bzero((char *) &serv_addr, sizeof(sockaddr_in_t));

	if ( (rValue = set_server_address(host, port, &serv_addr)) < 0 )
		return rValue;

	if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		comLog(ER,"socket() failed. %s(%d)", strerror(errno), errno);
		return -1;
	}
	if((rValue = set_socket_option(fd, buf_size, BMode, SERVER_SOCKET, L3_LAYER_TCP)) < 0) {
		comLog(ER,"set_socket_option retrun - value");
		close(fd);
		return -1;
	}
	if (bind(fd, (sockaddr_t *)&serv_addr, sizeof(sockaddr_t)) < 0) {
		comLog(ER,"bind() for port %d failed. %s(%d)", port, strerror(errno), errno);
		close(fd);
		return -1;
	}
	if (listen(fd, 5) < 0) {
		comLog(ER,"listen() failed. %s(%d)", strerror(errno), errno);
		close(fd);
		return -1;
	}

	return fd;
}

int  comOpenUDPSocket(uchar *host, uint port, uint buff_size)
{
	sint            fd;
	int             rValue;
	sockaddr_in_t   serv_addr;    // for local socket address

	bzero((char *) &serv_addr, sizeof(sockaddr_in_t));

	if ((rValue=set_server_address(host, port, &serv_addr)) < 0) {
		return rValue;
	}
	if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
		comLog(ER,"socket() failed. %s(%d)", strerror(errno), errno);
		return -1;
	}
	if((rValue=set_socket_option(fd, buff_size, 0, SERVER_SOCKET, L3_LAYER_UDP)) < 0) {
		close(fd);
		return rValue;
	}

	// bind the listen address to the socket.
	if (bind(fd, (sockaddr_t *)&serv_addr, sizeof(sockaddr_t)) == -1) {
		comLog(ER,"UDP bind() failed. %s(%d)", strerror(errno), errno);
		close(fd);
		return -1;
	}

	return fd;
}

int comOpenClientSocket(uchar *lhost, uchar *host, uint port, uint buff_size, uint BMode)
{
	sint            fd;
	int             rValue;
	sockaddr_in_t   dst_addr, src_addr;    // for local socket address


	bzero((char *) &dst_addr, sizeof(sockaddr_in_t));
	bzero((char *) &src_addr, sizeof(sockaddr_in_t));

	if ((rValue = set_server_address(host, port, &dst_addr)) < 0) {
		return rValue;
	}

	if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		comLog(ER,"socket() failed. %s(%d)", strerror(errno), errno);
		return -1;
	}

	if((rValue = set_socket_option(fd, buff_size, BMode, CLIENT_SOCKET, L3_LAYER_TCP)) < 0) {
		close(fd);
		return rValue;
	}

	if (lhost != NULL) {
		if ((rValue = set_server_address(lhost, 0, &src_addr)) < 0) {
			return rValue;
		}
		if (bind(fd, (sockaddr_t *)&src_addr, sizeof(sockaddr_t)) < 0) {
			comLog(ER,"bind() for host %s, port %d failed. %s(%d)", lhost, 0, strerror(errno), errno);
			close(fd);
			return -1;
		}
	}

	if (connect(fd, (sockaddr_t *)&dst_addr, sizeof(sockaddr_t)) < 0) {
		comLog(ER,"connect() failed. %s(%d)", strerror(errno), errno);
		close(fd);
		return -1;
	}

	return fd;
}

void client_connected(sint fd)
{
	sint            saved;

	saved = fcntl(fd, F_GETFL, 0);
	fcntl(fd, F_SETFL, saved & (~O_NONBLOCK));
	comLog(DG,"Connection Success");
}

int select_again(sint fd, struct sockaddr *p_serv_addr, int timeoutSec)
{
	int             rValue;
	fd_set          wmask, rmask;
	struct timeval  tmo;

	FD_ZERO(&rmask);
	FD_SET(fd, &rmask);
	wmask = rmask;
	tmo.tv_sec = timeoutSec? timeoutSec : 1;
	tmo.tv_usec = 0;

	errno = 0;

	rValue = select(fd+1, &rmask, &wmask, NULL, timeoutSec ? &tmo : NULL);
	if (rValue < 0) {
		if (errno == EINTR) return DO_SELECT_AGAIN; //retry again
		comLog(ER,"select() failed. %s(%d)", strerror(errno), errno);
		return -1;
	}
	else if (rValue == 0) {
		comLog(ER,"nonblocking connect() timed out(select())");
		return -1;
	}

	if (FD_ISSET(fd, &wmask) || FD_ISSET(fd, &rmask)) {
		if ((rValue = connect(fd, (struct sockaddr *)p_serv_addr, sizeof(struct sockaddr))) < 0) {
			if (errno == EISCONN) return 0; // connected
			return -1;
		}
	}
	else {
		comLog(ER,"nonblocking connect() error(select())");
		return -1;
	}
	return 0;
}

int  comOpenClientSocketTimeout(uchar *host, uint port, uint buff_size, int timeoutSec)
{
	sint            fd, saved;
	int             rValue;
	sockaddr_in_t   serv_addr;    // for local socket address

	bzero((char *) &serv_addr, sizeof(sockaddr_in_t));

	if ( (rValue = set_server_address(host, port, &serv_addr)) < 0) {
		return rValue;
	}

	if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		comLog(ER,"socket() failed. %s(%d)", strerror(errno), errno);
		return -1;
	}

	if((rValue =set_socket_option(fd, buff_size, BMODE_NONBLOCK, CLIENT_SOCKET, L3_LAYER_TCP))< 0) {
		close(fd);
		return rValue;
	}

	saved = fcntl(fd, F_GETFL, 0);

	if (fcntl(fd, F_SETFL, saved | O_NONBLOCK)<0) {
		comLog(ER,"fcntl failed. %s(%d)", strerror(errno), errno);
		close(fd);
		return -1;
	}

	// connect to the server
	if ((rValue = connect(fd, (struct sockaddr *)&serv_addr, sizeof(struct sockaddr))) < 0) {
		if (errno != EINPROGRESS) {
			comLog(ER,"connect() failed. %s(%d)", strerror(errno), errno);
			close(fd);
			return -1;
		}
	}

	if (rValue == 0) client_connected(fd);

	else {
		do {
			rValue = select_again(fd, (struct sockaddr *)&serv_addr, timeoutSec);
		} while (rValue == DO_SELECT_AGAIN );

		if (rValue < 0)  {
			close(fd);
			return rValue;
		} else if (rValue == 0) {
			client_connected(fd);
		}
	}

	return fd;
}

int comReadableTimeo(int fd, int timeo)
{
	fd_set rset;
	struct timeval tv;
	int cc;

	FD_ZERO(&rset);
	FD_SET(fd, &rset);

	tv.tv_sec  = timeo;
	tv.tv_usec = 0;

	/* block here! */
	if ((cc = select(fd+1, &rset, NULL, NULL, (timeo == -1) ? NULL : &tv)) == 0) {
		errno = ETIMEDOUT;
	}

	return cc;
}

int comWritableTimeo(int fd, int timeo)
{
	fd_set wset;
	struct timeval tv;
	int cc;

	FD_ZERO(&wset);
	FD_SET(fd, &wset);

	tv.tv_sec  = timeo;
	tv.tv_usec = 0;

	/* block here! */
	if ((cc = select(fd+1, NULL, &wset, NULL, (timeo == -1) ? NULL : &tv)) == 0) {
		errno = ETIMEDOUT;
	}

	return cc;
}

sint comGetHostAddr(char *host, sint port, sockaddr_in_t *serv_addr)
{
	return set_dedicate_server(host, port, serv_addr);
}

int  comOpenUDPClientSocket(uchar *host, uint port, sockaddr_in_t *serv_addr)
{
	sint            fd;

	if(host == NULL ) {
		set_local_server(port, serv_addr);
	} else {
		comGetHostAddr(host,port,  serv_addr);
	}

	// Create the socket
	if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		comLog(ER,"socket() failed. %s(%d)", strerror(errno), errno);
		return -1;
	}

	return fd;
}

int  comAccept(uint fd, sockaddr_in_t *addr, uchar **r_host, uint mod, uint linger)
{
	sint        addr_len = sizeof(sockaddr_t);
	sint        saved=0 , new_fd;
	struct linger   lng;

	// change the listening socket to nonblocking mode
	if(mod == ACCEPT_NONBLOCK ) {
		saved = fcntl(fd, F_GETFL, 0);
		fcntl(fd, F_SETFL, saved | O_NONBLOCK);
	}

L_ACCEPT_AGAIN:
	// it will block until a new connection arrives
	if ((new_fd = accept(fd, (sockaddr_t *)addr, &addr_len)) == -1) {
		switch (errno) {
			case EINTR:
				goto L_ACCEPT_AGAIN;
				break;
			case EWOULDBLOCK:   /* for Berkeley-derived, when the client aborts the connection before accept() */
			case ECONNABORTED:  /* for Posix.1g, when the client aborts the connection before accept() */
			case EPROTO:        /* for SVR4, when the client aborts the connection before accept() */
				comLog(ER,"accept(%d, ...) failed. Connection request has DISAPPEARED.", fd);
				return -1;
			case ENOBUFS:       /* for HP-UX 11.xx */
				comLog(ER,"accept(%d, ...) failed. The queued socket connect request is aborted.", fd);
				return -1;
			default:
				comLog(ER,"accept(%d, ...) failed. %s(%d)", fd, strerror(errno), errno);
				return -1;
		}
	}

	if(mod == ACCEPT_NONBLOCK )
		fcntl(fd, F_SETFL, saved);

	lng.l_onoff = 1; lng.l_linger = linger;

	if (setsockopt(new_fd, SOL_SOCKET, SO_LINGER, (char *) &lng, sizeof(lng)) < 0) {
		comLog(ER,"(%d, ...) failed. %s(%d)", new_fd, strerror(errno), errno);
		close(new_fd);
		return -1;
	}

	if(mod == ACCEPT_NONBLOCK )  {
		saved = fcntl(new_fd, F_GETFL, 0);
		fcntl(new_fd, F_SETFL, saved | O_NONBLOCK);
	}

	if (r_host) get_host_by_addr(addr, r_host);

	return new_fd;

}

int  comReadSocket(uint fd, char *buff, int len)
{
	sint    nbytes, ntbytes;
	char    *ptr = buff;
	ntbytes=0;

	do {
L_AGAIN:
		if ((nbytes = read(fd, ptr, len - (ptr - buff))) <= 0) {
			if (nbytes < 0) {
				comLog(ER,"read(%d, ...) failed. %s(%d)", fd, strerror(errno), errno);
				if (errno == EINTR || errno == EAGAIN) goto L_AGAIN;
			}
			return -1;
		}
		ptr += nbytes;
		ntbytes += nbytes;

	} while ((ptr - buff) < len);

	return ntbytes;
}

int  comReadSocketNB(uint fd, uchar *buff, uint len)
{
	sint    nbytes, ntbytes;
	char    *ptr = buff;

	ntbytes=0;

L_AGAIN:
	if ((nbytes = read(fd, ptr, len)) < 0) {
		switch (errno) {
			case EWOULDBLOCK :
				return 0;
			case EINTR :
				goto L_AGAIN;
				break;
			default :
				comLog(ER,"read(%d, ...) failed. %s(%d)", fd, strerror(errno), errno);
				return -1;
		}
		ntbytes += nbytes;
	}
	else if (nbytes == 0) {
		comLog(ER,"TCP peer closed the connection");
		return -1;
	}
	else {
		return ntbytes;
	}
}

int  comReadSocketNLine(uint fd, uchar *buff)
{
	char    *ptr = buff;
	char    ch;
	sint    dummy;
	int     nByte = 0;

	while (1) {
		if ((dummy = read(fd, &ch, 1)) <= 0) {
			if (dummy < 0) {
				comLog(ER,"read(%d, ...) failed. %s(%d)", fd, strerror(errno), errno);
			}
			return -1;
		}

		if (ch == '\n') {
			*ptr++ = ch;
			*ptr = 0;
			break;
		}

		*ptr++ = ch;
		nByte ++;
	}

	return nByte;
}

int  comMoreDataSocket (uint fd, sint wait_sec)
{
	timeval_t   timeout;
	fd_set      read_mask;
	sint        ret;

	FD_ZERO(&read_mask);
	FD_SET(fd, &read_mask);

	timeout.tv_sec  = wait_sec;
	timeout.tv_usec = 0;

	ret = select(fd + 1, &read_mask, NULL, NULL, &timeout);

	return (ret > 0 && FD_ISSET(fd, &read_mask));

}

int  comReadSocketTimeout(uint fd, uchar *buff, uint len, uint timeout_sec)
{
	char    *ptr;
	ssize_t nbytes;
	ssize_t ntbytes=0;

	ptr = buff;

	do {
		if (!comMoreDataSocket(fd, timeout_sec)) {
			comLog(ER,"read(%d,%d,%d) timed out, %d bytes read till now", fd, (int)len, timeout_sec, (int)ntbytes);
			return -1;
		}

		if ((nbytes = read(fd, ptr, len - ntbytes)) <= 0) {
			comLog(ER,"read(%d, ...) failed!!! (%s:%d)", fd, strerror(errno), errno);
			return -1;
		}
		ptr += nbytes;
		ntbytes += nbytes;
	} while (ntbytes< len);

	return ntbytes;

}

int  comReadUDPSocket(uint fd, uchar *buff, uint len, sockaddr_in_t *from_addr)
{
	sint    size = sizeof(sockaddr_in_t), ret;

	if ((ret = recvfrom(fd, buff, len, 0, (sockaddr_t *)from_addr, &size)) < 0) {
		comLog(ER,"recvfrom(%d, ...) failed. %s(%d)", fd, strerror(errno), errno);
	}

	return ret;
}

int  comReadUDPSocketNB(uint fd, uchar *buff, uint len, sockaddr_in_t *from_addr)
{
	sint    size = sizeof(sockaddr_in_t), ret;

again:

	if ((ret = recvfrom(fd, buff, len, MSG_DONTWAIT, (sockaddr_t *)from_addr, &size)) < 0) {
		switch (errno) {
			case EAGAIN:
				return 0;
				break;

			case EINTR:
				goto again;
				break;

			default:
				comLog(ER,"recvfrom(%d, ...) failed. %s(%d)", fd, strerror(errno), errno);
				return -1;
				break;
		}
	}

	return ret;
}

int comStatusSocketCheckWrite (uint fd, char *buff, uint len)
{
	if (fd <= 0) return -1;

	switch (comStatusSocket(fd)) {

		case SOCK_ERROR:
			comLog(ER,"socket error (sockfd = %d)", fd);
			return -1;

		case SOCK_BLOCK:
			comLog(ER,"Write blocked (sockfd = %d)", fd);
			break;

		case SOCK_NORMAL:
			if (comWriteSocket(fd, buff, len) < 0) {
				comLog(ER,"socket write error (sockfd = %d)", fd);
				return -1;
			}
			return len;
	}

	return 0;
}

int  comStatusSocketWriteTimeout (uint fd, char *buff, uint len, uint timeout_sec)
{
	if (fd <= 0) return -1;

	switch (comStatusSocket(fd)) {
		case SOCK_ERROR:
			comLog(ER,"socket error (sockfd = %d)", fd);
			return -1;

		case SOCK_BLOCK:
			comLog(ER,"Write blocked (sockfd = %d)", fd);
			break;

		case SOCK_NORMAL:
			if (comWriteSocketTimeout(fd, buff, len, timeout_sec) < 0) {
				comLog(ER,"socket write error (sockfd = %d)", fd);
				return -1;
			}
			break;
	}

	return 0;
}

int  comWriteSocket (uint fd, char *buff, uint len)
{
	sint    nbytes;
	char    *ptr = buff;

	do {
		if ((nbytes = write(fd, ptr, len - (ptr - buff))) <= 0) {
			comLog(ER,"write(%d, ...) failed. %s(%d)", fd, strerror(errno), errno);
			return -1;
		}
		ptr += nbytes;
	} while ((ptr - buff) < len);

	return 0;
}

int  comWriteSocketNB (uint fd, char *buff, uint len)
{
	sint    nbytes;
	char    *ptr = buff;

L_AGAIN:
	if ((nbytes = write(fd, ptr, len)) < 0) {
		switch (errno) {
			case EWOULDBLOCK :
				return 0;
			case EINTR :
				goto L_AGAIN;
				break;
			default :
				comLog(ER,"write(%d, ...) failed. %s(%d)", fd, strerror(errno), errno);
				return -1;
		}
	}
	else if (nbytes == 0) {
		comLog(ER,"TCP peer closed the connection");
		return -1;
	}
	else {
		return nbytes;
	}
}

int  comWriteSocketTimeout (uint fd, char *buff, uint len, uint timeout_sec)
{
	struct  timeval tv;
	sint    nbytes;
	char    *ptr = buff;

	tv.tv_sec = timeout_sec;
	tv.tv_usec = 0;

	if (setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv)) < 0) {
		comLog(ER,"(,, SO_SNDTIMEO, %d, ...) failed. %s(%d)", timeout_sec, strerror(errno), errno);
		return -1;
	}

	do {
		if ((nbytes = write(fd, ptr, len - (ptr - buff))) <= 0) {
			if (nbytes < 0 && errno ==  EINTR) {
				nbytes = 0;
			}
			else if (nbytes < 0 && errno == EWOULDBLOCK) {
				comLog(ER,"write(%d, ...) timeout", fd);
				return -1;
			}
			else {
				comLog(ER,"write(%d, ...) failed. %s(%d)", fd, strerror(errno), errno);
				return -1;
			}
		}
		ptr += nbytes;
	} while ((ptr - buff) < len);

	return 0;

}

int  comWriteSocketNL (uint fd, char *buff)
{
	char    *ptr = buff;

	while (1) {
		if (write(fd,ptr, 1) <= 0) {
			comLog(ER,"write(%d, ...) failed. %s(%d)", fd, strerror(errno), errno);
			return -1;
		}

		if (*ptr == '\n') {
			*ptr = 0;
			return 0;
		}
		ptr++;
	}

	return -1;
}

int  comWriteUDPSocket (uint fd, sockaddr_in_t *addr, uchar *buff, sint len)
{
	sint ret;

	if ((ret = sendto(fd, buff, len, 0, (sockaddr_t *)addr, sizeof(sockaddr_t))) < 0) {
		comLog(ER,"sendto(%d, ...) failed. %s(%d)", fd, strerror(errno), errno);
	}

	return ret;

}

int  comSocketStatusUDPWrite (uint fd, sockaddr_in_t *addr, uchar *buff, sint len)
{
	if (fd <= 0) return -1;

	switch (comStatusSocket(fd)) {
		case SOCK_ERROR:
			comLog(ER,"socket error (sockfd = %d)", fd);
			return -1;

		case SOCK_BLOCK:
			comLog(ER,"Write blocked (sockfd = %d)", fd);
			break;

		case SOCK_NORMAL:
			if (comWriteUDPSocket(fd, addr, buff, len) < 0) {
				comLog(ER,"socket write error (sockfd = %d)", fd);
				return -1;
			}
			break;
	}

	return 0;
}

int  comStatusSocket (uint fd)
{
	struct  pollfd  filedes;

	filedes.fd = fd;
	filedes.events = 0xffff;

	if (poll(&filedes, 1, 0) < 0) {
		comLog(ER,"poll() failed. %s(%d)", strerror(errno), errno);
		return SOCK_ERROR;
	}

	if (filedes.revents & (POLLHUP | POLLERR | POLLNVAL)) {
		return SOCK_ERROR;
	}

	if (filedes.revents & POLLOUT) {
		return SOCK_NORMAL;
	}

	return SOCK_BLOCK;
}

char  *comGetIPAddressByName (uchar *host)
{
	uint port=10000;
	sockaddr_in_t serv_addr;

	set_server_address(host, port, &serv_addr);
	return (char *)inet_ntoa(serv_addr.sin_addr);
}

void  comCloseSocket (uint fd)
{
	shutdown(fd, 2);
	close(fd);
}

void  comSetSelectMask (sint *max_fd, fd_set *mask, sint fd)
{
	FD_SET(fd, mask);

	if (fd >= *max_fd) {
		*max_fd = fd + 1;
	}
}

void  comUnsetSelectMask (sint *max_fd, fd_set *mask, sint fd)
{
	sint    i;

	FD_CLR(fd, mask);

	if (fd != (*max_fd - 1)) return;

	for (i = fd - 1; i >= 0; i--) {
		if (FD_ISSET(i, mask)) break;
	}

	*max_fd = i + 1;
}

/** @private */
struct addrinfo *comGetAddrInfo(const char *host, const char *serv, int family, int socktype)
{
	int             n;
	struct addrinfo hints, *res;

	comLog(DG,"host[%s] serv[%s] family[%d] socktype[%d]", host, serv, family, socktype );

	bzero(&hints, sizeof(struct addrinfo));
	hints.ai_flags = AI_CANONNAME;  /* always return canonical name */
	hints.ai_family = family;       /* 0, AF_INET, AF_INET6, etc. */
	hints.ai_socktype = socktype;   /* 0, SOCK_STREAM, SOCK_DGRAM, etc. */

	if ((n = getaddrinfo(host, serv, &hints, &res)) != 0) {
		comLog(ER,"host_serv error for %s, %s: %s",
				(host == NULL) ? "(no hostname)" : host,
				(serv == NULL) ? "(no service name)" : serv,
				gai_strerror(n));
		return (struct addrinfo *)NULL;
	}

	return (res);    /* return pointer to first on linked list */
}

/* nonblock read/write */
/** private */
int comNonblockRead(int sockfd, char *buff, int maxlen)
{
	int n;

	errno = 0;

again: /* in case of EINTR */

	if      ((n = comReadableTimeo(sockfd, 0)) == -1) { return -1; }
	else if ( n == 0)                                 { return  0; }

	if ((n = read(sockfd, buff, maxlen)) == -1) {
		switch (errno) {
			case EAGAIN:
				comLog(DG, "%s() OVERCOME BLOCK! (sockfd=%d)", __func__, sockfd);
				return 0;
				break;

			case EINTR:
				goto again;
				break;

			default:
				comLog(ER, "%s() fail to nonbread (sockfd=%d) - error=%d(%s)",
						__func__, sockfd,  errno, strerror(errno));
				return -1;
				break;
		}
	}
	else if (n == 0) {
		comLog(ER, "%s() meets EOF (sockfd=%d)", __func__, sockfd);
		return -1;
	}
	/*comLog(DG, "%s() [sockfd=%d] %d bytes read. (%d bytes requested)", __func__, sockfd, n, maxlen);*/

	return n;
}

/** private */
int comNonblockWrite(int sockfd, char *buff, int len)
{
	int n;

	errno = 0;

again: /* in case of EINTR */

	if ((n = write(sockfd, buff, len)) == -1) {
		switch (errno) {
			case EAGAIN:
				comLog(DG, "%s() OVERCOME BLOCK!", __func__);
				return 0;
				break;

			case EINTR:
				goto again;
				break;

			default:
				comLog(ER, "%s() fail to nonbwrite - error=%d(%s)",
						__func__, errno, strerror(errno));
				return -1;
				break;
		}
	}
	/*comLog(DG, "%s() [sockfd=%d] %d bytes written. (%d bytes requested)", __func__, sockfd, n, len);*/

	return n;
}

long long comNtohll(long long n)
{
	long long retval;

	retval  = ((long long)ntohl(n & 0xFFFFFFFFLLU)) << 32;
	retval |=     ntohl((n & 0xFFFFFFFF00000000LLU) >> 32);

	return(retval);
}

long long comHtonll(long long n)
{
	uint64_t retval;

	retval  = ((long long)htonl(n & 0xFFFFFFFFLLU)) << 32;
	retval |=     htonl((n & 0xFFFFFFFF00000000LLU) >> 32);

	return(retval);
}


