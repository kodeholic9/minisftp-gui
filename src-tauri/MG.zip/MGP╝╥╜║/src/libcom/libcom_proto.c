#include "libcom.h"

char *comProtoStr2Iuaddr(char *s, iuaddr_t *p_iuaddr)
{
	int  i, j, n = strlen(s);
	char ch;

	for (i = 0, j = 0; i < MAX_ADDRESS_LEN; i++) {
		if (i < n) {
			ch = (s[i] == '*') ? 0x0a :
				(s[i] == '#') ? 0x0b :
				(s[i] == '+') ? 0x0c : s[i] - 0x30;
		}
		else { ch = 0x0f; }

		if ((i % 2) == 0) {
			p_iuaddr->d[j] |= ch & 0x0f;
		}
		else {
			p_iuaddr->d[j] |= ch << 4;
			j++;
		}
	}

	return s;
}

char *comProtoIuaddr2Str(iuaddr_t *p_iuaddr, char *s)
{
	int  i, j;
	char ch;

	for (i = 0, j = 0; i < MAX_ADDRESS_LEN; i++) {
		if ((i % 2) == 0) {
			ch = (p_iuaddr->d[j] & 0x0f);
		}
		else {
			ch = ((p_iuaddr->d[j] >> 4) & 0x0f); j++;
		}

		if      (ch == 0x0f) { s[i] = 0x00; }
		else if (ch == 0x0a) { s[i] = '*' ; }
		else if (ch == 0x0b) { s[i] = '#' ; }
		else if (ch == 0x0c) { s[i] = '+' ; }
		else                 { s[i] = ch + 0x30; }
	}

	return s;
}

long comProtoI642Long(i64_t *p_i64)
{
#ifdef _LINUX
	long l, n;

	memcpy(&n, p_i64->s, MAX_I64_LEN);
	l  = ((long)ntohl( n & 0xFFFFFFFFLLU)) << 32;
	l |=        ntohl((n & 0xFFFFFFFF00000000LLU) >> 32);
#else
	long long l, n;

	memcpy(&n, p_i64->s, MAX_I64_LEN);
	l  = ((long long)ntohl( n & 0xFFFFFFFFLLU)) << 32;
	l |=             ntohl((n & 0xFFFFFFFF00000000LLU) >> 32);
#endif

	return l; /* Big Endian */
}

long comProtoLong2I64(long l, i64_t *p_i64)
{
#ifdef _LINUX
	long n;

	n  = ((long)htonl( l & 0xFFFFFFFFLLU)) << 32;
	n |=        htonl((l & 0xFFFFFFFF00000000LLU) >> 32);
	memcpy(p_i64->s, &n, MAX_UIDSTR_LEN);
#else
	long long n;

	n  = ((long long)htonl( l & 0xFFFFFFFFLLU)) << 32;
	n |=             htonl((l & 0xFFFFFFFF00000000LLU) >> 32);
	memcpy(p_i64->s, &n, MAX_UIDSTR_LEN);
#endif

	return n;
}

long comProtoIuid2Long    (        iuid_t    *p_iuid     ) { return comProtoI642Long(   p_iuid); }
long comProtoLong2Iuid    (long l, iuid_t    *p_iuid     ) { return comProtoLong2I64(l, p_iuid); }
long comProtoSid2Long     (        uesid_t    *p_sid     ) { return comProtoI642Long(   p_sid); }
long comProtoLong2Sid     (long l, uesid_t    *p_sid     ) { return comProtoLong2I64(l, p_sid); }
long comProtoDatetime2Long(        datetime_t *p_datetime) { return comProtoI642Long(   p_datetime); }
long comProtoLong2Datetime(long l, datetime_t *p_datetime) { return comProtoLong2I64(l, p_datetime); }

char *comProtoIpaddr2Str(ueipaddr_t *p_ipaddr, char *s)
{
	sprintf(s, "%u.%u.%u.%u",
			p_ipaddr->d[0], p_ipaddr->d[1], p_ipaddr->d[2], p_ipaddr->d[3]);

	return s;
}

ueipaddr_t *comProtoStr2Ipaddr(char *s, ueipaddr_t *p_ipaddr)
{
	sscanf(s, "%u.%u.%u.%u",
			(unsigned int *)&p_ipaddr->d[0],
			(unsigned int *)&p_ipaddr->d[1],
			(unsigned int *)&p_ipaddr->d[2],
			(unsigned int *)&p_ipaddr->d[3]);

	return p_ipaddr;
}


