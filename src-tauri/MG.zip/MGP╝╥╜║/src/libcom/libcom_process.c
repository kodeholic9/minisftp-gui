#include "libcom.h"
#include <ctype.h>

#define SH_CMDLINE "/bin/sh"

int lp_count(char *cmdline)
{
	int  argc;
	unsigned char ch, wsflag;

	argc = 0; wsflag = TRUE;
	while ((ch = (unsigned char)*cmdline) != '\0') {
		if (!isspace((int)ch)) {
			if (wsflag) {
				argc += 1;
			}
			wsflag = FALSE;
		}
		else {
			wsflag = TRUE;
		}
		cmdline++;
	}

	return argc;
}

char **lp_alloc(char *cmdline, int *argc)
{
	int  len, narg, i;
	char **argv, *sp, *cp, *ep;

	if ((narg = lp_count(cmdline)) == 0) {
		return NULL;
	}
	if ((argv = (char **)malloc((narg+1)*sizeof(char *))) != NULL) {
		sp = cmdline;
		for (i = 0; i < narg; i++) {
			while (isspace((int)(*sp))) sp++;
			ep = cp = sp;

			while (!isspace((int)(*ep)) && *ep != '\0') ep++;
			len = ep - cp;

			argv[i] = (char *)malloc(len+1);
			snprintf(argv[i], len+1, "%s", cp);
			sp = ep;
		}
		argv[narg] = NULL;
	}
	*argc = narg;

	return argv;
}

void lp_release(char **argv)
{
	int i;

	if (argv != NULL) {
		for (i = 0; argv[i] != NULL; i++) free(argv[i]);
		free(argv);
	}

	return;
}

void lp_print(int argc, char **argv)
{
	int i;

	for (i = 0; argv[i] != NULL; i++) {
		printf("argv[%d/%d] = %s\n", i, argc, argv[i]);
	}

	return;
}

int lp_load(char *cmdpath, char *cmdline, char *runningdir, char *logfile)
{
	int pid;

	if ((pid = fork()) == -1) {
		comErr(ER, errno, "Fail to fork()");
		return -1;
	}
	else if (pid == 0) {
		char **argv = NULL;
		int    argc = 0, fd;

		/* close all the file desc */
		for (fd = 3; fd < 64; fd++) {
			close(fd);
		}
		if (logfile != NULL && strlen(logfile) != 0) {
			comLogRedirect(logfile, "a", 0);
		}

		/* restore all the signal */
		signal(SIGHUP,  SIG_DFL); signal(SIGINT,  SIG_DFL);
		signal(SIGQUIT, SIG_DFL); signal(SIGABRT, SIG_DFL);
		signal(SIGTERM, SIG_DFL); signal(SIGCHLD, SIG_DFL);
		signal(SIGPIPE, SIG_DFL);

		/* change current dir */
		if (runningdir != NULL&& strlen(runningdir) != 0) {
			if (chdir(runningdir) == -1) {
				comErr(ER, errno, "%s() Fail to change the running dir(%s)", __func__, runningdir);
			}
		}

		/* split cmdline to argv */
		if ((argv = lp_alloc(cmdline, &argc)) == NULL) {
			comErr(ER, errno, "Fail to lp_alloc (%s)", cmdline);
			exit(2);
		}

		/* execute. can't reach to the end */
		execv(cmdpath, argv);
		comErr(ER, errno, "Fail to execv (%s)", cmdline);
		exit(1);
	}

	return pid;
}

int load_shell(char *cmdline)
{
	int child;

	comLog(IN, "%s() - cmdline: %s", __func__, cmdline);

	/* load child */
	if ((child = fork()) == -1) {
		comLog(ER, "%s() - fail to fork() - error:%d(%s)", __func__, errno, strerror(errno));
		return -1;
	}
	else if (child == 0) { /* child */
#if 0
		char *pathenv = NULL;
		int   fd;

		/* rewind the signal... */
		signal(SIGHUP , SIG_DFL);
		signal(SIGTERM, SIG_DFL);
		signal(SIGINT , SIG_DFL);
		signal(SIGUSR1, SIG_DFL);
		signal(SIGUSR2, SIG_DFL);
		signal(SIGALRM, SIG_DFL);
		signal(SIGCHLD, SIG_DFL);
		signal(SIGTSTP, SIG_DFL);
		signal(SIGCONT, SIG_DFL);

		/* duplicate */
		if (outfd != -1) {
			dup2(outfd, fileno(stdin));
			dup2(outfd, fileno(stdout)); 
		}
		if (errfd != -1) 
			dup2(errfd, fileno(stderr));

		/* close all the descriptor */
		for (fd = 3; fd < LP_MAXFD; fd++) {
			close(fd);
		}

		/* put pathenv */
		if ((pathenv = getpathenv()) != NULL) {
			char *_putpath = malloc(strlen(pathenv) + 6);
			sprintf(_putpath, "PATH=%s", pathenv);
			putenv(_putpath);
		}
#endif

		/* execute */
		execl(SH_CMDLINE, "sh", "-c", cmdline, (char *)0);

		/* shell not found.. */
		comLog(IN, "%s() fail to exec (%s, %s).", SH_CMDLINE, cmdline);

		exit(0);
	}

	return child;
}


int lp_input2split(const char *input, char *cmdpath, char *cmdline, int n)
{
	char pname[256], *p;
	unsigned int i, plen = 0;

	/* derive only the name from cmdline */
	snprintf(pname, sizeof(pname), "%s", input);
	for (i = 0; i < sizeof(pname); i++) {
		if (pname[i] == '\0' || pname[i] == ' ' || pname[i] == '\t' || pname[i] == '\n') {
			pname[i] = '\0';
			break;
		}
	}

	/* is absolute path, or pure cmdline */
	if (pname[0] == '/') {
		if ((p = strrchr(pname, '/')) == NULL) {
			comLog(ER, "%s() Can't happen!!", __func__);
			return -1;
		}
		plen = p - pname;
		snprintf(cmdline, n   , "%s", input + plen + 1);
		snprintf(cmdpath, 255 , "%s", pname);

		return 0;
	}

	/* lookup the path */
	snprintf(cmdline, n, "%s", input);

	return lp_input2path(input, cmdpath);
}

int lp_input2path(const char *input, char *cmdpath)
{
	struct stat sb;
	char   pname[255], *pathenv, *envp, *p;
	int    i;

	/* derive only the name from cmdline */
	snprintf(pname, sizeof(pname), "%s", input);
	for (i = 0; i < sizeof(pname); i++) {
		if (pname[i] == '\0' || pname[i] == ' ' || pname[i] == '\t' || pname[i] == '\n') {
			pname[i] = '\0';
			break;
		}
	}

	/* lookup the PATH env */
	if ((pathenv = getenv("PATH")) == NULL) {
		comLog(ER, "%s() Fail to getenv($PATH).", __func__);
		return -1;
	}

	/* lookup the all the path */
	p    = cmdpath;
	envp = pathenv;
	while (*envp != '\0') {
		if ((*p = *envp++) == ':') {
			*p = '\0';
			if (p == cmdpath || *(p - 1) == '/') { sprintf(p,  "%s", pname); }
			else                                 { sprintf(p, "/%s", pname); }

			/* check excutable? */
			if (stat(cmdpath, &sb) != -1 && sb.st_mode & S_IXUSR) {
				return 0;
			}

			/* reset */
			p = cmdpath;
		}
		else {
			p++;
		}
	}

	return -1;
}



