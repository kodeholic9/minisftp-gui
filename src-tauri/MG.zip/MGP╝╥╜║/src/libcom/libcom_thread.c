#include "libcom.h"

sint comThreadCreate(pthread_t *thread_id, void *(*func)(void *), void *arg)
{
	pthread_attr_t	thread_attr;
	sint			nRvalue, error;


	if ((error = pthread_attr_init(&thread_attr)) != 0) {
		comLog(ER, "Can't init thread attribute (errno=%d)", error);
		return -1;
	}

	if ((error = pthread_attr_setstacksize(&thread_attr, MAX_THREAD_STACK_SZ)) != 0) {
		comLog(ER, "Can't set thread stacksize(errno=%d)", error);
		pthread_attr_destroy(&thread_attr);
		return -1;
	}


	switch (nRvalue = pthread_create(thread_id, &thread_attr, func, arg)) {
		case 0 :	
			break;

		case EAGAIN:
			comLog(ER, "fail for lack of resources (errno=%d)", nRvalue);
			pthread_attr_destroy(&thread_attr);
			return -1;

		case EINVAL:
			comLog(ER, "fail for invalid attribute (errno=%d)", nRvalue);
			pthread_attr_destroy(&thread_attr);
			return -1;

		case ENOMEM:
			comLog(ER, "fail for insufficient memory(errno=%d)", nRvalue);
			pthread_attr_destroy(&thread_attr);
			return -1;

		case EPERM:
			comLog(ER, "fail for no permission of caller (errno=%d)", nRvalue);
			pthread_attr_destroy(&thread_attr);
			return -1;

		default:
			comLog(ER, "fail pthread_create (errno=%d)", nRvalue);
			pthread_attr_destroy(&thread_attr);
			return -1;
	}

	comLog(VB, "Start Thread (%lu)", *thread_id);
	pthread_attr_destroy(&thread_attr);
	return 0;
}

sint comThreadCreateSystemScope(pthread_t *thread_id, void *(*func)(void *), void *arg)
{
	pthread_attr_t	thread_attr;

	if (pthread_attr_init(&thread_attr) != 0) {
		comLog(ER, "Can't init thread attribute %s(errno=%d)", strerror(errno), errno);
		return -1;
	}

	if (pthread_attr_setinheritsched(&thread_attr, PTHREAD_EXPLICIT_SCHED) != 0) {
		comLog(ER, "Can't set thread inherit sched %s(errno=%d)", strerror(errno), errno);
		pthread_attr_destroy(&thread_attr);
		return -1;
	}


	if (pthread_attr_setscope(&thread_attr, PTHREAD_SCOPE_SYSTEM) < 0) {
		comLog(ER, "set thread to SYSTEM SCOPE fail %s(errno=%d)", strerror(errno), errno);
		pthread_attr_destroy(&thread_attr);
		return -1;
	}

	if (pthread_create(thread_id, &thread_attr, func, arg) != 0) {
		comLog(ER, "Can't create thread %s(errno=%d)", strerror(errno), errno);
		pthread_attr_destroy(&thread_attr);
		return -1;
	}

	comLog(VB, "Start System Scope Thread (%d)", *thread_id );
	pthread_attr_destroy(&thread_attr);
	return 0;
}

sint comThreadCancel(pthread_t thread_id)
{
	comLog(VB, "Thread Canced (%d->%d)", (int)pthread_self(), (int)thread_id);

	if( pthread_cancel(thread_id) == 0 ) {
		return 0;
	}
	else {
		return -1;
	}

}

void comThreadExit(void)
{
	comLog(VB, "Exit Thread (%lu)", pthread_self() );

	pthread_detach(pthread_self());
	pthread_exit(0);
}

void comThreadSleep(pthread_mutex_t* p_mutex, pthread_cond_t* p_cond, uint msec)
{
	struct timespec	ts;
	struct timeval	tv;
	time_t      sec; /* 64BIT -20070924.MON.graemrin */

	gettimeofday(&tv, NULL);

	ts.tv_nsec = tv.tv_usec * 1000 + (msec % 1000) * 1000 * 1000;
	sec     = ts.tv_nsec / (1000 * 1000 * 1000);

	if (sec != 0)
	{   
		ts.tv_nsec %= (1000 * 1000 * 1000);
	}

	ts.tv_sec = tv.tv_sec + msec / 1000 + sec;

	pthread_mutex_lock(p_mutex);

	while (1) {
		if (pthread_cond_timedwait(p_cond, p_mutex, &ts) == ETIMEDOUT) {
			pthread_mutex_unlock(p_mutex);
			return;
		}
	}

	pthread_mutex_unlock(p_mutex);
}

sint comMutexInit(pthread_mutex_t *p_mutex)
{
	pthread_mutexattr_t	attr;

	if (pthread_mutexattr_init(&attr) != 0) {
		comLog(ER, "pthread_mutexattr_init error(errno:%d)", errno);
		return -1;
	}
	if (pthread_mutexattr_setpshared(&attr, PTHREAD_PROCESS_SHARED) != 0) {
		comLog(ER, "pthread_mutexattr_setpshared error(errno:%d)", errno);
		pthread_mutexattr_destroy(&attr);
		return -1;
	}
	if (pthread_mutexattr_setrobust_np(&attr, PTHREAD_MUTEX_ROBUST_NP) != 0) {
		comLog(ER, "pthread_mutexattr_setrobust_np error(errno:%d)", errno);
		pthread_mutexattr_destroy(&attr);
		return -1;
	}

	if (pthread_mutex_init(p_mutex, &attr) != 0) {
		comLog(ER, "pthread_mutex_init error(errno:%d)", errno);
		pthread_mutexattr_destroy(&attr);
		return -1;
	}

	pthread_mutexattr_destroy(&attr);
	return 0;
}

sint comMutexLock(pthread_mutex_t *p_mutex)
{
	int		error;

	error = pthread_mutex_lock(p_mutex);

	if (error == EOWNERDEAD) {
		comLog(ER, "error == EOWNERDEAD");
		if (pthread_mutex_consistent_np(p_mutex) != 0) {
			comLog(ER, "pthread_mutex_consistent_np error(errno:%d)", errno);
			return -1;
		}
		return 0;
	}

	if (error == 0) {
		return 0;
	}
	else {
		return -1;
	}
}

sint comMutexUnlock(pthread_mutex_t *p_mutex)
{
	int		error;

	error = pthread_mutex_unlock(p_mutex);

	if( error == EOWNERDEAD) {
		comLog(ER, "error == EOWNERDEAD");
		if( pthread_mutex_consistent_np(p_mutex) != 0) {
			comLog(ER, "pthread_mutex_consistent_np error(errno:%d)", errno);
			return -1;
		}
		return 0;
	}

	if( error == 0 ) {
		return 0;
	}
	else {
		return -1;
	}
}

sint comMutexConsistentNp(pthread_mutex_t *p_mutex)
{
	if (pthread_mutex_consistent_np(p_mutex) != 0) {
		comLog(ER, "pthread_mutex_consistent_np error(errno:%d)", errno);
		return -1;
	}

	return 0;
}

sint comCondInit(pthread_cond_t *p_cond)
{
	pthread_condattr_t	cattr;
	int error;

	if ((error = pthread_condattr_init(&cattr)) != 0) {
		comLog(ER, "pthread_condattr_init error (errno:%d)", error);
		return -1;
	}

	if ((error = pthread_condattr_setpshared(&cattr, PTHREAD_PROCESS_SHARED)) != 0) {
		comLog(ER, "pthread_condattr_setpshared error (errno:%d)", error);
		pthread_condattr_destroy(&cattr);
		return -1;
	}

	if ((error = pthread_cond_init(p_cond, &cattr)) != 0) {
		comLog(ER, "pthread_cond_init error (errno:%d)", error);
		pthread_condattr_destroy(&cattr);
		return -1;
	}

	pthread_condattr_destroy(&cattr);
	return 0;
}

sint comCondSignal(pthread_cond_t *p_cond)
{
	int		error;

	if ((error = pthread_cond_signal(p_cond)) != 0) {
		comLog(ER, "pthread_cond_signal error(errno:%d)", error);
		return -1;
	}

	return 0;
}

sint comCondWaitTimeo(pthread_cond_t *p_cond, pthread_mutex_t *p_mutex, int msec)
{
	int    error;
	struct timespec	ts;
	struct timeval	tv;
	time_t sec;

	gettimeofday(&tv, NULL);

	ts.tv_nsec = tv.tv_usec * 1000 + (msec % 1000) * 1000 * 1000;
	sec        = ts.tv_nsec / (1000 * 1000 * 1000);
	if (sec != 0) {
		ts.tv_nsec %= (1000 * 1000 * 1000);
	}
	ts.tv_sec = tv.tv_sec + (msec / 1000) + sec;

	//
	if ((error = pthread_cond_timedwait(p_cond, p_mutex, &ts)) != 0) {
		if (error == ETIMEDOUT) {
			return 1;
		}
		//
		comLog(ER, "pthread_cond_timedwait error(errno:%d)", error);
		return -1;
	}

	return 0;
}

