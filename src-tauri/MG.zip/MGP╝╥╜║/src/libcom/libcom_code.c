#include "libcom.h"

static int load_codemap(codemap_t *p_codemap, char *cate, char *f)
{
	FILE *fp;
	char  line[128], tmp[3][64]; //cate[64], attr[64], value[64];
	int   n, i;

	if ((fp = fopen(f, "r")) == NULL) {
		comErr(ER, errno, "fail to open(%s)", f);
		return -1;
	}

	for (i = 0 ; fgets(line, sizeof(line)-1, fp) != NULL && i < p_codemap->maxnum; ) {
		if ((n = strlen(line)) != 0 && line[n - 1] == '\n') { 
			line[n - 1] = '\0';
		}
		if (strlen(line) == 0 || line[0] == '#') {
			continue;
		}
		/*                     CATE ATTR VAL */
		if ((n = sscanf(line, "%64s %64s %64s", tmp[0], tmp[1], tmp[2])) != 3) {
			continue;
		}
		if (strcmp(cate, tmp[0]) != 0) {
			continue;
		}

		/* copy */
		p_codemap->p_codelist[i].code = comAscii2Int(tmp[1]);
		snprintf(p_codemap->p_codelist[i].s, CMAP_STR_LEN, "%s", tmp[2]);
		i++;
	}
	p_codemap->curnum = i;

	fclose(fp); /* never forget!! */

	return 0;
}

int comCodeMapLoad(codemap_t *p_codemap, int maxnum, char *cate, char *f)
{
	/* init */
	memset(p_codemap, 0x00, sizeof(codemap_t));

	/* malloc */
	if ((p_codemap->p_codelist = (codeent_t *)malloc(sizeof(codeent_t) * maxnum)) == NULL) {
		comErr(ER, errno, "fail to malloc");
		return -1;
	}
	memset(p_codemap->p_codelist, 0x00, sizeof(codeent_t) * maxnum);
	p_codemap->maxnum = maxnum;

	/* load */
	if (load_codemap(p_codemap, cate, f) == -1) {
		free(p_codemap->p_codelist);
		return -1;
	}

	return 0;
}

char *comCodeMap2Str(codemap_t *p_codemap, int code)
{
	int i;

	if (p_codemap != NULL && p_codemap->p_codelist != NULL) {
		for (i = 0; i < p_codemap->curnum; i++) {
			if (p_codemap->p_codelist[i].code == code) {
				return p_codemap->p_codelist[i].s;
			}
		}
	}

	return CMAP_UNDEF_STR;
}

void comCodeMapPrint(codemap_t *p_codemap)
{
	int i;

	if (p_codemap == NULL || p_codemap->p_codelist == NULL) {
		comLog(DG, "CodeMap is empty!");
		return;
	}
	for (i = 0; i < p_codemap->curnum; i++) {
		comLog(DG, "code=0x%08x(%10d) - %s",
				p_codemap->p_codelist[i].code,
				p_codemap->p_codelist[i].code,
				p_codemap->p_codelist[i].s);
	}

	return;
}

