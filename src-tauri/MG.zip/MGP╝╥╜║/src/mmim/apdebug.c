/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"

static int PollingSec = 0;

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void show_debug(char *apname, int ap_id)
{
	int  i, j, k, n;
	char buff[128];

	/* for PHUB */
	for (i = 0; i < MAX_INST_NUM; i++) {
		for (j = 0; j < MAX_TASK_NUM; j++) {
			/* check */
			if (appP->debugholder.debug[ap_id][i][j].pos[0] == 0) {
				continue;
			}

			/* setup the outbuffer */
			n = sprintf(buff, "[DEBUG] %-5s I(%d) T(%d) Debug(", apname, i, j);
			for (k = 0; k < DEBUG_STATE_NUM; k++) {
				if (k == 0) {
					n += sprintf(buff + n, "%d", appP->debugholder.debug[ap_id][i][j].pos[k]);
				}
				else {
					n += sprintf(buff + n, ",%d", appP->debugholder.debug[ap_id][i][j].pos[k]);
				}
			}
			printf("%s) Count(%d)\n", buff, appP->debugholder.debug[ap_id][i][j].cnt);
		}
	}
}

void usage(char *pname)
{
	printf("Usage: %s [ -s SEC ]\n", pname);
	exit(1);
}

int main(int argc, char **argv)
{
	int cc;

	while ((cc = getopt(argc, argv, "s:")) != EOF) {
		switch (cc) {
			case 's' :
				if (optarg == NULL) usage(argv[0]); 
				PollingSec = atoi(optarg);
				break;

			default  :
				usage(argv[0]);
				break;
		}
	}
	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}

	if (PollingSec) {
		while (TRUE) {
			printf("-----------------------------------------------------------------------------\n");
			show_debug("PMON", PMON);
			show_debug("CHNL", CHNL);
			show_debug("MGPP", MGPP);
			show_debug("WEBI", WEBI);
			show_debug("HOOK", HOOK);
			sleep(PollingSec);
		}
	}
	else {
		printf("-----------------------------------------------------------------------------\n");
		show_debug("PMON", PMON);
		show_debug("CHNL", CHNL);
		show_debug("MGPP", MGPP);
		show_debug("WEBI", WEBI);
		show_debug("HOOK", HOOK);
	}
	printf("\n");

	return 0;
}

