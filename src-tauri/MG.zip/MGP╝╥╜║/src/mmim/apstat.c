/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"
#include "liboma.h"

/* for each calumn */
typedef struct _statent {
	char column[16];
	uint current;
	uint previous;
	int  l;
} statent_t;

typedef void (*op_prepare_f)();
typedef void (*op_makeup_f)();

/* operation */
op_prepare_f StatPrepare = NULL;
op_makeup_f  StatMakeup  = NULL;

/* global */
static int       StatSecs = 1;
static statent_t StatEntry[30];
static int       StatCount;
static char      StatBar[512];
static char      StatTitle[512];
static char      StatContents[512];

sst_t *sstP;

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////

/** @private */
void usage(char *cmd)
{
	printf("# Usage : %s -k kind -t sec\n", cmd);
	printf("# kind  :\n");
	printf("#        ueinvk\n");
	printf("#        cpsinvk\n");
	printf("#        lcsinvk\n");
	printf("#        service\n");
	printf("#        commsvc\n");
	printf("#        talksvc\n");
	printf("#        ue_error\n");
	printf("#        pe_error\n");
	printf("#        rtt\n");
	printf("#        mrs\n");
	printf("#        content\n");

	exit(1);
}

/** @private */
void stat_column_put(char *column, int length)
{
	/* check */
	if (StatCount >= 24) { 
		printf("# StatCount Overflowed!\n");
		return;
	}

	/* setup */
	sprintf(StatEntry[StatCount].column, "%s", column);
	StatEntry[StatCount].l = length;
	StatCount++;

	return;
}

void stat_value_put(char *column, uint value)
{
	int i;

	/* lookup */
	for (i = 0; i < StatCount; i++) {
		if (strcmp(StatEntry[i].column, column) == 0) {
			break;
		}
	}

	/* then, save */
	StatEntry[i].previous = StatEntry[i].current;
	StatEntry[i].current  = value;

	return ;
}

void stat_prepare()
{
	int  i, len;
	char fmt[80];

	/* init */
	memset(StatBar  , 0x00, sizeof(StatBar));
	memset(StatTitle, 0x00, sizeof(StatTitle));

	/* prepare the specifics */
	StatPrepare();

	/* prepare in generals */
	for (i = 0, len = 0; i < StatCount; i++) {
		/* formatting */
		sprintf(fmt, "%%%d.%ds ", StatEntry[i].l, StatEntry[i].l);

		/* append the columns */
		len += sprintf(StatTitle+len, fmt, StatEntry[i].column);
	}

	/* buildup the bar */
	for (i = 0; i < len; i++) { StatBar[i] = '-'; }

	return;
}

void stat_makeup()
{
	int  i, len, delta;
	char fmt[80];

	/* makeup the specifics */
	StatMakeup();

	/* makeup in generals */
	for (i = 0, len = 0; i < StatCount; i++) {
		//      printf("StatEntry[%d].current ........... %d\n", i, StatEntry[i].current);
		/* calculate the delta */
		delta = calcDelta("STAT", StatEntry[i].current, &StatEntry[i].previous);

		if (StatSecs > 1) {
			delta /= StatSecs;
		}

		/* formatting */
		sprintf(fmt, "%%%dd ", StatEntry[i].l);

		len += sprintf(StatContents+len, fmt, delta);
	}

	return;
}

void stat_title()
{
	/* print          */
	/*       00:00:00 */
	printf("\n");
	printf(" SYS_TIME %s\n", StatTitle);
	printf(" -------- %s\n", StatBar);
}

void stat_print()
{
	char tms[24];

	printf(" %s %s\n", comTimeT2Str(tms, sizeof(tms), "%H:%M:%S", comTime()), StatContents);

	return;
}

/** @private */
void prepare_rtt()
{
	int  i;
	char column[16];

	/* prepare columns */
	for (i = 0; i < SST_MAX_RTT_NUM; i++) {
		sprintf(column, "U%d", i);
		stat_column_put(column, 5);
	}
	for (i = 0; i < SST_MAX_RTT_NUM; i++) {
		sprintf(column, "P%d", i);
		stat_column_put(column, 5);
	}

	return;
}

void makeup_rtt()
{
	int  i;
	char column[16];
	sst_rtt_t rtt;

	/* make a snapshot */
	memcpy(&rtt, &sstP->rtt, sizeof(sst_rtt_t));

	/* then, put the new value */
	for (i = 0; i < SST_MAX_RTT_NUM; i++) {
		sprintf(column, "U%d", i);
		stat_value_put(column, rtt.ue[i]);
	}
	for (i = 0; i < SST_MAX_RTT_NUM; i++) {
		sprintf(column, "P%d", i);
		stat_value_put(column, rtt.pe[i]);
	}

	return;
}

/** @private */
void prepare_service()
{
	int  i;
	char column[16];

	/* prepare columns */
	for (i = 0; i < SST_MAX_SERVICE_NUM; i++) {
		if (sstP->service.fid[i] > 0) {
			sprintf(column, "%u", sstP->service.fid[i]);
			stat_column_put(column, 7);
		}
	}

	return;
}

void makeup_service()
{
	int  i;
	char column[16];
	sst_service_t service;

	/* make a snapshot */
	memcpy(&service, &sstP->service, sizeof(sst_service_t));

	/* then, put the new value */
	for (i = 0; i < SST_MAX_SERVICE_NUM; i++) {
		if (service.fid[i] > 0) {
			sprintf(column, "%u" , service.fid[i]);
			stat_value_put(column, service.n[i]);
		}
	}

	return;
}

void makeup_commsvc()
{
	int  i;
	char column[16];
	sst_service_t service;

	/* make a snapshot */
	memcpy(&service, &sstP->commsvc, sizeof(sst_service_t));

	/* then, put the new value */
	for (i = 0; i < SST_MAX_SERVICE_NUM; i++) {
		if (service.fid[i] > 0) {
			sprintf(column, "%u" , service.fid[i]);
			stat_value_put(column, service.n[i]);
		}
	}

	return;
}

void makeup_talksvc()
{
	int  i;
	char column[16];
	sst_service_t service;

	/* make a snapshot */
	memcpy(&service, &sstP->talksvc, sizeof(sst_service_t));

	/* then, put the new value */
	for (i = 0; i < SST_MAX_SERVICE_NUM; i++) {
		if (service.fid[i] > 0) {
			sprintf(column, "%u" , service.fid[i]);
			stat_value_put(column, service.n[i]);
		}
	}

	return;
}

/** @private */
void prepare_error()
{
	int  i;
	char column[16];

	/* prepare columns */
	for (i = 0; i < SST_MAX_ERROR_NUM; i++) {
		sprintf(column, "E%02d", i);
		stat_column_put(column, 5);
	}

	return;
}

void makeup_ue_error()
{
	int  i;
	char column[16];
	sst_error_t error;

	/* make a snapshot */
	memcpy(&error, &sstP->error, sizeof(sst_error_t));

	/* then, put the new value */
	for (i = 0; i < SST_MAX_ERROR_NUM; i++) {
		sprintf(column, "E%02d", i);
		stat_value_put(column, error.ue_error[i]);
	}

	return;
}

void makeup_pe_error()
{
	int  i;
	char column[16];
	sst_error_t error;

	/* make a snapshot */
	memcpy(&error, &sstP->error, sizeof(sst_error_t));

	/* then, put the new value */
	for (i = 0; i < SST_MAX_ERROR_NUM; i++) {
		sprintf(column, "E%02d", i);
		stat_value_put(column, error.pe_error[i]);
	}

	return;
}

/** @private */
void prepare_ueinvk()
{
	/* prepare columns */
	stat_column_put("UADD" , 5);
	stat_column_put("UDEL1", 5);
	stat_column_put("UDEL2", 5);
	stat_column_put("UINVK", 5);
	stat_column_put("USUCC", 5);
	stat_column_put("UFAIL", 5);
	stat_column_put("UDUPL", 5);
	stat_column_put("PINVK", 5);
	stat_column_put("PSUCC", 5);
	stat_column_put("PFAIL", 5);
	stat_column_put("PDUPL", 5);
	stat_column_put("PTIMO", 5);

	stat_column_put("IMESG", 5);
	stat_column_put("OMESG", 5);
	stat_column_put("IBYTE", 7);
	stat_column_put("OBYTE", 7);

	return;
}

void makeup_ueinvk()
{
	sst_user_t   user;
	sst_invoke_t invoke;
	sst_bytes_t  bytes;

	/* make a snapshot */
	memcpy(&user  , &sstP->user  , sizeof(sst_user_t));
	memcpy(&invoke, &sstP->invoke + SST_INVK_UE, sizeof(sst_invoke_t));
	memcpy(&bytes , &sstP->bytes , sizeof(sst_bytes_t));

	/* then, put the new value */
	stat_value_put("UADD" , user.add);
	stat_value_put("UDEL1", user.del_leave);
	stat_value_put("UDEL2", user.del_timeo);
	stat_value_put("UINVK", invoke.recv);
	stat_value_put("USUCC", invoke.recv_succ);
	stat_value_put("UFAIL", invoke.recv_fail);
	stat_value_put("UDUPL", invoke.recv_dupl);
	stat_value_put("PINVK", invoke.send);
	stat_value_put("PSUCC", invoke.send_succ);
	stat_value_put("PFAIL", invoke.send_fail);
	stat_value_put("PDUPL", invoke.send_dupl);
	stat_value_put("PTIMO", invoke.send_timeo);
	stat_value_put("IMESG", bytes.recv);
	stat_value_put("OMESG", bytes.send);
	stat_value_put("IBYTE", bytes.recv_bytes);
	stat_value_put("OBYTE", bytes.send_bytes);

	return;
}

/** @private */
void prepare_cpsinvk()
{
	/* prepare columns */
	stat_column_put("RINVK", 5);
	stat_column_put("RSUCC", 5);
	stat_column_put("RFAIL", 5);
	stat_column_put("RDUPL", 5);
	stat_column_put("SINVK", 5);
	stat_column_put("SSUCC", 5);
	stat_column_put("SFAIL", 5);
	stat_column_put("SDUPL", 5);

	return;
}

void makeup_cpsinvk()
{
	sst_invoke_t invoke;

	/* make a snapshot */
	memcpy(&invoke, &sstP->invoke + SST_INVK_CPS, sizeof(sst_invoke_t));

	/* then, put the new value */
	stat_value_put("RINVK", invoke.recv);
	stat_value_put("RSUCC", invoke.recv_succ);
	stat_value_put("RFAIL", invoke.recv_fail);
	stat_value_put("RDUPL", invoke.recv_dupl);
	stat_value_put("SINVK", invoke.send);
	stat_value_put("SSUCC", invoke.send_succ);
	stat_value_put("SFAIL", invoke.send_fail);
	stat_value_put("SDUPL", invoke.send_dupl);

	return;
}

/** @private */
void prepare_lcsinvk()
{
	/* prepare columns */
	stat_column_put("RINVK", 5);
	stat_column_put("RSUCC", 5);
	stat_column_put("RFAIL", 5);
	stat_column_put("RDUPL", 5);
	stat_column_put("SINVK", 5);
	stat_column_put("SSUCC", 5);
	stat_column_put("SFAIL", 5);
	stat_column_put("SDUPL", 5);

	return;
}

void makeup_lcsinvk()
{
	sst_invoke_t invoke;

	/* make a snapshot */
	memcpy(&invoke, &sstP->invoke + SST_INVK_LCS, sizeof(sst_invoke_t));

	/* then, put the new value */
	stat_value_put("RINVK", invoke.recv);
	stat_value_put("RSUCC", invoke.recv_succ);
	stat_value_put("RFAIL", invoke.recv_fail);
	stat_value_put("RDUPL", invoke.recv_dupl);
	stat_value_put("SINVK", invoke.send);
	stat_value_put("SSUCC", invoke.send_succ);
	stat_value_put("SFAIL", invoke.send_fail);
	stat_value_put("SDUPL", invoke.send_dupl);

	return;
}

/** @private */
void prepare_mrs()
{
	/* prepare columns */
	stat_column_put("ALLOC", 5);
	stat_column_put("ASUCC", 5);
	stat_column_put("AFAIL", 5);
	stat_column_put("RELES", 5);
	stat_column_put("RSUCC", 5);
	stat_column_put("RFAIL", 5);
	stat_column_put("IMESG", 5);
	stat_column_put("OMESG", 5);
	stat_column_put("IBYTE", 10);
	stat_column_put("OBYTE", 10);

	return;
}

void makeup_mrs()
{
	sst_resource_t resource;
	sst_bytes_t    relay;

	/* make a snapshot */
	memcpy(&resource, &sstP->resource, sizeof(sst_resource_t));
	memcpy(&relay   , &sstP->relay   , sizeof(sst_bytes_t));

	/* then, put the new value */
	stat_value_put("ALLOC", resource.alloc);
	stat_value_put("ASUCC", resource.alloc_succ);
	stat_value_put("AFAIL", resource.alloc_fail);
	stat_value_put("RINVK", resource.release);
	stat_value_put("RSUCC", resource.release_succ);
	stat_value_put("RFAIL", resource.release_fail);
	stat_value_put("IMESG", relay.recv);
	stat_value_put("OMESG", relay.send);
	stat_value_put("IBYTE", relay.recv_bytes);
	stat_value_put("OBYTE", relay.send_bytes);

	return;
}

int main(int argc, char **argv)
{
	int cc, i;

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		comLog(ER, "# fail to appInitialize");
		return -1;
	}
	if (omaInitialize(OMA_SHM_KEY) < 0) {
		comLog(ER, "# fail to appInitialize");
		return -1;
	}
	sstP = &appP->sst;

	/* the default */
	StatPrepare = prepare_ueinvk;
	StatMakeup  = makeup_ueinvk;

	/* options.. */
	while ((cc = getopt(argc, argv, "k:t:h")) != EOF) {
		switch(cc) {
			case 'k' :
				if      (optarg == NULL) usage(argv[0]); 
				else if (strcmp(optarg, "ueinvk"    ) == 0) { StatPrepare = prepare_ueinvk ; StatMakeup  = makeup_ueinvk;   }
				else if (strcmp(optarg, "cpsinvk"   ) == 0) { StatPrepare = prepare_cpsinvk; StatMakeup  = makeup_cpsinvk;  }
				else if (strcmp(optarg, "lcsinvk"   ) == 0) { StatPrepare = prepare_lcsinvk; StatMakeup  = makeup_lcsinvk;  }
				else if (strcmp(optarg, "ue_error"  ) == 0) { StatPrepare = prepare_error  ; StatMakeup  = makeup_ue_error; }
				else if (strcmp(optarg, "pe_error"  ) == 0) { StatPrepare = prepare_error  ; StatMakeup  = makeup_pe_error; }
				else if (strcmp(optarg, "service"   ) == 0) { StatPrepare = prepare_service; StatMakeup  = makeup_service;  }
				else if (strcmp(optarg, "commsvc"   ) == 0) { StatPrepare = prepare_service; StatMakeup  = makeup_commsvc;  }
				else if (strcmp(optarg, "talksvc"   ) == 0) { StatPrepare = prepare_service; StatMakeup  = makeup_talksvc;  }
				else if (strcmp(optarg, "rtt"       ) == 0) { StatPrepare = prepare_rtt    ; StatMakeup  = makeup_rtt;      }
				else if (strcmp(optarg, "rtt"       ) == 0) { StatPrepare = prepare_rtt    ; StatMakeup  = makeup_rtt;      }
				else if (strcmp(optarg, "rtt"       ) == 0) { StatPrepare = prepare_rtt    ; StatMakeup  = makeup_rtt;      }
				else if (strcmp(optarg, "mrs"       ) == 0) { StatPrepare = prepare_mrs    ; StatMakeup  = makeup_mrs;      }
				else if (strcmp(optarg, "content"   ) == 0) { 
					omaContentMapShow(&omaP->cmap);
					exit(0);
				}
				break;

			case 't' : StatSecs = atoi(optarg); break;
			case 'h' : 
			default  : usage(argv[0]); 
		}
	}

	/* prepare */
	stat_prepare();

	/* run... until interrupted */
	i = 0;
	while (TRUE) { 
		if ((i  %  30) == 0) stat_title();
		stat_makeup();
		stat_print();
		sleep(StatSecs);

		i++;
	}

	exit(0);

	return 0;
}

