/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"
#include "libtbl.h"

enum {
	CPS_LOAD = 1,
	CPS_ADD,
	CPS_DEL,
	LCS_LOAD,
	LCS_ADD,
	LCS_DEL,
	MRS_LOAD,
	MRS_ADD,
	MRS_DEL,
	NODE_LOAD,
	NODE_ADD,
	NODE_DEL,
};

static int  Operation = 0;
static int  Index = 0;
static int  Key   = 0;
static char Host[32];
static int  Port;

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *cmd)
{
	printf("Usage: %s [ -l | -a | -d | -s {node|lcs|cps|exp|mrsport} ] -i index -k key -h host -p port -P port\n", cmd);
	printf("Ex   : %s -l node       # load NODETBL\n", cmd);
	printf("Ex   : %s -l lcs        # load LCSTBL\n", cmd);
	printf("Ex   : %s -l cps        # load CPSTBL\n", cmd);
	printf("Ex   : %s -l exp        # load EXPTBL\n", cmd);
	printf("Ex   : %s -l mrsport    # load MRSPORT\n", cmd);
	printf("Ex   : %s -s node       # show NODETBL\n", cmd);
	printf("Ex   : %s -s lcs        # show LCSTBL\n", cmd);
	printf("Ex   : %s -s cps        # show CPSTBL\n", cmd);
	printf("Ex   : %s -s exp        # show EXPTBL\n", cmd);
	printf("Ex   : %s -s mrsport    # show MRSPORTTBL\n", cmd);
	printf("Ex   : %s -a lcs -i 100 -k 0x03000101 -h 10.1.1.10 -p 13390 # add LCSTBL\n", cmd);
	printf("Ex   : %s -d cps -i 76  # del CPSTBL\n", cmd);

	return;
}

int load_node()
{
	/* create the node table */
	if (tblNodeLoad(&tblP->nodetbl) == -1) {
		printf("LOAD.. %-10s FAILED.\n", "NODETBL");
		return -1;
	}
	printf("LOAD.. %-10s OK.\n", "NODETBL");

	return 0;
}

int load_exp()
{
	/* create the cps table */
	if (tblExpLoad(&tblP->exptbl) == -1) {
		printf("LOAD.. %-10s FAILED.\n", "EXPTBL");
		return -1;
	}
	printf("LOAD.. %-10s OK.\n", "EXPTBL");

	return 0;
}

int load_mrsport()
{
	/* create the cps table */
	if (tblMrsPortLoad(&tblP->mrsporttbl) == -1) {
		printf("LOAD.. %-10s FAILED.\n", "MRSPORTTBL");
		return -1;
	}
	printf("LOAD.. %-10s OK.\n", "MRSPORTTBL");

	return 0;
}

void  check_args(char *cmd, int is_add) {
	if (Index == 0) {
		printf("INVALID INDEX\n");
		usage(cmd);
		exit(1);
	}

	/* this is only for ADD operation */
	if (is_add) {
		if (Key == 0) {
			printf("INVALID KEY\n");
			usage(cmd);
			exit(1);
		}
		if (Port == 0) {
			printf("INVALID PORT\n");
			usage(cmd);
			exit(1);
		}
		if (strlen(Host) == 0) {
			printf("INVALID HOST\n");
			usage(cmd);
			exit(1);
		}
	}

	return;
}

void show_node() { tblNodePrint(&tblP->nodetbl); }
void show_exp()  { tblExpPrint (&tblP->exptbl); }
void show_mrsport() { tblMrsPortPrint(&tblP->mrsporttbl); }

int main(int argc, char **argv)
{
	int cc, option = 0;

	/* create the shared memory */
	if (tblInitialize(TBL_SHM_KEY) < 0) {
		printf("INFO] not initialized. let's create.\n");
		if (tblCreate(TBL_SHM_KEY) < 0) {
			printf("CREATE %-10s [%-15s] FAILED.\n", "TBL", ".....");
			return -1;
		}
		printf("CREATE %-10s [%-15s] OK.\n", "TBL", ".....");
	}
	appInitialize(APP_SHM_KEY, MMIM, 0);

	/* check option */
	while ((cc = getopt(argc, argv, "l:s:a:d:i:k:h:p:")) != EOF) {
		switch (cc) {
			case 'a' :
				if      (strcmp(optarg, "lcs" ) == 0) { Operation = LCS_ADD; }
				else if (strcmp(optarg, "cps" ) == 0) { Operation = CPS_ADD; }
				else                                  { usage(argv[0]); exit(1); }
				option++;
				break;

			case 'd' :
				if      (strcmp(optarg, "lcs" ) == 0) { Operation = LCS_DEL; }
				else if (strcmp(optarg, "cps" ) == 0) { Operation = CPS_DEL; }
				else                                  { usage(argv[0]); exit(1); }
				option++;
				break;

			case 'i' :
				Index = atoi(optarg);
				break;

			case 'k' :
				Key = comAscii2Int(optarg);
				break;

			case 'h' :
				sprintf(Host, "%s", optarg);
				break;

			case 'p' :
				Port = atoi(optarg);
				break;

			case 'l' :
				if      (strcmp(optarg, "node")    == 0) { load_node(); }
				else if (strcmp(optarg, "exp")     == 0) { load_exp();  }
				else if (strcmp(optarg, "mrsport") == 0) { load_mrsport(); }
				else                                     { usage(argv[0]); exit(1); }
				option++;
				break;

			case 's' :
				if      (strcmp(optarg, "node")    == 0) { show_node(); }
				else if (strcmp(optarg, "exp")     == 0) { show_exp();  }
				else if (strcmp(optarg, "mrsport") == 0) { show_mrsport(); }
				else                                 { usage(argv[0]); exit(1); }
				option++;
				break;

			default :
				usage(argv[0]); exit(1);
				break;
		}
	}
	if (!option) {
		show_node();
		show_exp();
		show_mrsport();
	}

	return 0;
}



