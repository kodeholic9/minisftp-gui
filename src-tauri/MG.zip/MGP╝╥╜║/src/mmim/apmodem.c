#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "libcom.h"
#include "libapp.h"

#ifdef _DSTECH
#include "modem.h"

#ifndef ON
#define ON  1
#endif

#ifndef OFF
#define OFF 0
#endif

#define STR_BUF	100
#define DBG_BUF	512

#define ATCMD_GET_IMEI	"at%imei?\r\n"		/* IMEI */
#define ATCMD_GET_CNUM	"at+cnum\r\n"			/* 전화번호 */
#define ATCMD_GET_NSI	"at@nsi\r\n"			/* 개통 정보 */
#define ATCMD_GET_DBG	"at@dbg\r\n"			/* 모뎀 상태 디버깅 메세지 */
#define ATCMD_GET_CSQ	"at+csq\r\n"			/* RSSI 정보 */
#define ATCMD_GET_CGDCONT "at+cgdcont?\r\n"  	/* APN 정보 */
#define ATCMD_GET_CGPADDR "at+cgpaddr\r\n" 	/* Modem 에서 수신한 IP 정보*/

void help(void)
{
	printf("=========================\n");
	printf("1 : GET IMEI \n");
	printf("2 : GET CNUM\n");
	printf("3 : GET NSI\n");
	printf("4 : GET CSQ\n");
	printf("5 : GET CGDCONT\n");
	printf("6 : GET CGPADDR\n");
	printf("7 : GET DBG\n");
	printf("8 : SET DBGMSG ON\n");
	printf("9 : SET DBGMSG OFF\n");
	printf("0 : EXIT\n");
	printf("h : HELP\n");
	printf("=========================\n");
}
#endif

int main(int argc, char* argv[])
{
	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		fprintf(stderr, "fail to appInitialize()\n");
		return -1;
	}

#ifdef _DSTECH
	DST_MODEM_RESULT mRet=eDST_MODEM_OK;
	int ret;
	char imei[STR_BUF] = {0,};
	char cnum[STR_BUF] = {0,};
	char nsi[STR_BUF] = {0,};
	char cgdcont[STR_BUF]={0,};
	char cgpaddr[STR_BUF]={0,};
	char dbg[DBG_BUF]={0,};
	int csq;

	printf("[%s] start!!\n", __FILE__);
	help();
//	while((ret = getopt(argc, argv, "0123456789abcdefghijklmnrwstuz")) != -1)
	while(1)
	{
		ret = getchar();
		switch(ret)
		{
			case '0':
				exit(1);
				break;
			case '1':
				mRet = modem_get_imei(imei, sizeof(imei));
				printf("ret: %d, imei: %s\n",mRet, imei);
				break;
			case '2':
				mRet = modem_get_cnum(cnum, sizeof(cnum));
				printf("ret: %d, cnum: %s\n",mRet, cnum);
				break;
			case '3':
				mRet = modem_get_nsi(nsi, sizeof(nsi));
				printf("ret: %d, nsi: %s\n",mRet, nsi);
				break;
			case '4':
				mRet = modem_get_csq(&csq);
				printf("ret: %d, csq: %d\n",mRet, csq);
				break;
			case '5':
				modem_get_cgdcont(cgdcont, sizeof(cgdcont));
				printf("ret: %d, cgdcont: %s\n",mRet, cgdcont);
				break;
			case '6':
				modem_get_cgpaddr(cgpaddr, sizeof(cgpaddr));
				printf("ret: %d, cgpaddr: %s\n",mRet, cgpaddr);
				break;
			case '7':
				modem_get_dbg(dbg, sizeof(dbg));
				printf("ret: %d, dbg: %s\n",mRet, dbg);
				break;
			case '8':
				modem_set_dbgmsg(ON);
				printf("debug ON\n");
				break;
			case '9':
				modem_set_dbgmsg(OFF);
				printf("debug OFF\n");
				break;
			case 'h':
				help();
				break;
			default :
				break;
		}
	}

	printf("[%s] exit!!\n", __FILE__);
#endif

	return 0;
}
