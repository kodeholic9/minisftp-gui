/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"
#include "liboma.h"

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *cmd)
{
	printf("Usage: %s [ -c | -p seconds ]\n", cmd);
	printf("Ex   : %s        # Show Resource\n", cmd);
	printf("Ex   : %s -p 1   # Show Performance\n", cmd);
	printf("Ex   : %s -c     # Create Resource\n", cmd);
	exit(1);

	return;
}
void show_performance(int seconds)
{
	sysbundle_t sysbundle;

	omaCollectInit(&sysbundle);
	while (TRUE) {
		/* collect */
		omaCollectSysBundle(&sysbundle);
		omaCollectOdbInfo(&sysbundle, pOmaProfile->ODBStatusCommand);
		omaCollectTdbInfo(&sysbundle, pOmaProfile->TDBStatusCommand);
		omaCollectYdbInfo(&sysbundle, pOmaProfile->YDBStatusCommand);

		/* print */
		omaCollectPrint(&sysbundle);

		sleep(seconds);
	}

	return;
}

int main(int argc, char **argv)
{
	int  cc;

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}

	while ((cc = getopt(argc, argv, "hcp:")) != EOF) {
		switch (cc) {
			case 'c' :
				if (appResourceLoad(&appP->resourceholder) == -1) {
					printf("FAILED.\n");
				}
				else {
					printf("OK.\n");
				}
				exit(0);
				break;

			case 'p' :
				show_performance(atoi(optarg));
				exit(0);
				break;

			case 'h' :
			default  :
				usage(argv[0]);
				break;
		}
	}
	appResourcePrint(&appP->resourceholder);

	return 0;
}
