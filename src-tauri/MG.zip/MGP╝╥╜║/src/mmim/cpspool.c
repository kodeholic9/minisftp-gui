/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"
#include "libcps.h"

typedef struct _mmioption {
	int  inst_id; 
	int  pool_id;
	char ue[MAX_ADDRESS_LEN+1];
} mmioption_t;

mmioption_t mmiOption;
char        TS[20];
int         counter = 0;

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *pname)
{
	printf("Usage: %s [ -i INST_ID -p POOL_ID | -u UE_ADDR ]\n", pname);
	printf("Ex   : %s -i 1 -p 1\n", pname);
	printf("Ex   : %s -u 01041731793\n", pname);
	exit(1);

	return;
}

void show_pooldata(cmpool_t *p_cmpool, int index, int inst_id)
{
	printf("===============================================\n");
	printf(" [%02d] POOL ID [%6d]\n", inst_id, p_cmpool->poolmeta.id);
	printf("-----------------------------------------------\n");
	printf(" STATUS          = %s\n", appCodeMap2Str(CC_MpStatus, p_cmpool->poolmeta.status));
	printf(" TIMERED         = %s\n", p_cmpool->poolmeta.timered ? "TRUE" : "FALSE");
	printf(" COMMAND ID      = 0x%04x (%s)\n",
			p_cmpool->pooldata.command_id,
			appCodeMap2Str(CC_CmCmdId, p_cmpool->pooldata.command_id));
	printf(" COMMAND LEN     = %d\n", p_cmpool->pooldata.command_length);
	printf(" EXPRTIME        = %s\n", comTimeT2Str(TS, 20, "%m/%d %H:%M:%S", p_cmpool->poolmeta.exprtime));
	printf(" NEXTTIME        = %f\n", p_cmpool->poolmeta.nexttime);
	printf(" QLINK FREE(L:R) = %d:%d (%d,%s)\n",
			p_cmpool->poolmeta.qlink[CMQNAME_FREE].L,
			p_cmpool->poolmeta.qlink[CMQNAME_FREE].R,
			CMQNAME_FREE, appCodeMap2Str(CC_MpQName, CMQNAME_FREE));
	printf(" QLINK TIMR(L:R) = %d:%d (%d,%s)\n",
			p_cmpool->poolmeta.qlink[CMQNAME_TIMR].L,
			p_cmpool->poolmeta.qlink[CMQNAME_TIMR].R,
			CMQNAME_TIMR, appCodeMap2Str(CC_MpQName, CMQNAME_TIMR));
	printf(" QLINK PEND(L:R) = %d:%d (%d,%s)\n",
			p_cmpool->poolmeta.qlink[CMQNAME_PEND].L,
			p_cmpool->poolmeta.qlink[CMQNAME_PEND].R,
			CMQNAME_PEND, appCodeMap2Str(CC_MpQName, CMQNAME_PEND));

	printf("------------------\n");
	printf(" FROM            = %s\n", p_cmpool->pooldata.from);
	printf(" TO              = %s\n", p_cmpool->pooldata.ttoo);
	printf(" PEND-PATH    ID = %d\n", p_cmpool->pooldata.pend_path_id);
	printf("              UE = %s\n", p_cmpool->pooldata.pend_path_ue);
	printf(" DATA        LEN = %d\n", p_cmpool->pooldata.datalen);
	//p_cmpool->pooldata.data[MAX_CPSMSG_DATA_SIZE];

	/* TIME */
	printf(" REPORT FLAG     = %d\n", p_cmpool->pooldata.report_flag);
	printf(" REPORTED        = %d\n", p_cmpool->pooldata.reported);
	printf(" START           = 0x%02x\n", p_cmpool->pooldata.start_bit);
	printf(" VERION          = 0x%02x\n", p_cmpool->pooldata.version);
	printf(" TRANSACTION  ID = %d\n", p_cmpool->pooldata.recvtid);
	printf(" SERVICE      ID = %d\n", p_cmpool->pooldata.service_id);
	printf(" SEQUENCE        = %d\n", p_cmpool->pooldata.sequence);
	printf(" FROMTYPE        = %d\n", p_cmpool->pooldata.from_type);
	printf(" TRIES     [I,R] = %d, %d\n", p_cmpool->pooldata.invtries, p_cmpool->pooldata.tries);

	printf(" TIME   RECEIVED = %s\n", comTimeT2Str(TS, 20, "%m/%d %H:%M:%S", p_cmpool->pooldata.rcvtime));
	printf("         INVOKED = %s\n", comTimeT2Str(TS, 20, "%m/%d %H:%M:%S", p_cmpool->pooldata.invtime));
	printf("        REPORTED = %s\n", comTimeT2Str(TS, 20, "%m/%d %H:%M:%S", p_cmpool->pooldata.rpttime));
	printf("        FINISHED = %s\n", comTimeT2Str(TS, 20, "%m/%d %H:%M:%S", p_cmpool->pooldata.fintime));
	printf(" CODE  RESPONSED = %d (%s)\n",
			p_cmpool->pooldata.rescode, appCodeMap2Str(CC_CmResCode, p_cmpool->pooldata.rescode));
	printf("        REPORTED = %d (%s)\n",
			p_cmpool->pooldata.rptcode, appCodeMap2Str(CC_CmResCode, p_cmpool->pooldata.rptcode));
	printf("        FINISHED = %d (%s)\n",
			p_cmpool->pooldata.fincode, appCodeMap2Str(CC_CmResCode, p_cmpool->pooldata.fincode)); 
	printf("\n");


	return;
}

int _cmcbscan(cphashmagic_t *p_magic, cmqueue_t *p_cmqueue, cmpool_t *p_cmpool, void *p_args)
{
	int inst_id = *(int *)p_args;

	show_pooldata(p_cmpool, p_cmpool->poolmeta.id, inst_id);

	return RET_CONTINUE;
}

void show_pool(int inst_id)
{
	cmpool_t     *p_cmpool = NULL;
	int i;

	if (cpsInitialize(CPS_SHM_KEY + inst_id) < 0) {
		return;
	}
	if (strlen(mmiOption.ue) > 0) {
		for (i = 1; i < MAX_CMPOOL_NUM; i++) {
			p_cmpool = cpsP->hashmagic.poolData + i;
			if (strstr(p_cmpool->pooldata.from, mmiOption.ue) == NULL
					&& strstr(p_cmpool->pooldata.ttoo, mmiOption.ue) == NULL)
			{
				continue;
			}
			show_pooldata(p_cmpool, p_cmpool->poolmeta.id, inst_id);
			//_cmpool_qscan(&cpsP->hashmagic, &p_hashdata->poolPendQ, TRUE, _cmcbscan, &inst_id);
		}
	}
	else if (mmiOption.pool_id > 0) {
		show_pooldata(cpsP->hashmagic.poolData + mmiOption.pool_id, mmiOption.pool_id, inst_id);
	}

	/* detach.. */
	shmdt(cpsP);

	return;
}

int main(int argc, char **argv)
{
	int cc, i;

	comLogLevelSet(WA);
	memset(&mmiOption, 0x00, sizeof(mmioption_t));

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}
	while ((cc = getopt(argc, argv, "i:p:u:")) != EOF) {
		switch (cc) {
			case 'i':
				if (optarg == NULL) {
					usage(argv[0]);
				}

				/* INST_ID */
				mmiOption.inst_id = atoi(optarg);
				if (mmiOption.inst_id <= 0
						|| mmiOption.inst_id >= MAX_CPS_INST_NUM)
				{
					usage(argv[0]);
				}
				counter++;
				break;

			case 'p':
				if (optarg == NULL) {
					usage(argv[0]);
				}

				/* INST_ID */
				mmiOption.pool_id = atoi(optarg);
				if (mmiOption.pool_id <= 0
						|| mmiOption.inst_id >= MAX_CMPOOL_NUM)
				{
					usage(argv[0]);
				}
				counter++;
				break;

			case 'u':
				if (optarg == NULL) {
					usage(argv[0]);
				}

				/* UE */
				snprintf(mmiOption.ue, MAX_ADDRESS_LEN+1, "%s", optarg);
				break;

			default :
				usage(argv[0]);
				break;
		}
	}
	if (counter != 2 && strlen(mmiOption.ue) == 0) {
		usage(argv[0]);
	}

	if (mmiOption.inst_id == 0) {
		for (i = 1; i < MAX_CPS_INST_NUM; i++) {
			if (appP->debugholder.debug[PHUB][i][0].pos[0] == 0) {
				continue;
			}
			show_pool(i);
		}
	}
	else {
		show_pool(mmiOption.inst_id);
	}

	return 0;
}

