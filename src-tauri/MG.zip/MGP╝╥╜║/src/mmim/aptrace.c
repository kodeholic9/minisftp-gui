/**
 * @date    2016/09/07
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void sighandler(int signo)
{
	pProfile->LogTraceUntil = 0;
	exit(0);
}

int main(int argc, char **argv)
{
	char path[128];
	char buff[8192];
	int  fd, n;

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}

	comInstallSignal(SIGINT , sighandler);
	comInstallSignal(SIGTERM, sighandler);

	comGetTmpPath(TRACE_F, path);
	if ((fd = open(path, O_RDONLY)) == -1) {
		fprintf(stderr, "%s() - fail to open(%s) error=%s(%d)\n", __func__, path, strerror(errno), errno);
		return -1;
	}

	pProfile->LogTraceUntil = comTime() + 300;

	while ((n = read(fd, buff, sizeof(buff)-1)) > 0) {
		buff[n] = '\0';
		fprintf(stdout, "%s", buff);
	}
	close(fd);

	pProfile->LogTraceUntil = 0;

	return 0;
}

