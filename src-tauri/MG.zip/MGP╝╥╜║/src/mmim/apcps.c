/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"
#include "libpath.h"

typedef struct _mmioption {
	unsigned long  uid;
	int            all;
} mmioption_t;

mmioption_t mmiOption;
char        TS[20];
time_t      CurrTime;

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *pname)
{
	printf("Usage: %s [ -u UID ] [ -a ]\n", pname);
	printf("Ex   : %s -u 1\n", pname);
	printf("Ex   : %s -u 1 -v\n", pname);
	exit(1);

	return;
}

void show_mpool(mpool_t *p_mpool)
{
	char TS[3][20];
	char src[32], dst[32];

	comTimeT2Str(TS[0], 20, "%H:%M:%S", p_mpool->data.rcvtime);
	if (p_mpool->data.src.type == ET_UE) {
		sprintf(src, "%lu(%s:%lu)",
				comProtoIuid2Long(&p_mpool->data.from_addr.uid),
				appCodeMap2Str(CC_MpEntType, p_mpool->data.src.type),
				p_mpool->data.src.uid);
	}
	else {
		sprintf(src, "%lu(%s:H'%08x)",
				comProtoIuid2Long(&p_mpool->data.from_addr.uid),
				appCodeMap2Str(CC_MpEntType, p_mpool->data.src.type),
				(int)p_mpool->data.src.uid);
	}

	if (p_mpool->data.dst.type == ET_UE) {
		sprintf(dst, "%lu(%s:%lu)",
				comProtoIuid2Long(&p_mpool->data.ttoo_addr.uid),
				appCodeMap2Str(CC_MpEntType, p_mpool->data.dst.type),
				p_mpool->data.dst.uid);
	}
	else {
		sprintf(dst, "%lu(%s:H'%08x)",
				comProtoIuid2Long(&p_mpool->data.ttoo_addr.uid),
				appCodeMap2Str(CC_MpEntType, p_mpool->data.dst.type),
				(int)p_mpool->data.dst.uid);
	}
	printf("      mpool [%05d] %s %-10s %s %s (%s --> %s)\n",
			p_mpool->meta.id,
			TS[0],
			appCodeMap2Str(CC_MpStatus, p_mpool->meta.status),
			appCodeMap2Str(CC_MpMsgType, p_mpool->data.mtype),
			appCodeMap2Str(CC_LmTalkType, p_mpool->data.talktype),
			src, dst);

	return;
}

int _proc_mpool(phashmagic_t *p_magic, pqueue_t *p_squeue, mpool_t *p_mpool, void *p_args)
{
	show_mpool(p_mpool);

	return RET_NOTFOUND;
}

void show_rpool(rpool_t *p_rpool)
{
	char TS[3][20];

	comTimeT2Str(TS[0], 20, "%H:%M:%S", p_rpool->data.crtetime);
	printf("      rpool [%05d] %s UID(%lu) SID(%lu) RID(%u)\n",
			p_rpool->meta.id,
			TS[0],
			p_rpool->data.uid,
			p_rpool->data.sid,
			p_rpool->data.rid);

	return;
}

int _proc_rpool(phashmagic_t *p_magic, pqueue_t *p_squeue, rpool_t *p_rpool, void *p_args)
{
	show_rpool(p_rpool);

	return RET_NOTFOUND;
}

void show_spool(spool_t *p_spool)
{
	char TS[3][20];

	comTimeT2Str(TS[0], 20, "%H:%M:%S", p_spool->data.ueleg.crttime);
	printf("      spool [%05d] %s UID(%lu) CPS(H'%08x) %lu %s(%d) UE(%s) PE(%s)\n",
			p_spool->meta.id,
			TS[0],
			comProtoIuid2Long(&p_spool->data.ueleg.peaddr.uid),
			p_spool->data.ueleg.pecpsid,
			p_spool->data.ueleg.sid,
			appCodeMap2Str(CC_CmEvtCode, p_spool->data.ueleg.pestatus),
			p_spool->data.ueleg.pestatus,
			p_spool->data.ueleg.ueanswered ? "ANSWERED" : "",
			p_spool->data.ueleg.peanswered ? "ANSWERED" : "");

	return;
}

int _proc_spool(phashmagic_t *p_magic, pqueue_t *p_squeue, spool_t *p_spool, void *p_args)
{
	show_spool(p_spool);

	return RET_NOTFOUND;
}

void show_phash(phashmagic_t *p_magic, phash_t *p_phash, int inst_id)
{
	char TS[3][20];
	char *p, host[32];
	int   n = 0;

	if ((p = inet_ntoa(p_phash->data.udpaddr.sin_addr)) != NULL) {
		n = sprintf(host, "%s", p);
	}
	n += sprintf(host + n, ":%d", p_phash->data.udpaddr.sin_port);

	comTimeT2Str(TS[0], 20, "%H:%M:%S", p_phash->data.crtetime);
	comTimeT2Str(TS[1], 20, "%H:%M:%S", p_phash->data.pingtime);
	printf(" [%2d] phash [%05d] %s UID(%lu) MDN(%s) HOST(%s) %s(%ld) %s%s%s Q(%d,%d,%d,%d) V(%02x)\n",
			inst_id,
			p_phash->meta.id,
			TS[0],
			p_phash->data.uid,
			p_phash->data.mdn,
			host,
			p_phash->data.idleflag ? "IDLE" : "BUSY",
			CurrTime - p_phash->data.pingtime,
			p_phash->data.cryptflag ? "<<" : "<",
			appCodeMap2Str(CC_CmAccType, p_phash->data.acctype),
			p_phash->data.cryptflag ? ">>" : ">",
			p_phash->data.sessQ.qnum,
			p_phash->data.resoQ.qnum,
			p_phash->data.pendQ.qnum,
			p_phash->data.sendQ.qnum,
			p_phash->data.version);

	_spool_qscan(p_magic, &p_phash->data.sessQ, TRUE, _proc_spool, NULL);
	_rpool_qscan(p_magic, &p_phash->data.resoQ, TRUE, _proc_rpool, NULL);
	_mpool_qscan(p_magic, &p_phash->data.pendQ, TRUE, _proc_mpool, NULL);
	_mpool_qscan(p_magic, &p_phash->data.sendQ, TRUE, _proc_mpool, NULL);

	return;
}

void show_each(int inst_id)
{
	phash_t *p_phash;
	int i;

	for (i = 1; i < MAX_PHASH_DATA_NUM; i++) {
		p_phash = pathP->phashmagic.hashData + i;
		if (p_phash->meta.status != PST_FREED) {
			if (mmiOption.uid == 0 || mmiOption.uid == p_phash->data.uid) {
				show_phash(&pathP->phashmagic, p_phash, inst_id);
			}
		}
	}

	return;
}

void show_list(int inst_id)
{
	int i;
	int slotfree, slotused, maxdepth , avgdepth;
	int phashfree, phashused, phashalloc, phashqfree, phashqused;
	int mpoolfree, mpoolused, mpoolalloc, mpoolqfree, mpoolqused;
	int spoolfree, spoolused, spoolalloc, spoolqfree, spoolqused;
	int rpoolfree, rpoolused, rpoolalloc, rpoolqfree, rpoolqused;
	phash_t  *p_phash;
	mpool_t  *p_mpool;
	spool_t  *p_spool;
	rpool_t  *p_rpool;
	pqueue_t *p_pqueue;

	/* FOR HASH DATA */
	phashfree = 0;
	phashused = 0;
	for (i = 1; i < MAX_PHASH_DATA_NUM; i++) {
		p_phash = pathP->phashmagic.hashData + i;
		if (p_phash->meta.id != i) {
			printf("ERROR] IVALID PHASH ID [ID:%d != INDEX:%d]\n", p_phash->meta.id, i);
		}
		if (p_phash->meta.status != PST_FREED) {
			phashused += 1;
		}
		else {
			phashfree += 1;
		}
	}
	phashalloc = MAX_PHASH_DATA_NUM - 1;
	phashqfree = pathP->phashmagic.hashFreeQ.qnum;
	phashqused = phashalloc - phashqfree;

	/* FOR HASH SLOT */
	slotfree = 0; slotused = 0;
	avgdepth = 0; maxdepth = 0;
	for (i = 0; i < MAX_PHASH_SLOT_NUM; i++) {
		p_pqueue = pathP->phashmagic.hashSlot + i;
		if (p_pqueue->qnum > 0) {
			if (p_pqueue->qnum > maxdepth) {
				maxdepth  = p_pqueue->qnum;
			}
			avgdepth += p_pqueue->qnum;
			slotused += 1;
		}
		else {
			slotfree += 1;
		}
	}

	/* FOR MPOOL DATA */
	mpoolfree = 0; mpoolused = 0; 
	mpoolalloc= 0; mpoolqfree= 0; mpoolqused = 0; 
	for (i = 1; i < MAX_MPOOL_NUM; i++) {
		p_mpool = pathP->phashmagic.mesgData + i;
		if (p_mpool->meta.id != i) {
			printf("ERROR] IVALID MPOOL ID [ID:%d != INDEX:%d]\n", p_mpool->meta.id, i);
		}
		if (p_mpool->meta.status == PST_FREED) {
			mpoolfree += 1;
		}
		else {
			mpoolused += 1;
		}
	}
	mpoolalloc = MAX_MPOOL_NUM - 1;
	mpoolqfree = pathP->phashmagic.mesgFreeQ.qnum;
	mpoolqused = mpoolalloc - mpoolqfree;

	/* FOR SPOOL DATA */
	spoolfree = 0; spoolused = 0; 
	spoolalloc= 0; spoolqfree= 0; spoolqused = 0; 
	for (i = 1; i < MAX_SPOOL_NUM; i++) {
		p_spool = pathP->phashmagic.sessData + i;
		if (p_spool->meta.id != i) {
			printf("ERROR] IVALID SPOOL ID [ID:%d != INDEX:%d]\n", p_spool->meta.id, i);
		}
		if (p_spool->meta.status == PST_FREED) {
			spoolfree += 1;
		}
		else {
			spoolused += 1;
		}
	}
	spoolalloc = MAX_SPOOL_NUM - 1;
	spoolqfree = pathP->phashmagic.sessFreeQ.qnum;
	spoolqused = spoolalloc - spoolqfree;

	/* FOR RPOOL DATA */
	rpoolfree = 0; rpoolused = 0; 
	rpoolalloc= 0; rpoolqfree= 0; rpoolqused = 0; 
	for (i = 1; i < MAX_RPOOL_NUM; i++) {
		p_rpool = pathP->phashmagic.resoData + i;
		if (p_rpool->meta.id != i) {
			printf("ERROR] IVALID RPOOL ID [ID:%d != INDEX:%d]\n", p_rpool->meta.id, i);
		}
		if (p_rpool->meta.status == PST_FREED) {
			rpoolfree += 1;
		}
		else {
			rpoolused += 1;
		}
	}
	rpoolalloc = MAX_RPOOL_NUM - 1;
	rpoolqfree = pathP->phashmagic.resoFreeQ.qnum;
	rpoolqused = rpoolalloc - rpoolqfree;

	printf(" [%2d] PHASH T(%5d,%5d) F(%5d,%5d) U(%5d,%5d) SLOT(%d) DEPTH(%d:%d)\n" \
			"      MPOOL T(%5d,%5d) F(%5d,%5d) U(%5d,%5d)\n" \
			"      SPOOL T(%5d,%5d) F(%5d,%5d) U(%5d,%5d)\n" \
			"      RPOOL T(%5d,%5d) F(%5d,%5d) U(%5d,%5d)\n",
			inst_id,
			phashalloc, phashqused + phashqfree,
			phashqfree, phashfree,
			phashqused, phashused,
			slotused,  maxdepth,
			(slotused != 0) ? (int)(avgdepth / (double)slotused) : 0,
			mpoolalloc, mpoolqused + mpoolqfree,
			mpoolqfree, mpoolfree,
			mpoolqused, mpoolused,
			spoolalloc, spoolqused + spoolqfree,
			spoolqfree, spoolfree,
			spoolqused, spoolused,
			rpoolalloc, rpoolqused + rpoolqfree,
			rpoolqfree, rpoolfree,
			rpoolqused, rpoolused
	);


	return;
}

void show_debug(int inst_id)
{
	int i, current, mpoolfree = 0;
	int qname = pathP->phashmagic.mesgFreeQ.qname;
	mpool_t  *p_mpool;

	char buffer[MAX_MPOOL_NUM];
	memset(buffer, 0x00, sizeof(buffer));

	current = pathP->phashmagic.mesgFreeQ.H;
	for (i = 0; current > 0 && i < MAX_MPOOL_NUM; i++) {
		if ((p_mpool = MPOOL_PTR(&pathP->phashmagic, current, __func__, __LINE__)) == NULL) {
			break;
		}
#if 0
		if (current == 5966 || current == 6022) {
			printf("ILLEGAL - %d [prev=%d, next=%d]\n",
					current,
					p_mpool->meta.qlink[qname].L,
					p_mpool->meta.qlink[qname].R);
		}
#endif
		buffer[current] += 1;
		mpoolfree += 1;
		current    = p_mpool->meta.qlink[qname].R;
	}
	for (i = 1; i < MAX_MPOOL_NUM; i++) {
		if (!buffer[i]) {
			p_mpool = MPOOL_PTR(&pathP->phashmagic, i, __func__, __LINE__);
			printf("# FREE NOT EXIST - %d [prev=%d, next=%d]\n",
					i,
					p_mpool->meta.qlink[qname].L,
					p_mpool->meta.qlink[qname].R);
		}
		else if (buffer[i] > 1) {
			printf("# FREE DUPLICATED - %d [%d]\n", i, buffer[i]);
		}
	}

	printf("  ** mpoolfree: %d\n", mpoolfree);

	return;
}

int main(int argc, char **argv)
{
	int cc, i;

	comLogLevelSet(WA);
	memset(&mmiOption, 0x00, sizeof(mmioption_t));

	CurrTime = comTime();

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}
	while ((cc = getopt(argc, argv, "u:a")) != EOF) {
		switch (cc) {
			case 'u':
				/* UE */
				mmiOption.uid = atol(optarg);
				break;

			case 'a':
				mmiOption.all = TRUE;
				break;

			default :
				usage(argv[0]);
				break;
		}
	}

	/* for each */
	if (mmiOption.uid == 0) {
		if (mmiOption.all) {
			printf(" =======================================================================\n");
			printf(" PHASH DETAIL\n");
			printf(" =======================================================================\n");
			for (i = 0; i < MAX_CPS_INST_NUM; i++) {
				if (appP->debugholder.debug[PATH][i][0].pos[0] == 0) {
					continue;
				}
				if (pathInitialize(PATH_SHM_KEY + i) >= 0) {
					show_each(i);
					shmdt(pathP);
				}
			}
		}

		/* for list */
		printf(" =======================================================================\n");
		printf(" PHASH SUMMARY\n");
		printf(" =======================================================================\n");
		for (i = 0; i < MAX_CPS_INST_NUM; i++) {
			if (appP->debugholder.debug[PATH][i][0].pos[0] == 0) {
				continue;
			}
			if (pathInitialize(PATH_SHM_KEY + i) >= 0) { 
				show_list(i);
				show_debug(i); /* for TEST */
				shmdt(pathP);
				printf(" -----------------------------------------------------------------------\n");
			}
		}
	}
	else {
		printf(" =======================================================================\n");
		printf(" PHASH FOR UID(%lu)\n", mmiOption.uid);
		printf(" =======================================================================\n");
		for (i = 0; i < MAX_CPS_INST_NUM; i++) {
			if (appP->debugholder.debug[PATH][i][0].pos[0] == 0) {
				continue;
			}
			if (pathInitialize(PATH_SHM_KEY + i) >= 0) { 
				phash_t *p_phash = pathApiGetPath(&pathP->phashmagic, mmiOption.uid, NULL);
				if (p_phash != NULL) {
					show_phash(&pathP->phashmagic, p_phash, i);
				}
				shmdt(pathP);
			}
		}
	}
	printf("\n");

	return 0;
}

