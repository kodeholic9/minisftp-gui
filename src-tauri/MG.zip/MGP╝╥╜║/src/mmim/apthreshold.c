/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *cmd)
{
	printf("Usage: %s [ -l ]\n", cmd);
	printf("Ex   : %s      # Show Threshold\n", cmd);
	printf("Ex   : %s -l   # Load Threshold\n", cmd);
	exit(1);

	return;
}
int main(int argc, char **argv)
{
	int  cc;

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}

	while ((cc = getopt(argc, argv, "hl")) != EOF) {
		switch (cc) {
			case 'l' :
				if (appThresholdLoad(&appP->thresholdblock) == -1) {
					printf("FAILED.\n");
				}
				else {
					printf("OK.\n");
				}
				exit(0);
				break;

			case 'h' :
			default  :
				usage(argv[1]);
				break;
		}
	}
	appThresholdPrint(&appP->thresholdblock);

	return 0;
}
