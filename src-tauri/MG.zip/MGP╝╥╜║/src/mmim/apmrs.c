/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"
#include "libmrs.h"

typedef struct _mmioption {
	unsigned long  uid;
	int            all;
} mmioption_t;

mmioption_t mmiOption;
char        TS[20];
time_t      CurrTime;

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *pname)
{
	printf("Usage: %s [ -u UID ] [ -a ]\n", pname);
	printf("Ex   : %s -u 1\n", pname);
	printf("Ex   : %s -u 1 -v\n", pname);
	exit(1);

	return;
}

void show_rhash(rhashmagic_t *p_magic, rhash_t *p_rhash, int inst_id)
{
	char TS[3][20];
	char host[256], *p;
	int  i, n = 0;

	comTimeT2Str(TS[0], 20, "%H:%M:%S", p_rhash->data.crtetime);
	comTimeT2Str(TS[1], 20, "%H:%M:%S", p_rhash->data.recvtime);
	printf(" [%2d] rhash [%05d] %s UID(%lu) SID(%lu) RID(%d) CPS(H'%08x) IDLE(%ld) NPORTS(%d)\n",
			inst_id,
			p_rhash->meta.id,
			TS[0],
			p_rhash->data.uid,
			p_rhash->data.sid,
			p_rhash->data.rid,
			p_rhash->data.cpsid,
			CurrTime - p_rhash->data.recvtime,
			p_rhash->data.nports);

	for (i = 0; i < p_rhash->data.nports; i++) {
		n = 0;
		comTimeT2Str(TS[2], 20, "%H:%M:%S", p_rhash->data.mrsports[i].actime);
		if ((p = inet_ntoa(p_rhash->data.mrsports[i].addr.sin_addr)) != NULL) {
			n = sprintf(host, "%s", p);
		}
		n += sprintf(host + n, ":%d", p_rhash->data.mrsports[i].addr.sin_port);
		printf("      ..... ....... %s PORT(%d) REMOTE(%s)\n", TS[2], p_rhash->data.mrsports[i].port, host);
	}

	return;
}

void show_each(int inst_id)
{
	rhash_t *p_rhash;
	int i;

	for (i = 1; i < MAX_RHASH_DATA_NUM; i++) {
		p_rhash = mrsP->rhashmagic.hashData + i;
		if (p_rhash->meta.status != PST_FREED) {
			if (mmiOption.uid == 0 || mmiOption.uid == p_rhash->data.uid) {
				show_rhash(&mrsP->rhashmagic, p_rhash, inst_id);
			}
		}
	}

	return;
}

void show_list(int inst_id)
{
	int i;
	int slotfree, slotused, maxdepth , avgdepth;
	int rhashfree, rhashused, rhashalloc, rhashqfree, rhashqused;
	rhash_t  *p_rhash;
	pqueue_t *p_pqueue;

	/* FOR HASH DATA */
	rhashfree = 0;
	rhashused = 0;
	for (i = 1; i < MAX_RHASH_DATA_NUM; i++) {
		p_rhash = mrsP->rhashmagic.hashData + i;
		if (p_rhash->meta.id != i) {
			printf("ERROR] IVALID RHASH ID [ID:%d != INDEX:%d]\n", p_rhash->meta.id, i);
		}
		if (p_rhash->meta.status != PST_FREED) {
			rhashused += 1;
		}
		else {
			rhashfree += 1;
		}
	}
	rhashalloc = MAX_RHASH_DATA_NUM - 1;
	rhashqfree = mrsP->rhashmagic.hashFreeQ.qnum;
	rhashqused = rhashalloc - rhashqfree;

	/* FOR HASH SLOT */
	slotfree = 0; slotused = 0;
	avgdepth = 0; maxdepth = 0;
	for (i = 0; i < MAX_RHASH_SLOT_NUM; i++) {
		p_pqueue = mrsP->rhashmagic.hashSlot + i;
		if (p_pqueue->qnum > 0) {
			if (p_pqueue->qnum > maxdepth) {
				maxdepth  = p_pqueue->qnum;
			}
			avgdepth += p_pqueue->qnum;
			slotused += 1;
		}
		else {
			slotfree += 1;
		}
	}

	printf(" [%2d] RHASH T(%5d,%5d) F(%5d,%5d) U(%5d,%5d) SLOT(%d) DEPTH(%d:%d)\n",
			inst_id,
			rhashalloc, rhashqused + rhashqfree,
			rhashqfree, rhashfree,
			rhashqused, rhashused,
			slotused,  maxdepth,
			(slotused != 0) ? (int)(avgdepth / (double)slotused) : 0
	);


	return;
}

int main(int argc, char **argv)
{
	int cc, i;

	comLogLevelSet(WA);
	memset(&mmiOption, 0x00, sizeof(mmioption_t));

	CurrTime = comTime();

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}
	while ((cc = getopt(argc, argv, "u:a")) != EOF) {
		switch (cc) {
			case 'u':
				/* UE */
				mmiOption.uid = atol(optarg);
				break;

			case 'a':
				mmiOption.all = TRUE;
				break;

			default :
				usage(argv[0]);
				break;
		}
	}

	/* for each */
	if (mmiOption.uid == 0) {
		if (mmiOption.all) {
			printf(" =======================================================================\n");
			printf(" RHASH DETAIL\n");
			printf(" =======================================================================\n");
			for (i = 0; i < MAX_MRS_INST_NUM; i++) {
				if (appP->debugholder.debug[MRSP][i][0].pos[0] == 0) {
					continue;
				}
				if (mrsInitialize(MRS_SHM_KEY + i) >= 0) {
					show_each(i);
					shmdt(mrsP);
				}
			}
		}

		/* for list */
		printf(" =======================================================================\n");
		printf(" RHASH SUMMARY\n");
		printf(" =======================================================================\n");
		for (i = 0; i < MAX_MRS_INST_NUM; i++) {
			if (appP->debugholder.debug[MRSP][i][0].pos[0] == 0) {
				continue;
			}
			if (mrsInitialize(MRS_SHM_KEY + i) >= 0) { 
				show_list(i);
				shmdt(mrsP);
				printf(" -----------------------------------------------------------------------\n");
			}
		}
	}
	else {
		printf(" =======================================================================\n");
		printf(" RHASH FOR UID(%lu)\n", mmiOption.uid);
		printf(" =======================================================================\n");
		for (i = 0; i < MAX_MRS_INST_NUM; i++) {
			if (appP->debugholder.debug[MRSP][i][0].pos[0] == 0) {
				continue;
			}
			if (mrsInitialize(MRS_SHM_KEY + i) >= 0) { 
				show_each(i);
				shmdt(mrsP);
			}
		}
	}
	printf("\n");

	return 0;
}

