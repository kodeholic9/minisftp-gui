/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"
#include "libcps.h"

typedef struct _mmioption {
	int  inst_id; /* 0: ALL */
	char ue[MAX_ADDRESS_LEN+1];
	int  detailed;
	int  period;
	int  all;
} mmioption_t;

mmioption_t mmiOption;
char        TS[20];

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *pname)
{
	printf("Usage: %s [ -i INST_ID ] [ -u UE_ADDR ] [ -d ] [ -s ]\n", pname);
	printf("Ex   : %s -i 1 -d\n", pname);
	printf("Ex   : %s -s\n"   , pname);
	exit(1);

	return;
}

int _cmcb_showcmpool(cphashmagic_t *p_magic, cmqueue_t *p_cmqueue, cmpool_t *p_cmpool, void *p_args)
{
	printf("   POOL[%6d] %10s [%s:%s] MK(%u:%u) T(%d) S(%d:%d:%d)\n",
			p_cmpool->poolmeta.id,
			appCodeMap2Str(CC_CmCmdId, p_cmpool->pooldata.command_id),
			p_cmpool->pooldata.from,
			p_cmpool->pooldata.ttoo,
			p_cmpool->pooldata.recvtid,
			p_cmpool->pooldata.sequence,
			p_cmpool->pooldata.tries,
			p_cmpool->pooldata.rescode,
			p_cmpool->pooldata.rptcode,
			p_cmpool->pooldata.fincode
	);
	return RET_CONTINUE;
}

void show_hashdata(cphashdata_t *p_hashdata, int index, int inst_id)
{
	cphashdata_t *p_peerdata = cpsPathApiGetPath(&cpsP->hashmagic,
			p_hashdata->pathkey.peer, p_hashdata->pathkey.ue, p_hashdata->pathkey.session_id, TRUE, NULL);

	printf("===============================================\n");
	printf(" [%02d] PATH HASH DATA ID [%6d]\n", inst_id, p_hashdata->id);
	printf("-----------------------------------------------\n");
	printf(" STATUS          = %s\n", appCodeMap2Str(CC_MpStatus, p_hashdata->status));
	printf(" PATHKEY    CALL = %s -> %s\n",
			p_hashdata->pathkey.is_calling ? p_hashdata->pathkey.ue   : p_hashdata->pathkey.peer,
			p_hashdata->pathkey.is_calling ? p_hashdata->pathkey.peer : p_hashdata->pathkey.ue
	);
	printf("            UE   = %s\n", p_hashdata->pathkey.ue);
	printf("            PEER = %s [%s]\n",
			p_hashdata->pathkey.peer, p_peerdata  ? "KIN" : "OTL"
	);
	printf("            SID  = %lu\n", p_hashdata->pathkey.session_id);
	printf(" PATHADDR        = %s\n", inet_ntoa(p_hashdata->pathaddr.sin_addr));
	printf(" REGISTER   TIME = %s\n", comTimeT2Str(TS, 20, "%m/%d %H:%M:%S", p_hashdata->regitime));
	printf(" PING       TIME = %s\n", comTimeT2Str(TS, 20, "%m/%d %H:%M:%S", p_hashdata->pingtime));
	printf(" FREE       TIME = %s\n", comTimeT2Str(TS, 20, "%m/%d %H:%M:%S", p_hashdata->freetime));
	printf(" RECV       SEQ  = %u\n", p_hashdata->recvseq);
	printf(" SEND       SEQ  = %u\n", p_hashdata->sendseq);
	printf(" PENDQ      NAME = %d\n", p_hashdata->poolPendQ.qname);
	printf("            NUM  = %d\n", p_hashdata->poolPendQ.qnum);
	printf("            H:T  = %d:%d\n", p_hashdata->poolPendQ.H, p_hashdata->poolPendQ.T);
	if (p_hashdata->poolPendQ.qnum) {
		_cmpool_qscan(&cpsP->hashmagic, &p_hashdata->poolPendQ, TRUE, _cmcb_showcmpool, NULL);
	}
	printf(" FREELINK L:R    = %d:%d\n",
			p_hashdata->qlink[CPQNAME_FREE].L, p_hashdata->qlink[CPQNAME_FREE].R);
	printf(" PATHLINK L:R    = %d:%d\n",
			p_hashdata->qlink[CPQNAME_PATH].L, p_hashdata->qlink[CPQNAME_PATH].R);
	printf("\n");


	return;
}

void show_hash(int inst_id)
{
	int i, len;
	int hashfree, hashused, hashalloc, hashqfree, hashqused;
	int slotfree, slotused, maxdepth , avgdepth;
	int poolfree, poolused, pooltimer, poolalloc, poolqfree, poolqused, poolqtimer;
	cphashdata_t *p_hashdata;
	cpqueue_t    *p_slotqueue;
	cmpool_t     *p_cmpool;

	if (cpsInitialize(CPS_SHM_KEY + inst_id) < 0) {
		return;
	}

	/* FOR HASH DATA */
	hashfree = 0;
	hashused = 0;
	for (i = 1; i < MAX_CPHASH_DATA_NUM; i++) {
		p_hashdata = cpsP->hashmagic.hashData + i;
		if (p_hashdata->id != i) {
			printf("# Mismatched Hashdata [ID:%d != INDEX:%d]", p_hashdata->id, i);
		}
		if ((len = strlen(mmiOption.ue)) > 0) {
			if (strstr(p_hashdata->pathkey.ue, mmiOption.ue) != NULL
					|| strstr(p_hashdata->pathkey.peer, mmiOption.ue) != NULL)
			{
				show_hashdata(p_hashdata, i, inst_id);
			}
		}
		else if (p_hashdata->status != CPST_FREED) {
			hashused += 1;
			if (mmiOption.detailed) {
				show_hashdata(p_hashdata, i, inst_id);
			}
			else {
				printf(" [%02d] HASHDATA [%06d] LCS(%u) SID(%lu) UE(%s) CALLING(%s) CALLED(%s) ST(%s)\n",
						inst_id,
						p_hashdata->id,
						p_hashdata->pathkey.is_lcs,
						p_hashdata->pathkey.session_id,
						p_hashdata->pathkey.ue,
						p_hashdata->pathkey.is_calling ? p_hashdata->pathkey.ue   : p_hashdata->pathkey.peer,
						p_hashdata->pathkey.is_calling ? p_hashdata->pathkey.peer : p_hashdata->pathkey.ue,
						appCodeMap2Str(CC_MpStatus, p_hashdata->status)
				);
			}
		}
		else {
			hashfree += 1;
		}
	}
	hashalloc = MAX_CPHASH_DATA_NUM - 1;
	hashqfree = cpsP->hashmagic.hashFreeQ.qnum;
	hashqused = hashalloc - hashqfree;

	/* FOR HASH SLOT */
	slotfree = 0; slotused = 0;
	avgdepth = 0; maxdepth = 0;
	for (i = 0; i < MAX_CPHASH_SLOT_NUM; i++) {
		p_slotqueue = cpsP->hashmagic.hashSlot + i;
		if (p_slotqueue->qnum > 0) {
			if (p_slotqueue->qnum > maxdepth) {
				maxdepth  = p_slotqueue->qnum;
				avgdepth += p_slotqueue->qnum;
			}
			slotused += 1;
		}
		else {
			slotfree += 1;
		}
	}

	/* FOR POOL DATA */
	poolfree = 0; poolused = 0; pooltimer = 0;
	poolalloc= 0; poolqfree= 0; poolqused = 0; poolqtimer = 0;
	for (i = 1; i < MAX_CMPOOL_NUM; i++) {
		p_cmpool = cpsP->hashmagic.poolData + i;
		if (p_cmpool->poolmeta.status == CPST_FREED) {
			poolfree += 1;
		}
		else {
			poolused += 1;
			if (p_cmpool->poolmeta.timered) {
				pooltimer += 1;
			}
		}
	}
	poolalloc = MAX_CMPOOL_NUM - 1;
	poolqfree = cpsP->hashmagic.poolFreeQ.qnum;
	poolqtimer= cpsP->hashmagic.poolTimrQ.qnum;
	poolqused = poolalloc - poolqfree;

	printf("===============================================\n");
	printf("-----------------------------------------------\n");
	printf(" PATH HASH SUMMARY [ApInstId: %d]\n", inst_id);
	printf("-----------------------------------------------\n");
	printf(" HASHDATA     TOTAL = %d\n", hashalloc);
	printf("            FREE[A] = %d (%5.3f%%)\n", hashqfree, (hashqfree / (double)hashalloc) * 100.0);
	printf("            FREE[B] = %d\n", hashfree);
	printf("            USED[A] = %d (%5.3f%%)\n", hashqused, (hashqused / (double)hashalloc) * 100.0);
	printf("            USED[B] = %d\n", hashused);
	printf("    USED[B]+FREE[B] = %d\n", hashused + hashfree);
	printf("                H:T = %d:%d\n", cpsP->hashmagic.hashFreeQ.H, cpsP->hashmagic.hashFreeQ.T);
	printf("-----------------------------------------------\n");
	printf(" HASHSLOT     TOTAL = %d\n", MAX_CPHASH_SLOT_NUM);
	printf("               FREE = %d (%5.3f%%)\n", slotfree, (slotfree / (double)MAX_CPHASH_SLOT_NUM) * 100.0);
	printf("               USED = %d\n", slotused);
	printf("              DEPTH = %d (%d)\n", avgdepth, maxdepth);
	printf("-----------------------------------------------\n");
	printf(" POOLDATA     TOTAL = %d\n", poolalloc);
	printf("            FREE[A] = %d (%5.3f%%)\n", poolqfree, (poolqfree / (double)poolalloc) * 100.0);
	printf("            FREE[B] = %d\n", poolfree);
	printf("            USED[A] = %d (%5.3f%%)\n", poolqused, (poolqused / (double)poolalloc) * 100.0);
	printf("            USED[B] = %d\n", poolused);
	printf("           TIMER[A] = %d\n", poolqtimer);
	printf("           TIMER[B] = %d\n", pooltimer);
	printf("    USED[B]+FREE[B] = %d\n", poolused + poolfree);
	printf("          FREE[H:T] = %d:%d\n", cpsP->hashmagic.poolFreeQ.H, cpsP->hashmagic.poolFreeQ.T);
	printf("         TIMER[H:T] = %d:%d\n", cpsP->hashmagic.poolTimrQ.H, cpsP->hashmagic.poolTimrQ.T);
	printf("-----------------------------------------------\n");

	/* detach.. */
	shmdt(cpsP);

	return;
}

int main(int argc, char **argv)
{
	int cc, i;

	comLogLevelSet(WA);
	memset(&mmiOption, 0x00, sizeof(mmioption_t));

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}
	while ((cc = getopt(argc, argv, "i:u:s:d")) != EOF) {
		switch (cc) {
			case 'i':
				if (optarg == NULL) { usage(argv[0]); }

				/* INST_ID */
				mmiOption.inst_id = atoi(optarg);
				if (mmiOption.inst_id <= 0
						|| mmiOption.inst_id >= MAX_CPS_INST_NUM)
				{
					usage(argv[0]);
				}
				break;

			case 'u':
				if (optarg == NULL) { usage(argv[0]); }

				/* UE */
				snprintf(mmiOption.ue, MAX_ADDRESS_LEN+1, "%s", optarg);
				break;

			case 's':
				if (optarg == NULL) { usage(argv[0]); }
				mmiOption.period = atoi(optarg);

				break;

			case 'd':
				mmiOption.detailed = TRUE;
				break;

			default :
				usage(argv[0]);
				break;
		}
	}

	if (mmiOption.inst_id == 0) {
		while (TRUE) {
			for (i = 1; i < MAX_CPS_INST_NUM; i++) {
				if (appP->debugholder.debug[PHUB][i][0].pos[0] == 0) {
					continue;
				}
				show_hash(i);
			}
			if (mmiOption.period) { sleep(mmiOption.period); }
			else                  { break; }
		}
	}
	else {
		show_hash(mmiOption.inst_id);
	}

	return 0;
}

