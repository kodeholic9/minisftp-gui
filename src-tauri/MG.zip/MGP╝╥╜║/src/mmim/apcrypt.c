/**
 * @date    2012/12/04
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libsec.h"

char          key[64];
unsigned char sum[16];
unsigned char encflag = TRUE;

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *cmd)
{
	printf("Usage: %s [-e|-d] KEY\n", cmd);
	printf("Ex   : %s -e TISQUARE\n", cmd);
	printf("Ex   : %s -d TISQUARE\n", cmd);
	exit(1);

	return;
}

void proc_crypt()
{
	char line[8192];
	char bstr[1024];
	int  n, padding;

	secUtilMd5(key, sum);
	secUtilDumpRaw("KEY", (char *)sum, 16);

	printf("# "); fflush(stdout);
	while (fgets(line, sizeof(line), stdin) != NULL) {
		memset(bstr, 0x00, sizeof(bstr));
		n = comHexLine2Bin(line, bstr, sizeof(bstr));
		if ((padding = n % 16) != 0) {
			padding = 16 - padding;
		}
		secUtilDumpRaw("INPUT", bstr, n);
		printf("padding [%d]\n", padding);

		if (encflag) {
			secUtilAesCbc128Enc((unsigned char *)sum, defaultIV, (unsigned char *)bstr, (unsigned char *)line, n + padding);
			secUtilDumpRaw("ENCRYPT", line, n+padding);
		}
		else {
			secUtilAesCbc128Dec((unsigned char *)sum, defaultIV, (unsigned char *)bstr, (unsigned char *)line, n + padding);
			secUtilDumpRaw("DECRYPT", line, n+padding);
		}

		/* prompt */
		printf("# "); fflush(stdout);
	}

	return;
}

int main(int argc, char **argv)
{
	int  cc;

	memset(key, 0x00, sizeof(key));
	memset(sum, 0x00, sizeof(sum));

	while ((cc = getopt(argc, argv, "e:d:")) != EOF) {
		switch (cc) {
			case 'e' :
				encflag = TRUE;
				sprintf(key, "%s", optarg);
				break;

			case 'd' :
				encflag = FALSE;
				sprintf(key, "%s", optarg);
				break;

			case 'h' :
			default  :
				usage(argv[0]);
				break;
		}
	}
	if (strlen(key) == 0) { usage(argv[0]); }

	proc_crypt();

	return 0;
}



