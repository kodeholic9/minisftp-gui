/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
int main(int argc, char **argv)
{
	/* create the shared memory */
	if (appCreate(APP_SHM_KEY) < 0) {
		printf("CREATE %-10s [%-15s] FAILED.\n", "APP", ".....");
		return -1;
	}
	printf("CREATE %-10s [%-15s] OK.\n", "APP", ".....");

	/* create fifo */
	if (comLogTraceCreate() == -1) {
		printf("CREATE %-10s [%-15s] FAILED.\n", "FIFO", TRACE_F);
		return -1;
	}
	printf("CREATE %-10s [%-15s] OK.\n", "FIFO", TRACE_F);

	/* load profile */
	if (appProfileLoad() == -1) {
		printf("CREATE %-10s [%-15s] FAILED.\n", "CONF", ".....");
		return -1;
	}
	printf("CREATE %-10s [%-15s] OK.\n", "CONF", ".....");

	/* load slave */
	if (appSlaveConfigLoad(&appP->slaveholder) == -1) {
		printf("CREATE %-10s [%-15s] FAILED.\n", "PROC", SLAVE_F);
		return -1;
	}
	printf("CREATE %-10s [%-15s] OK.\n", "PROC", SLAVE_F);

	return 0;
}



