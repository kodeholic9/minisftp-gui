/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"
#include "liboma.h"

#define MAX_PERIOD 3600

typedef struct _omserver {
	tcpsock_t tcpsock;
	int       maxfd;
	fd_set    rmask;
	fd_set    wmask;
} omserver_t;

int        notiId = 0;
omserver_t oms;

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *cmd)
{
	printf("Usage: %s -n NOTI_ID\n", cmd);
	printf("Ex   : %s -n 1\n", cmd);
	exit(1);

	return;
}

int wait_for(fd_set *rset, fd_set *wset, int usec)
{
	struct timeval timeo;

	/* CHECK INPUT EVENT */
	timeo.tv_sec  = 0;
	timeo.tv_usec = usec;
	memcpy(rset, &oms.rmask, sizeof(fd_set));
	memset(wset, 0x00      , sizeof(fd_set));

	if (oms.tcpsock.pstatus == TST_CONNECTING) {
		memcpy(wset, &oms.wmask, sizeof(fd_set));
		return select(oms.maxfd, rset, wset, NULL, &timeo);
	}

	return select(oms.maxfd, rset, NULL, NULL, &timeo);
}

int proc_bindres(tcpsock_t *p_tcpsock, ommsg_t *p_ommsg)
{
	/* CHECK RESULT */
	if (p_onmmsg->bind_res.d.result != OMR_EOK) {
		comLog(WA, "%s() BIND FAILED (%d)", __func__, p_onmmsg->bind_res.d.result);
		appTcpSockClose(p_tcpsock);
		return -1;
	}

	/* UPDATE STATUS */
	appTcpSockUpdate(p_tcpsock, TST_KIN);

	/* SEND TRACE */
	if (onmOnmMesgSendNoti(p_tcpsock, notiId, "", 0) == -1) {
		comLog(WA, "%s() Failed to Notification.", __func__);
	}
	else {
		/* ON SUCCESS */
		comLog(WA, "%s() Success to Notification.", __func__);
	}
	appTcpSockClose(p_tcpsock);
	exit(0);

	return 0;
}

int proc_with(fd_set *rset, fd_set *wset)
{
	tcpsock_t *p_tcpsock = &oms.tcpsock;
	tcpbuffer_t   *p_tcpbuff = &p_tcpsock->recvbuff;
	onmmsg_t      *p_onmmsg  = (onmmsg_t *)p_tcpbuff->data;
	int n;

	if (p_tcpsock->pstatus == TST_CLOSED) {
		comLog(ER, "%s() Can't happen!", __func__);
		return -1;
	}
	if (p_tcpsock->pstatus == TST_CONNECTING) {
		appTcpSockUpdate(p_tcpsock, TST_CONNECTED);
		return 0;
	}

	/* RECV */
	if ((n = onmOnmMesgRecv(p_tcpsock)) == -1) {
		comErr(ER, errno, "%s() BROKEN OMS PATH", __func__);
		return -1;
	}
	else if (n == 0) return 0; /* HAS MORE! */

	/* PROC */
	switch (p_onmmsg->h.msg_type) {
		case OMT_BIND_RES  : return proc_bindres(p_tcpsock, p_onmmsg); break;
		case OMT_LINK_RES  : break;
		default            :
							 comLog(WA, "NO PROC FUNCTION FOR MTYPE(0x%04x)", p_onmmsg->h.msg_type);
							 break;
	}

	return 0;
}

int proc_timer()
{
	tcpsock_t *p_tcpsock = &oms.tcpsock;
	time_t     currtime  = comTime();

	switch (p_tcpsock->pstatus) {
		case TST_CLOSED :
			if ((currtime - p_tcpsock->chgtime) > pSysConf->OnmLinkRetransSec) {
				appTcpSockConnect(p_tcpsock, pSysConf->OnmServerHost, pSysConf->OnmServerPort);
			}
			break;

		case TST_CONNECTING :
			if ((currtime - p_tcpsock->chgtime) > pSysConf->OnmLinkRetransSec) {
				appTcpSockClose(p_tcpsock);
				return -1;
			}
			break;

		case TST_CONNECTED :
			if (onmOnmMesgSendBindReq(p_tcpsock, OT_OMC, 0) != -1) {
				appTcpSockUpdate(p_tcpsock, TST_BINDING);
			}
			break;

		case TST_BINDING :
			if ((currtime - p_tcpsock->chgtime) > pSysConf->OnmLinkRetransSec) {
				appTcpSockClose(p_tcpsock);
				return -1;
			}
			break;

		case TST_KIN :
			if ((currtime - p_tcpsock->sndtime) > pSysConf->OnmLinkRetransSec) {
				onmOnmMesgSendLinkReq(p_tcpsock);
			}
			if ((currtime - p_tcpsock->rcvtime) > pSysConf->OnmLinkLostSec) {
				comLog(ER, "%s() IDLE OMS PATH", __func__);
				appTcpSockClose(p_tcpsock);
				return -1;
			}
			break;
	}

	return 0;
}

void oms_process()
{
	fd_set rset, wset;
	int    cc;

	/* init */
	memset(&oms, 0x00, sizeof(omserver_t));
	appTcpSockInit(&oms.tcpsock, "OMS", &oms.maxfd, &oms.rmask, &oms.wmask, NULL, NULL);
	appTcpSockConnect(&oms.tcpsock, pSysConf->OnmServerHost, pSysConf->OnmServerPort);

	while (TRUE) {
		/* PROC WITH SOCK */
		cc = wait_for(&rset, &wset, 5*1000);
		switch (cc) {
			case 0 : break;
			case -1:
					 if (errno != EINTR) {
						 comErr(ER, errno, "fail to select.");
						 goto out;
					 }
					 break;

			default :
					/* PROC */
					 if (proc_with(&rset, &wset) == -1) {
						 goto out;
					 }
					 break;
		}

		/* TIMER */
		if (proc_timer() == -1) {
			goto out;
		}
	}

out:

	printf("bye~\n");
	exit(0);

	return;
}

int main(int argc, char **argv)
{
	int cc;

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}
	while ((cc = getopt(argc, argv, "n:")) != EOF) {
		switch (cc) {
			case 'n' :
				notiId = atoi(optarg);
				break;

			case 'h' :
			default  :
				usage(argv[0]);
				break;
		}
	}
	if (notiId == 0) { usage(argv[0]); }
	comLogLevelSet(TR);
	oms_process();

	return 0;
}
