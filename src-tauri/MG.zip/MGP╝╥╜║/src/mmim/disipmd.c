/**
 * @date    2013/05/29
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"

typedef struct _ipmdinfo{
	char switchType[2];        // 3 --> 2 (20130514)
	char switchVersion[4];     // 4
	char switchNo[2];          // 2
	char dataFileName[40];     // 40
	char dataFileSeq[10];      // 10
	char recordCount[8];       // 8
	char recordSize[6];        // 6
	char firstEndDateTime[10]; // 10 - MMDDHHMISS
	char lastEndDateTime[10];  // 10 - MMDDHHMISS
	char recordCreateTime[14]; // 14 - YYYYMMDDHHMISS
} ipmdinfo_t;

typedef struct _ipmddata {
	char   serviceType[3];       // 3
	char   callDirection[1];     // 1
	char   suppService[2];       // 2
	char   callingMDN[16];       // 16
	char   calledMDN[24];        // 24
	char   chargingMDN[24];      // 24
	char   dialedNumberAddress[32]; // 32
	char   callForwardMDN[24];   // 24
	char   startTime[15];        // 15 - YYYYMMDDHHMISSs
	char   endTime[15];          // 15 - YYYYMMDDHHMISSs
	char   chargingDuration[10]; // 10 - (1/10 sec unit)
	char   ACRStopLost[1];       // 1  - T(true) | F(false)
	char   callingDomainCode[3]; // 3  - 011 : SKT
	char   calledDomainCode[3];  // 3  - 011 : SKT, 016 : KTF, 019 : LGT, 999 : ETC
	char   accessNetType[1];     // 1  - 1 : WCDMA, 2 : LTE
	char   ratType[1];           // 1  - 1 : WCDMA, 2 : LTE
	char   WCDMACellID[20];      // 20
	char   LTECellID[10];        // 10
} ipmddata_t;

char ipmdPath[256];
char ipmdDataFile[256];

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *cmd)
{
	printf("Usage: %s [PATH] [FILE]\n", cmd);
	printf("Ex   : %s /lmcdata/svcdata/IPMD/DATA LMCR.D20130523.S001.F0000043.B01\n", cmd);
	return;
}

int display_column(int no, char *column, char *line, int len)
{
	char value[64];
	int  i;

#if 0
	char fmt[20];
	sprintf(fmt, "%%-%d.%ds", len, len);
	sprintf(value, fmt, line);
#endif
	for (i = 0; i < len && i < sizeof(value); i++) {
		if (line[i] == 0x00 || line[i] == 0x20) {
			value[i] = '*';
		}
		else {
			value[i] = line[i];
		}
	}
	value[i] = '\0';

	printf(" %2d. %-20s %-2d [%s]\n", no, column, len, value);

	return len;
}

void display_ipmdinfo()
{
	int  fd;
	char path[256];
	char line[1024];
	int  n, i;

	snprintf(path, sizeof(path), "%s/%s.INFO", ipmdPath, ipmdDataFile);
	if ((fd = open(path, O_RDONLY)) == -1) {
		fprintf(stderr, "# fail to open IPMD-INFO [%s]\n", path);
		return;
	}
	i = 1;
	while (read(fd, line, sizeof(ipmdinfo_t)) > 0) {
		printf("=========================================================================\n");
		printf("[%04d] IPMD-INFO[%s.INFO]\n", 0, ipmdDataFile);
		printf("=========================================================================\n");
		n = 0;
		n += display_column(1 , "switchType"      , line + n, 2);  // 3 --> 2 (20130514)
		n += display_column(2 , "switchVersion"   , line + n, 4);  // 4
		n += display_column(3 , "switchNo"        , line + n, 2);  // 2
		n += display_column(4 , "dataFileName"    , line + n, 40); // 40
		n += display_column(5 , "dataFileSeq"     , line + n, 10); // 10
		n += display_column(6 , "recordCount"     , line + n, 8);  // 8
		n += display_column(7 , "recordSize"      , line + n, 6);  // 6
		n += display_column(8 , "firstEndDateTime", line + n, 10); // 10 - MMDDHHMISS
		n += display_column(9 , "lastEndDateTime" , line + n, 10); // 10 - MMDDHHMISS
		n += display_column(10, "recordCreateTime", line + n, 14); // 14 - YYYYMMDDHHMISS
		i++;
	}
	close(fd);

	return;
}

void display_ipmddata()
{
	int  fd;
	char path[256];
	char line[1024];
	int  n, i;

	snprintf(path, sizeof(path), "%s/%s", ipmdPath, ipmdDataFile);
	if ((fd = open(path, O_RDONLY)) == -1) {
		fprintf(stderr, "# fail to open IPMD-DATA [%s]\n", path);
		return;
	}
	i = 1;
	while (read(fd, line, sizeof(ipmddata_t)) > 0) {
		printf("-------------------------------------------------------------------------\n");
		printf("[%04d] IPMD-DATA[%s]\n", i, ipmdDataFile);
		printf("-------------------------------------------------------------------------\n");
		n = 0;
		n += display_column(1 , "serviceType"        , line + n, 3);   // 3
		n += display_column(2 , "callDirection"      , line + n, 1);   // 1
		n += display_column(3 , "suppService"        , line + n, 2);   // 2
		n += display_column(4 , "callingMDN"         , line + n, 16);  // 16
		n += display_column(5 , "calledMDN"          , line + n, 24);  // 24
		n += display_column(6 , "chargingMDN"        , line + n, 24);  // 24
		n += display_column(7 , "dialedNumberAddress", line + n, 32);  // 32
		n += display_column(8 , "callForwardMDN"     , line + n, 24);  // 24
		n += display_column(9 , "startTime"          , line + n, 15);  // 15 - YYYYMMDDHHMISSs
		n += display_column(10, "endTime"            , line + n, 15);  // 15 - YYYYMMDDHHMISSs
		n += display_column(11, "chargingDuration"   , line + n, 10);  // 10 - (1/10 sec unit)
		n += display_column(12, "ACRStopLost"        , line + n, 1);   // 1  - T(true) | F(false)
		n += display_column(13, "callingDomainCode"  , line + n, 3);   // 3  - 011 : SKT
		n += display_column(14, "calledDomainCode"   , line + n, 3);   // 3  - 011 : SKT, 016 : KTF, 019 : LGT, 999 : ETC
		n += display_column(15, "accessNetType"      , line + n, 1);   // 1  - 1 : WCDMA, 2 : LTE
		n += display_column(16, "ratType"            , line + n, 1);   // 1  - 1 : WCDMA, 2 : LTE
		n += display_column(17, "WCDMACellID"        , line + n, 20);  // 20
		n += display_column(18, "LTECellID"          , line + n, 10);  // 10
		i++;
	}

	close(fd);

	return;
}

int main(int argc, char **argv)
{
	if (argc != 3) {
		usage(argv[0]);
		exit(1);
	}
	snprintf(ipmdPath    , sizeof(ipmdPath)    , "%s", argv[1]);
	snprintf(ipmdDataFile, sizeof(ipmdDataFile), "%s", argv[2]);

	display_ipmdinfo();
	display_ipmddata();

	return 0;
}



