#include "libcom.h"
#include "libapp.h"

void display_general();
void display_specific(int ap_id);
void display_title();

void usage(char *cmd)
{
	printf("usage: %s\n", cmd);
	exit(1);
}

int main(int argc, char *argv[])
{
	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}

	display_title();
	display_general();

	return 0;
}

char *ipc_mutex_status(pthread_mutex_t *p_mutex)
{
	if (pthread_mutex_trylock(p_mutex) == 0) {
		pthread_mutex_unlock(p_mutex);
		return "U"; /* Unlocked */
	}

	return "L";     /* Locked */
}

void display_title()
{
	printf("-------------------------------------------------------\n");
	printf("- %-7s  %5s   %5s   %5s   %5s    %5s  %s-\n",
			"AP",
			"send",
			"recv",
			"left",
			"used",
			"usage",
			"lock"
	);
	printf("-------------------------------------------------------\n");
}

void display_ipc(int ap_id, ipc_t *p_ipc)
{
	char apname[16];
	int  used;

	/* apname */
	sprintf(apname, "%s", appName(ap_id));

	/* round */
	if ((used = p_ipc->ipcctl.sendIdx - p_ipc->ipcctl.recvIdx) < 0) {
		used = (p_ipc->ipcctl.maxnum - p_ipc->ipcctl.recvIdx) + p_ipc->ipcctl.sendIdx;
	}
	printf("  %-7s  %5d   %5d   %5d   %5d   %5.2f%% %s\n",
			apname,
			p_ipc->ipcctl.sendIdx,
			p_ipc->ipcctl.recvIdx,
			p_ipc->ipcctl.maxnum - used,
			used,
			(used / (double)p_ipc->ipcctl.maxnum) * 100.0,
			ipc_mutex_status(&p_ipc->ipcctl.lock)
	);

	return;
}

void display_general()
{
	int ap_id;

	for (ap_id = 0; ap_id < NUMOF_AP; ap_id++) {
		display_ipc(ap_id, appP->ipcdefault + ap_id);
	}
	printf("\n");

	return;
}



