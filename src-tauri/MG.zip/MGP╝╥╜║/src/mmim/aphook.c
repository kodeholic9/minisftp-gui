/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *cmd)
{
	printf("Usage: %s -p\n", cmd);
	printf("Ex   : %s -p #pressed\n", cmd);
	exit(1);

	return;
}
int main(int argc, char **argv)
{
	char line[128];
	int  cc, failed = 1;

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}
	memset(line, 0x00, sizeof(line));

	while ((cc = getopt(argc, argv, "prt")) != EOF) {
		switch (cc) {
			case 'p' :
				appIpcSendArgs(MGPP, IMT_CTL_HOOK_PRESSED, 0, 0, 0);
				failed = 0;
				break;

			default  :
				break;
		}
	}

	if (failed) {
		usage(argv[0]);
		printf("NOK\n");
	}
	else {
		printf("OK\n");
	}

	return 0;
}
