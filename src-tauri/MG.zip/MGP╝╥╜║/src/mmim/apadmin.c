/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"

#define _PMON    "PMON"

#define _UNTIL_UNDEF  0
#define _UNTIL_KILLED 1
#define _UNTIL_LOADED 2

#if 0
#define _PS_CMD  "ps -eo pid,ppid,user"
#define MAX_PSINFO_NUM 1024
typedef struct _ext_psinfo {
	unsigned int pid;
	unsigned int ppid;
	char         user[32];
	char         comm[100];
	char         pcpu[32];
	char         pmem[32];
} ext_psinfo_t;

typedef struct _ext_pstable {
	ext_psinfo_t psinfo[MAX_PSINFO_NUM];
	int          n;
} ext_pstable_t;
#endif

static char          User[100];
static ext_pstable_t PsTable;

int load_psinfo(char *pname);

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *cmd)
{
	printf("Usage: %s [ -l ID | -k ID | -9 ID | -C | -x | -X ] \n", cmd);
	printf("Ex   : %s -l PHUB01      # Load  PHUB01\n", cmd);
	printf("Ex   : %s -k PHUB01      # TERM  PHUB01\n", cmd);
	printf("Ex   : %s -9 PHUB01      # Kill  PHUB01\n", cmd);
	printf("Ex   : %s -x             # Stop  Slaves\n", cmd);
	printf("Ex   : %s -X             # Stop  Slaves\n", cmd);
	printf("Ex   : %s -C             # Check Slaves\n", cmd);
	exit(1);

	return;
}

void load_slave(slaveholder_t *p_slaveholder, char *slave)
{
	slaveinfo_t *p_slaveinfo;

	if ((p_slaveinfo = appSlaveSearchByAlias(p_slaveholder, slave)) == NULL) {
		printf("FAILED: The target slave(%s) is not exist.\n", slave);
		exit(1);
	}
	if (p_slaveinfo->pid > 0) {
		printf("FAILED: The target slave(%s) is already loaded.\n", slave);
		exit(1);
	}
	appSlaveUpdateBlock(p_slaveinfo, FALSE, comTime());

	printf("OK\n"); exit(0);

	return ;
}

void kill_slave(slaveholder_t *p_slaveholder, char *slave, int kill9flag)
{
	slaveinfo_t *p_slaveinfo;
	int i;

	if ((p_slaveinfo = appSlaveSearchByAlias(p_slaveholder, slave)) == NULL) {
		printf("FAILED: The target slave(%s) is not exist.\n", slave);
		exit(1);
	}
	if (p_slaveinfo->pid == 0) {
		printf("FAILED: The target slave(%s) is already killed.\n", slave);
		exit(1);
	}
	appSlaveUpdateBlock(p_slaveinfo, TRUE, comTime());

	/* kill -9 */
	if (kill9flag) {
		for (i = 0; i < 3; i++) {
			if (p_slaveinfo->pid == 0) { break; }
			fprintf(stdout, "."); fflush(stdout);
			sleep(1);
		}
		if (p_slaveinfo->pid > 0) { kill(p_slaveinfo->pid, SIGKILL); }
	}

	printf("OK\n"); exit(0);
}

void enable_slave(slaveholder_t *p_slaveholder, char *slave)
{
	slaveinfo_t *p_slaveinfo;

	if ((p_slaveinfo = appSlaveSearchByAlias(p_slaveholder, slave)) == NULL) {
		printf("FAILED: The target slave(%s) is not exist.\n", slave);
		exit(1);
	}
	if (p_slaveinfo->enabled) {
		printf("FAILED: The target slave(%s) is already enabled.\n", slave);
		exit(1);
	}
	appSlaveUpdateEnable(p_slaveinfo, TRUE, comTime());

	printf("OK\n"); exit(0);
}

void show_slave(slaveholder_t *p_slaveholder, int showall, int nsleep)
{
	if (nsleep) {
		while (TRUE) {
			if (system("clear") == -1) {
				; // do nothing
			}
			appSlaveConfigPrint(p_slaveholder, showall);
			sleep(nsleep);

			/* stop showing.. */
			if (p_slaveholder->mpid <= 0) {
				if (system("clear") == -1) {
					; // do nothing
				}
				appSlaveConfigPrint(p_slaveholder, showall);
				break;
			}
		}
	}
	else {
		appSlaveConfigPrint(p_slaveholder, showall);
	}

	exit(0);
}

void stop_all(char *pname, slaveholder_t *p_slaveholder)
{
	/* confirm.. */
#if 0
	char ch;

	printf("%s> are you sure to stop all? [N] ", pname);
	fflush(stdout);
	ch = getc(stdin);
	if (ch == 'Y' || ch == 'y') {
		printf("%s> all the process will stop soon.\n", pname);
		appSlaveUpdateStop(p_slaveholder, comTime());
		printf("OK\n"); 
		return;
	}

	printf("%s> the request is canceled by You.\n", pname);
	printf("ABORTED\n");
	exit(0);
#endif

	printf("%s> all the process will stop soon.\n", pname);
	appSlaveUpdateStop(p_slaveholder, comTime());
	printf("OK\n"); 

	return;
}

ext_psinfo_t *lookup_psinfo(int pid, int ppid)
{
	int i;

	for (i = 0; i < PsTable.n; i++) {
#if 0
		printf("pid: %d, ppid: %d, comm: %s, user: %s / %s - pid: %d, ppid: %d\n",
				PsTable.psinfo[i].pid,
				PsTable.psinfo[i].ppid,
				PsTable.psinfo[i].comm,
				PsTable.psinfo[i].user, 
				User,
				pid,
				ppid);
#endif
		if (PsTable.psinfo[i].pid == pid) {
			if (ppid == 0 || PsTable.psinfo[i].ppid == ppid) {
				return PsTable.psinfo + i;
			}
		}
	}

	return NULL;
}

int check_psinfo()
{
	ext_psinfo_t *p_psinfo;
	int i;

	if ((p_psinfo = lookup_psinfo(appP->slaveholder.mpid, 0)) != NULL) {
//		printf("PMON IS RUNNING.\n");
		return 0;
	}

//	printf("PMON IS NOT RUNNING. CLEAR ALL THE ZOMBIE PROCESS.\n");
	for (i = 0; i < appP->slaveholder.used; i++) {
		/* psinfo */
		if (appP->slaveholder.slaveinfo[i].pid != 0
				&& (p_psinfo = lookup_psinfo(appP->slaveholder.slaveinfo[i].pid, 0)) != NULL)
		{
			printf("kill -9 %d (%s/%s)\n",
				p_psinfo->pid,
				p_psinfo->comm,
				appP->slaveholder.slaveinfo[i].alias);

			kill(p_psinfo->pid, SIGKILL);
		}
	}

	return -1;
}

int check_lock_file()
{
	return comPidFileCheck("PMON", 0);
}

void show_psinfo()
{
	int  i;
	int  ap_id = 0;
	char s_status[64];
	char s_key[64];
	char s_strttime[64];
	char s_downtime[64];
	char s_pid[64];
	char s_ppid[64];
	char s_pcpu[64];
	char s_pmem[64];
	char s_downnum[64];
	ext_psinfo_t *p_psinfo;
	ipc_t        *p_ipc;

	printf("=======================================================================================\n");
	printf("---------------------------------------------------------------------------------------\n");
	printf(" %-6s %7s %7s %5s %5s %6s %15s %15s %5s %s\n",
		"ALIAS",
		"PID",
		"PPID",
		"SEND",
		"RECV",
		"DEBUG",
		"STRT-TIME",
		"STOP-TIME",
		"DCNT",
		"STATUS"
	);
	printf("---------------------------------------------------------------------------------------\n");

	/* prepare */
	ap_id    = PMON;
	p_psinfo = lookup_psinfo(appP->slaveholder.mpid, 0);

	sprintf(s_status, "%s", (p_psinfo == NULL) ? "DOWN" : "LIVE");
	sprintf(s_key, "H'%08x", 0);
	if (p_psinfo != NULL) {
		sprintf(s_pid , "%d", p_psinfo->pid); 
		sprintf(s_ppid, "%d", p_psinfo->ppid);
		comTimeT2Str(s_strttime, sizeof(s_strttime), "%m/%d-%H:%M:%S", appP->slaveholder.strttime);
		sprintf(s_pcpu, "%s", p_psinfo->pcpu); 
		sprintf(s_pmem, "%s", p_psinfo->pmem);
	}
	else {
		sprintf(s_pid , "------");  
		sprintf(s_ppid, "------"); 
		sprintf(s_strttime, "--------------");
		sprintf(s_pcpu, "----");  
		sprintf(s_pmem, "----");  
	}
	sprintf(s_downtime, "--------------");

	p_ipc = appP->ipcdefault + ap_id;

	printf(" %-6s %7s %7s %5d %5d %6d %15s %15s %5s %s\n",
		"PMON",
		s_pid,
		s_ppid,
		p_ipc->ipcctl.sendIdx,
		p_ipc->ipcctl.recvIdx,
		appP->debugholder.debug[ap_id][0][0].pos[0],
		s_strttime,
		s_downtime,
		"*",
		s_status
	);

	for (i = 0; i < appP->slaveholder.used; i++) {
		if (!appP->slaveholder.slaveinfo[i].enabled) {
			continue;
		}

		/* psinfo */
		if ((p_psinfo = lookup_psinfo(appP->slaveholder.slaveinfo[i].pid, appP->slaveholder.mpid)) == NULL) {
			p_psinfo = lookup_psinfo(appP->slaveholder.slaveinfo[i].pid, 0);
		}

		/* prepare */
		ap_id = appId(appP->slaveholder.slaveinfo[i].alias);

		sprintf(s_status, "%s%s", 
			(p_psinfo != NULL) ? appCodeMap2Str(CC_SlStatus, appP->slaveholder.slaveinfo[i].status) : "DOWN", 
			appP->slaveholder.slaveinfo[i].blocked ? "|BLOCKED" : "");

		sprintf(s_key, "H'%08x", appP->slaveholder.slaveinfo[i].key);

		if (appP->slaveholder.slaveinfo[i].downtime[0] != 0) {
			comTimeT2Str(s_downtime, sizeof(s_downtime), "%m/%d-%H:%M:%S", appP->slaveholder.slaveinfo[i].downtime[0]);
		}
		else {
			sprintf(s_downtime, "--------------");
		}
		if (p_psinfo != NULL) {
			sprintf(s_pid , "%d", p_psinfo->pid);
			sprintf(s_ppid, "%d", p_psinfo->ppid);
			comTimeT2Str(s_strttime, sizeof(s_strttime), "%m/%d-%H:%M:%S", appP->slaveholder.slaveinfo[i].strttime);
			sprintf(s_pcpu, "%s", p_psinfo->pcpu); 
			sprintf(s_pmem, "%s", p_psinfo->pmem);
		}
		else {
			sprintf(s_pid , "------");  
			sprintf(s_ppid, "------"); 
			sprintf(s_strttime, "--------------");
			sprintf(s_pcpu, "----");  
			sprintf(s_pmem, "----");  
		}

		sprintf(s_downnum, "%d/%d",
				appP->slaveholder.slaveinfo[i].faultednum,
				appP->slaveholder.slaveinfo[i].downnum);

		p_ipc = appP->ipcdefault + ap_id;

		/* print */
		printf(" %-6s %7s %7s %5d %5d %6d %15s %15s %5s %s\n",
			appP->slaveholder.slaveinfo[i].alias,
			s_pid,
			s_ppid,
			p_ipc->ipcctl.sendIdx,
			p_ipc->ipcctl.recvIdx,
			appP->debugholder.debug[ap_id][0][0].pos[0],
			s_strttime,
			s_downtime,
			s_downnum,
			s_status
		);
	}
	printf("---------------------------------------------------------------------------------------\n");
	printf("\n");

	return;
}

void show_psinfo_loop(int sec, int until_flag)
{
	int i = 0;
	time_t prev, curr;

	/* current */
	curr = prev = comTime();

	while (TRUE) {
		if (system("clear") == -1) {
			; // do nothing
		}
		switch (until_flag) {
			case _UNTIL_KILLED :
				if (lookup_psinfo(appP->slaveholder.mpid, 0) == NULL) {
					show_psinfo();
					printf("STOPED.\n");
					return;
				}
				break;

			case _UNTIL_LOADED :
				if (((curr = comTime()) - prev) > 6) {
					show_psinfo();
					printf("STARTED.\n");
					return;
				}
				break;
		}

		/* refresh */
		load_psinfo("loop");
		show_psinfo();
		sleep(sec);

		i++;
	}

	return;
}

int load_psinfo(char *pname)
{
	FILE *pipefp;
	char  line[1024];
	ext_psinfo_t psinfo;

	/* PSINFO */
	memset(&PsTable , 0x00, sizeof(PsTable));

	/* load */
	if ((pipefp = popen(_PS_CMD, "r")) == NULL) {
		printf("%s> fail to execute command [%s]", pname, _PS_CMD);
		return -1;
	}
	while (fgets(line, sizeof(line), pipefp) != NULL) {
		memset(&psinfo, 0x00, sizeof(psinfo));
		sscanf(line, "%u %u %s", &psinfo.pid, &psinfo.ppid, psinfo.user);
		if (psinfo.pid <= 0 || (strlen(User) != 0 && strcmp(psinfo.user, User) != 0)) {
			continue;
		}
		if (PsTable.n >= MAX_PSINFO_NUM) {
			printf("%s> can't hold too many psinfo [%d]", pname, PsTable.n);
			pclose(pipefp);
			return -1;
		} 
		memcpy(PsTable.psinfo + PsTable.n, &psinfo, sizeof(ext_psinfo_t));
		PsTable.n += 1;

		/* reinit */
		memset(line, 0x00, sizeof(line));
	}
	pclose(pipefp);

	return 0;
}

int initialize(char *pname)
{
	/* APP */
	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		printf("%s> can't initialize APP\n", pname);
		return -1;
	}

	/* USER */
	comGetUName(User, sizeof(User));
	//printf("User..... |%s|\n", User);

	return load_psinfo(pname);
}

int main(int argc, char **argv)
{
	int cc, options = 0;
	int retval = 0;

	if (initialize(argv[0]) == -1) {
		printf("ABORTED\n");
		return -1;
	}

	while ((cc = getopt(argc, argv, "l:k:e:s:9:xC")) != EOF) {
		switch (cc) {
			case 'l' :
				if (optarg == NULL) {
					usage(argv[0]);
				}
				load_slave(&appP->slaveholder, optarg);
				options += 1;
				break;

			case '9' :
				if (optarg == NULL) {
					usage(argv[0]);
				}
				kill_slave(&appP->slaveholder, optarg, TRUE);
				options += 1;
				break;

			case 'k' :
				if (optarg == NULL) {
					usage(argv[0]);
				}
				kill_slave(&appP->slaveholder, optarg, FALSE);
				options += 1;
				break;

			case 's' :
				if (optarg == NULL) {
					usage(argv[0]);
				}
				show_psinfo_loop(atoi(optarg), _UNTIL_LOADED);
				options += 1;
				break;

			case 'x' :
				stop_all(argv[0], &appP->slaveholder);
				show_psinfo_loop(2, _UNTIL_KILLED);
				options += 1;
				break;

			case 'C' :
#if 0
				if (check_psinfo() == 0) {
#endif
				if (check_lock_file() == -1) {
					printf("OK\n"); 
					retval = 0;
				}
				else {
					printf("NOK\n"); 
					retval = 1;
				}
				options += 1;
				break;

			default  :
				usage(argv[0]);
				break;
		}
	}
	if (!options) { show_psinfo(); }

	return retval;
}
