/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *cmd)
{
	printf("Usage: %s cmd#\n", cmd);
	printf("Ex   : %s 0x0101 #PLAY SOUND\n", cmd);
	printf("Ex   : %s 0x0102 #REBOOT\n", cmd);
	printf("Ex   : %s 0x0103 #UPGRADE\n", cmd);
	printf("Ex   : %s 0x0104 #COLLECT LOG\n", cmd);
	printf("Ex   : %s 0x0105 #SHOW BOARD\n", cmd);
	exit(1);

	return;
}
int main(int argc, char **argv)
{
	int  code;
	char data[256];

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}

	if (argc < 2) {
		usage(argv[0]);
		return -1;
	}
	if ((code = comAscii2Int(argv[1])) == -1 || code == 0) {
		usage(argv[0]);
		return -1;
	}
	if (argc > 2) {
		snprintf(data, sizeof(data), "%s", argv[2]);
	}

	appIpcSendMsg(CHNL, code, (uchar *)data, strlen(data));
	printf("OK\n");

	return 0;
}
