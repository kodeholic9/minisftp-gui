/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"
#include "libpath.h"

typedef struct _mmioption {
	unsigned long  uid;
	int            detailed;
} mmioption_t;

mmioption_t mmiOption;
char        TS[20];

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *pname)
{
	printf("Usage: %s [ -u UID ] [ -v ]\n", pname);
	printf("Ex   : %s -u 1\n", pname);
	printf("Ex   : %s -u 1 -v\n", pname);
	exit(1);

	return;
}

void show_spool(spool_t *p_spool)
{
	return;
}

int _proc_spool(phashmagic_t *p_magic, pqueue_t *p_squeue, spool_t *p_spool, void *p_args)
{
	show_spool(p_spool);

	return RET_NOTFOUND;
}

void show_phash(phashmagic_t *p_magic, phash_t *p_phash, int inst_id)
{
	char TS[3][20];

	comTimeT2Str(TS[0], 20, "%H:%M:%S", p_phash->data.crtetime);
	comTimeT2Str(TS[1], 20, "%H:%M:%S", p_phash->data.pingtime);
	printf(" [%05d %-10lu(%-13s)] %s %s %-6s %4s SP(%d) RP(%d) MP(%d:%d)\n",
			p_phash->meta.id,
			p_phash->data.uid,
			p_phash->data.mdn,
			TS[0],
			TS[1],
			p_phash->data.cryptflag ? "CRYPT" : "!CRYPT",
			appCodeMap2Str(CC_CmAccType, p_phash->data.acctype),
			p_phash->data.sessQ.qnum,
			p_phash->data.resoQ.qnum,
			p_phash->data.pendQ.qnum,
			p_phash->data.sendQ.qnum);

	_spool_qscan(p_magic, &p_phash->data.sessQ, TRUE, _proc_spool, NULL);

	return;
}

void show_each(int inst_id)
{
	phash_t *p_phash;
	int i;

	for (i = 1; i < MAX_PHASH_DATA_NUM; i++) {
		p_phash = pathP->phashmagic.hashData + i;
		if (p_phash->meta.status != PST_FREED) {
			if (mmiOption.uid == 0 || mmiOption.uid == p_phash->data.uid) {
				show_phash(&pathP->phashmagic, p_phash, inst_id);
			}
		}
	}

	return;
}

void show_list(int inst_id)
{
	int i;
	int slotfree, slotused, maxdepth , avgdepth;
	int phashfree, phashused, phashalloc, phashqfree, phashqused;
	int mpoolfree, mpoolused, mpoolalloc, mpoolqfree, mpoolqused;
	int spoolfree, spoolused, spoolalloc, spoolqfree, spoolqused;
	int rpoolfree, rpoolused, rpoolalloc, rpoolqfree, rpoolqused;
	phash_t  *p_phash;
	mpool_t  *p_mpool;
	spool_t  *p_spool;
	rpool_t  *p_rpool;
	pqueue_t *p_pqueue;

	/* FOR HASH DATA */
	phashfree = 0;
	phashused = 0;
	for (i = 1; i < MAX_PHASH_DATA_NUM; i++) {
		p_phash = pathP->phashmagic.hashData + i;
		if (p_phash->meta.id != i) {
			printf("ERROR] IVALID PHASH ID [ID:%d != INDEX:%d]", p_phash->meta.id, i);
			continue;
		}
		if (p_phash->meta.status != PST_FREED) {
			phashused += 1;
		}
		else {
			phashfree += 1;
		}
	}
	phashalloc = MAX_PHASH_DATA_NUM - 1;
	phashqfree = pathP->phashmagic.hashFreeQ.qnum;
	phashqused = phashalloc - phashqfree;

	/* FOR HASH SLOT */
	slotfree = 0; slotused = 0;
	avgdepth = 0; maxdepth = 0;
	for (i = 0; i < MAX_PHASH_SLOT_NUM; i++) {
		p_pqueue = pathP->phashmagic.hashSlot + i;
		if (p_pqueue->qnum > 0) {
			if (p_pqueue->qnum > maxdepth) {
				maxdepth  = p_pqueue->qnum;
			}
			avgdepth += p_pqueue->qnum;
			slotused += 1;
		}
		else {
			slotfree += 1;
		}
	}

	/* FOR MPOOL DATA */
	mpoolfree = 0; mpoolused = 0; 
	mpoolalloc= 0; mpoolqfree= 0; mpoolqused = 0; 
	for (i = 1; i < MAX_MPOOL_NUM; i++) {
		p_mpool = pathP->phashmagic.mesgData + i;
		if (p_mpool->meta.status == PST_FREED) {
			mpoolfree += 1;
		}
		else {
			mpoolused += 1;
		}
	}
	mpoolalloc = MAX_MPOOL_NUM - 1;
	mpoolqfree = pathP->phashmagic.mesgFreeQ.qnum;
	mpoolqused = mpoolalloc - mpoolqfree;

	/* FOR SPOOL DATA */
	spoolfree = 0; spoolused = 0; 
	spoolalloc= 0; spoolqfree= 0; spoolqused = 0; 
	for (i = 1; i < MAX_SPOOL_NUM; i++) {
		p_spool = pathP->phashmagic.sessData + i;
		if (p_spool->meta.status == PST_FREED) {
			spoolfree += 1;
		}
		else {
			spoolused += 1;
		}
	}
	spoolalloc = MAX_MPOOL_NUM - 1;
	spoolqfree = pathP->phashmagic.mesgFreeQ.qnum;
	spoolqused = spoolalloc - spoolqfree;

	/* FOR RPOOL DATA */
	rpoolfree = 0; rpoolused = 0; 
	rpoolalloc= 0; rpoolqfree= 0; rpoolqused = 0; 
	for (i = 1; i < MAX_RPOOL_NUM; i++) {
		p_rpool = pathP->phashmagic.resoData + i;
		if (p_rpool->meta.status == PST_FREED) {
			rpoolfree += 1;
		}
		else {
			rpoolused += 1;
		}
	}
	rpoolalloc = MAX_RPOOL_NUM - 1;
	rpoolqfree = pathP->phashmagic.resoFreeQ.qnum;
	rpoolqused = rpoolalloc - rpoolqfree;

	printf(" [%2d] PHASH T(%5d,%5d) F(%5d,%5d) U(%5d,%5d) SLOT(%d) DEPTH(%d:%d)\n" \
			"      MPOOL T(%5d,%5d) F(%5d,%5d) U(%5d,%5d)\n" \
			"      SPOOL T(%5d,%5d) F(%5d,%5d) U(%5d,%5d)\n" \
			"      RPOOL T(%5d,%5d) F(%5d,%5d) U(%5d,%5d)\n",
			inst_id,
			phashalloc, phashqused + phashqfree,
			phashqfree, phashfree,
			phashqused, phashused,
			slotused,  maxdepth,
			(slotused != 0) ? (int)(avgdepth / (double)slotused) : 0,
			mpoolalloc, mpoolqused + mpoolqfree,
			mpoolqfree, mpoolfree,
			mpoolqused, mpoolused,
			spoolalloc, spoolqused + spoolqfree,
			spoolqfree, spoolfree,
			spoolqused, spoolused,
			rpoolalloc, rpoolqused + rpoolqfree,
			rpoolqfree, rpoolfree,
			rpoolqused, rpoolused
	);


	return;
}

int main(int argc, char **argv)
{
	int cc, i;

	comLogLevelSet(WA);
	memset(&mmiOption, 0x00, sizeof(mmioption_t));

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}
	while ((cc = getopt(argc, argv, "u:d")) != EOF) {
		switch (cc) {
			case 'u':
				/* UE */
				mmiOption.uid = atol(optarg);
				break;

			case 'v':
				mmiOption.detailed = TRUE;
				break;

			default :
				usage(argv[0]);
				break;
		}
	}

	/* for each */
	printf(" =======================================================================\n");
	for (i = 0; i < MAX_CPS_INST_NUM; i++) {
		if (appP->debugholder.debug[PATH][i][0].pos[0] == 0) {
			continue;
		}
		if (pathInitialize(PATH_SHM_KEY + i) >= 0) {
			show_each(i);
			shmdt(pathP);
		}
	}

	/* for list */
	printf(" =======================================================================\n");
	for (i = 0; i < MAX_CPS_INST_NUM; i++) {
		if (appP->debugholder.debug[PATH][i][0].pos[0] == 0) {
			continue;
		}
		if (pathInitialize(PATH_SHM_KEY + i) >= 0) { 
			show_list(i);
			shmdt(pathP);
			printf(" -----------------------------------------------------------------------\n");
		}
	}

	return 0;
}

