/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"
#include "liboma.h"

#define MAX_PERIOD 3600

int  period   = MAX_PERIOD;
int  detailed = FALSE;

/* omaproc */
omaproc_t     omaProc;
omaproc_t   *pOmaProc   = &omaProc;
omshandle_t *pOmsHandle = &omaProc.omshandle;
tracelist_t *pTraceList = &omaProc.tracelist;

/* for nonbsock */
int omaproc_wait (nonbsock_t *p_nonb, fd_set *rset, int usec);
int omaproc_timer(nonbsock_t *p_nonb);

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *cmd)
{
	printf("Usage: %s [ -i UID] [ -m MDN] [-b BLOCK ] [ -p seconds ] [ -d ]\n", cmd);
	exit(1);

	return;
}

int tr_proc_trace_data(nonbsock_t *p_nonb, ommsg_t *p_ommsg)
{
	char data[8192+1];
	int  dlen;

	if ((dlen = (p_ommsg->tracedata.dlen + 1)) > (sizeof(data) - 1)) {
		dlen = sizeof(data) - 1;
	}
	snprintf(data, dlen, "%s", p_ommsg->tracedata.data);
	if (detailed) {
		printf("\n================================================================================\n");
		printf("%s\n", data);
	}
	else {
		char *p = strchr(data, '\n');
		if (p != NULL) {
			*p = '\0';
		}
		printf("%s\n", data);
	}
	fflush(stdout);

	return 0;
}

int omaproc_with(nonbsock_t *p_nonb, fd_set *rset)
{
	ommsgwrap_t *p_wrap  = &pOmsHandle->recvwrap;
	ommsg_t     *p_ommsg = &p_wrap->ommsg;
	int n = 0;

	if (!FD_ISSET(p_nonb->psockfd, rset)) { return 0; }

	while ((n = omaOmMesgRecvTcp(p_nonb, p_wrap)) > 0) {
		switch (p_wrap->ommsg.h.opflag) {
			case OMT_TRACE_DATA: tr_proc_trace_data(p_nonb, p_ommsg); break;
			case OMT_LINK_RES  : break;
			default            :
				comLog(WA, "%s() INVALID MESSAGE - MID(%04x)", __func__, p_wrap->ommsg.h.opflag);
				break;
		}
	}

	if (n == -1) { appNonbsockClose(p_nonb); }

	return n;
}

long nextTraceId()
{
	return (TR_MAGIC | getpid());
}

int traceon()
{
	nonbsock_t  *p_nonb     = &pOmsHandle->nonb;
	ommsgwrap_t *p_sendwrap = &pOmsHandle->sendwrap;
	int cc;

	cc = omaOmMesgSendTraceOn(
			p_nonb,
			p_sendwrap,
			pTraceList->traceinfo[0].source, 
			period,
			nextTraceId(),
			pTraceList->traceinfo[0].mdn, 
			pTraceList->traceinfo[0].iuid, 
			pTraceList->traceinfo[0].block, 
			detailed
	);

	return cc;
}

void oms_process()
{
	nonbsock_t  *p_nonb = &pOmsHandle->nonb;
	fd_set rset;
	time_t started = comTime();
	int    cc;

	/* then, connect */
	appNonbsockConnect(p_nonb, "127.0.0.1", pComProfile->ControlPort);

	while (TRUE) {
		/* check trace period */
		if ((comTime() - started) > period) {
			printf("Trace session is expired.\n");
			goto out;
		}

		/* PROC WITH SOCK */
		cc = omaproc_wait(p_nonb, &rset, 5*1000);
		switch (cc) {
			case 0 : break;
			case -1:
				if (errno != EINTR) {
					comErr(ER, errno, "fail to select.");
					goto out;
				}
				break;

			default :
				/* PROC */
				if (omaproc_with(p_nonb, &rset) == -1) {
					goto out;
				}
				break;
		}

		/* TIMER */
		if (omaproc_timer(p_nonb) == -1) {
			break;
		}
	}

out:

	printf("bye~\n");
	exit(0);

	return;
}

int omaproc_wait(nonbsock_t *p_nonb, fd_set *rset, int usec)
{
	struct timeval timeo;

	if (p_nonb->pstatus == TST_CONNECTING) {
		if (comWritableTimeo(p_nonb->psockfd, 0) > 0) {
			appNonbsockUpdate(p_nonb, TST_CONNECTED);
		}
	}
	timeo.tv_sec  = 0;
	timeo.tv_usec = usec;
	memcpy(rset, &pOmaProc->rmask, sizeof(fd_set));

	return select(pOmaProc->maxfd, rset, NULL, NULL, &timeo);
}

int omaproc_timer(nonbsock_t *p_nonb)
{
	time_t current = comTime();

	switch (p_nonb->pstatus) {
		case TST_CLOSED     : 
			if ((current - p_nonb->chgtime) >= pOmaProfile->OnmLinkIdleSec) {
				/* init sock */
				appNonbsockInit(p_nonb, "PMON", &pOmaProc->maxfd, &pOmaProc->rmask, &pOmaProc->wmask);

				/* init wrap */
				memset(&pOmaProc->omshandle.recvwrap, 0x00, sizeof(ommsgwrap_t));

				/* then, connect */
				appNonbsockConnect(p_nonb, pOmaProc->omshandle.omshost, pOmaProc->omshandle.omsport);
			}
			break;

		case TST_CONNECTED  : 
			if (traceon() != -1) {
				appNonbsockUpdate(p_nonb, TST_BINDING);
				appNonbsockUpdate(p_nonb, TST_KIN);
				comLogLevelSet(WA);
				printf("---------------------------------------------------------------\n");
			}
			break;

		case TST_CONNECTING : 
			if (comWritableTimeo(p_nonb->psockfd, 0) > 0) {
				appNonbsockUpdate(p_nonb, TST_CONNECTED);
			}
			else if ((current - p_nonb->chgtime) >= pOmaProfile->OnmLinkIdleSec) {
				comLog(TR, "%s() BORED......", __func__);
				appNonbsockClose(p_nonb);
				return -1;
			}
			break;

		case TST_KIN        : 
			if ((current - p_nonb->rcvtime) >= pOmaProfile->OnmLinkLostSec) {
				comLog(ER, "%s() IDLE OMS FOUND...", __func__);
				appNonbsockClose(p_nonb);
				return -1;
				break;
			}
			if ((current - p_nonb->pngtime) >= pOmaProfile->OnmLinkIdleSec) {
				omaOmMesgSendLinkReq(p_nonb, &pOmaProc->omshandle.sendwrap);
				p_nonb->pngtime = current;
			}
			break;
	}

	if (p_nonb->psockfd > 0) {
		if (appNonbsockCheckCurrW(p_nonb) > 0
				&& comWritableTimeo(p_nonb->psockfd, 0) > 0
				&& appNonbsockFlush(p_nonb) == -1)
		{
			appNonbsockClose(p_nonb);
			return -1;
		}
	}

	return 0;
}

void omaproc_init()
{
	nonbsock_t *p_nonb = &pOmsHandle->nonb;

	/* init */
	memset(pOmaProc, 0x00, sizeof(omaproc_t));

	/* prepare */
	memset(&pOmsHandle->recvwrap, 0x00, sizeof(ommsgwrap_t));
	appNonbsockInit(p_nonb, "OMC", &pOmaProc->maxfd, &pOmaProc->rmask, &pOmaProc->wmask);

	return;
}

int main(int argc, char **argv)
{
	int cc;

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}
	omaproc_init();

	while ((cc = getopt(argc, argv, "p:i:m:b:d")) != EOF) {
		switch (cc) {
			case 'i' :
				pTraceList->traceinfo[0].iuid = atol(optarg);
				break;

			case 'm' :
				sprintf(pTraceList->traceinfo[0].mdn, "%s", optarg);
				break;

			case 'b' :
				sprintf(pTraceList->traceinfo[0].block, "%s", optarg);
				break;

			case 'p' :
				period = atoi(optarg);
				break;

			case 'd' :
				detailed = TRUE;
				break;

			case 'h' :
			default  :
				usage(argv[0]);
				break;
		}
	}
	comLogLevelSet(TR);
	oms_process();

	return 0;
}
