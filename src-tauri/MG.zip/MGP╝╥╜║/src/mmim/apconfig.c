/**
 * @date    2012/07/20
 * @author  Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 * 
 */

#include "libcom.h"
#include "libapp.h"

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void usage(char *cmd)
{
	printf("Usage: %s [-s ATTR=VALUE]\n", cmd);
	printf("Ex   : %s -s ControlPort=30\n", cmd);
	exit(1);

	return;
}
int main(int argc, char **argv)
{
	char line[128];
	int  cc, change = FALSE;

	if (appInitialize(APP_SHM_KEY, MMIM, 0) < 0) {
		return -1;
	}
	memset(line, 0x00, sizeof(line));

	while ((cc = getopt(argc, argv, "c:s:h")) != EOF) {
		switch (cc) {
			case 's' :
				sprintf(line, "%s", optarg);
				change = TRUE;
				break;

			case 'h' :
			default  :
				usage(argv[0]);
				break;
		}
	}

	if (change) {
		if (strlen(line) == 0) {
			usage(argv[0]);
		}
		if (appProfileSet(line, 0) == -1) {
			printf("FAILED\n");
			return -1;
		}
		else {
			if (strstr(line, "VoipAudioVolume=") != NULL) {
				appIpcSendArgs(MGPP, IMT_MGP_SET_VOLUME_REQ, 0, 0, 0);
			}
			appProfileSave();
			printf("OK\n");
		}
	}
	else {
		if (appProfileShow() == -1) {
			return -1;
		}
		printf("\n");
	}

	return 0;
}
