/**
 * @date   2016/07/26
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */
#include "mgpp.h"

/* for debug */
#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_MAIN, __LINE__)

/* for main */
mgppmagic_t    Oz;
mgppmagic_t  *pOz = &Oz;

time_t Current;

/* main.. */
int main(int argc, char **argv)
{
	ipcmsg_t *p_ipcmsg;

	/* init LogLevel */
	comLogLevelSet(IN);

	/* INITIALIZE */
	if (initialize(argc, argv) == -1) {
		comLog(ER, "fail to initialize.");
		terminate(2);
	}

	/* NEVER DIE!! */
	FNDEBUG(TASK_MAIN);
	while (Oz.running) {
		FNDEBUG(TASK_MAIN);
		if (getppid() == 1) {
			comLog(ER, "the parent process is down!");
			Oz.running = FALSE;
			break;
		}

		FNDEBUG(TASK_MAIN);
		Current = comTime();

		FNDEBUG(TASK_MAIN);
		if (appIpcRecvMsg(&p_ipcmsg, 1000) != -1) {
			comLog(DG, "process something with ipc!!");
			proc_ipc(p_ipcmsg);
		}

		FNDEBUG(TASK_MAIN);
		proc_timer();

		usleep(10000);
	}

	/* TERMINATE */
	FNDEBUG(TASK_MAIN);
	terminate(99);

	return 0;
}

#if 0
void check_connected(psock_t *p_psock)
{
	if (p_psock->d.status == TST_CONNECTING) {
		if (comWritableTimeo(p_psock->meta.id, 0) > 0) {
			pathPSockStatusUpdate(p_psock, TST_CONNECTED, __func__, __LINE__);
		}
	}

	return;
}
#endif

int wait_for(fd_set *rset, int usec)
{
	struct timeval timeo;
	int    cc;

	/* CHECK INPUT EVENT */
	FNDEBUG(TASK_MAIN);
	timeo.tv_sec  = 0;
	timeo.tv_usec = usec;
	memcpy(rset, &pOz->rmask, sizeof(fd_set));

	FNDEBUG(TASK_MAIN);
	if ((cc = select(pOz->maxfd, rset, NULL, NULL, &timeo)) == -1) {
		FNDEBUG(TASK_MAIN);
		if (errno != EINTR) {
			FNDEBUG(TASK_MAIN);
			comErr(ER, errno, "fail to select.");
			terminate(98);
		}
	}

	FNDEBUG(TASK_MAIN);
	return cc;
}

int proc_sock(fd_set *rset)
{
	int num = 0;

	FNDEBUG(TASK_MAIN);
	//num += proc_cps_real_mesg(rset);

	return num;
}

int proc_ipc(ipcmsg_t *p_ipcmsg)
{
	switch (p_ipcmsg->mtype) {
		case IMT_MGP_STRT_REQ:
			FNDEBUG(TASK_MAIN);
			if (voip_start() != -1) {
				pProfile->VoipRunning = 1;
			}
			break;

		case IMT_MGP_STOP_REQ:
			FNDEBUG(TASK_MAIN);
			voip_stop();
			pProfile->VoipRunning = 0;
			break;

		case IMT_MGP_SET_VOLUME_REQ:
			FNDEBUG(TASK_MAIN);
			voip_setvolume();
			break;

		case IMT_CTL_HOOK_PRESSED:
			FNDEBUG(TASK_MAIN);
			switch (pProfile->MBCPStatus) {
				case MBCP_IDLE:
					voip_talkreq();
					break;

				case MBCP_GRANTED:
					voip_talkrel();
					break;

				case MBCP_TAKEN:
					comLog(IN, "%s() - PRESSED! But, TAKEN status!", __func__);
					break;
			}
			break;
	}

	return 0;
}

int proc_timer()
{
	comLog(VB, "process something with timer!!");

	FNDEBUG(TASK_MAIN);
	comLogLevelSet(pProfile->LogLevel);

	return 0;
}

void sighandler(int signo)
{
	pOz->running = FALSE;
}

int initialize(int argc, char **argv)
{
	/* parse args */
	memset(pOz, 0x00, sizeof(mgppmagic_t));

	/* initialize */
	if (appInitialize(APP_SHM_KEY, MGPP, 0) == -1) {
		comErr(ER, errno, "fail to appInitialize.");
		return -1;
	}

	if (appDaemonInit("MGPP", FALSE) == -1) {
		comErr(ER, errno, "fail to appDaemonInit.");
		return -1;
	}

	/* attach the globla hashmagic */
	pOz->running = TRUE;

	/* install signal */
	comInstallSignal(SIGINT , sighandler);
	comInstallSignal(SIGTERM, sighandler);

	/* init my IPC */
	appIpcResetAp();

	/* welcome... */
	appWelcome(argv[0]);

	if (pProfile->VoipRunning) {
		pProfile->VoipRunning = 0;
	}
	voip_init();

	/* signal to CHNL */
	appIpcSendArgs(CHNL, IMT_PROC_MGPP_STRT, 0, 0, 0);

	return 0;
}

int terminate(int code)
{
	int i;

	for (i = 0; i < 3; i++) {
		comLog(WA, "wait....[%d]", i);
		sleep(1);
	}

	/* terminate self.. */
	comGoodbye(code);
	exit(code);

	return 0;
}

