/**
 * @date   2016/09/08
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */
#include "mgpp.h"

/* for Ti2Me */
#include <stdbool.h>
#include "hPTTManager.h"
//#include "hPTTSession.h"
#include "hPTTAudio.h"
#include "hPTTMbcp.h"

#define VOIP_AUDIO_PORT 31820
#define VOIP_MBCP_PORT  31824

/* for debug */
#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_MISC, __LINE__)


hSessionListener mSessionListener;
v2HMbcpCb        mMbcpListener;

HPTTManager mPTTManager;
HPTTSession mPTTSession;

// session listener
void onNetworkError(void* me)
{
	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - me: 0x%08x", __func__, me);
}

int cbMovedIntoQueue(void* user, int priority, int quePosition) {
	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - user: %p, priority: %d, quePosition: %d", __func__,
			user,
			priority,
			quePosition);
	return 0;
}
int cbMovedOutQueue(void* user, int reason) {
	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - user: %p, reason: %d", __func__, user, reason);
	return 0;
}

int cbGranted(void* user, int members, int maxTalkTime, int margin_alert, int seq) {
	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - user: %p, members: %d, maxTalkTime: %d, margin_alert: %d, seq: %d", __func__,
			user,
			members,
			maxTalkTime,
			margin_alert,
			seq);

	FNDEBUG(TASK_MAIN);
	HPTTAudio aud = PTTSession_getAudio((HPTTSession)user);
	if (aud == NULL) {
		comLog(WA, "%s() - PTTSession_getAudio() failed!", __func__);
		return 0;
	}
	PTTAudio_setInputActive (aud, 1);
	PTTAudio_setOutputActive(aud, 0);

	FNDEBUG(TASK_MAIN);
	pProfile->MBCPStatus  = MBCP_GRANTED;
	pProfile->MBCPChgTime = comTime();

	FNDEBUG(TASK_MAIN);
	//appCLI_PTTStart();

	FNDEBUG(TASK_MAIN);
	return 0;
}

int cbOffGranted(void* user, int reason, int revoke_code, int seq) {
	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - user: %p, reason: %d, revoke_code: %d, seq: %d", __func__,
			user,
			reason,
			revoke_code,
			seq);

	FNDEBUG(TASK_MAIN);
	HPTTAudio aud = PTTSession_getAudio((HPTTSession)user);
	if (aud == NULL) {
		comLog(WA, "%s() - PTTSession_getAudio() failed!", __func__);
		return 0;
	}
	PTTAudio_setInputActive (aud, 0);
	PTTAudio_setOutputActive(aud, 0);

	FNDEBUG(TASK_MAIN);
	pProfile->MBCPStatus  = MBCP_IDLE;
	pProfile->MBCPChgTime = comTime();

	FNDEBUG(TASK_MAIN);
	//appCLI_PTTStop();

	FNDEBUG(TASK_MAIN);
	return 0;
}

int cbTaken(void* user, int members, char* talker_domain, char* talker_name, char* phone_num, int seq) {
	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - user: %p, members: %d, talker_domain: %s, talker_name: %s, phone_num: %s, seq: %d", __func__,
			user,
			members,
			(talker_domain != NULL) ? talker_domain : "null",
			(talker_name   != NULL) ? talker_name : "null",
			(phone_num     != NULL) ? phone_num : "null",
			seq);

	FNDEBUG(TASK_MAIN);
	HPTTSession sess = user;
	HPTTAudio   aud = PTTSession_getAudio(sess);
	PTTAudio_setOutputActive(aud, 1);

	FNDEBUG(TASK_MAIN);
	pProfile->MBCPStatus  = MBCP_TAKEN;
	pProfile->MBCPChgTime = comTime();

	FNDEBUG(TASK_MAIN);
	return 0;
}

int cbOffTaken( void* user, int seq) {
	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - user: %p, seq: %d", __func__, user, seq);

	FNDEBUG(TASK_MAIN);
	HPTTSession sess = user;
	HPTTAudio   aud = PTTSession_getAudio(sess);
	PTTAudio_setOutputActive( aud, 0);

	FNDEBUG(TASK_MAIN);
	pProfile->MBCPStatus  = MBCP_IDLE;
	pProfile->MBCPChgTime = comTime();

	FNDEBUG(TASK_MAIN);
	return 0;
}

int cbResultFailTalkReq( void* user,  int reason_code) {
	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - user: %p, reason_code: %d", __func__, user, reason_code);
	return 0;
}

int cbResultAliveAck( void* user, int result) {
	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - user: %p, result: %d", __func__, user, result);

	FNDEBUG(TASK_MAIN);
	if (result) {
		pProfile->MBCPStillAliveTime = comTime();
	}
	else {
#ifndef _LINUX
		FNDEBUG(TASK_MAIN);
		HPTTSession sess = user;
		HPTTMbcp    mbcp = PTTSession_getMBCP(sess);

		PTTMbcp_sendStillAlive(mbcp);
#endif
	}

	return 0;
}

int voip_start() {
	char *local_ip = pProfile->SCFTcpSourceIp;
	int   local_mbcp_port  = 0;
	int   local_audio_port = 0;

	char *remote_ip = pProfile->VoipDestIp;
	int   remote_mbcp_port  = pProfile->VoipDestMPort;
	int   remote_audio_port = pProfile->VoipDestAPort;

	comLog(IN, "%s() ENTER - local_ip: %s, remote_ip: %s, remote_mbcp_port: %d, remote_audio_port: %d", __func__,
			local_ip,
			remote_ip,
			remote_mbcp_port,
			remote_audio_port);

	FNDEBUG(TASK_MAIN);
	pProfile->MBCPStatus  = MBCP_IDLE;
	pProfile->MBCPChgTime = 0;
	pProfile->MBCPStillAliveTime = comTime();

	FNDEBUG(TASK_MAIN);
	if (mPTTSession != NULL) {
		comLog(WA, "%s() - mPTTSession is NOT NULL! continue", __func__);
		voip_stop();
	}

	FNDEBUG(TASK_MAIN);
	if ((mPTTSession = PTTManager_createSession(mPTTManager)) == NULL) {
		comLog(WA, "%s() - LEAVE - failed to PTTManager_createSession()", __func__);
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	PTTSession_setListener(mPTTSession, (void *)mPTTSession, &mSessionListener);

	/* MBCP init */
	FNDEBUG(TASK_MAIN);
	HPTTMbcp mbcp = PTTSession_getMBCP(mPTTSession);

	FNDEBUG(TASK_MAIN);
	local_mbcp_port = PTTMbcp_getLocalPort(mbcp, pProfile->SCFTcpSourceIp, VOIP_MBCP_PORT);
	PTTMbcp_setRemotePort(mbcp, pProfile->VoipDestIp, pProfile->VoipDestMPort);
	PTTMbcp_setListener(mbcp, mPTTSession , &mMbcpListener);
	comLog(IN, "%s() - local_mbcp_port: %d", __func__, local_mbcp_port);

	FNDEBUG(TASK_MAIN);
	PTTMbcp_setEnableStillAlive(mbcp, true, 15);
	PTTMbcp_setSSRC(mbcp, pProfile->IUID);

	/* AUDIO init */
	FNDEBUG(TASK_MAIN);
	HPTTAudio audio = PTTSession_getAudio(mPTTSession);
	PTTAudio_initParameters(audio);

	FNDEBUG(TASK_MAIN);
	local_audio_port = PTTAudio_getLocalPort(audio, pProfile->SCFTcpSourceIp, VOIP_AUDIO_PORT);
	PTTAudio_setRemotePort(audio, pProfile->VoipDestIp, pProfile->VoipDestAPort);
	comLog(IN, "%s() - local_audio_port: %d", __func__, local_audio_port);

	FNDEBUG(TASK_MAIN);
	//PTTAudio_setCodec(audio, CODEC_OPUS_WB, 97);
	PTTAudio_setCodec(audio, pProfile->VoipAudioCodec, appAudioCodec2Pid(pProfile->VoipAudioCodec));
	//  PTTAudio_setCodec(audio, CODEC_PCMU, 0);
	PTTAudio_setSSRC(audio, pProfile->IUID);

	FNDEBUG(TASK_MAIN);
	PTTMbcp_start(mbcp);

	FNDEBUG(TASK_MAIN);
	PTTAudio_start(audio);

	FNDEBUG(TASK_MAIN);
	voip_setvolume();

	FNDEBUG(TASK_MAIN);
	PTTAudio_setOutputActive(audio, 0);

	comLog(IN, "%s() LEAVE", __func__);


	return 0;
}

void voip_stop() {
	HPTTMbcp  mbcp = NULL;
	HPTTAudio audio = NULL;

	comLog(IN, "%s() - ENTER", __func__);

	FNDEBUG(TASK_MAIN);
	if (mPTTSession == NULL) {
		comLog(IN, "%s() - mPTTSession is NULL, return", __func__);
		return;
	}

	FNDEBUG(TASK_MAIN);
	if ((mbcp = PTTSession_getMBCP(mPTTSession)) != NULL) {
		PTTMbcp_stop(mbcp);
	}

	FNDEBUG(TASK_MAIN);
	if ((audio = PTTSession_getAudio(mPTTSession)) != NULL) {
		PTTAudio_stop(audio);
	}

	FNDEBUG(TASK_MAIN);
	PTTManager_releaseSession(mPTTManager, mPTTSession);
	mPTTSession = NULL;

	comLog(IN, "%s() - LEAVE", __func__);
}

void voip_init()
{
	comLog(DG, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	mPTTManager = PTTManager_new();
	PTTManager_initialize(mPTTManager);

	/* for session listener */
	FNDEBUG(TASK_MAIN);
	memset(&mSessionListener, 0x00, sizeof(mSessionListener));
	mSessionListener.onNetworkError = onNetworkError;

	/* for mbcp callback */
	FNDEBUG(TASK_MAIN);
	memset(&mMbcpListener, 0x00, sizeof(mMbcpListener));
	mMbcpListener.cbInQueuingMsg = cbMovedIntoQueue;
	mMbcpListener.cbMovedOutQueuing = cbMovedOutQueue;
	mMbcpListener.cbGranted = cbGranted;
	mMbcpListener.cbTaken = cbTaken;
	mMbcpListener.cbOffGranted = cbOffGranted;
	mMbcpListener.cbOffTaken = cbOffTaken;
	mMbcpListener.cbResultFailTalkReq = cbResultFailTalkReq;
	mMbcpListener.cbResultAliveAck = cbResultAliveAck;

	return;
}

void voip_setvolume()
{
	HPTTAudio audio  = NULL;
	int       volume = 0;
	
	FNDEBUG(TASK_MAIN);
	comLog(DG, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (mPTTManager == NULL || mPTTSession == NULL) {
		comLog(ER, "%s() - NULL Session", __func__);
		return;
	}
	audio = PTTSession_getAudio(mPTTSession);

	FNDEBUG(TASK_MAIN);
	if ((volume = pProfile->VoipAudioVolume) > 100 || volume < 0) {
		volume = 20;
	}
	PTTAudio_setVolume(audio, volume);
	comLog(IN, "%s() - audio volume: %d", __func__, volume);

	return;
}

void voip_talkreq()
{
	FNDEBUG(TASK_MAIN);
	comLog(DG, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (mPTTManager == NULL || mPTTSession == NULL) {
		comLog(ER, "%s() - NULL Session", __func__);
		return;
	}

#ifndef _LINUX
	FNDEBUG(TASK_MAIN);
	HPTTMbcp mbcp = PTTSession_getMBCP(mPTTSession);
	if (mbcp == NULL) {
		comLog(ER, "%s() - NULL mbcp", __func__);
		return;
	}

	/**
	 * 미디어 송출 요청합니다.
	 * @param PTTMbcp 포인터
	 * @param priority 우선순위 \n
	 *      1: normal \n
	 *      2: high     \n
	 *      3: pre-emptive(가로채기) \n
	 * @param reDuration 톡 타임. default : 30, 30초 동안 미디어 송출 요청
	 * @param reqText : 송출 이유 - description.
	 */
	PTTMbcp_TalkReq(mbcp, /*priority*/ 1, /*reDuration*/ 30, "");
#endif
}


void voip_talkrel()
{
	FNDEBUG(TASK_MAIN);
	comLog(DG, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (mPTTManager == NULL || mPTTSession == NULL) {
		comLog(ER, "%s() - NULL Session", __func__);
		return;
	}

#ifndef _LINUX
	FNDEBUG(TASK_MAIN);
	HPTTMbcp mbcp = PTTSession_getMBCP(mPTTSession);
	if (mbcp == NULL) {
		comLog(ER, "%s() - NULL mbcp", __func__);
		return;
	}

	/**
	 * 미디어 송출 중지를 통보 합니다.
	 */
	PTTMbcp_TalkRel(mbcp);
#endif
}

