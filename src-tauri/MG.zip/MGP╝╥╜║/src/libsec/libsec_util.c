/**
 * @date   2012/12/03
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "libsec.h"

unsigned char defaultIV[CRYPT_KEY_LEN] =
{
	0xcb, 0x67, 0xd3, 0x17, 0xbe, 0xde, 0xd0, 0xdd,
	0x3a, 0xfa, 0x5c, 0x17, 0xea, 0x6a, 0x54, 0x5d 
};

unsigned char defaultSUM[CRYPT_KEY_LEN] =
{
	0xad, 0xbd, 0xf1, 0x51, 0xcc, 0x52, 0xa8, 0x2a,
	0xa3, 0x54, 0x60, 0x74, 0x45, 0xab, 0xce, 0x55
};

/** ----------------------------------------------------- */
void secUtilMd5(char *s, unsigned char *sum)
{
	md5((unsigned char *)s, strlen(s), sum);
}

int secUtilAesCbc128Enc(unsigned char *sum, unsigned char *iv, unsigned char *in, unsigned char *out, int len)
{
	aes_context   ctx;
	unsigned char tmpiv[CRYPT_KEY_LEN];

	memcpy(tmpiv, iv, CRYPT_KEY_LEN);
	aes_setkey_enc(&ctx, sum, 128);
	aes_crypt_cbc (&ctx, AES_ENCRYPT, len, tmpiv, in, out);

	return 0;
}

int secUtilAesCbc128Dec(unsigned char *sum, unsigned char *iv, unsigned char *in, unsigned char *out, int len)
{
	aes_context   ctx;
	unsigned char tmpiv[CRYPT_KEY_LEN];

	memcpy(tmpiv, iv, CRYPT_KEY_LEN);
	aes_setkey_dec(&ctx, sum, 128);
	aes_crypt_cbc (&ctx, AES_DECRYPT, len, tmpiv, in, out);

	return 0;
}

void secUtilDumpRaw(char *name, char *s, int len)
{
	int i;

	fprintf(stdout, "--------------------------------------------------------\n");
	fprintf(stdout, "- %s (%d)\n", name, len);
	fprintf(stdout, "--------------------------------------------------------\n");
	for (i = 0; i < len; i++) {
		if (i != 0 && (i % 32) == 0) {
			fprintf(stdout, "\n"); fflush(stdout);
		}
		fprintf(stdout, "%02x ", (unsigned char)s[i]);
	}
	fprintf(stdout, "\n"); fflush(stdout);

	return;
}

