/**
 * @date   2016/08/16
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */
#include "chnl.h"

/* for debug */
#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_MISC, __LINE__)

/****************************************************************/
/*                                                              */
/* JSONPACK                                                     */
/*                                                              */
/****************************************************************/
jsonpack_t *CHNLPACK_PTR(int id, const char *f)
{
	jsonpack_t *p_pack = NULL;

	FNDEBUG(TASK_MAIN);
	if (id < 0 || id >= MAX_CHNLPACK_NUM) {
		FNDEBUG(TASK_MAIN);
		comLog(ER, "%s() <-- %s() invalid chnlpack_id: %d", __func__, f, id);
		return NULL;
	}

	FNDEBUG(TASK_MAIN);
	p_pack = pOz->chnlpack + id;

	FNDEBUG(TASK_MAIN);
	if (p_pack->id != id) {
		FNDEBUG(TASK_MAIN);
		comLog(ER, "%s() <-- %s() mismatched chnlpack_id (%d != %d) ", __func__, f, p_pack->id, id);
		return NULL;
	}
	FNDEBUG(TASK_MAIN);

	return p_pack;
}

static int gNextChnlPackID = 0;
static int chnlpack_next_id()
{
	FNDEBUG(TASK_MAIN);
	gNextChnlPackID += 1;
	gNextChnlPackID %= MAX_CHNLPACK_NUM;

	FNDEBUG(TASK_MAIN);
	return gNextChnlPackID;
}

void chnlpack_init()
{
	jsonpack_t *p_pack = NULL;
	int i;

	FNDEBUG(TASK_MAIN);
	for (i = 0; i < MAX_CHNLPACK_NUM; i++) {
		p_pack = pOz->chnlpack + i;
		p_pack->type   = JPT_NONE;
		p_pack->status = JPS_FREE;
		p_pack->id     = i;
	}
}

void chnlpack_update_status(jsonpack_t *p_pack, int status, const char *f)
{
	FNDEBUG(TASK_MAIN);
	if (p_pack == NULL) {
		FNDEBUG(TASK_MAIN);
		comLog(ER, "%s() - !p_pack", __func__);
		return;
	}

	FNDEBUG(TASK_MAIN);
	if (p_pack->status != status) {
		FNDEBUG(TASK_MAIN);
		comLog(IN, "%s() - chnlpack_id: %d, status: %s --> %s", __func__, 
				p_pack->id,
				appCodeMap2Str(CC_JPackStatus, p_pack->status),
				appCodeMap2Str(CC_JPackStatus, status));

		FNDEBUG(TASK_MAIN);
		p_pack->status = status;
		if (status == JPS_USING) {
			p_pack->using_time = comTime();
		}
	}
	FNDEBUG(TASK_MAIN);

	return;
}

void chnlpack_update_type(jsonpack_t *p_pack, int type, const char *f)
{
	FNDEBUG(TASK_MAIN);
	if (p_pack == NULL) {
		FNDEBUG(TASK_MAIN);
		comLog(ER, "%s() - !p_pack", __func__);
		return;
	}

	FNDEBUG(TASK_MAIN);
	if (p_pack->type != type) {
		FNDEBUG(TASK_MAIN);
		comLog(IN, "%s() - chnlpack_id: %d, type: %s --> %s", __func__,
				p_pack->id,
				appCodeMap2Str(CC_JPackType, p_pack->type),
				appCodeMap2Str(CC_JPackType, type));

		p_pack->type = type;
	}
	FNDEBUG(TASK_MAIN);

	return;
}

jsonpack_t *chnlpack_alloc(const char *f)
{
	jsonpack_t *p_pack;
	int i, next;

	FNDEBUG(TASK_MAIN);
	comLog(DG, "%s() - chnlpack_id: ?", __func__);

	FNDEBUG(TASK_MAIN);
	for (i = 0; i < MAX_CHNLPACK_NUM; i++) {
		next = chnlpack_next_id();
		if ((p_pack = CHNLPACK_PTR(next, __func__)) != NULL && p_pack->status == JPS_FREE) {
			comLog(IN, "%s() - chnlpack_id: %d", __func__, p_pack->id);
			chnlpack_update_status(p_pack, JPS_USING, __func__);
			
			return p_pack;
		}
	}

	FNDEBUG(TASK_MAIN);
	comLog(ER, "%s() - chnlpack_id: NULL", __func__);

	return NULL;
}

void chnlpack_release(jsonpack_t *p_pack, const char *f)
{
	FNDEBUG(TASK_MAIN);
	if (p_pack == NULL) {
		FNDEBUG(TASK_MAIN);
		comLog(ER, "%s() - !p_pack", __func__);
		return;
	}
	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - chnlpack_id: %d", __func__, p_pack->id);

	FNDEBUG(TASK_MAIN);
	if (p_pack->status == JPS_FREE) {
		FNDEBUG(TASK_MAIN);
		comLog(ER, "%s() - invalid status of chnlpack_id: %d, status: %d", __func__, p_pack->id, p_pack->status);
		return;
	}
	FNDEBUG(TASK_MAIN);
	chnlpack_update_type  (p_pack, JPT_NONE, __func__);
	chnlpack_update_status(p_pack, JPS_FREE, __func__);

	FNDEBUG(TASK_MAIN);
	return;
}

/****************************************************************/
/*                                                              */
/* MGPP Control                                                 */
/*                                                              */
/****************************************************************/
int mgp_signal_strt_req()
{
	FNDEBUG(TASK_MAIN);
	return appIpcSendArgs(MGPP, IMT_MGP_STRT_REQ, 0, 0, pProfile->ChannelSID);
}

int mgp_signal_stop_req()
{
	FNDEBUG(TASK_MAIN);
	return appIpcSendArgs(MGPP, IMT_MGP_STOP_REQ, 0, 0, pProfile->ChannelSID);
}

/****************************************************************/
/*                                                              */
/* ChannelStatus                                                */
/*                                                              */
/****************************************************************/
void channel_status_update(long sid, int status, const char *f)
{
	FNDEBUG(TASK_MAIN);
	comLog(DG, "%s/%s()", f, __func__);

	FNDEBUG(TASK_MAIN);
	appProfileUpdateChannelInfo(sid, status);

#if 0
	switch (status) {
		case CST_IDLE  : timer_proc_status_idle();   break;
		case CST_ROOMED: timer_proc_status_roomed(); break;
		case CST_JOINED: timer_proc_status_joined(); break;
	}
#endif

	return;
}


