/**
 * @date   2016/11/14
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */
#include "chnl.h"

#ifdef _DSTECH
#include "modem.h"
#endif

/* for debug */
#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_OMA, __LINE__)

int oma_get_modem_info(j_modem_t *p_modem)
{
	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

#ifdef _DSTECH
	FNDEBUG(TASK_MAIN);
	memset(p_modem, 0x00, sizeof(j_modem_t));
	modem_get_imei(p_modem->imei, sizeof(p_modem->imei));
	modem_get_cnum(p_modem->cnum, sizeof(p_modem->cnum));
	modem_get_nsi (p_modem->nsi , sizeof(p_modem->nsi ));
	modem_get_cgdcont (p_modem->cgdcont, sizeof(p_modem->cgdcont));
	modem_get_cgpaddr (p_modem->cgpaddr, sizeof(p_modem->cgpaddr));
	modem_get_csq(&p_modem->csq);
#endif

	FNDEBUG(TASK_MAIN);
	return 0;
}

int oma_get_board_info(j_board_t *p_board, char *request_key)
{
	json_t *json;
	char    text[8192];

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	snprintf(p_board->request_key, sizeof(p_board->request_key), "%s", request_key);
	p_board->process_count = appOmaGetJSProcInfo(p_board->process_list, MAX_SLAVE_PROC_NUM);
	appOmaGetJSConfigInfo(&p_board->config);
	appOmaGetJSUnameInfo (&p_board->uname);
	appOmaGetJSCpustat(&p_board->cpustat);
	appOmaGetJSMemstat(&p_board->memstat);
	p_board->fsystat_count = appOmaGetJSFsystat(p_board->fsystat_list);
	p_board->netstat_count = appOmaGetJSNetstat(p_board->netstat_list);

	FNDEBUG(TASK_MAIN);
	oma_get_modem_info(&p_board->modem);

	FNDEBUG(TASK_MAIN);
	if ((json = rmsJsonPack_board(p_board)) != NULL) {
		FNDEBUG(TASK_MAIN);
		rmsHttpJson2Text(json, text, sizeof(text));
		comLog(IN, "<<boardinfo>>\n%s", text);

		/* don't forget!! */
		FNDEBUG(TASK_MAIN);
		if (json != NULL) {
			rmsHttpFreeJson(&json);
			json = NULL;
		}
	}

	return 0;
}

void *omInvoker(void *arg)
{
	omsdata_t *p_omsdata = (omsdata_t *)arg;

	appOmMesgSendDataReq(
			p_omsdata->host,
			p_omsdata->port,
			p_omsdata->op_type,
			p_omsdata->data);

	//release the memory
	free(p_omsdata);

	comThreadExit();

	return NULL;
}

void om_response(j_datarcv_t *p_datarcv, int op_type, char *data)
{
	pthread_t    tid;
	omsdata_t   *p_omsdata;
	j_addinfo_t *p_addinfo = &p_datarcv->addinfo;

	FNDEBUG(TASK_MAIN);
	p_omsdata = malloc(sizeof(omsdata_t));

	FNDEBUG(TASK_MAIN);
	memset(p_omsdata, 0x00, sizeof(omsdata_t));
	snprintf(p_omsdata->host, sizeof(p_omsdata->host), "%s", p_addinfo->dst_ip);
	p_omsdata->port = p_addinfo->dst_port;
	p_omsdata->op_type = op_type;
	if (data != NULL) {
		snprintf(p_omsdata->data, sizeof(p_omsdata->data), "%s", data);
	}

	FNDEBUG(TASK_MAIN);
	if (comThreadCreate(&tid, omInvoker, p_omsdata) == -1) {
		comLog(ER, "%s() fail to comThreadCreate()", __func__);
		free(p_omsdata);
		return;
	}

	FNDEBUG(TASK_MAIN);
	return;
}

void om_response_result(j_datarcv_t *p_datarcv, int op_type, int result)
{
	json_t *json;
	j_omsres_t omsres;
	char    text[8192];

	/* response with result */
	FNDEBUG(TASK_MAIN);
	omsres.result = result;
	omsres.volume = pProfile->VoipAudioVolume;
	snprintf(omsres.request_key, sizeof(omsres.request_key), "%s", p_datarcv->addinfo.request_key);

	FNDEBUG(TASK_MAIN);
	if ((json = rmsJsonPack_omsres(&omsres)) == NULL) {
		comLog(ER, "%s() fail to rmsJsonPack_omsres()", __func__);
		return;
	}

	FNDEBUG(TASK_MAIN);
	rmsHttpJson2Text(json, text, sizeof(text));
	om_response(p_datarcv, op_type, text);

	FNDEBUG(TASK_MAIN);
	if (json != NULL) {
		rmsHttpFreeJson(&json);
		json = NULL;
	}


	return;
}

