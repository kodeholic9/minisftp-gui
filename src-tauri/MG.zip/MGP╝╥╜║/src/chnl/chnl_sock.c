/**
 * @date   2016/07/27
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */
#include "chnl.h"

/* for debug */
#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_SOCK, __LINE__)

#define SCF_BINDING_TIMEO    5

static int    sPayloadId = 1;

int scf_sock_next_payload_id()
{
	if (++sPayloadId >= 10000) {
		sPayloadId = 1;
	}
	
	return sPayloadId;
}

int scf_sock_curr_payload_id()
{
	return sPayloadId;
}

void scf_sock_init()
{
	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	appNonbsockInit(&pOz->ns, "SCF", &pOz->maxfd, &pOz->rmask, &pOz->wmask);

	/* init wrap */
	FNDEBUG(TASK_MAIN);
	memset(&pOz->sendwrap, 0x00, sizeof(scmsgwrap_t));
	memset(&pOz->recvwrap, 0x00, sizeof(scmsgwrap_t));

	FNDEBUG(TASK_MAIN);
	if (READY1() && READY2()) {
		appNonbsockConnect(&pOz->ns, pProfile->SCFTcpServerHost, pProfile->SCFTcpServerPort);
	}
}

int scf_sock_send_bindreq()
{
	scmsg_t *p_scmsg = &pOz->sendwrap.uemsg;
	int n;

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (pOz->ns.pstatus != TST_CONNECTED) {
		comLog(WA, "%s() - invalid socket status: %s [CONNECTED]", __func__, appCodeMap2Str(CC_TcpStatus, pOz->ns.pstatus));
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	memset(&pOz->sendwrap, 0x00, sizeof(scmsgwrap_t));

	FNDEBUG(TASK_MAIN);
	rmsScMesgPackBindReq(p_scmsg, pProfile->IUID, 9, pProfile->E164, pProfile->AppType, pProfile->AuthKey);
	if ((n = rmsScMesgSendTcp(&pOz->ns, &pOz->sendwrap)) == -1) {
		FNDEBUG(TASK_MAIN);
		appNonbsockClose(&pOz->ns);
	}

	return n;
}

int scf_sock_send_pingreq()
{
	scmsg_t *p_scmsg = &pOz->sendwrap.uemsg;
	int n;

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (pOz->ns.pstatus != TST_KIN) {
		comLog(WA, "%s() - invalid socket status: %s [KIN]", __func__, appCodeMap2Str(CC_TcpStatus, pOz->ns.pstatus));
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	memset(&pOz->sendwrap, 0x00, sizeof(scmsgwrap_t));

	FNDEBUG(TASK_MAIN);
	rmsScMesgPackPingReq(p_scmsg, pProfile->IUID, 9);
	if ((n = rmsScMesgSendTcp(&pOz->ns, &pOz->sendwrap)) == -1) {
		FNDEBUG(TASK_MAIN);
		appNonbsockClose(&pOz->ns);
	}

	return n;
}

int scf_sock_send_pingres(int pid, int result)
{
	scmsg_t *p_scmsg = &pOz->sendwrap.uemsg;
	int n;

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (pOz->ns.pstatus != TST_KIN) {
		comLog(WA, "%s() - invalid socket status: %s [KIN]", __func__, appCodeMap2Str(CC_TcpStatus, pOz->ns.pstatus));
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	memset(&pOz->sendwrap, 0x00, sizeof(scmsgwrap_t));

	FNDEBUG(TASK_MAIN);
	rmsScMesgPackPingRes(p_scmsg, pProfile->IUID, pid, result);
	if ((n = rmsScMesgSendTcp(&pOz->ns, &pOz->sendwrap)) == -1) {
		FNDEBUG(TASK_MAIN);
		appNonbsockClose(&pOz->ns);
	}

	return n;
}

int scf_sock_send_datareq(int pid, long ttoo, long sid, int action, char *data)
{
	scmsg_t *p_scmsg = &pOz->sendwrap.uemsg;
	int n;

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (pOz->ns.pstatus != TST_KIN) {
		comLog(WA, "%s() - invalid socket status: %s [KIN]", __func__, appCodeMap2Str(CC_TcpStatus, pOz->ns.pstatus));
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	memset(&pOz->sendwrap, 0x00, sizeof(scmsgwrap_t));

	FNDEBUG(TASK_MAIN);
	rmsScMesgPackDataReq(p_scmsg, pProfile->IUID, pid, ttoo, sid, action, data);
	if ((n = rmsScMesgSendTcp(&pOz->ns, &pOz->sendwrap)) == -1) {
		FNDEBUG(TASK_MAIN);
		appNonbsockClose(&pOz->ns);
	}

	return n;
}

int scf_sock_send_datares(int pid, int result, char *ack_data)
{
	scmsg_t *p_scmsg = &pOz->sendwrap.uemsg;
	int n;

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (pOz->ns.pstatus != TST_KIN) {
		comLog(WA, "%s() - invalid socket status: %s [KIN]", __func__, appCodeMap2Str(CC_TcpStatus, pOz->ns.pstatus));
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	memset(&pOz->sendwrap, 0x00, sizeof(scmsgwrap_t));

	FNDEBUG(TASK_MAIN);
	rmsScMesgPackDataRes(p_scmsg, pProfile->IUID, pid, result, ack_data);
	if ((n = rmsScMesgSendTcp(&pOz->ns, &pOz->sendwrap)) == -1) {
		FNDEBUG(TASK_MAIN);
		appNonbsockClose(&pOz->ns);
	}

	return n;
}

int scf_sock_send_leavreq(int pid)
{
	scmsg_t *p_scmsg = &pOz->sendwrap.uemsg;
	int n;

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (pOz->ns.pstatus != TST_KIN) {
		comLog(WA, "%s() - invalid socket status: %s [KIN]", __func__, appCodeMap2Str(CC_TcpStatus, pOz->ns.pstatus));
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	memset(&pOz->sendwrap, 0x00, sizeof(scmsgwrap_t));

	FNDEBUG(TASK_MAIN);
	rmsScMesgPackLeavReq(p_scmsg, pProfile->IUID, pid);
	if ((n = rmsScMesgSendTcp(&pOz->ns, &pOz->sendwrap)) == -1) {
		FNDEBUG(TASK_MAIN);
		appNonbsockClose(&pOz->ns);
	}

	return n;
}

static void proc_bindres(scmsg_t *p_scmsg)
{
	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (p_scmsg->h.result != SCM_RC_EOK) {
		comLog(WA, "%s() BIND FAILED (%d)", __func__, p_scmsg->h.result);
		appNonbsockClose(&pOz->ns);
		return;
	}

	FNDEBUG(TASK_MAIN);
	pProfile->SCFTcpFaultTime = 0;

	FNDEBUG(TASK_MAIN);
	appNonbsockUpdate(&pOz->ns, TST_KIN);

	FNDEBUG(TASK_MAIN);
	pProfile->SCFTcpFaultDuration = 0;

	FNDEBUG(TASK_MAIN);
	scf_sock_check_bound();

	return;
}

static void proc_pingres(scmsg_t *p_scmsg)
{
	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (p_scmsg->h.result != SCM_RC_EOK) {
		comLog(WA, "%s() BIND FAILED (%d)", __func__, p_scmsg->h.result);
		appNonbsockClose(&pOz->ns);
		return;
	}

	return;
}

static void proc_pingreq(scmsg_t *p_scmsg)
{
	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	scf_sock_send_pingres(p_scmsg->h.payload_id, SCM_RC_EOK);

	return;
}

static void proc_datareq_inactive(j_datarcv_t *p_datarcv)
{
	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (pProfile->ChannelSID != 0 && pProfile->ChannelSID != p_datarcv->sid) {
		comLog(WA, "%s() - inactivate channel - mismatched - sid: %lu[%lu], status: %s", __func__,
				p_datarcv->sid, pProfile->ChannelSID, appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus));
	}

	FNDEBUG(TASK_MAIN);
	switch (pProfile->ChannelStatus) {
		case CST_ACTIVE:
		case CST_ACTIVATING:
		case CST_JOINED:
			FNDEBUG(TASK_MAIN);
			comLog(IN, "%s() - inactivate channel - sid: %lu[%lu], status: %s", __func__,
					p_datarcv->sid, pProfile->ChannelSID, appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus));

			FNDEBUG(TASK_MAIN);
			channel_status_update(pProfile->ChannelSID, CST_INACTIVE, __func__);

			FNDEBUG(TASK_MAIN);
			channel_status_update(pProfile->ChannelSID, CST_LEAVING, __func__);
			scf_sock_request_leave();
			mgp_signal_stop_req();

			FNDEBUG(TASK_MAIN);
			channel_status_update(p_datarcv->sid, CST_ROOMED, __func__);
			timer_proc_channel_roomed();
			break;
	}

	return;
}

static void proc_datareq_activate(j_datarcv_t *p_datarcv)
{
	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (pProfile->ChannelSID != 0 && pProfile->ChannelSID != p_datarcv->sid) {
		comLog(WA, "%s() - activate channel - mismatched - sid: %lu[%lu], status: %s", __func__,
				p_datarcv->sid, pProfile->ChannelSID, appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus));
	}

	FNDEBUG(TASK_MAIN);
	switch (pProfile->ChannelStatus) {
		case CST_IDLE:
		case CST_ROOMED:
			FNDEBUG(TASK_MAIN);
			comLog(IN, "%s() - activate channel - sid: %lu[%lu], status: %s", __func__,
					p_datarcv->sid, pProfile->ChannelSID, appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus));

			FNDEBUG(TASK_MAIN);
			channel_status_update(p_datarcv->sid, CST_ROOMED, __func__);
			timer_proc_channel_roomed();
			break;
	}

	return;
}

static void proc_datareq_grant(j_datarcv_t *p_datarcv)
{
	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	switch (pProfile->ChannelStatus) {
		case CST_IDLE:
		case CST_ROOMED:
			FNDEBUG(TASK_MAIN);
			comLog(IN, "%s() - grant channel - sid: %lu[%lu], status: %s", __func__,
					p_datarcv->sid, pProfile->ChannelSID, appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus));

			FNDEBUG(TASK_MAIN);
			channel_status_update(p_datarcv->sid, CST_ROOMED, __func__);
			timer_proc_channel_roomed();
			break;

		case CST_JOINED:
		case CST_ACTIVATING:
		case CST_ACTIVE:
			FNDEBUG(TASK_MAIN);
			comLog(IN, "%s() - grant channel - sid: %lu[%lu], status: %s", __func__,
					p_datarcv->sid, pProfile->ChannelSID, appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus));
			if (pProfile->ChannelSID != p_datarcv->sid) {
				FNDEBUG(TASK_MAIN);
				channel_status_update(pProfile->ChannelSID, CST_LEAVING, __func__);
				scf_sock_request_leave();
				mgp_signal_stop_req();

				FNDEBUG(TASK_MAIN);
				channel_status_update(p_datarcv->sid, CST_ROOMED, __func__);
				timer_proc_channel_roomed();
			}
			break;
	}
}

static void proc_datareq_invite(j_datarcv_t *p_datarcv)
{
	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	switch (pProfile->ChannelStatus) {
		case CST_IDLE:
		case CST_ROOMED:
			FNDEBUG(TASK_MAIN);
			comLog(IN, "%s() - invite channel - sid: %lu[%lu], status: %s", __func__,
					p_datarcv->sid, pProfile->ChannelSID, appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus));

			FNDEBUG(TASK_MAIN);
			channel_status_update(p_datarcv->sid, CST_ROOMED, __func__);
			timer_proc_channel_roomed();
			break;

		case CST_JOINED:
		case CST_ACTIVE:
			FNDEBUG(TASK_MAIN);
			comLog(IN, "%s() - invite channel - sid: %lu[%lu], status: %s", __func__,
					p_datarcv->sid, pProfile->ChannelSID, appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus));

			FNDEBUG(TASK_MAIN);
			channel_status_update(pProfile->ChannelSID, CST_LEAVING, __func__);
			scf_sock_request_leave();
			mgp_signal_stop_req();

			FNDEBUG(TASK_MAIN);
			channel_status_update(p_datarcv->sid, CST_ROOMED, __func__);
			timer_proc_channel_roomed();
			break;
	}
}

static void proc_datareq_ban(j_datarcv_t *p_datarcv)
{
	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (pProfile->ChannelSID == p_datarcv->sid) {
		comLog(WA, "%s() - ban channel - sid: %lu[%lu], status: %s", __func__,
				p_datarcv->sid, pProfile->ChannelSID, appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus));

		FNDEBUG(TASK_MAIN);
		switch (pProfile->ChannelStatus) {
			case CST_JOINED:
			case CST_ACTIVE:
				FNDEBUG(TASK_MAIN);
				channel_status_update(pProfile->ChannelSID, CST_LEAVING, __func__);
				scf_sock_request_leave();
				mgp_signal_stop_req();
				break;
		}

		FNDEBUG(TASK_MAIN);
		channel_status_update(0, CST_IDLE, __func__);
		timer_proc_channel_idle();
	}

	return;
}

static void proc_datareq_board_status(j_datarcv_t *p_datarcv)
{
	json_t *json;
	j_board_t board;
	char    text[8192];

	FNDEBUG(TASK_MAIN);
	comLog(DG, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	oma_get_board_info(&board, p_datarcv->addinfo.request_key);

	FNDEBUG(TASK_MAIN);
	if ((json = rmsJsonPack_board(&board)) == NULL) {
		comLog(ER, "%s() fail to rmsJsonPack_board()", __func__);
		return;
	}

	FNDEBUG(TASK_MAIN);
	rmsHttpJson2Text(json, text, sizeof(text));
	om_response(p_datarcv, OPT_BOARD_STATUS, text);

	FNDEBUG(TASK_MAIN);
	if (json != NULL) {
		rmsHttpFreeJson(&json);
		json = NULL;
	}

	return;
}

static void proc_datareq_board_control_volume(j_datarcv_t *p_datarcv)
{
	int volume = 0;

	FNDEBUG(TASK_MAIN);
	comLog(DG, "%s()", __func__);

	/* check the volume requested! */
	FNDEBUG(TASK_MAIN);
	if ((volume = p_datarcv->addinfo.volume) < 0 || volume > 100) {
		comLog(WA, "%s() invalid value of volume (%d)", __func__, volume);
		return;
	}

	/* update the volume */
	FNDEBUG(TASK_MAIN);
	comLog(WA, "%s() update the volume (%d)", __func__, volume);
	pProfile->VoipAudioVolume = volume;

	//
	FNDEBUG(TASK_MAIN);
	appIpcSendArgs(MGPP, IMT_MGP_SET_VOLUME_REQ, 0, 0, 0);
	appProfileSave();

	/* response with result */
	om_response_result(p_datarcv, OPT_CONTROL_VOLUME, 0);

	return;
}

static void proc_datareq_board_control_reboot(j_datarcv_t *p_datarcv)
{
	FNDEBUG(TASK_MAIN);
	comLog(DG, "%s()", __func__);

	/* reboot */
	FNDEBUG(TASK_MAIN);
	appCLI_reboot();

	/* response with result */
	FNDEBUG(TASK_MAIN);
	om_response_result(p_datarcv, OPT_CONTROL_REBOOT, 0);

	return;
}

static void proc_datareq_firmware_update(j_datarcv_t *p_datarcv)
{
	FNDEBUG(TASK_MAIN);
	comLog(DG, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (!pProfile->FirmwareUpdateEnabled) {
		comLog(WA, "%s() FirmwareUpdateEnabled != TRUE. skip!!", __func__);

		/* response with result */
		FNDEBUG(TASK_MAIN);
		om_response_result(p_datarcv, OPT_CONTROL_FWUPDATE, 0);
		return;
	}

	FNDEBUG(TASK_MAIN);
	if (p_datarcv->addinfo.download_file_url == NULL
			|| strlen(p_datarcv->addinfo.download_file_url) == 0)
	{
		comLog(WA, "%s() invalid value of download file url (%s)", __func__, p_datarcv->addinfo.download_file_url);

		/* response with result */
		FNDEBUG(TASK_MAIN);
		om_response_result(p_datarcv, OPT_CONTROL_FWUPDATE, 1);
		return;
	}

	if(appVersionCheck(p_datarcv->addinfo.version) < 0) {
		comLog(WA, "%s() firmware version is %s. update not needed. update has skipped!!", __func__, p_datarcv->addinfo.version);

		/* response with result */
		FNDEBUG(TASK_MAIN);
		om_response_result(p_datarcv, OPT_CONTROL_FWUPDATE, 0);
		return;
	}

	/* update the volume */
	FNDEBUG(TASK_MAIN);
	comLog(WA, "%s() do firmware update (%s)", __func__, p_datarcv->addinfo.download_file_url);
	appCLI_fwupdate(p_datarcv->addinfo.installer_url, p_datarcv->addinfo.download_file_url); 
	
	/* response with result */
	FNDEBUG(TASK_MAIN);
	om_response_result(p_datarcv, OPT_CONTROL_FWUPDATE, 0);

	return;
}

static void proc_datareq_log_upload(j_datarcv_t *p_datarcv)
{
	FNDEBUG(TASK_MAIN);
	comLog(DG, "%s()", __func__);

}

static void proc_datareq(scmsg_t *p_scmsg)
{
	json_t     *json = NULL;
	j_datarcv_t datarcv;

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	scf_sock_send_datares(p_scmsg->h.payload_id, SCM_RC_EOK, NULL);

	FNDEBUG(TASK_MAIN);
	if ((json = rmsHttpText2Json(p_scmsg->datareq.data)) == NULL) {
		comLog(ER, "%s() - fail to rmsHttpText2Json()", __func__);
		goto out;
	}

	FNDEBUG(TASK_MAIN);
	if (rmsJsonUnpack_datarcv(json, &datarcv) == -1) {
		comLog(ER, "%s() - fail to rmsJsonUnpack_datarcv()", __func__);
		goto out;
	}

	FNDEBUG(TASK_MAIN);
	/* INACTIVE */
	if (strcmp(CTYPE_CONTROL_EVENT_INACTIVATE, datarcv.ctype) == 0) {
		FNDEBUG(TASK_MAIN);
		proc_datareq_inactive(&datarcv);
	}
	/* GRANTED */
	else if (strcmp(CTYPE_FLOOR_EVENT_GRANT, datarcv.ctype) == 0) {
		FNDEBUG(TASK_MAIN);
		proc_datareq_grant(&datarcv);
	}
	/* ACTIVATE */
	else if (strcmp(CTYPE_STATUS_EVENT_USER_ENTER, datarcv.ctype) == 0) {
		FNDEBUG(TASK_MAIN);
		proc_datareq_activate(&datarcv);
	}
	/* INVITE */
	else if (strcmp(CTYPE_CONTROL_INVITE, datarcv.ctype) == 0) {
		FNDEBUG(TASK_MAIN);
		proc_datareq_invite(&datarcv);
	}
	/* BAN */
	else if (strcmp(CTYPE_CONTROL_BAN, datarcv.ctype) == 0) {
		FNDEBUG(TASK_MAIN);
		proc_datareq_ban(&datarcv);
	}
	/* BOARD_STATUS */
	else if (strcmp(CTYPE_EMS_BOARD_STATUS, datarcv.ctype) == 0) {
		FNDEBUG(TASK_MAIN);
		proc_datareq_board_status(&datarcv);
	}
	/* BOARD_CONTROL_VOLUME */
	else if (strcmp(CTYPE_EMS_BOARD_CONTROL_VOLUME, datarcv.ctype) == 0) {
		FNDEBUG(TASK_MAIN);
		proc_datareq_board_control_volume(&datarcv);
	}
	/* BOARD_CONTROL_REBOOT */
	else if (strcmp(CTYPE_EMS_BOARD_CONTROL_REBOOT, datarcv.ctype) == 0) {
		FNDEBUG(TASK_MAIN);
		proc_datareq_board_control_reboot(&datarcv);
	}
	/* FIRMWARE_UPDATE */
	else if (strcmp(CTYPE_EMS_FIRMWARE_UPDATE, datarcv.ctype) == 0) {
		FNDEBUG(TASK_MAIN);
		proc_datareq_firmware_update(&datarcv);
	}
	/* LOG_UPLOAD */
	else if (strcmp(CTYPE_EMS_LOG_UPLOAD, datarcv.ctype) == 0) {
		FNDEBUG(TASK_MAIN);
		proc_datareq_log_upload(&datarcv);
	}

out:
	FNDEBUG(TASK_MAIN);
	if (json != NULL) {
		rmsHttpFreeJson(&json);
	}

	return;
}

static void proc_datares(scmsg_t *p_scmsg)
{
	scpool_t   *p_pool = NULL;
	json_t     *json   = NULL;

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if ((p_pool = rmsScpoolGetResponsed(&pOz->scbase, p_scmsg->h.payload_id)) == NULL) {
		FNDEBUG(TASK_MAIN);
		comLog(ER, "%s() - not requested! - pid: %u", __func__, p_scmsg->h.payload_id);
		goto out;
	}

	FNDEBUG(TASK_MAIN);
	if ((json = rmsHttpText2Json(p_scmsg->datares.ack_data)) == NULL) {
		FNDEBUG(TASK_MAIN);
		comLog(ER, "%s() - fail to rmsHttpText2Json()", __func__);
		goto out;
	}

	FNDEBUG(TASK_MAIN);
	if (rmsJsonUnpack_datarcv(json, &p_pool->_d.res.datarcv) == -1) {
		FNDEBUG(TASK_MAIN);
		comLog(ER, "%s() - fail to rmsJsonUnpack_datarcv()", __func__);
		goto out;
	}

	/* JOIN -------------- */
	FNDEBUG(TASK_MAIN);
	switch (p_pool->_d.type) {
		case JPT_JOIN:
			FNDEBUG(TASK_MAIN);
			/* failed */
			if (p_scmsg->h.result != 0 || p_pool->_d.res.datarcv.result.code != 200) {
				FNDEBUG(TASK_MAIN);
				comLog(ER, "%s() - join failed! - result: %d[0], code: %d[200], sid: %lu", __func__,
						p_scmsg->h.result, p_pool->_d.res.datarcv.result.code, p_pool->_d.sid);
				channel_status_update(0, CST_IDLE, __func__);
				goto out;
			}

			/* success */
			FNDEBUG(TASK_MAIN);
			comLog(IN, "%s() - join success! - sid: %lu, dst_ip: %s, dst_aport: %d, dst_mport:%d, codec:%s, call_id: %s", __func__,
					p_pool->_d.sid,
					p_pool->_d.res.datarcv.dst_ip,
					p_pool->_d.res.datarcv.dst_port,
					p_pool->_d.res.datarcv.dst_tbcp_port,
					p_pool->_d.res.datarcv.codec,
					p_pool->_d.res.datarcv.call_id);

			FNDEBUG(TASK_MAIN);
			appProfileUpdateVoipInfo(
					p_pool->_d.res.datarcv.dst_ip,
					p_pool->_d.res.datarcv.dst_port, 
					p_pool->_d.res.datarcv.dst_tbcp_port, 
					p_pool->_d.res.datarcv.codec,
					p_pool->_d.res.datarcv.call_id);

			FNDEBUG(TASK_MAIN);
			channel_status_update(pProfile->ChannelSID, CST_JOINED, __func__);

			//process with current status (JOINED)
			FNDEBUG(TASK_MAIN);
			timer_proc_channel_joined();
			break;

		case JPT_LEAVE:
			FNDEBUG(TASK_MAIN);
			break;
	}

out:

	FNDEBUG(TASK_MAIN);
	if (json != NULL) {
		rmsHttpFreeJson(&json);
	}

	FNDEBUG(TASK_MAIN);
	if (p_pool != NULL) {
		rmsScpoolRelease(&pOz->scbase, p_pool);
		p_pool = NULL;
	}

	return;
}

int scf_sock_proc(fd_set *rset)
{
	scmsg_t *p_scmsg = &pOz->recvwrap.uemsg;
	int n;

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	//if (!FD_ISSET(pOz->ns.psockfd, rset)) { return 0; }

	FNDEBUG(TASK_MAIN);
	while ((n = rmsScMesgRecvTcp(&pOz->ns, &pOz->recvwrap)) > 0) {
		switch (p_scmsg->h.command_id) {
			case SCM_BIND_RES: proc_bindres(p_scmsg); break;
			case SCM_PING_REQ: proc_pingreq(p_scmsg); break;
			case SCM_PING_RES: proc_pingres(p_scmsg); break;
			case SCM_DATA_REQ: proc_datareq(p_scmsg); break;
			case SCM_DATA_RES: proc_datares(p_scmsg); break;
		}
	}

	FNDEBUG(TASK_MAIN);
	if (n == -1) { appNonbsockClose(&pOz->ns); }

	return 0;
}

int scf_sock_check_expired(time_t current)
{
	scpool_t *p_pool  = NULL;

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	while ((p_pool= rmsScpoolGetExpired(&pOz->scbase, current)) != NULL) {
		switch (p_pool->_d.type) {
			case JPT_JOIN:
				FNDEBUG(TASK_MAIN);
				channel_status_update(0, CST_IDLE, __func__);
				break;

			case JPT_LEAVE:
				FNDEBUG(TASK_MAIN);
				/* ignore?? */
				break;
		}
		rmsScpoolRelease(&pOz->scbase, p_pool);
	}
	FNDEBUG(TASK_MAIN);

	return 0;
}

int scf_sock_check_outgoing()
{
	scpool_t *p_pool  = NULL;

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (pOz->ns.pstatus != TST_KIN) {
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	while ((p_pool = rmsScpoolPutSending(&pOz->scbase, SCPOOL_WINSZ)) != NULL) {
		FNDEBUG(TASK_MAIN);
		if (scf_sock_send_datareq(
					p_pool->id, 
					p_pool->_d.sid, 
					p_pool->_d.sid, 
					p_pool->_d.action, 
					p_pool->_d.rawreq) == -1)
		{
			comLog(ER, "%s() - fail to scf_sock_send_datareq()", __func__);
			break;
		}
	}

	return 0;
}

int scf_sock_check_bound()
{
	scpool_t **pp_pool = NULL;
	int i;

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (pOz->ns.pstatus != TST_KIN) {
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	if ((pp_pool = rmsScpoolAllocArray(&pOz->scbase, &pOz->scbase.sendQ)) != NULL) {
		FNDEBUG(TASK_MAIN);
		for (i = 0; pp_pool[i] != NULL; i++) {
			if (scf_sock_send_datareq(
						pp_pool[i]->id, 
						pp_pool[i]->_d.sid, 
						pp_pool[i]->_d.sid, 
						pp_pool[i]->_d.action, 
						pp_pool[i]->_d.rawreq) == -1)
			{
				FNDEBUG(TASK_MAIN);
				comLog(ER, "%s() - fail to scf_sock_send_datareq()", __func__);
				break;
			}
		}

		FNDEBUG(TASK_MAIN);
		free(pp_pool);
	}

	FNDEBUG(TASK_MAIN);
	scf_sock_check_outgoing();

	FNDEBUG(TASK_MAIN);
	timer_proc_channel_idle();

	FNDEBUG(TASK_MAIN);
	timer_proc_channel_roomed();

	return 0;
}

int scf_sock_check()
{
	time_t      current = comTime();
	nonbsock_t *p_ns  = &pOz->ns;
	char        sockname[MAX_HOST_SIZE];

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	scf_sock_check_expired(current);

	FNDEBUG(TASK_MAIN);
	switch (p_ns->pstatus) {
		case TST_CLOSED     :
			FNDEBUG(TASK_MAIN);
			if (pProfile->SCFTcpFaultTime == 0) {
				pProfile->SCFTcpFaultTime = current;
			}
			if ((current - p_ns->chgtime) >= SCF_BINDING_TIMEO) {
				/* init wrap */
				memset(&pOz->sendwrap, 0x00, sizeof(scmsgwrap_t));
				memset(&pOz->recvwrap, 0x00, sizeof(scmsgwrap_t));

				/* then, connect */
				if (READY1() && READY2()) {
					appNonbsockConnect(p_ns, pProfile->SCFTcpServerHost, pProfile->SCFTcpServerPort);
				}
			}
			break;

		case TST_CONNECTING :
			FNDEBUG(TASK_MAIN);
			if (comWritableTimeo(p_ns->psockfd, 0) > 0) {
				appNonbsockUpdate(p_ns, TST_CONNECTED);
			}
			else if ((current - p_ns->chgtime) >= SCF_BINDING_TIMEO) {
				comLog(IN, "%s() CONNECT TIMEOUT!!", __func__);
				appNonbsockClose(p_ns);
			}
			break;

		case TST_CONNECTED  :
			FNDEBUG(TASK_MAIN);
			if (scf_sock_send_bindreq() != -1) {
				appNonbsockUpdate(p_ns, TST_BINDING);
			}
			break;

		case TST_BINDING    :
			FNDEBUG(TASK_MAIN);
			if ((current - p_ns->chgtime) >= SCF_BINDING_TIMEO) {
				comLog(IN, "%s() BINDING TIMEOUT!!", __func__);
				appNonbsockClose(p_ns);
			}
			break;

		case TST_KIN        :
			FNDEBUG(TASK_MAIN);
			if ((current - p_ns->rcvtime) >= pProfile->SCFTcpLostSec) {
				comLog(ER, "%s() IDLE SCF FOUND...", __func__);
				appNonbsockClose(p_ns);
				break;
			}
			if ((current - p_ns->pngtime) >= pProfile->SCFTcpIdleSec) {
				scf_sock_send_pingreq();
				p_ns->pngtime = current;
			}
			break;
	}

	FNDEBUG(TASK_MAIN);
	scf_sock_check_outgoing();

	FNDEBUG(TASK_MAIN);
	if (p_ns->pstatus != pProfile->SCFTcpStatus) {
		FNDEBUG(TASK_MAIN);
		pProfile->SCFTcpStatus = p_ns->pstatus;
		comLog(DG, "%s() UPDATE SCF PSTATUS... %d", __func__, p_ns->pstatus);

		switch (p_ns->pstatus) {
			case TST_CONNECTED:
			case TST_KIN:
				if (p_ns->psockfd > 0
						&& comGetSockName(p_ns->psockfd, sockname, sizeof(sockname)) != -1
						&& strlen(sockname) > 0
						&& strcmp(sockname, pProfile->SCFTcpSourceIp) != 0)
				{
					FNDEBUG(TASK_MAIN);
					comLog(IN, "%s() UPDATE SCF SOCKNAME... |%s| -> |%s|", __func__, pProfile->SCFTcpSourceIp, sockname);
					snprintf(pProfile->SCFTcpSourceIp, sizeof(pProfile->SCFTcpSourceIp), "%s", sockname);
				}
				break;
		}
	}

	return 0;
}

/************************************************************/
/* JOIN                                                     */
/************************************************************/
int scf_sock_request_join()
{
	scpool_t     *p_pool = NULL;
	j_joinreq_t  *p_oreq = NULL;
	json_t       *p_jreq = NULL;

	long sid; 
	int  result = -1;

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if ((p_pool = rmsScpoolAlloc(&pOz->scbase)) == NULL) {
		comLog(ER, "%s() - fail to rmsScpoolAlloc()", __func__);
		goto out;
	}

	FNDEBUG(TASK_MAIN);
	if ((sid = pProfile->ChannelSID) == 0) {
		comLog(ER, "%s() - no channel - SID: %lu", __func__, sid);
		goto out;
	}
	memset(&p_pool->_d, 0x00, sizeof(scpooldata_t));

	FNDEBUG(TASK_MAIN);
	p_oreq = &p_pool->_d.req.join;

	/* POOLDATA.REQ.JOIN */
	FNDEBUG(TASK_MAIN);
	p_oreq->sid = sid;
	snprintf(p_oreq->ctype, sizeof(p_oreq->ctype), "%s", CTYPE_CHANNEL_JOIN);
	snprintf(p_oreq->telecom_code, sizeof(p_oreq->telecom_code), "%s", TELECOM_CODE);
	snprintf(p_oreq->codec       , sizeof(p_oreq->codec)       , "%s,%s", S_OPUS_WB, S_PCMU);
	snprintf(p_oreq->roaming     , sizeof(p_oreq->roaming)     , "N");
	rmsGetTimestamp(p_oreq->timestamp, sizeof(p_oreq->timestamp));
	rmsGetISO8601  (p_oreq->datetime , sizeof(p_oreq->datetime));
	rmsGetUUID     (p_oreq->mesg_id  , sizeof(p_oreq->mesg_id));

	/* POOLDATA.REQ.JOIN.FROM */
	FNDEBUG(TASK_MAIN);
	snprintf(p_oreq->from.mdn , sizeof(p_oreq->from.mdn ), "%s", pProfile->E164);
	snprintf(p_oreq->from.name, sizeof(p_oreq->from.name), "%s", pProfile->E164);
	p_oreq->from.iuid = pProfile->IUID;

	/* POOLDATA.REQ.JOIN.VOIP */
	FNDEBUG(TASK_MAIN);
	snprintf(p_oreq->src_ip, sizeof(p_oreq->src_ip), "%s", pProfile->SCFTcpSourceIp);
	p_oreq->src_port      = VOIP_APORT;
	p_oreq->src_tbcp_port = VOIP_MPORT;

	/* POOLDATA.RAWREQ */
	FNDEBUG(TASK_MAIN);
	if ((p_jreq = rmsJsonPack_joinreq(p_oreq)) == NULL) {
		comLog(ER, "%s() - fail to rmsJsonPack_joinreq()", __func__);
		goto out;
	}
	FNDEBUG(TASK_MAIN);
	if (rmsHttpJson2Text(p_jreq, p_pool->_d.rawreq, MAX_SCRAWDATA_SIZE) == NULL) {
		comLog(ER, "%s() - fail to rmsHttpJson2Text()", __func__);
		goto out;
	}

	/* POOLDATA */
	FNDEBUG(TASK_MAIN);
	p_pool->_d.type   = JPT_JOIN;
	p_pool->_d.sid    = sid;
	p_pool->_d.action = ACTION_CHANNEL_JOIN;

	FNDEBUG(TASK_MAIN);
	if (rmsScpoolPutPending(&pOz->scbase, p_pool, comTime() + SCPOOL_EXPTIMEO) == NULL) {
		comLog(ER, "%s() - fail to rmsScpoolPutPending()", __func__);
		goto out;
	}

	FNDEBUG(TASK_MAIN);
	scf_sock_check_outgoing();
	result = 0;

out:

	FNDEBUG(TASK_MAIN);
	if (result == -1) {
		if (p_pool != NULL) {
			rmsScpoolRelease(&pOz->scbase, p_pool);
			p_pool  = NULL;
		}
	}

	/* don't forget!! */
	FNDEBUG(TASK_MAIN);
	if (p_jreq != NULL) {
		rmsHttpFreeJson(&p_jreq);
		p_jreq = NULL;
	}

	return result;
}

/************************************************************/
/* LEAVE                                                    */
/************************************************************/
int scf_sock_request_leave()
{
	scpool_t     *p_pool = NULL;
	j_leavereq_t *p_oreq = NULL;
	json_t       *p_jreq = NULL;

	long sid; 
	int  result = -1;

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if ((p_pool = rmsScpoolAlloc(&pOz->scbase)) == NULL) {
		comLog(ER, "%s() - fail to rmsScpoolAlloc()", __func__);
		goto out;
	}

	FNDEBUG(TASK_MAIN);
	if ((sid = pProfile->ChannelSID) == 0) {
		comLog(ER, "%s() - no channel - SID: %lu", __func__, sid);
		goto out;
	}

	FNDEBUG(TASK_MAIN);
	memset(&p_pool->_d, 0x00, sizeof(scpooldata_t));

	FNDEBUG(TASK_MAIN);
	p_oreq = &p_pool->_d.req.leave;

	/* POOLDATA.REQ.LEAVE */
	FNDEBUG(TASK_MAIN);
	p_oreq->sid = sid;
	snprintf(p_oreq->ctype        , sizeof(p_oreq->ctype)  , "%s", CTYPE_CHANNEL_LEAVE);
	snprintf(p_oreq->roaming      , sizeof(p_oreq->roaming), "N");
	rmsGetISO8601(p_oreq->datetime, sizeof(p_oreq->datetime));
	rmsGetUUID   (p_oreq->mesg_id , sizeof(p_oreq->mesg_id));
	//snprintf(oreq.call_id     , sizeof(oreq.call_id)      , "%s", call_id);

	/* POOLDATA.REQ.LEAVE.FROM */
	FNDEBUG(TASK_MAIN);
	snprintf(p_oreq->from.mdn , sizeof(p_oreq->from.mdn ), "%s", pProfile->E164);
	snprintf(p_oreq->from.name, sizeof(p_oreq->from.name), "%s", pProfile->E164);
	p_oreq->from.iuid = pProfile->IUID;

	/* POOLDATA.REQ.LEAVE.CAUSE */
	FNDEBUG(TASK_MAIN);
	p_oreq->cause.code = 0;

	/* POOLDATA.RAWREQ */
	FNDEBUG(TASK_MAIN);
	if ((p_jreq = rmsJsonPack_leavereq(p_oreq)) == NULL) {
		comLog(ER, "%s() - fail to rmsJsonPack_leavereq()", __func__);
		goto out;
	}

	FNDEBUG(TASK_MAIN);
	if (rmsHttpJson2Text(p_jreq, p_pool->_d.rawreq, MAX_SCRAWDATA_SIZE) == NULL) {
		comLog(ER, "%s() - fail to rmsHttpJson2Text()", __func__);
		goto out;
	}

	/* POOLDATA */
	FNDEBUG(TASK_MAIN);
	p_pool->_d.type   = JPT_LEAVE;
	p_pool->_d.sid    = sid;
	p_pool->_d.action = ACTION_CHANNEL_LEAVE;

	FNDEBUG(TASK_MAIN);
	if (rmsScpoolPutPending(&pOz->scbase, p_pool, comTime() + SCPOOL_EXPTIMEO) == NULL) {
		comLog(ER, "%s() - fail to rmsScpoolPutPending()", __func__);
		goto out;
	}

	FNDEBUG(TASK_MAIN);
	scf_sock_check_outgoing();
	result = 0;

out:

	FNDEBUG(TASK_MAIN);
	if (result == -1) {
		if (p_pool != NULL) {
			rmsScpoolRelease(&pOz->scbase, p_pool);
			p_pool  = NULL;
		}
	}

	/* don't forget!! */
	FNDEBUG(TASK_MAIN);
	if (p_jreq != NULL) {
		rmsHttpFreeJson(&p_jreq);
		p_jreq = NULL;
	}

	return result;
}






