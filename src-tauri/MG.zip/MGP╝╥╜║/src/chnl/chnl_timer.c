/**
 * @date   2016/08/17
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */
#include "chnl.h"

#ifdef _HAVE_USIM
#include "modem.h"
#endif

/* for debug */
#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_TIMER, __LINE__)

static int get_mobile_number()
{
#ifdef _HAVE_USIM
	char cnum[MAX_MDN_LEN];
	DST_MODEM_RESULT result = modem_get_cnum(cnum, sizeof(cnum));
	if (result != eDST_MODEM_OK) {
		comLog(ER, "%s() - fail to modem_get_cnum() - result: %d", __func__, result);
		return -1;
	}
	else {
		comLog(IN, "%s() - modem_get_cnum() - cnum: %s", __func__, cnum);
	}
	snprintf(MobileNumber, sizeof(MobileNumber), "+82%s", cnum + 1);
#else
	snprintf(MobileNumber, sizeof(MobileNumber), "%s", pProfile->E164);
#endif

	return 0;
}

static int check_mobile_number()
{
	FNDEBUG(TASK_MAIN);
	if (get_mobile_number() == -1 || strlen(MobileNumber) == 0) {
		comLog(WA, "%s() - fail to get_mobile_number()", __func__);
		return -1;
	}
	comLog(IN, "%s() - mobile number: %s", __func__, MobileNumber);

	FNDEBUG(TASK_MAIN);
	if (strcmp(pProfile->E164, MobileNumber) == 0) {
		comLog(IN, "%s() - mobile number is equals! %s[%s]", __func__, pProfile->E164, MobileNumber);
		return 0;
	}

	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - mobile number is changed! %s -> %s", __func__, pProfile->E164, MobileNumber);

	snprintf(pProfile->E164, sizeof(pProfile->E164), "%s", MobileNumber);
	pProfile->IUID = 0;

	return 0;
}

static void timer_check_chnlpack_deviceinfo(jsonpack_t *p_pack)
{
	int i, j;
	j_serverinfo_t *p_server;

	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	switch (p_pack->status) {
		case JPS_SUCCESS:
			FNDEBUG(TASK_MAIN);
			comLog(IN, "%s() - deviceinfo success! - iuid: %lu, auth_key: %s", __func__,
					p_pack->res.deviceinfo.iuid,
					p_pack->res.deviceinfo.auth_key);

			FNDEBUG(TASK_MAIN);
			pProfile->IUID = p_pack->res.deviceinfo.iuid;
			snprintf(pProfile->AuthKey, sizeof(pProfile->AuthKey), "%s", p_pack->res.deviceinfo.auth_key);

			FNDEBUG(TASK_MAIN);
			for (i = 0; i < p_pack->res.deviceinfo.server_count && i < MAX_SERVERINFO_NUM; i++) {
				p_server = p_pack->res.deviceinfo.servers + i;
				if (strcmp("WS", p_server->name) == 0) {
					for (j = 0; j < p_server->connection_count && j < MAX_SERVERCONN_NUM; j++) {
						if (strcmp("http", p_server->connections[j].protocol) == 0) {
							snprintf(pProfile->RMSHttpServerHost, sizeof(pProfile->RMSHttpServerHost), "%s", p_server->connections[j].ip);
							pProfile->RMSHttpServerPort = p_server->connections[j].port;
						}
					}
				}
				if (strcmp("SCF", p_server->name) == 0) {
					for (j = 0; j < p_server->connection_count && j < MAX_SERVERCONN_NUM; j++) {
						if (strcmp("tcp", p_server->connections[j].protocol) == 0) {
							snprintf(pProfile->SCFTcpServerHost, sizeof(pProfile->SCFTcpServerHost), "%s", p_server->connections[j].ip);
							pProfile->SCFTcpServerPort = p_server->connections[j].port;
						}
					}
				}
			}
			FNDEBUG(TASK_MAIN);
			appProfileSave();

			FNDEBUG(TASK_MAIN);
			timer_proc_channel_idle();
			break;

		case JPS_FAIL:
			FNDEBUG(TASK_MAIN);
			break;
	}

	return;
}

static void timer_check_chnlpack_showmylist(jsonpack_t *p_pack)
{
	j_roomlistvalue_t *p_room;

	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	switch (p_pack->status) {
		case JPS_SUCCESS:
			FNDEBUG(TASK_MAIN);
			p_room = p_pack->res.showmylist.room_list + 0;
			if (p_room->sid > 0) {
				FNDEBUG(TASK_MAIN);
				channel_status_update(p_room->sid, CST_ROOMED, __func__);

				//process with current status (ROOMED)
				timer_proc_channel_roomed();
			}
			else {
				FNDEBUG(TASK_MAIN);
				channel_status_update(0, CST_IDLE, __func__);
			}

			break;

		case JPS_FAIL:
			FNDEBUG(TASK_MAIN);
			channel_status_update(0, CST_IDLE, __func__);
			break;
	}

	return;
}

#if 0
static void timer_check_chnlpack_join(jsonpack_t *p_pack)
{
	j_datarcv_t *p_datarcv = &p_pack->res.datarcv;
	j_joinreq_t *p_join    = &p_pack->req.join;

	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	switch (p_pack->status) {
		case JPS_SUCCESS:
			FNDEBUG(TASK_MAIN);
			comLog(IN, "%s() - join success! - sid: %lu, dst_ip: %s, dst_aport: %d, dst_mport:%d, call_id: %s", __func__,
					p_join->sid,
					p_datarcv->dst_ip,
					p_datarcv->dst_port,
					p_datarcv->dst_tbcp_port,
					p_datarcv->call_id);

			FNDEBUG(TASK_MAIN);
			snprintf(pProfile->VoipDestIp, sizeof(pProfile->VoipDestIp), "%s", p_datarcv->dst_ip);
			pProfile->VoipDestAPort = p_datarcv->dst_port;
			pProfile->VoipDestMPort = p_datarcv->dst_tbcp_port;

			FNDEBUG(TASK_MAIN);
			channel_status_update(pProfile->ChannelSID, CST_JOINED, __func__);

			//process with current status (JOINED)
			FNDEBUG(TASK_MAIN);
			timer_proc_channel_joined();

			break;

		case JPS_FAIL:
			FNDEBUG(TASK_MAIN);
			comLog(WA, "%s() - join failed! - sid: %lu", __func__, p_join->sid);
			channel_status_update(0, CST_IDLE, __func__);
			break;
	}

	return;
}
#endif

void timer_check_chnlpack(time_t current)
{
	jsonpack_t *p_pack;
	time_t elapsed = 0;
	int i;

	comLog(VB, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	for (i = 0; i < MAX_CHNLPACK_NUM; i++) {
		if ((p_pack = CHNLPACK_PTR(i, __func__)) == NULL) {
			continue;
		}

		/* do by type */
		FNDEBUG(TASK_MAIN);
		switch (p_pack->type) {
			case JPT_DEVICEINFO:
				FNDEBUG(TASK_MAIN);
				timer_check_chnlpack_deviceinfo(p_pack);
				break;

			case JPT_SHOWMYLIST:
				FNDEBUG(TASK_MAIN);
				timer_check_chnlpack_showmylist(p_pack);
				break;
#if 0
			case JPT_JOIN:
				FNDEBUG(TASK_MAIN);
				timer_check_chnlpack_join(p_pack);
				break;

			case JPT_LEAVE:
				FNDEBUG(TASK_MAIN);
				/* DO NOTHING!! */
				break;
#endif
		}

		/* do by status */
		FNDEBUG(TASK_MAIN);
		switch (p_pack->status) {
			case JPS_SUCCESS:
			case JPS_FAIL:
				FNDEBUG(TASK_MAIN);
				comLog(IN, "%s() completed, release this - chnlpack_id: %d", __func__, p_pack->id);
				chnlpack_release(p_pack, __func__);
				break;

			case JPS_USING :
			case JPS_REQUESTING :
				FNDEBUG(TASK_MAIN);
				if ((elapsed = current - p_pack->using_time) >= 15) {
					FNDEBUG(TASK_MAIN);
					comLog(ER, "%s() Invalid using - chnlpack_id: %d, elapsed: %u", __func__, p_pack->id, elapsed);
					chnlpack_release(p_pack, __func__);
				}
				else if ((elapsed = current - p_pack->using_time) >= 10) {
					FNDEBUG(TASK_MAIN);
					comLog(ER, "%s() Invalid using - chnlpack_id: %d, elapsed: %u", __func__, p_pack->id, elapsed);
				}
				break;
		}
	}
}

void timer_check_status(time_t current)
{
	long elapsed = 0;

	FNDEBUG(TASK_MAIN);
	switch (pProfile->ChannelStatus) {
		case CST_ROOMING :
			FNDEBUG(TASK_MAIN);
			if ((elapsed = current - pProfile->ChannelChgTime) > 15) {
				FNDEBUG(TASK_MAIN);
				comLog(WA, "%s() - ROOMING TIMER expired! - elapsed: %lu", __func__, elapsed);
				channel_status_update(0, CST_IDLE, __func__);
			}
			break;

		case CST_JOINING:
			FNDEBUG(TASK_MAIN);
			if ((elapsed = current - pProfile->ChannelChgTime) > 15) {
				FNDEBUG(TASK_MAIN);
				comLog(WA, "%s() - JOINING TIMER expired! - elapsed: %lu", __func__, elapsed);
				channel_status_update(0, CST_IDLE, __func__);
			}

		case CST_ACTIVATING:
			FNDEBUG(TASK_MAIN);
			if (pProfile->VoipRunning) {
				FNDEBUG(TASK_MAIN);
				comLog(WA, "%s() - VoipRunning... true", __func__);
				channel_status_update(pProfile->ChannelSID, CST_ACTIVE, __func__);
			}
			else if ((elapsed = current - pProfile->ChannelChgTime) > 15) {
				FNDEBUG(TASK_MAIN);
				comLog(WA, "%s() - ACTIVATING TIMER expired! - elapsed: %lu", __func__, elapsed);
				channel_status_update(pProfile->ChannelSID, CST_LEAVING, __func__);
				scf_sock_request_leave();
				mgp_signal_stop_req();

				FNDEBUG(TASK_MAIN);
				channel_status_update(pProfile->ChannelSID, CST_ROOMED, __func__);
			}
			break;

		case CST_ACTIVE:
			FNDEBUG(TASK_MAIN);
			elapsed = (pProfile->MBCPStillAliveTime != 0) ? current - pProfile->MBCPStillAliveTime : 0;
			if (!pProfile->VoipRunning || elapsed > 30) {
				FNDEBUG(TASK_MAIN);
				comLog(WA, "%s() - invalid VoipRunning: %d, status: %s, elapsed: %lu[30]", __func__,
						pProfile->VoipRunning, appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus), elapsed);

				FNDEBUG(TASK_MAIN);
				channel_status_update(pProfile->ChannelSID, CST_LEAVING, __func__);
				scf_sock_request_leave();
				mgp_signal_stop_req();

				FNDEBUG(TASK_MAIN);
				channel_status_update(pProfile->ChannelSID, CST_ROOMED, __func__);
				timer_proc_channel_roomed();
			}
			break;
	}
}

void timer_proc_device_unknown()
{
	time_t current = comTime();

	if (READY1()) {
		comLog(VB, "%s() - invalid - iuid: %lu[0], mobile: %s", __func__, pProfile->IUID, MobileNumber);
		return;
	}

	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - iuid: %lu, mobile: %s, elapsed: %ld", __func__,
			pProfile->IUID, MobileNumber, current - pOz->last_device_time);
	pOz->last_device_time = current;

	// then, request
	FNDEBUG(TASK_MAIN);
	if (check_mobile_number() != -1) {
		timer_proc_user_unknown();
	}
}

void timer_proc_user_unknown()
{
	time_t current = comTime();

	if (!READY1() || READY2()) {
		comLog(VB, "%s() - invalid - iuid: %lu[0], mobile: %s", __func__, pProfile->IUID, MobileNumber);
		return;
	}

	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - iuid: %lu, elapsed: %ld", __func__, pProfile->IUID, current - pOz->last_usering_time);
	pOz->last_usering_time = current;

	// then, request
	FNDEBUG(TASK_MAIN);
	if (start_http_deviceinfo_req() == -1) {
		FNDEBUG(TASK_MAIN);
		comLog(WA, "%s() - failed to start_http_deviceinfo_req()", __func__);
	}
}

void timer_proc_channel_idle()
{
	time_t current = comTime();

	FNDEBUG(TASK_MAIN);
	if (!READY1() || !READY2() || pProfile->ChannelStatus != CST_IDLE) {
		FNDEBUG(TASK_MAIN);
		comLog(VB, "%s() - invalid - iuid: %lu, sid: %lu, status: %s[IDLE], mobile: %s", __func__,
				pProfile->IUID,
				pProfile->ChannelSID,
				appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus),
				MobileNumber);
		return;
	}

	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - iuid: %lu, sid: %lu, status: %s, elapsed: %ld", __func__,
			pProfile->IUID , pProfile->ChannelSID, appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus),
			current - pOz->last_rooming_time);

	// update status to ROOMING
	FNDEBUG(TASK_MAIN);
	channel_status_update(pProfile->ChannelSID, CST_ROOMING, __func__);
	pOz->last_rooming_time = current;

	// then, request
	FNDEBUG(TASK_MAIN);
	if (start_http_showmylist_req() == -1) {
		FNDEBUG(TASK_MAIN);
		comLog(WA, "%s() - failed to start_http_showmylist_req()", __func__);
		channel_status_update(0, CST_IDLE, __func__);
	}
}

void timer_proc_channel_roomed()
{
	time_t current = comTime();

	FNDEBUG(TASK_MAIN);
	if (!READY1() || !READY2() || pProfile->ChannelStatus != CST_ROOMED || pOz->ns.pstatus != TST_KIN) {
		FNDEBUG(TASK_MAIN);
		comLog(VB, "%s() - invalid - iuid: %lu, sid: %lu, status: %s[ROOMED], tcpstatus: %s[KIN]", __func__,
				pProfile->IUID,
				pProfile->ChannelSID,
				appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus),
				appCodeMap2Str(CC_TcpStatus, pOz->ns.pstatus));
		return;
	}

	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() - iuid: %lu, sid: %lu, status: %s, elapsed: %ld", __func__,
			pProfile->IUID, pProfile->ChannelSID, appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus),
			current - pOz->last_joining_time);

	// update status to JOINING
	FNDEBUG(TASK_MAIN);
	channel_status_update(pProfile->ChannelSID, CST_JOINING, __func__);
	pOz->last_joining_time = comTime();

	// then, request
	FNDEBUG(TASK_MAIN);
	if (scf_sock_request_join() == -1) {
		FNDEBUG(TASK_MAIN);
		comLog(WA, "%s() - failed to scf_sock_request_join()", __func__);
		channel_status_update(0, CST_IDLE, __func__);
	}
}

void timer_proc_channel_joined()
{
	FNDEBUG(TASK_MAIN);
	if (!READY1() || !READY2() || pProfile->ChannelStatus != CST_JOINED) {
		FNDEBUG(TASK_MAIN);
		comLog(VB, "%s() - invalid - iuid: %lu, sid: %lu, status: %s[JOINED]", __func__,
				pProfile->IUID,
				pProfile->ChannelSID,
				appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus));
		return;
	}

	FNDEBUG(TASK_MAIN);
	comLog(DG, "%s() - iuid: %lu, sid: %lu, status: %s", __func__,
			pProfile->IUID, pProfile->ChannelSID, appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus));

	// update status to JOINING
	FNDEBUG(TASK_MAIN);
	channel_status_update(pProfile->ChannelSID, CST_ACTIVATING, __func__);

	// then, request
	FNDEBUG(TASK_MAIN);
	if (mgp_signal_strt_req() == -1) {
		FNDEBUG(TASK_MAIN);
		comLog(WA, "%s() - failed to mgp_signal_strt_req()", __func__);

		//
		FNDEBUG(TASK_MAIN);
		channel_status_update(pProfile->ChannelSID, CST_LEAVING, __func__);
		scf_sock_request_leave();
		mgp_signal_stop_req();

		FNDEBUG(TASK_MAIN);
		channel_status_update(pProfile->ChannelSID, CST_ROOMED, __func__);
	}

	return;
}

