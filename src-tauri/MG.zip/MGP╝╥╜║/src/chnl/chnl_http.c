/**
 * @date   2016/08/16
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */
#include "chnl.h"

/* for debug */
#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_HTTP, __LINE__)

/****************************************************************/
/*                                                              */
/* HTTP                                                         */
/*                                                              */
/****************************************************************/
static int http_showmylist_req(jsonpack_t *p_pack)
{
	httpconn_t http;

	json_t *jreq = NULL;
	json_t *jres = NULL;
	j_room_showmylistreq_t oreq;
	j_room_showmylistres_t ores;
	char sreq[128];
	int  success = 0;

	/* init head */
	rmsHttpInit(&http, pProfile->RMSHttpServerHost, pProfile->RMSHttpServerPort);
	rmsHttpHeaderInit(&http);
	rmsHttpHeaderPut_LU(&http, HH_TN_IUID, pProfile->IUID);
	rmsHttpHeaderPut_S (&http, HH_TN_AUTH_KEY, pProfile->AuthKey);
	rmsHttpHeaderPut_S (&http, HH_TN_APP_TYPE, pProfile->AppType);

	/* init request object & make it to json string */
	memset(&oreq, 0x00, sizeof(j_room_showmylistreq_t));
	snprintf(oreq.ctype, sizeof(oreq.ctype), "%s", CTYPE_ROOM_SHOW_MY_LIST);
	oreq.search_type = SEARCH_TYPE_MY;
	oreq.start_row = 1;
	oreq.end_row   = 2;

	/* setup the request */
	chnlpack_update_status(p_pack, JPS_REQUESTING, __func__);
	memcpy(&p_pack->req.showmylist, &oreq, sizeof(j_room_showmylistreq_t));

	if ((jreq = rmsJsonPack_showmylistreq(&oreq)) == NULL) {
		comLog(ER, "%s() - fail to rmsJsonPack_showmylistreq()", __func__);
		goto out;
	}

	if (rmsHttpJson2Text(jreq, sreq, sizeof(sreq)) == NULL) {
		comLog(ER, "%s() - fail to rmsHttpJson2Text()", __func__);
		goto out;
	}

	if (rmsHttpRequest(&http, HM_GET, URL_RMS, sreq, 5) == -1) {
		comLog(ER, "%s() - fail to rmsHttpRequest()", __func__);
		goto out;
	}

	if (rmsHttpResponse(&http, 5) == NULL) {
		comLog(ER, "%s() - fail to rmsHttpResponse()", __func__);
		goto out;
	}

	if (http.response.code != 200) {
		comLog(ER, "%s() - response code(%d) not expected!", __func__, http.response.code);
		goto out;
	}

	if ((jres = rmsHttpText2Json(http.response.content)) == NULL) {
		comLog(ER, "%s() - fail to rmsHttpText2Json()", __func__);
		goto out;
	}

	memset(&ores, 0x00, sizeof(ores));
	if (rmsJsonUnpack_showmylistres(jres, &ores) == -1) {
		comLog(ER, "%s() - fail to rmsJsonUnpack_showmylistres()", __func__);
		goto out;
	}

	success = 1;

out:

	if (success) {
		memcpy(&p_pack->res.showmylist, &ores, sizeof(j_room_showmylistres_t));
		chnlpack_update_status(p_pack, JPS_SUCCESS, __func__);
	}
	else {
		chnlpack_update_status(p_pack, JPS_FAIL, __func__);
	}

	/* don't forget!! */
	if (jreq != NULL) {
		rmsHttpFreeJson(&jreq);
		jreq = NULL;
	}

	/* don't forget!! */
	if (jres != NULL) {
		rmsHttpFreeJson(&jres);
		jres = NULL;
	}

	return 0;
}

static int http_deviceinfo_req(jsonpack_t *p_pack)
{
	httpconn_t http;

	char url[256];
	json_t *jres = NULL;
	j_deviceinfo_t ores;
	int  success = 0;

	/* init head */
	rmsHttpInit(&http, pProfile->ACSHttpServerHost, pProfile->ACSHttpServerPort);
	rmsHttpHeaderInit(&http);
	rmsHttpHeaderPut_S(&http, HH_TN_REQ_USER, pProfile->E164);

	/* init url */
	memset(&url, 0x00, sizeof(url));
	snprintf(url, sizeof(url), "%s?os-type=linux", URL_ACS_DEVICEINFO);

	/* setup the request */
	chnlpack_update_status(p_pack, JPS_REQUESTING, __func__);

	if (rmsHttpRequest(&http, HM_GET, url, NULL, 5) == -1) {
		comLog(ER, "%s() - fail to rmsHttpRequest()", __func__);
		goto out;
	}

	if (rmsHttpResponse(&http, 5) == NULL) {
		comLog(ER, "%s() - fail to rmsHttpResponse()", __func__);
		goto out;
	}

	if (http.response.code != 200) {
		comLog(ER, "%s() - response code(%d) not expected!", __func__, http.response.code);
		goto out;
	}

	if ((jres = rmsHttpText2Json(http.response.content)) == NULL) {
		comLog(ER, "%s() - fail to rmsHttpText2Json()", __func__);
		goto out;
	}

	memset(&ores, 0x00, sizeof(ores));
	if (rmsJsonUnpack_deviceinfo(jres, &ores) == -1) {
		comLog(ER, "%s() - fail to rmsJsonUnpack_deviceinfo()", __func__);
		goto out;
	}

	success = 1;

out:

	if (success) {
		memcpy(&p_pack->res.deviceinfo, &ores, sizeof(j_deviceinfo_t));
		chnlpack_update_status(p_pack, JPS_SUCCESS, __func__);
	}
	else {
		chnlpack_update_status(p_pack, JPS_FAIL, __func__);
	}

	/* don't forget!! */
	if (jres != NULL) {
		rmsHttpFreeJson(&jres);
		jres = NULL;
	}

	return 0;
}

/****************************************************************/
/*                                                              */
/* Thread                                                       */
/*                                                              */
/****************************************************************/
void *httpInvoker(void *arg)
{
	jsonpack_t *p_pack = (jsonpack_t *)arg;

	comLog(DG, "%s() TID(%lu) STARTED", __func__, pthread_self());

	switch (p_pack->type) {
		case JPT_DEVICEINFO:
			http_deviceinfo_req(p_pack);
			break;

		case JPT_SHOWMYLIST:
			http_showmylist_req(p_pack);
			break;

		default:
			comLog(WA, "%s() INVALID type(%d)", __func__, p_pack->type);
			break;
	}

	comLog(DG, "%s() TID(%lu) STOPPED", __func__, pthread_self());
	appPipeSignal(&pOz->np);

	comThreadExit();

	return NULL;
}

int start_http_showmylist_req()
{
	jsonpack_t *p_pack = chnlpack_alloc(__func__);
	pthread_t  tid;

	if (p_pack == NULL) {
		comLog(ER, "%s() fail to chnlpack_alloc()", __func__);
		return -1;
	}

	chnlpack_update_type(p_pack, JPT_SHOWMYLIST, __func__);

	if (comThreadCreate(&tid, httpInvoker, p_pack) == -1) {
		comLog(ER, "%s() fail to comThreadCreate()", __func__);
		chnlpack_release(p_pack, __func__);
		return -1;
	}

	return 0;
}

int start_http_deviceinfo_req()
{
	jsonpack_t *p_pack = chnlpack_alloc(__func__);
	pthread_t  tid;

	if (p_pack == NULL) {
		comLog(ER, "%s() fail to chnlpack_alloc()", __func__);
		return -1;
	}

	chnlpack_update_type(p_pack, JPT_DEVICEINFO, __func__);

	if (comThreadCreate(&tid, httpInvoker, p_pack) == -1) {
		comLog(ER, "%s() fail to comThreadCreate()", __func__);
		chnlpack_release(p_pack, __func__);
		return -1;
	}

	return 0;
}



