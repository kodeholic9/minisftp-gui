/**
 * @date   2016/07/26
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */
#include "chnl.h"

/* for debug */
#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_MAIN, __LINE__)

/* for main */
chnlmagic_t    Oz;
chnlmagic_t  *pOz = &Oz;

/* for mobile number */
char MobileNumber[MAX_MDN_LEN];

time_t Every01Sec  = 0;
time_t Every05Sec  = 0;
time_t Every10Sec  = 0;
time_t Every30Sec  = 0;
time_t Every60Sec  = 0;
time_t Every120Sec = 0;
time_t Every300Sec = 0;

int is_first_timer_loop = 1;

/* main.. */
int main(int argc, char **argv)
{
	ipcmsg_t *p_ipcmsg;
	int timrnum = 0, procnum = 0, cntlnum = 0;
	int usec;

	fd_set rset;

	/* init LogLevel */
	comLogLevelSet(IN);

	/* INITIALIZE */
	if (initialize(argc, argv) == -1) {
		comLog(ER, "fail to initialize.");
		terminate(2);
	}

	/* NEVER DIE!! */
	FNDEBUG(TASK_MAIN);
	while (Oz.running) {
		FNDEBUG(TASK_MAIN);
		if (getppid() == 1) {
			comLog(ER, "the parent process is down!");
			Oz.running = FALSE;
			break;
		}

		FNDEBUG(TASK_MAIN);
		if ((procnum + timrnum + cntlnum) > 0) { usec = 10  *1000; }
		else                                   { usec = 1000*1000; }

		FNDEBUG(TASK_MAIN);
		procnum = 0;
		if (wait_for(&rset, usec) > 0) {
			FNDEBUG(TASK_MAIN);
			procnum = proc_sock(&rset);
		}

		FNDEBUG(TASK_MAIN);
		cntlnum = 0;
		if (appIpcRecvMsg(&p_ipcmsg, 0) != -1) {
			comLog(DG, "process something with ipc!!");
			cntlnum = proc_ipc(p_ipcmsg);
		}

		FNDEBUG(TASK_MAIN);
		timrnum = proc_timer();
	}

	/* TERMINATE */
	FNDEBUG(TASK_MAIN);
	terminate(99);

	return 0;
}

/****************************************************************/
/*                                                              */
/* CHECK READY                                                  */
/*                                                              */
/****************************************************************/
int READY1() {
	return (strlen(MobileNumber) != 0);
}
int READY2() {
	return (pProfile->IUID > 0);
}

int wait_for(fd_set *rset, int usec)
{
	struct timeval timeo;
	int    cc;

	/* CHECK INPUT EVENT */
	FNDEBUG(TASK_MAIN);
	timeo.tv_sec  = 0;
	timeo.tv_usec = usec;
	memcpy(rset, &pOz->rmask, sizeof(fd_set));

	FNDEBUG(TASK_MAIN);
	if ((cc = select(pOz->maxfd, rset, NULL, NULL, &timeo)) == -1) {
		FNDEBUG(TASK_MAIN);
		if (errno != EINTR) {
			FNDEBUG(TASK_MAIN);
			comErr(ER, errno, "fail to select.");
			terminate(98);
		}
	}
	//comLog(DG, "%s() - usec: %d, cc: %d", __func__, usec, cc);

	FNDEBUG(TASK_MAIN);
	return cc;
}

int proc_sock(fd_set *rset)
{
	FNDEBUG(TASK_MAIN);
	if (FD_ISSET(pOz->ns.psockfd, rset)) { 
		comLog(DG, "%s() - ready to process with sock!!", __func__);
		scf_sock_proc(rset);
	}

	FNDEBUG(TASK_MAIN);
	if (FD_ISSET(pOz->np.pipefd[0], rset)) { 
		comLog(DG, "%s() - ready to process with pipe!!", __func__);
		appPipeSignalled(&pOz->np);
	}

	return 0;
}

int proc_ipc(ipcmsg_t *p_ipcmsg)
{
	j_board_t board;

	switch (p_ipcmsg->mtype) {
		case IMT_PROC_MGPP_STRT:
			FNDEBUG(TASK_MAIN);
			comLog(IN, "%s() - MGPP is STARTED - status: %s", __func__,
					appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus));

			FNDEBUG(TASK_MAIN);
			switch (pProfile->ChannelStatus) {
				case CST_ACTIVE:
				case CST_ACTIVATING:
					FNDEBUG(TASK_MAIN);
					channel_status_update(pProfile->ChannelSID, CST_LEAVING, __func__);
					scf_sock_request_leave();

					FNDEBUG(TASK_MAIN);
					channel_status_update(pProfile->ChannelSID, CST_ROOMED, __func__);
					timer_proc_channel_roomed();
					break;

				case CST_ROOMED:
					FNDEBUG(TASK_MAIN);
					timer_proc_channel_roomed();
					break;

				case CST_IDLE:
					FNDEBUG(TASK_MAIN);
					timer_proc_channel_idle();
					break;
			}
			break;

		/* for TEST */
		case IMT_CTL_PLAY_SOUND : appCLI_mplayer(0); break;
		case IMT_CTL_REBOOT     : appCLI_reboot(); break;
		case IMT_CTL_UPGRADE    : appCLI_fwupdate(NULL, (char *)(p_ipcmsg->data));  break;
		case IMT_CTL_COLLECT_LOG: /* TODO */ break;
		case IMT_CTL_SHOW_BOARD : oma_get_board_info(&board, ""); break;
		default:
			comLog(IN, "%s() - Invalid mtpye(%d)", __func__, p_ipcmsg->mtype);
			break;
	}

	return 1;
}

int proc_timer()
{
	time_t current = comTime();
	int elapsed;

	/* every time */
	FNDEBUG(TASK_MAIN);
	comLogLevelSet(pProfile->LogLevel);

	/* check if first loop or not */
	FNDEBUG(TASK_MAIN);
	if (is_first_timer_loop) {
		FNDEBUG(TASK_MAIN);
		is_first_timer_loop = 0;

		/* TODO */
		FNDEBUG(TASK_MAIN);
		if ((current - pOz->last_usering_time) >= pProfile->UseringPeriodSec) {
			FNDEBUG(TASK_MAIN);
			timer_proc_user_unknown(); 
		}

		FNDEBUG(TASK_MAIN);
		if ((current - pOz->last_rooming_time) >= pProfile->RoomingPeriodSec) {
			FNDEBUG(TASK_MAIN);
			timer_proc_channel_idle(); 
		}

		FNDEBUG(TASK_MAIN);
		if ((current - pOz->last_joining_time) >= pProfile->JoiningPeriodSec) {
			FNDEBUG(TASK_MAIN);
			timer_proc_channel_roomed(); 
		}
	}

	FNDEBUG(TASK_MAIN);
	timer_check_chnlpack(current); 

	FNDEBUG(TASK_MAIN);
	timer_check_status(current); 

	FNDEBUG(TASK_MAIN);
	scf_sock_check();

	FNDEBUG(TASK_MAIN);
	proc_child();

	/* per 1 sec */
	FNDEBUG(TASK_MAIN);
	if ((elapsed = current - Every01Sec) >= 1) {
		Every01Sec = current;

		FNDEBUG(TASK_MAIN);
		if ((current - pOz->last_device_time) >= 15) {
			FNDEBUG(TASK_MAIN);
			timer_proc_device_unknown(); 
		}

		FNDEBUG(TASK_MAIN);
		if ((current - pOz->last_usering_time) >= pProfile->UseringPeriodSec) {
			FNDEBUG(TASK_MAIN);
			timer_proc_user_unknown(); 
		}

		FNDEBUG(TASK_MAIN);
		if ((current - pOz->last_rooming_time) >= pProfile->RoomingPeriodSec) {
			FNDEBUG(TASK_MAIN);
			timer_proc_channel_idle(); 
		}

		FNDEBUG(TASK_MAIN);
		if ((current - pOz->last_joining_time) >= pProfile->JoiningPeriodSec) {
			FNDEBUG(TASK_MAIN);
			timer_proc_channel_roomed(); 
		}
	}

	/* per 5 sec */
	FNDEBUG(TASK_MAIN);
	if ((elapsed = current - Every05Sec) >= 5) {
		FNDEBUG(TASK_MAIN);
		Every05Sec = current;
	}

	/* per 10 sec */
	FNDEBUG(TASK_MAIN);
	if ((elapsed = current - Every10Sec) >= 10) {
		FNDEBUG(TASK_MAIN);
		Every10Sec = current;
	}

	/* per 30 sec */
	FNDEBUG(TASK_MAIN);
	if ((elapsed = current - Every30Sec) >= 30) {
		FNDEBUG(TASK_MAIN);
		Every30Sec = current;
	}

	/* per 60 sec */
	FNDEBUG(TASK_MAIN);
	if ((elapsed = current - Every60Sec) >= 60) {
		FNDEBUG(TASK_MAIN);
		Every60Sec = current;
#if 0
		FNDEBUG(TASK_MAIN);
		appPlaySoundClip(0);
#endif
	}

	/* per 120 sec */
	FNDEBUG(TASK_MAIN);
	if ((elapsed = current - Every120Sec) >= 120) {
		FNDEBUG(TASK_MAIN);
		Every120Sec = current;
	}

	/* per 300 sec */
	FNDEBUG(TASK_MAIN);
	if ((elapsed = current - Every300Sec) >= 300) {
		FNDEBUG(TASK_MAIN);
		Every300Sec = current;
	}

	return 0;
}

int proc_child()
{
	int deadpid, statloc = 0;

	FNDEBUG(TASK_MAIN);
	while ((deadpid = waitpid(-1, &statloc, WNOHANG)) > 0) {
		comLog(WA, "Child Dead PID(%d) WIFEXITED(%d) WEXITSTATUS(%d) WIFSIGNALED(%d) WTERMSIG(%d)",
				deadpid, WIFEXITED(statloc), WEXITSTATUS(statloc), WIFSIGNALED(statloc), WTERMSIG(statloc));
	}

	return 0;
}

void sighandler(int signo)
{
	pOz->running = FALSE;
}

int initialize(int argc, char **argv)
{
	time_t current = comTime();

	/* init */
	memset(pOz, 0x00, sizeof(chnlmagic_t));
	memset(MobileNumber, 0x00, sizeof(MobileNumber));

	/* initialize */
	if (appInitialize(APP_SHM_KEY, CHNL, 0) == -1) {
		comErr(ER, errno, "fail to appInitialize.");
		return -1;
	}

	/* daemon and lock */
	if (appDaemonInit("CHNL", FALSE) == -1) {
		comErr(ER, errno, "fail to appDaemonInit.");
		return -1;
	}

	/* attach the globla hashmagic */
	pOz->running = TRUE;

	//
	scf_sock_init();
	chnlpack_init();
	rmsScpoolInit(&pOz->scbase);
	//
	appPipeOpen(&pOz->np, "CHNL", &pOz->maxfd, &pOz->rmask, &pOz->wmask);

	/* install signal */
	comInstallSignal(SIGINT , sighandler);
	comInstallSignal(SIGTERM, sighandler);

	/* welcome... */
	appWelcome(argv[0]);

	/* status... */
	Every01Sec  = current;
	Every05Sec  = current;
	Every10Sec  = current;
	Every30Sec  = current;
	Every60Sec  = current;
	Every120Sec = current;
	Every300Sec = current;

	/* init */
	channel_status_update(0, CST_IDLE, __func__);

	//
	timer_proc_device_unknown();

	return 0;
}

int terminate(int code)
{
	int i;

	FNDEBUG(TASK_MAIN);
	switch (pProfile->ChannelStatus) {
		case CST_ACTIVE:
		case CST_JOINED:
			scf_sock_request_leave();
			mgp_signal_stop_req();
			channel_status_update(0, CST_IDLE, __func__);
			break;
	}

	FNDEBUG(TASK_MAIN);
	for (i = 0; i < 3; i++) {
		comLog(WA, "wait....[%d]", i);
		sleep(1);
	}

	/* terminate self.. */
	FNDEBUG(TASK_MAIN);
	comGoodbye(code);
	exit(code);

	return 0;
}

