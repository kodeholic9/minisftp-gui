/**
 * @date   2012/12/04
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "libapp.h"

#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_MAIN, __LINE__)

/** ----------------------------------------------------- */
void *appTimer(void *arg)
{
	timerproc_t *p_timerproc = (timerproc_t *)arg;

	sleep(2);
	comLog(WA, "%s - Started", __func__);

	FNDEBUG(TASK_TIMER);
	while (p_timerproc->running) {
		FNDEBUG(TASK_TIMER);
		appTimerLoop(p_timerproc); 
	}
	comLog(WA, "%s - Stoped", __func__);

	FNDEBUG(TASK_TIMER);
	pthread_exit(NULL);

	return NULL;
}

void appTimerLoop(timerproc_t *p_timerproc) 
{
	double usec, rate;
	int    i, current = 0, nloop = 0, expnum = 0;

	FNDEBUG(TASK_TIMER);
	usec    = comTimeGetU();
	current = (int)usec;
	if (current != p_timerproc->prev) {
		if (p_timerproc->prev == 0) {
			p_timerproc->done = (usec - (1.0 * current)) * p_timerproc->persec;
		}
		else {
			p_timerproc->done = 0;
		}
		p_timerproc->prev = current;
	}

	FNDEBUG(TASK_TIMER);
	rate  = usec - (1.0 * current);
	nloop = ((1 + (rate * p_timerproc->persec)) - p_timerproc->done);

	FNDEBUG(TASK_TIMER);
	for (i = 0, expnum = 0; i < nloop && expnum < 100; i++) {
		if (p_timerproc->proc(usec) > 0) {
			expnum += 1;
		}
		p_timerproc->done += 1;
	}

	/* profile */
	/*printf("rate=%5.2f, done=%d/%f, nloop=%d, CallPerSec=%d\n",
	 	rate, p_timerproc->done, rate * p_timerproc->persec, nloop, p_timerproc->persec);*/

	FNDEBUG(TASK_TIMER);
	usleep(10000);

	return;
}

int appTimerStart(timerproc_t *p_timerproc, tmCallback *proc, int persec) 
{
	/* init */
	memset(p_timerproc, 0x00, sizeof(timerproc_t));
	p_timerproc->running = TRUE;
	p_timerproc->persec  = persec;
	p_timerproc->proc    = proc;

	/* run... */
	if (comThreadCreate(&p_timerproc->thread, appTimer, p_timerproc) == -1) {
		comErr(ER, errno, "fail to comThreadCreate.");
		return -1;
	}

	return 0;
}


