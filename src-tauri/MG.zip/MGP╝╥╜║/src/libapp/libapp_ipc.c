/**
 * @file    libsys/libsys_ipc.c
 * @date    2009.12.01
 * @author  Kang Tae Goo (tgkang@tisquare.com, r9i9c9@gmail.com)
 * @brief   
 * 
 * 
 */

#include "libapp.h"

static unsigned int nIpcNotReadies;

////////////////////////////////////////////////////////////////////////////////
//
////////////////////////////////////////////////////////////////////////////////
void mIpcCreate(ipc_t *p_ipcroot, int ap_id, int maxnum)
{
	ipc_t *p_ipc = p_ipcroot + ap_id;

	memset(p_ipc, 0x00, sizeof(ipc_t));

	/* ipcctl */
	comMutexInit(&p_ipc->ipcctl.lock);
	comCondInit (&p_ipc->ipcctl.cond);
	p_ipc->ipcctl.sendIdx = 0;
	p_ipc->ipcctl.recvIdx = 0;
	p_ipc->ipcctl.maxnum  = maxnum;

	return;
}

void appIpcCreate()
{
	int i;

	for (i = 0; i < NUMOF_AP; i++) {
		mIpcCreate(appP->ipcdefault, i, MAX_IPC_MSG_NUM); /* for default */
	}

	return;
}

////////////////////////////////////////////////////////////////////////////////
// 
////////////////////////////////////////////////////////////////////////////////
sint mResetMsg(ipc_t *p_ipcroot, int ap_id)
{
	ipc_t *p_ipc = p_ipcroot + ap_id;

	comMutexLock(&p_ipc->ipcctl.lock);

	p_ipc->ipcctl.recvIdx = 0;
	p_ipc->ipcctl.sendIdx = 0;

	comMutexUnlock(&p_ipc->ipcctl.lock);

	return 0;
}

sint appIpcResetAp()
{
	return mResetMsg(appP->ipcdefault, ApId);
}


////////////////////////////////////////////////////////////////////////////////
// 
////////////////////////////////////////////////////////////////////////////////
sint mReadyMsg(ipc_t *p_ipcroot, int ap_id)
{
	ipc_t *p_ipc = p_ipcroot + ap_id;

	if (p_ipc->ipcctl.sendIdx == p_ipc->ipcctl.recvIdx
			|| !p_ipc->ipcmsg[p_ipc->ipcctl.recvIdx].occupied)
	{
		nIpcNotReadies++;
		return FALSE;
	}
	nIpcNotReadies = 1;

	return TRUE;
}

sint appIpcReadyMsg()
{
	return mReadyMsg(appP->ipcdefault, ApId); 
}

////////////////////////////////////////////////////////////////////////////////
// 
////////////////////////////////////////////////////////////////////////////////
sint mRecvMsg(ipc_t *p_ipcroot, int ap_id, ipcmsg_t **p_msg, int msec)
{
	ipc_t *p_ipc = p_ipcroot + ap_id;
	int error;

	/* pthread_mutex_lock(&p_ipc->ipcMutex);  */
	comMutexLock(&p_ipc->ipcctl.lock);

	while (p_ipc->ipcctl.sendIdx == p_ipc->ipcctl.recvIdx
			|| !p_ipc->ipcmsg[p_ipc->ipcctl.recvIdx].occupied)
	{
		if (msec <= 0 || (error = comCondWaitTimeo(&p_ipc->ipcctl.cond, &p_ipc->ipcctl.lock, msec)) != 0) {
			comMutexUnlock(&p_ipc->ipcctl.lock);
			return -1;
		}
	}

	*p_msg = p_ipc->ipcmsg + p_ipc->ipcctl.recvIdx;
	(*p_msg)->occupied = !OCCUPIED;

	p_ipc->ipcctl.recvIdx = (p_ipc->ipcctl.recvIdx + 1) % p_ipc->ipcctl.maxnum; 

	/* pthread_mutex_unlock(&p_ipc->ipcMutex); */
	comMutexUnlock(&p_ipc->ipcctl.lock);

	if (*p_msg != NULL) {
		comLog(DG, "%s() - from: %s, mtype: %s", __func__,
				appName((*p_msg)->from), appCodeMap2Str(CC_IpcMsgType, (*p_msg)->mtype));
	}

	return 0;
}

sint appIpcRecvMsg(ipcmsg_t **p_msg, int msec)
{
	return mRecvMsg(appP->ipcdefault, ApId, p_msg, msec); 
}

////////////////////////////////////////////////////////////////////////////////
// 
////////////////////////////////////////////////////////////////////////////////
sint mSendMsg(ipc_t *p_ipcroot, uint from, uint ttoo, uint mtype, uchar *data, uint len)
{
	ipc_t    *p_ipc = p_ipcroot + ttoo;
	ipcmsg_t *p_ipcmsg;

	comLog(DG, "%s() from=%d, ttoo=%d, mtype=%d", __func__, from, ttoo, mtype);

	comMutexLock(&p_ipc->ipcctl.lock);

	if (p_ipc->ipcctl.recvIdx == ((p_ipc->ipcctl.sendIdx + 2) % p_ipc->ipcctl.maxnum)) {
		comLog(ER, "%s() Overflow into %s, discard msg", __func__, appName(ttoo));
		comMutexUnlock(&p_ipc->ipcctl.lock);
		return -1;
	}
	p_ipcmsg = p_ipc->ipcmsg + p_ipc->ipcctl.sendIdx;
	p_ipc->ipcctl.sendIdx = (p_ipc->ipcctl.sendIdx + 1) % p_ipc->ipcctl.maxnum;

	gettimeofday(&p_ipcmsg->time, NULL);
	p_ipcmsg->mtype = mtype;
	p_ipcmsg->from  = from;
	p_ipcmsg->ttoo  = ttoo;
	p_ipcmsg->len   = len;
	if (data != NULL) {
		memcpy(p_ipcmsg->data, data, len);
	}
	p_ipcmsg->occupied = OCCUPIED;

	comCondSignal(&p_ipc->ipcctl.cond);

	comMutexUnlock(&p_ipc->ipcctl.lock);

	//
	comLog(DG, "%s() - ttoo: %s, mtype: %s", __func__,
			appName(ttoo), appCodeMap2Str(CC_IpcMsgType, mtype));

	return 0;
}

sint appIpcSendMsg(uint ttoo, uint mtype, uchar *data, uint len)
{
	if (ttoo >= NUMOF_AP) {
		comLog(ER, "%s() invalid ttoo(%d)", __func__, ttoo);
		return -1;
	}

	if (len >= MAX_IPC_MSG_LEN) {
		comLog(ER, "%s() invalid length of IPC msg (len=%d)", __func__, len);
		return -1;
	}

	return mSendMsg(appP->ipcdefault, ApId, ttoo, mtype, data, len); 
}

#if 0
sint sysSendMsgIntl(uint from, uint ttoo, uint mtype, unchar *data, uint len)
{
	int ipc_id;

	// check the boundary
	if (mtype >= NUM_OF_MSGTYPE) {
		sysLog(ER, "invalid mtype %d", mtype);
		return(-1);
	}
	if (len >= MAX_MSG_LEN) {
		sysLog(ER, "invalid length of IPC msg (len=%d)", len);
		return(-1);
	}

	/* decide IpcType */
	if ((ipc_id = decideIpcType(ttoo)) == -1) {
		return -1;
	}
	/*sysLog(DG, "%s() ipc_id=%d, ttoo=%d", __func__, ipc_id, ttoo);*/

	return mSendMsg(from, ttoo, mtype, data, len); 
}

#endif

/** @private */
sint appIpcSleep(int basis)
{
	int n;

	if ((n = basis) == 0) {
		n = 1000;
	}
	if ((nIpcNotReadies % n) == 0) {
		usleep(1);
		return 1;
	}

	return 0;
}

sint appIpcSendArgs(uint ttoo, uint mtype, int arg1, unsigned int arg2, unsigned long arg3)
{
	ipcdata_t data;

	memset(&data, 0x00, sizeof(ipcdata_t));
	data.arg1 = arg1;
	data.arg2 = arg2;
	data.arg3 = arg3;

	return appIpcSendMsg(ttoo, mtype, (uchar *)&data, sizeof(ipcdata_t));
}
