/**
 * @date   2012/07/27
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "libapp.h"
#include "hPTTAudio.h"

/** ----------------------------------------------------- */

/* shared memory pointer */
appshm_t  *appP     = NULL;
profile_t *pProfile = NULL;

/** ----------------------------------------------------- */
void appShortCut()
{
	if (appP == NULL) {
		comLog(ER, "appP NOT INITIALIZED.");
		return;
	}

	pProfile = &appP->profile;
}

void appSstPrepare()
{
	codemap_t *p_codemap;

	if ((p_codemap = appCodeMapGet(CC_TnSvcCode)) == NULL || p_codemap->p_codelist == NULL) {
		comLog(ER, "NO SUCH TN-SVC-CODE[%u]", CC_TnSvcCode);
		return;
	}

	return;
}

int appCreate(int shm_key)
{
	int shm_id;
	int shm_index;

	if ((shm_index = comGetIndex()) == -1) {
		comErr(ER, errno, "comGetIndex failed.");
		return -1;
	}

	shm_key += shm_index;
	if ((shm_id = shmget(shm_key, sizeof(appshm_t), IPC_CREAT | PERM)) < 0) {
		comErr(ER, errno, "shmget(0x%x,%d) failed.", shm_key, sizeof(appshm_t));
		return -1;
	}
	if ((appP = (appshm_t *)shmat(shm_id, (void *) 0, 0)) == SHM_FAILED) {
		comErr(ER, errno, "shmat() failed.");
		return -1;
	}
	memset(appP, 0x00, sizeof(appshm_t));

	/* load code */
	if (appLoadCode() == -1) { return -1; }

	/* ipc create */
	appIpcCreate();

	/* SST */
	appSstPrepare();
	
	/* for shortcut */
	appShortCut();

	return 0;
}

int appInitialize(int shm_key, unsigned int ap_id, unsigned int inst_id)
{
	int shm_id;
	int shm_index;

	/* for Ap/Instance */
	if ((ApId = ap_id) >= NUMOF_AP) {
		comLog(ER, "invalie ApId(%d)", ap_id);
		return -1;
	}
	if ((ApInstId = inst_id) >= MAX_INST_NUM) {
		comLog(ER, "invalie inst_id(%d)", inst_id);
		return -1;
	}

	if ((shm_index = comGetIndex()) == -1) {
		comErr(ER, errno, "comGetIndex failed.");
		return -1;
	}

	shm_key += shm_index;
	/* Attach */
	if ((shm_id = shmget(shm_key, sizeof(appshm_t), 0)) < 0) {
		comLog(ER, "shmget(0x%x,%d) failed.", shm_key, sizeof(appshm_t));
		return -1;
	}

	if ((appP = (appshm_t *)shmat(shm_id, (void *) 0, 0)) == SHM_FAILED) {
		comLog(ER, "shmat() failed.");
		return -1;
	}

	/* load code */
	if (appLoadCode() == -1) { return -1; }
	
	/* for shortcut */
	appShortCut();

	return 0;
}

/* counting dot in char array */
int getVersionArraySize(char *version)
{
    int idx = 0, max = strlen(version), count = 0;
    while(idx < max) {
        //printf("check char : %c\n", version[idx]);
        if(version[idx] == '.') {
            count++;
        }
        idx++;
    }

    return ++count;
}

/* split array using dot and convert to string to int*/
void convertVersionToInt(char *version, int *dest)
{
    char *ptr;
    int destIdx = 0;

    //printf("before convert - version : %s\n", version);

    ptr = strtok(version, ".");
    while(ptr != NULL) {
        //printf("get - %s\n", ptr);
        dest[destIdx] = atoi(ptr);
        //printf("save - %d\n", dest[destIdx]);
        destIdx++;
        ptr = strtok(NULL, ".");
    }
}

/* check App version before firmware update */
int appVersionCheck(char *version)
{
    int result = -1;
    char appVersion[16], urlVersion[16];

    sprintf      (appVersion, "%s", VERSION);
    sprintf      (urlVersion, "%s", version);

    int av[getVersionArraySize(VERSION)], uv[getVersionArraySize(version)];

    convertVersionToInt(appVersion, av);
    convertVersionToInt(urlVersion, uv);

    int vLength, avLength, uvLength;
    avLength = sizeof(av) / sizeof(av[0]);
    uvLength = sizeof(uv) / sizeof(uv[0]);

    vLength = avLength > uvLength ? uvLength : avLength;

    //smaller side version check. defensing error of version code miss input.
    int i;
    for(i = 0; i < vLength; i++) {
        if(av[i] == uv[i]){     //check version code
            continue;
        } else if(av[i] < uv[i]) {
            if(i == 0) {
                result = 0;         //major update
            } else {
                result = 1;         //minor update
            }
        }
    }

    comLog(ER, "%s() app version cheched - result : %d", __func__, result);

    return result;
}

/** @private */
unsigned int calcDelta(char *name, uint newvalue, uint *p_oldvalue)
{
	int deltavalue;

	if (newvalue >= *p_oldvalue) {
		deltavalue = newvalue - *p_oldvalue;
	}
	else {
		deltavalue  = UINT_MAX - *p_oldvalue;
		deltavalue += newvalue;
	}
#if 0
	comLog(DG, "! %20s] NEW=%10u, OLD=%10u, DELTA=%10u", name, newvalue, *p_oldvalue, deltavalue);
#endif

	*p_oldvalue = newvalue;

	return deltavalue;
}

/** @private */
unsigned int calcTps(char *name, uint newvalue, uint *p_oldvalue, double elapsed)
{
	return (unsigned int)(calcDelta(name, newvalue, p_oldvalue) / elapsed);
}

/** @private */
int appDaemonInit(char *apname, int bgflag)
{
	int  child;
	char log_file[128], path[128];
	int  parent_fd = 0;

	/* pid file lock */
	if ((parent_fd = comPidFileLock(apname, ApInstId, (int)getpid())) == -1) {
		comLog(ER, "%s() ALREADY RUNNING.", __func__);
		return -1;
	}

	if (bgflag) {
		if      ((child = fork()) == -1) { return -1; }
		else if ( child            >  0) { exit(0);   }

		/* be a session leader */
		setsid();

		/* logfile */
		if (pProfile->Logging != 0) {
			sprintf      (log_file, "%s.out", apname);
			comGetLogPath(log_file, path);
			comLogRedirect(path, "a", 0);
		}
		else {
			comGetTmpPath(TRACE_F, path);
			comLogRedirect(path, "a+", 1);
		}
		printf("path... logging: %d, appname: %s, path:%s\n", pProfile->Logging, apname, path);

		/* pid file lock again!! */
		if (parent_fd > 0) {
			close(parent_fd);
			parent_fd = 0;
		}
		if (comPidFileLock(apname, ApInstId, (int)getpid()) == -1) {
			comLog(ER, "%s() ALREADY RUNNING.", __func__);
			return -1;
		}
	}

	/* change the running directory */
	comGetPidPath(apname, path);
	mkdir(path, S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH); 
	if (chdir(path) == -1) {
		printf("fail to chdir() to %s - error:%d(%s)\n", path, errno, strerror(errno));
	}

	return 0;
}

char *appAudioCodec2Str(int codec)
{
        switch (codec) {
                case CODEC_AMR_NB_OA: return S_AMR_NB_OA;
                case CODEC_AMR_NB_BE: return S_AMR_NB_BE;
                case CODEC_AMR_WB_OA: return S_AMR_WB_OA;
                case CODEC_AMR_WB_BE: return S_AMR_WB_BE;
                case CODEC_PCMA     : return S_PCMA;
                case CODEC_PCMU     : return S_PCMU;
                case CODEC_OPUS_NB  : return S_OPUS_NB;
                case CODEC_OPUS_WB  : return S_OPUS_WB;
                case CODEC_OPUS_FB  : return S_OPUS_FB;
        }

        return S_OPUS_WB;
}

int appAudioCodec2Int(char *s)
{
        if (s != NULL) {
                if      (strcmp(s, S_AMR_NB_OA) == 0) return CODEC_AMR_NB_OA;
                else if (strcmp(s, S_AMR_NB_BE) == 0) return CODEC_AMR_NB_BE;
                else if (strcmp(s, S_AMR_WB_OA) == 0) return CODEC_AMR_WB_OA;
                else if (strcmp(s, S_AMR_WB_BE) == 0) return CODEC_AMR_WB_BE;

                else if (strcmp(s, S_PCMA) == 0) return CODEC_PCMA;
                else if (strcmp(s, S_PCMU) == 0) return CODEC_PCMU;

                else if (strcmp(s, S_OPUS_NB) == 0) return CODEC_OPUS_NB;
                else if (strcmp(s, S_OPUS_WB) == 0) return CODEC_OPUS_WB;
                else if (strcmp(s, S_OPUS_FB) == 0) return CODEC_OPUS_FB;
        }

        return CODEC_OPUS_WB;
}

int appAudioCodec2Pid(int codec)
{
        switch (codec) {
                case CODEC_AMR_NB_OA: return 0;
                case CODEC_AMR_NB_BE: return 0;
                case CODEC_AMR_WB_OA: return 0;
                case CODEC_AMR_WB_BE: return 0;
                case CODEC_PCMA     : return 0;
                case CODEC_PCMU     : return 0;
                case CODEC_OPUS_NB  : return 0;
                case CODEC_OPUS_WB  : return 99;
                case CODEC_OPUS_FB  : return 0;
        }

        return 99;
}

int appCLI_PTTStart()
{
	char cmdline[128];

	snprintf(cmdline, sizeof(cmdline), "%s %s", pProfile->CLI_mplayer, pProfile->SoundClipPTTStart);

	return appLoadCmdline(cmdline);
}

int appCLI_PTTStop()
{
	char cmdline[128];

	snprintf(cmdline, sizeof(cmdline), "%s %s", pProfile->CLI_mplayer, pProfile->SoundClipPTTStop);

	return appLoadCmdline(cmdline);
}

int appCLI_mplayer(int clip_id)
{
	char *p_clip = NULL;
	char cmdline[128];

	switch (clip_id) {
		case 0: p_clip = pProfile->SoundClipPath_00; break;
		case 1: p_clip = pProfile->SoundClipPath_01; break;
		case 2: p_clip = pProfile->SoundClipPath_02; break;
		case 3: p_clip = pProfile->SoundClipPath_03; break;
		case 4: p_clip = pProfile->SoundClipPath_04; break;
		case 5: p_clip = pProfile->SoundClipPath_05; break;
		case 6: p_clip = pProfile->SoundClipPath_06; break;
		case 7: p_clip = pProfile->SoundClipPath_07; break;
		case 8: p_clip = pProfile->SoundClipPath_08; break;
		case 9: p_clip = pProfile->SoundClipPath_09; break;
	}

	if (p_clip == NULL || strlen(p_clip) == 0) {
		comLog(ER, "%s() - p_clip for clip_id[%d] is NULL", __func__, clip_id);
		return -1;
	}

	//snprintf(cmdline, sizeof(cmdline), "aplay -D hw:0,0 %s", p_clip);
	snprintf(cmdline, sizeof(cmdline), "%s %s", pProfile->CLI_mplayer, p_clip);

	return appLoadCmdline(cmdline);
}

int appCLI_reboot()
{
	return appLoadCmdline(pProfile->CLI_reboot);
}

int appCLI_fwupdate(char *installer, char *url)
{
	char cmdline[256];

	if (url == NULL || strlen(url) == 0) {
		comLog(ER, "%s() - URL is NULL", __func__);
		return -1;
	}

	snprintf(cmdline, sizeof(cmdline), "%s %s %s",
			pProfile->CLI_fwupdate, (installer != NULL && strlen(installer)) ? installer : "-", url);

	return appLoadCmdline(cmdline);
}

int appLoadCmdline(const char *cmdline)
{
	int  child;
	char path[256 ];
	char line[1024];

	if (lp_input2split(cmdline, path, line, sizeof(line)) == -1) {
		comLog(ER, "%s() - failed to lp_input2split() - [%s]", __func__, cmdline);
		return -1;
	}
	if ((child = lp_load(path, line, NULL, NULL)) == -1) { 
		comLog(ER, "%s() - failed to lp_load() - [%s|%s]", __func__, path, line);
		return -1;
	}

	comLog(IN, "%s() - success to Load - child: %d, [%s|%s]", __func__, child, path, line);

	return child;
}



