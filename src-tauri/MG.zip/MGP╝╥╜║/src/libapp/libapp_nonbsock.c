/**
 * @date   2012/11/12
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "libapp.h"

void appNonbsockInit(nonbsock_t *p_nonb, char *name, int *maxfd, fd_set *rset, fd_set *wset)
{
	memset(p_nonb, 0x00, sizeof(nonbsock_t));
	sprintf(p_nonb->name, "%s", name);
	p_nonb->maxfd = maxfd;
	p_nonb->rset  = rset;
	p_nonb->wset  = wset;

	return;
}

void appNonbsockUpdate(nonbsock_t *p_nonb, int status)
{
	time_t currtime = comTime();

	/* logging */
	comLog(DG, "SOCK(%s) FD(%d) STATUS(%s --> %s)",
			p_nonb->name,
			p_nonb->psockfd,
			appCodeMap2Str(CC_TcpStatus, p_nonb->pstatus),
			appCodeMap2Str(CC_TcpStatus, status));

	/* update the dynamics */
	p_nonb->pstatus = status;
	p_nonb->chgtime = currtime;
	p_nonb->sndtime = currtime;
	p_nonb->rcvtime = currtime;

	return;
}

void appNonbsockBufferInit(sockbuffer_t *p_buffer)
{
	memset(p_buffer, 0x00, sizeof(sockbuffer_t));
}

int appNonbsockConnect(nonbsock_t *p_nonb, char *host, int port)
{
	sockaddr_in_t serv;
	int           sockfd, flags, n;

	/* init */
	bzero((char *)&serv,sizeof(serv));
	serv.sin_family      = AF_INET;
	serv.sin_addr.s_addr = inet_addr(host);
	serv.sin_port        = htons(port);

	/* makeup the socket */
	if ((sockfd = socket(AF_INET,SOCK_STREAM,0)) == -1) {
		comErr(ER, errno, "%s() fail to make socket.", __func__);
		return -1;
	}
	comLog(DG, "Connect - name(%s) sockfd(%d) host(%s) port(%d)", p_nonb->name, sockfd, host, port);

	/* set NONBLOCK */
	flags = fcntl(sockfd, F_GETFL, 0);
	fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);

	/* update the status */
	appNonbsockUpdate(p_nonb, TST_CONNECTING);

	/* connect */
	if ((n = connect(sockfd, (struct sockaddr *)&serv, sizeof(serv))) == -1) {
		if (errno != EINPROGRESS) {
			comErr(ER, errno, "%s() fail to connect(%s, %d).", __func__, host, port);
			close(sockfd);

			/* update the status */
			appNonbsockUpdate(p_nonb, TST_CLOSED);

			return -1;
		}
	}

	/* save the sockfd */
	p_nonb->psockfd = sockfd;

	/* update mask */
	if (p_nonb->maxfd != NULL && p_nonb->rset) {
		comSetSelectMask(p_nonb->maxfd, p_nonb->rset, p_nonb->psockfd);
	}
	if (p_nonb->maxfd != NULL && p_nonb->wset) {
		comSetSelectMask(p_nonb->maxfd, p_nonb->wset, p_nonb->psockfd);
	}

	/* update the path status */
	if (n == 0) {
		appNonbsockUpdate(p_nonb, TST_CONNECTED);
	}

	/* update the tcpbuffer */
	appNonbsockBufferInit(&p_nonb->sendbuff);
	appNonbsockBufferInit(&p_nonb->recvbuff);

	return sockfd;
}

int appNonbsockListen(char *host, int port)
{
	return comOpenServerSocket(host, port, MAX_SOCKET_BUFFER_SZ, 1);
}

int appNonbsockAccept(int lsnrfd, nonbsock_t *p_nonb)
{
	sockaddr_in_t addr;
	int           addrlen = 0, saved, connfd;
	struct linger lng;

	/* set NONBLOCK */
	saved = fcntl(lsnrfd, F_GETFL, 0);
	fcntl(lsnrfd, F_SETFL, saved | O_NONBLOCK);

L_ACCEPT_AGAIN:

	if ((connfd = accept(lsnrfd, (sockaddr_t *)&addr, &addrlen)) == -1) {
		switch (errno) {
			case EINTR:
				goto L_ACCEPT_AGAIN;
				break;

			case EWOULDBLOCK:   /* for Berkeley-derived, when the client aborts the connection before accept() */
			case ECONNABORTED:  /* for Posix.1g, when the client aborts the connection before accept() */
			case EPROTO:        /* for SVR4, when the client aborts the connection before accept() */
				comErr(ER, errno, "accept(%d, ...) failed. Connection request has DISAPPEARED.", lsnrfd);
				return -1;

			case ENOBUFS:       /* for HP-UX 11.xx */
				comErr(ER, errno, "accept(%d, ...) failed. The queued socket connect request is aborted.", lsnrfd);
				return -1;

			default:
				comErr(ER, errno, "accept(%d, ...) failed. %s(%d)", lsnrfd, strerror(errno), errno);
				return -1;
		}
	}

	/* for linger option */
	lng.l_onoff = 1; lng.l_linger = 0;
	if (setsockopt(connfd, SOL_SOCKET, SO_LINGER, (char *)&lng, sizeof(lng)) < 0) {
		comErr(ER, errno, "setsockopt(%d, ...) failed. %s(%d)", connfd);
		close(connfd);
		return -1;
	}

	/* set NONBLOCK */
	saved = fcntl(connfd, F_GETFL, 0);
	fcntl(connfd, F_SETFL, saved | O_NONBLOCK);

	/* save the sockfd */
	p_nonb->psockfd = connfd;

	/* update mask */
	if (p_nonb->maxfd != NULL && p_nonb->rset != NULL) {
		comSetSelectMask(p_nonb->maxfd, p_nonb->rset, p_nonb->psockfd);
	}
	if (p_nonb->maxfd != NULL && p_nonb->wset != NULL) {
		comSetSelectMask(p_nonb->maxfd, p_nonb->wset, p_nonb->psockfd);
	}

	/* update the path status */
	appNonbsockUpdate(p_nonb, TST_ACCEPTED);

	/* update the tcpbuffer */
	appNonbsockBufferInit(&p_nonb->sendbuff);
	appNonbsockBufferInit(&p_nonb->recvbuff);

	return connfd;
}

int appNonbsockClose(nonbsock_t *p_nonb)
{
	comLog(DG, "Close - name(%s) sockfd(%d)", p_nonb->name, p_nonb->psockfd);

	if (p_nonb->psockfd > 0) {
		/* update the path status */
		appNonbsockUpdate(p_nonb, TST_CLOSED);

		if (p_nonb->maxfd != NULL && p_nonb->rset != NULL) {
			comUnsetSelectMask(p_nonb->maxfd, p_nonb->rset, p_nonb->psockfd);
		}
		if (p_nonb->maxfd != NULL && p_nonb->wset != NULL) {
			comUnsetSelectMask(p_nonb->maxfd, p_nonb->wset, p_nonb->psockfd);
		}
		close(p_nonb->psockfd); p_nonb->psockfd = 0;
	}

	return 0;
}

int appNonbsockCheckCurrR(nonbsock_t *p_nonb)
{
	sockbuffer_t *p_buffer = &p_nonb->recvbuff;
	int           ncurr    =  p_buffer->limit - p_buffer->pos;

	return ncurr;
}

int appNonbsockRecv(nonbsock_t *p_nonb, char *data, char *raw, int dlen)
{
	sockbuffer_t *p_buffer = &p_nonb->recvbuff;
	int n = 0, ncurr = 0;

	/* check */
	if (p_nonb->psockfd <= 0) {
		comLog(WA, "%s() Illegal Sockfd - FD(%d)", __func__, p_nonb->psockfd);
		return -1;
	}
	if (dlen > MAX_SOCKBUFF_LEN) {
		comLog(WA, "%s() Illegal Length Requested - dlen(%d > %d)", __func__, dlen, MAX_SOCKBUFF_LEN);
		return -1;
	}
	if ((ncurr = appNonbsockCheckCurrR(p_nonb)) < dlen) {
		if (MAX_SOCKBUFF_LEN - p_buffer->pos < dlen) {
			if (ncurr > 0) {
				memmove(p_buffer->data, p_buffer->data + p_buffer->pos, ncurr);
			}
			p_buffer->pos   = 0;
			p_buffer->limit = ncurr;
		}
		if ((n = comNonblockRead(p_nonb->psockfd,
						p_buffer->data   + p_buffer->limit,
						MAX_SOCKBUFF_LEN - p_buffer->limit)) == -1)
		{
			comErr(ER, errno, "%s() READ FAILED - fd(%d) pos(%d) limit(%d) dlen(%d) max(%d)", __func__,
					p_nonb->psockfd, p_buffer->pos, p_buffer->limit, dlen, MAX_SOCKBUFF_LEN);
			return -1;
		}
		p_buffer->limit  += n;
		p_nonb  ->rcvtime = comTime();
	}
	if ((ncurr = p_buffer->limit - p_buffer->pos) >= dlen) {
		memcpy(data, p_buffer->data + p_buffer->pos, dlen);
		memcpy(raw , p_buffer->data + p_buffer->pos, dlen);
		p_buffer->pos += dlen;
		return dlen;
	}

#if 0
	comLog(DG, "%s() pos(%d) limit(%d) dlen(%d) nread(%d)",
			__func__, p_buffer->pos, p_buffer->limit, dlen, n);
#endif

	return 0;
}

int appNonbsockCheckCurrW(nonbsock_t *p_nonb)
{
	sockbuffer_t *p_buffer = &p_nonb->sendbuff;
	int           ncurr    =  p_buffer->limit - p_buffer->pos;

	/* shift.... */
	if (p_buffer->pos != 0) {
	   	if (ncurr > 0) {
			memmove(p_buffer->data, p_buffer->data + p_buffer->pos, ncurr);
		}
		p_buffer->pos   = 0;
		p_buffer->limit = ncurr;
	}

	return ncurr;
}

int appNonbsockFlush(nonbsock_t *p_nonb)
{
	sockbuffer_t *p_buffer = &p_nonb->sendbuff;
	int           ncurr, n = 0;

	if (p_nonb->psockfd <= 0) {
		comLog(WA, "%s() Illegal Sockfd - dlen(%d)", __func__, p_nonb->psockfd);
		return -1;
	}
	if ((ncurr = appNonbsockCheckCurrW(p_nonb)) > 0) { 
		if ((n = comNonblockWrite(p_nonb->psockfd, p_buffer->data + p_buffer->pos, ncurr)) == -1) {
			comErr(ER, errno, "%s() FLUSH FAILED - fd(%d) pos(%d) limit(%d) max(%d)", __func__,
					p_nonb->psockfd, p_buffer->pos, p_buffer->limit, MAX_SOCKBUFF_LEN);
			return -1;
		}

		/* update the pos and the flushed time */
		p_buffer->pos += n;
		p_nonb  ->sndtime = comTime();
	}

	return n;
}

int appNonbsockSend(nonbsock_t *p_nonb, char *data, int dlen)
{
	sockbuffer_t *p_buffer = &p_nonb->sendbuff;
	int n = 0, ncurr = 0;

	/* validation check */
	if (p_nonb->psockfd <= 0) {
		comLog(WA, "%s() Illegal Sockfd - dlen(%d)", __func__, p_nonb->psockfd);
		return -1;
	}

	/* flush the old one */
	if (appNonbsockFlush(p_nonb) == -1) { return -1; }

	/* append the new one */
	if ((ncurr = appNonbsockCheckCurrW(p_nonb)) + dlen > MAX_SOCKBUFF_LEN) {
		comLog(WA, "%s() OVERFLOWED - fd(%d) pos(%d) limit(%d) dlen(%d) max(%d)", __func__,
				p_nonb->psockfd, p_buffer->pos, p_buffer->limit, dlen, MAX_SOCKBUFF_LEN);
		return -1;
	}
	
	/* memory copy... */
	memcpy(p_buffer->data + p_buffer->limit, data, dlen);
	p_buffer->limit += dlen;

	/* flush the new one */
	if ((n = appNonbsockFlush(p_nonb)) == -1) { return -1; }

	return n;
}


