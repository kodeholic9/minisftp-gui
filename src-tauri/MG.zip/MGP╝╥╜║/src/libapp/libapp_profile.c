/**
 * @date   2012/12/13
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "libapp.h"

static int setInt (int  *p, char *v) { *p = atoi(v); return 0; }
static int setLong(long *p, char *v) { *p = atol(v); return 0; }
static int setStr (char *p, char *v) { sprintf(p, "%s", v);  return 0; }
static int setLvl (int  *p, char *v) {
	if      (strcasecmp(v, "E") == 0) { *p = ER; }
	else if (strcasecmp(v, "W") == 0) { *p = WA; }
	else if (strcasecmp(v, "I") == 0) { *p = IN; }
	else if (strcasecmp(v, "D") == 0) { *p = DG; }
	else                              { *p = VB; }

	return 0;
}
static void saveInt (FILE *fp, char *para, int   v) { fprintf(fp, "%s=%d\n" , para, v); }
static void saveLong(FILE *fp, char *para, long  v) { fprintf(fp, "%s=%ld\n", para, v); }
static void saveStr (FILE *fp, char *para, char *v) { fprintf(fp, "%s=%s\n" , para, v); }
static void saveLvl (FILE *fp, char *para, int   v)
{
	if      (v == ER) { fprintf(fp, "%s=E\n", para); }
	else if (v == WA) { fprintf(fp, "%s=W\n", para); }
	else if (v == IN) { fprintf(fp, "%s=I\n", para); }
	else if (v == DG) { fprintf(fp, "%s=D\n", para); }
	else              { fprintf(fp, "%s=V\n", para); }
}

static void showInt (char *para, int   v) { fprintf(stdout, " %-20s = %d\n" , para, v); }
static void showLong(char *para, long  v) { fprintf(stdout, " %-20s = %ld\n", para, v); }
static void showStr (char *para, char *v) { fprintf(stdout, " %-20s = %s\n" , para, v); }
static void showLvl (char *para, int   v)
{
	if      (v == ER) { showStr(para, "E"); }
	else if (v == WA) { showStr(para, "W"); }
	else if (v == IN) { showStr(para, "I"); }
	else if (v == DG) { showStr(para, "D"); }
	else              { showStr(para, "V"); }
}

/*************************************************************/
/** COMMON                                                   */
/*************************************************************/
int appProfileShow()
{
	char chgtime[32];
	char acs_addr[64];
	char rms_addr[64];
	char scf_addr[64];

	//
	memset(acs_addr, 0x00, sizeof(acs_addr));
	memset(rms_addr, 0x00, sizeof(rms_addr));
	memset(scf_addr, 0x00, sizeof(scf_addr));
	if (strlen(pProfile->ACSHttpServerHost) != 0) {
		snprintf(acs_addr, sizeof(acs_addr), "http://%s:%d", pProfile->ACSHttpServerHost, pProfile->ACSHttpServerPort);
	}
	if (strlen(pProfile->RMSHttpServerHost) != 0) {
		snprintf(rms_addr, sizeof(rms_addr), "http://%s:%d", pProfile->RMSHttpServerHost, pProfile->RMSHttpServerPort);
	}
	if (strlen(pProfile->SCFTcpServerHost) != 0) {
		snprintf(scf_addr, sizeof(scf_addr), "sock://%s:%d", pProfile->SCFTcpServerHost , pProfile->SCFTcpServerPort);
	}

	printf("===============================================\n");
	printf("-----------------------------------------------\n");
	printf("[%s, %s]\n", COMMON_F, comTimeT2Str(chgtime, sizeof(chgtime), "%Y/%m/%d %H:%M:%S", comTime()));
	//for USER
	printf("-----------------------------------------------\n");
	showStr ("VERSION", VERSION);
	showStr ("E164"   , pProfile->E164);
	showStr ("AppType", pProfile->AppType);
	showLong("IUID"   , pProfile->IUID);
	showStr ("AuthKey", pProfile->AuthKey);

	//for SERVER
	printf("-----------------------------------------------\n");
	showStr("ACSHttpServerAddr", acs_addr);
	showStr("RMSHttpServerAddr", rms_addr);
	showStr("SCFTcpServerAddr" , scf_addr);

	//for WEBI
	printf("-----------------------------------------------\n");
	showInt("WEBIListenPort", pProfile->WEBIListenPort);

	//for SCF
	printf("-----------------------------------------------\n");
	showStr("SCFTcpSourceIp", pProfile->SCFTcpSourceIp);
	showStr("SCFTcpStatus"  , appCodeMap2Str(CC_TcpStatus, pProfile->SCFTcpStatus));
	showStr("SCFTcpFaultTime", comTimeT2Str(chgtime, sizeof(chgtime), "%Y/%m/%d %H:%M:%S", pProfile->SCFTcpFaultTime));
	showInt("SCFTcpFaultDuration", pProfile->SCFTcpFaultDuration);

	//for CHANNEL
	printf("-----------------------------------------------\n");
	showLong("ChannelSID"    , pProfile->ChannelSID);
	showStr ("ChannelChgTime", comTimeT2Str(chgtime, sizeof(chgtime), "%Y/%m/%d %H:%M:%S", pProfile->ChannelChgTime));
	showStr ("ChannelStatus" , appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus));

	//for VOIP
	printf("-----------------------------------------------\n");
	showInt("VoipAudioVolume", pProfile->VoipAudioVolume); 
	showStr("VoipRunning"    , (pProfile->VoipRunning == 1) ? "true" : "false");
	showStr("VoipDestIp"     , pProfile->VoipDestIp);
	showInt("VoipDestAPort"  , pProfile->VoipDestAPort);
	showInt("VoipDestMPort"  , pProfile->VoipDestMPort);
	showStr("VoipAudioCodec" , appAudioCodec2Str(pProfile->VoipAudioCodec));
	showStr("VoipCallID"     , pProfile->VoipCallID);

	//for MBCP
	printf("-----------------------------------------------\n");
	showStr("MBCPStatus"        , appCodeMap2Str(CC_MbcpStatus, pProfile->MBCPStatus));
	showStr("MBCPChgTime"       , comTimeT2Str(chgtime, sizeof(chgtime), "%Y/%m/%d %H:%M:%S", pProfile->MBCPChgTime));
	showStr("MBCPStillAliveTime", comTimeT2Str(chgtime, sizeof(chgtime), "%Y/%m/%d %H:%M:%S", pProfile->MBCPStillAliveTime));

	//for CLI
	printf("-----------------------------------------------\n");
	showStr("CLI_mplayer" , pProfile->CLI_mplayer);
	showStr("CLI_reboot"  , pProfile->CLI_reboot);
	showStr("CLI_fwupdate", pProfile->CLI_fwupdate);

	//for Sound Clip
	printf("-----------------------------------------------\n");
	showStr("SoundClipPTTStart", pProfile->SoundClipPTTStart);
	showStr("SoundClipPTTStop" , pProfile->SoundClipPTTStop );
	//
	if (strlen(pProfile->SoundClipPath_00) > 0) { showStr("SoundClipPath_00", pProfile->SoundClipPath_00); }
	if (strlen(pProfile->SoundClipPath_01) > 0) { showStr("SoundClipPath_01", pProfile->SoundClipPath_01); }
	if (strlen(pProfile->SoundClipPath_02) > 0) { showStr("SoundClipPath_02", pProfile->SoundClipPath_02); }
	if (strlen(pProfile->SoundClipPath_03) > 0) { showStr("SoundClipPath_03", pProfile->SoundClipPath_03); }
	if (strlen(pProfile->SoundClipPath_04) > 0) { showStr("SoundClipPath_04", pProfile->SoundClipPath_04); }
	if (strlen(pProfile->SoundClipPath_05) > 0) { showStr("SoundClipPath_05", pProfile->SoundClipPath_05); }
	if (strlen(pProfile->SoundClipPath_06) > 0) { showStr("SoundClipPath_06", pProfile->SoundClipPath_06); }
	if (strlen(pProfile->SoundClipPath_07) > 0) { showStr("SoundClipPath_07", pProfile->SoundClipPath_07); }
	if (strlen(pProfile->SoundClipPath_08) > 0) { showStr("SoundClipPath_08", pProfile->SoundClipPath_08); }
	if (strlen(pProfile->SoundClipPath_09) > 0) { showStr("SoundClipPath_09", pProfile->SoundClipPath_09); }

	//for AutoRecovery
	printf("-----------------------------------------------\n");
	showInt("AutoRecoveryPeriodSec", pProfile->AutoRecoveryPeriodSec);
	showInt("FirmwareUpdateEnabled", pProfile->FirmwareUpdateEnabled);

	//for PING
	printf("-----------------------------------------------\n");
	showInt("SCFTcpIdleSec", pProfile->SCFTcpIdleSec);
	showInt("SCFTcpLostSec", pProfile->SCFTcpLostSec);

	//for PERIODIC
	printf("-----------------------------------------------\n");
	showInt("UseringPeriodSec", pProfile->UseringPeriodSec);
	showInt("RoomingPeriodSec", pProfile->RoomingPeriodSec);
	showInt("JoiningPeriodSec", pProfile->JoiningPeriodSec);

	//for LOG
	printf("-----------------------------------------------\n");
	showInt("Logging"      , pProfile->Logging);
	showLvl("LogLevel"     , pProfile->LogLevel);

	return 0;
}

int appProfileSave()
{
	FILE *fp;
	char  path[256];

	/* setup the path */
	comGetConfPath(COMMON_F, path);

	/* open and load... */
	if ((fp = fopen(path, "w")) == NULL) {
		printf("# FAILED - NO SUCH FILE(%s) <%s>\n", path, __func__);
		return -1;
	}
	//for USER
	saveStr (fp, "E164"   , pProfile->E164);
	saveStr (fp, "AppType", pProfile->AppType);
	saveLong(fp, "IUID"   , pProfile->IUID);
	saveStr (fp, "AuthKey", pProfile->AuthKey);
	//for SERVER
//	saveStr(fp, "ACSHttpServerHost" , pProfile->ACSHttpServerHost);
//	saveInt(fp, "ACSHttpServerPort" , pProfile->ACSHttpServerPort);
	saveStr(fp, "RMSHttpServerHost" , pProfile->RMSHttpServerHost);
	saveInt(fp, "RMSHttpServerPort" , pProfile->RMSHttpServerPort);
	saveStr(fp, "SCFTcpServerHost"  , pProfile->SCFTcpServerHost);
	saveInt(fp, "SCFTcpServerPort"  , pProfile->SCFTcpServerPort);
	//for WEBI
//	saveInt(fp, "WEBIListenPort", pProfile->WEBIListenPort);
	//for Voip
	saveInt(fp, "VoipAudioVolume", pProfile->VoipAudioVolume);
	//for CLI
//	saveStr(fp, "CLI_mplayer" , pProfile->CLI_mplayer);
//	saveStr(fp, "CLI_reboot"  , pProfile->CLI_reboot);
//	saveStr(fp, "CLI_fwupdate", pProfile->CLI_fwupdate);
	//for SoundClip
//	saveStr(fp, "SoundClipPTTStart", pProfile->SoundClipPTTStart);
//	saveStr(fp, "SoundClipPTTStop" , pProfile->SoundClipPTTStop);
	//
	saveStr(fp, "SoundClipPath_00" , pProfile->SoundClipPath_00);
	saveStr(fp, "SoundClipPath_01" , pProfile->SoundClipPath_01);
	saveStr(fp, "SoundClipPath_02" , pProfile->SoundClipPath_02);
	saveStr(fp, "SoundClipPath_03" , pProfile->SoundClipPath_03);
	saveStr(fp, "SoundClipPath_04" , pProfile->SoundClipPath_04);
	saveStr(fp, "SoundClipPath_05" , pProfile->SoundClipPath_05);
	saveStr(fp, "SoundClipPath_06" , pProfile->SoundClipPath_06);
	saveStr(fp, "SoundClipPath_07" , pProfile->SoundClipPath_07);
	saveStr(fp, "SoundClipPath_08" , pProfile->SoundClipPath_08);
	saveStr(fp, "SoundClipPath_09" , pProfile->SoundClipPath_09);
	//for AutoRecovery
	saveInt(fp, "AutoRecoveryPeriodSec", pProfile->AutoRecoveryPeriodSec);
//	saveInt(fp, "FirmwareUpdateEnabled", pProfile->FirmwareUpdateEnabled);
	//for PING
	saveInt(fp, "SCFTcpIdleSec", pProfile->SCFTcpIdleSec);
	saveInt(fp, "SCFTcpLostSec", pProfile->SCFTcpLostSec);
	//for PERIODIC
	saveInt(fp, "UseringPeriodSec", pProfile->UseringPeriodSec);
	saveInt(fp, "RoomingPeriodSec", pProfile->RoomingPeriodSec);
	saveInt(fp, "JoiningPeriodSec", pProfile->JoiningPeriodSec);
	//
	saveInt (fp, "Logging"      , pProfile->Logging);
	saveLvl (fp, "LogLevel"     , pProfile->LogLevel);

	fclose(fp);

	return 0;
}

int appProfileSet(char *line, int hasSet)
{
	char  para[100], value[100];
	char *p;

	/* ... */
	if ((p = strstr(line, "=")) == NULL) {
		return 0;
	}

	/* property */
	snprintf(para, (p - line) + 1, "%s", line);

	/* value */
	while (*p == '=' || *p == ' ' || *p == '\t' || *p == '\n') {
		p++;
	}
	sprintf(value, "%s", p);

	/* update */
	//for USER
	if      (strcasecmp(para, "E164"        ) == 0) { return setStr ( pProfile->E164   , value); }
	else if (strcasecmp(para, "AppType"     ) == 0) { return setStr ( pProfile->AppType, value); }
	else if (strcasecmp(para, "IUID"        ) == 0) { return setLong(&pProfile->IUID   , value); }
	else if (strcasecmp(para, "AuthKey"     ) == 0) { return setStr ( pProfile->AuthKey, value); }
	//for CHANNEL
	else if (strcasecmp(para, "ACSHttpServerHost" ) == 0) {
		if(hasSet) {
			return setStr( pProfile->ACSHttpServerHost , value);
		} else {
			printf("# FAILED - CAN NOT EDIT THIS OPTION\n");
			return -1;
		}
	}
	else if (strcasecmp(para, "ACSHttpServerPort" ) == 0) {
		if(hasSet) {
			return setInt(&pProfile->ACSHttpServerPort , value);
		} else {
			printf("# FAILED - CAN NOT EDIT THIS OPTION\n");
			return -1;
		}
	}
	else if (strcasecmp(para, "SCFTcpServerHost"  ) == 0) { return setStr( pProfile->SCFTcpServerHost  , value); }
	else if (strcasecmp(para, "SCFTcpServerPort"  ) == 0) { return setInt(&pProfile->SCFTcpServerPort  , value); }
	else if (strcasecmp(para, "RMSHttpServerHost" ) == 0) { return setStr( pProfile->RMSHttpServerHost , value); }
	else if (strcasecmp(para, "RMSHttpServerPort" ) == 0) { return setInt(&pProfile->RMSHttpServerPort , value); }
	//for WEBI
	else if (strcasecmp(para, "WEBIListenPort" ) == 0) {
		if(hasSet) {
			return setInt(&pProfile->WEBIListenPort , value);
		} else {
			printf("# FAILED - CAN NOT EDIT THIS OPTION\n");
			return -1;
		}
	}
	//for VOIP
	else if (strcasecmp(para, "VoipAudioVolume" ) == 0) { return setInt(&pProfile->VoipAudioVolume , value); }
	//for CLI
	else if (strcasecmp(para, "CLI_mplayer" ) == 0) {
		if(hasSet) {
			return setStr(pProfile->CLI_mplayer , value);
		} else {
			printf("# FAILED - CAN NOT EDIT THIS OPTION\n");
			return -1;
		}
	}
	else if (strcasecmp(para, "CLI_reboot"  ) == 0) {
		if(hasSet) {
			return setStr(pProfile->CLI_reboot  , value);
		} else {
			printf("# FAILED - CAN NOT EDIT THIS OPTION\n");
			return -1;
		}
	}
	else if (strcasecmp(para, "CLI_fwupdate") == 0) {
		if(hasSet) {
			return setStr(pProfile->CLI_fwupdate, value);
		} else {
			printf("# FAILED - CAN NOT EDIT THIS OPTION\n");
			return -1;
		}
	}
	//for SoundClip
	else if (strcasecmp(para, "SoundClipPTTStart") == 0) {
		if(hasSet) {
			return setStr(pProfile->SoundClipPTTStart, value);
		} else {
			printf("# FAILED - CAN NOT EDIT THIS OPTION\n");
			return -1;
		}
	}
	else if (strcasecmp(para, "SoundClipPTTStop" ) == 0) {
		if(hasSet) {
			return setStr(pProfile->SoundClipPTTStop , value);
		} else {
			printf("# FAILED - CAN NOT EDIT THIS OPTION\n");
			return -1;
		}
	}
	//
	else if (strcasecmp(para, "SoundClipPath_00") == 0) { return setStr(pProfile->SoundClipPath_00, value); }
	else if (strcasecmp(para, "SoundClipPath_01") == 0) { return setStr(pProfile->SoundClipPath_01, value); }
	else if (strcasecmp(para, "SoundClipPath_02") == 0) { return setStr(pProfile->SoundClipPath_02, value); }
	else if (strcasecmp(para, "SoundClipPath_03") == 0) { return setStr(pProfile->SoundClipPath_03, value); }
	else if (strcasecmp(para, "SoundClipPath_04") == 0) { return setStr(pProfile->SoundClipPath_04, value); }
	else if (strcasecmp(para, "SoundClipPath_05") == 0) { return setStr(pProfile->SoundClipPath_05, value); }
	else if (strcasecmp(para, "SoundClipPath_06") == 0) { return setStr(pProfile->SoundClipPath_06, value); }
	else if (strcasecmp(para, "SoundClipPath_07") == 0) { return setStr(pProfile->SoundClipPath_07, value); }
	else if (strcasecmp(para, "SoundClipPath_08") == 0) { return setStr(pProfile->SoundClipPath_08, value); }
	else if (strcasecmp(para, "SoundClipPath_09") == 0) { return setStr(pProfile->SoundClipPath_09, value); }
	//for AutoRecovery
	else if (strcasecmp(para, "AutoRecoveryPeriodSec") == 0) { return setInt(&pProfile->AutoRecoveryPeriodSec, value); }
	else if (strcasecmp(para, "FirmwareUpdateEnabled") == 0) {
		if(hasSet) {
			return setInt(&pProfile->FirmwareUpdateEnabled, value);
		} else {
			printf("# FAILED - CAN NOT EDIT THIS OPTION\n");
			return -1;
		}
	}
	//for PING
	else if (strcasecmp(para, "SCFTcpIdleSec") == 0) { return setInt(&pProfile->SCFTcpIdleSec, value); }
	else if (strcasecmp(para, "SCFTcpLostSec") == 0) { return setInt(&pProfile->SCFTcpLostSec, value); }
	//for PERIODIC
	else if (strcasecmp(para, "UseringPeriodSec") == 0) { return setInt(&pProfile->UseringPeriodSec, value); }
	else if (strcasecmp(para, "RoomingPeriodSec") == 0) { return setInt(&pProfile->RoomingPeriodSec, value); }
	else if (strcasecmp(para, "JoiningPeriodSec") == 0) { return setInt(&pProfile->JoiningPeriodSec, value); }
	//
	else if (strcasecmp(para, "Logging"      ) == 0) { return setInt (&pProfile->Logging , value); }
	else if (strcasecmp(para, "LogLevel"     ) == 0) { return setLvl (&pProfile->LogLevel, value); }
	else {
		printf("# FAILED - NO SUCH STATIC PROFILE (common.conf --> %s)\n", para);
		return -1;
	}

	return 0;
}

static int _loadconfig(char *file)
{
	FILE *fp;
	char  path[256], line[256];

	/* setup the path */
	comGetConfPath(file, path);

	/* open and load... */
	if ((fp = fopen(path, "r")) == NULL) {
		printf("# FAILED - NO SUCH FILE(%s) <%s>\n", path, __func__);
		return -1;
	}
	while (fgets(line, 256, fp) != NULL) {
		/* check */
		if (*line != '\0' && line[strlen(line) - 1] == '\n') {
			line[strlen(line) - 1] = '\0';
		}
		if (*line == '#' || *line == '\0') { /* skip the comments and blank line */
			continue;
		}
		if (strstr(line, "=") == NULL) {
			continue;
		}

		appProfileSet(line, 1);
	}
	fclose(fp); /* close (don't forget!) */

	return 0;
}

int appProfileLoad()
{
	int result = -1;
	result = _loadconfig(COMMON_F);
	result = _loadconfig(INIT_F);

	return result;
}

void appProfileUpdateChannelInfo(long sid, int status)
{
	comLog(DG, "%s() - sid: %lu, status: %s --> %s", __func__,
			sid, 
			appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus),
			appCodeMap2Str(CC_ChnlStatus, status));

	if (pProfile->ChannelSID != sid) {
		pProfile->ChannelSID = sid;
		pProfile->ChannelChgTime= comTime();
	}

	if (pProfile->ChannelStatus != status) {
		pProfile->ChannelStatus = status;
		pProfile->ChannelChgTime= comTime();

		switch (status) {
			case CST_ROOMED :
			case CST_IDLE :
				memset(pProfile->VoipDestIp, 0x00, sizeof(pProfile->VoipDestIp));
				memset(pProfile->VoipCallID, 0x00, sizeof(pProfile->VoipCallID));
				pProfile->VoipDestAPort = 0;
				pProfile->VoipDestMPort = 0;
				pProfile->VoipRunning   = 0;
				break;
		}
	}

	return;
}

void appProfileUpdateVoipInfo(char *dst_ip, int dst_aport, int dst_mport, char *codec, char *call_id)
{
	comLog(DG, "%s() - dst_ip: %s, dst_aport: %d, dst_mport: %d, codec: %s, call_id: %s", __func__, dst_ip, dst_aport, dst_mport, codec, call_id);
	snprintf(pProfile->VoipDestIp, sizeof(pProfile->VoipDestIp), "%s", dst_ip);
	pProfile->VoipDestAPort = dst_aport;
	pProfile->VoipDestMPort = dst_mport;
	snprintf(pProfile->VoipCallID, sizeof(pProfile->VoipCallID), "%s", call_id);
	pProfile->VoipAudioCodec = appAudioCodec2Int(codec);

	return;
}

int appProfileGetFaultDuration()
{
	if (pProfile->AutoRecoveryPeriodSec > 60 && pProfile->SCFTcpFaultTime != 0) {
		return comTime() - pProfile->SCFTcpFaultTime;
	}

	return 0;
}


