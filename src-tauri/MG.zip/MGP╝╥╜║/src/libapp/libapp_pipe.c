/**
 * @date   2012/11/12
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "libapp.h"

int appPipeOpen(nonbpipe_t *p_nonb, char *name, int *maxfd, fd_set *rset, fd_set *wset)
{
	comLog(DG, "%s() - name: %s", __func__, name);

	/* init */
	memset(p_nonb, 0x00, sizeof(nonbpipe_t));
	sprintf(p_nonb->name, "%s", name);
	p_nonb->maxfd = maxfd;
	p_nonb->rset  = rset;
	p_nonb->wset  = wset;

	/* create */
	if (pipe(p_nonb->pipefd) == -1) {
		comErr(ER, errno, "fail to pipe().");
		return -1;
	}

	/* update mask */
	if (p_nonb->maxfd != NULL && p_nonb->rset) {
		comSetSelectMask(p_nonb->maxfd, p_nonb->rset, p_nonb->pipefd[0]);
	}
	if (p_nonb->maxfd != NULL && p_nonb->wset) {
		comSetSelectMask(p_nonb->maxfd, p_nonb->wset, p_nonb->pipefd[1]);
	}

	return 0;
}

int appPipeClose(nonbpipe_t *p_nonb)
{
	comLog(DG, "%s() - name: %s, pipefd[0]: %d, pipefd[1]: %d",
			__func__, p_nonb->name, p_nonb->pipefd[0], p_nonb->pipefd[1]);

	/* destroy */
	if (p_nonb->pipefd[0] != 0) {
		if (p_nonb->maxfd != NULL && p_nonb->rset != NULL) {
			comUnsetSelectMask(p_nonb->maxfd, p_nonb->rset, p_nonb->pipefd[0]);
		}
		close(p_nonb->pipefd[0]); p_nonb->pipefd[0] = 0;
	}

	if (p_nonb->pipefd[1] != 0) {
		if (p_nonb->maxfd != NULL && p_nonb->wset != NULL) {
			comUnsetSelectMask(p_nonb->maxfd, p_nonb->wset, p_nonb->pipefd[1]);
		}
		close(p_nonb->pipefd[1]); p_nonb->pipefd[1] = 0;
	}

	return 0;
}

int appPipeReadTimeo(nonbpipe_t *p_nonb, unsigned char *data, size_t dlen, int timeo)
{
	int n, nread, nleft;

	comLog(DG, "%s()", __func__);

	nread = 0;
	while ((nleft = dlen - nread) > 0) {
		errno = 0;

		comLog(DG, "%s() - nread: %d, nleft: %d, dlen: %d", __func__, nread, nleft, dlen);
		if ((n = comReadableTimeo(p_nonb->pipefd[0], timeo)) == -1) {
			if (errno == EINTR) {
				continue;
			}
			comLog(ER, "%s() fail to comReadableTimeo() error=%d(%s)", __func__, errno, strerror(errno));
			return -1;
		}
		if (n == 0) {
			comLog(ER, "%s() Readable Timeout!", __func__);
			return -1;
		}

		if ((n = read(p_nonb->pipefd[0], data + nread, nleft)) == -1) {
			if (errno == EINTR || errno == EAGAIN) {
				continue;
			}
			comLog(ER, "%s() fail to read() error=%d(%s)", __func__, errno, strerror(errno));
			return -1;
		}
		else if (n == 0) { /* EOF */
			comLog(ER, "%s() EOF!", __func__);
			return -1;
		}
		nread += n;
	}

	return nread;
}

int appPipeWriteTimeo(nonbpipe_t *p_nonb, unsigned char *data, size_t dlen, int timeo)
{
	int n, nwritten, nleft;

	comLog(DG, "%s()", __func__);

	nwritten = 0;
	while ((nleft = dlen - nwritten) > 0) {
		if ((n = comWritableTimeo(p_nonb->pipefd[1], timeo)) == -1) {
			if (errno == EINTR) {
				continue;
			}
			comLog(ER, "%s() fail to comWritableTimeo() error=%d(%s)", __func__, errno, strerror(errno));
			return -1;
		}
		if (n == 0) {
			comLog(ER, "%s() Writable Timeout!", __func__);
			return -1;
		}

		if ((n = write(p_nonb->pipefd[1], data + nwritten, nleft)) == -1) {
			if (errno == EINTR || errno == EAGAIN) {
				continue;
			}
			comLog(ER, "%s() fail to write() error=%d(%s)", __func__, errno, strerror(errno));
			return -1;
		}

		nwritten += n;
	}

	return nwritten;
}

int appPipeSignal(nonbpipe_t *p_nonb)
{
	unsigned char signal[1] = { 0x00 };

	return appPipeWriteTimeo(p_nonb, signal, sizeof(signal), 5);
}

int appPipeSignalled(nonbpipe_t *p_nonb)
{
	unsigned char signal[1];

	return appPipeReadTimeo(p_nonb, signal, sizeof(signal), 5);
}



