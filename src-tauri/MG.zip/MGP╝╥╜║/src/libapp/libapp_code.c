/**
 * @date   2012/07/27
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "libapp.h"

typedef struct _code_cate {
	int   id;
	char *name;
	int   maxnum;
} code_cate_t;

/** ----------------------------------------------------- */
static code_cate_t CodeCateMap[] = {
	{ CC_LogLevel   , "LogLevel"   , 20 },
	{ CC_CmCmdId    , "CmCmdId"    , 20 },
	{ CC_CmResCode  , "CmResCode"  , 30 },
	{ CC_CmEvtCode  , "CmEvtCode"  , 10 },
	{ CC_CmDirCode  , "CmDirCode"  , 10 },
	{ CC_CmAccType  , "CmAccType"  , 10 },
	{ CC_MpStatus   , "MpStatus"   , 20 },
	{ CC_MpQName    , "MpQName"    , 10 },
	{ CC_MpMsgType  , "MpMsgType"  , 15 },
	{ CC_MpEntType  , "MpEntType"  , 10 },
	{ CC_LmType     , "LmType"     , 15 },
	{ CC_LmResCode  , "LmResCode"  , 15 },
	{ CC_LmEvtCode  , "LmEvtCode"  , 10 },
	{ CC_LmN2N      , "LmN2N"      , 10 },
	{ CC_LmTalkType , "LmTalkType" , 10 },
	{ CC_LmNotiFlag , "LmNotiFlag" , 10 },
	{ CC_OmType     , "OmType"     , 15 },
	{ CC_HaType     , "HaType"     , 15 },
	{ CC_TcpStatus  , "TcpStatus"  , 10 },
	{ CC_EvLevel    , "EvLevel"    , 10 },
	{ CC_EvCode     , "EvCode"     , 100},
	{ CC_SlStatus   , "SlStatus"   , 10 },
	{ CC_TnSvcCode  , "TnSvcCode"  , 30 },
	{ CC_ChnlStatus , "ChnlStatus" , 10 },
	{ CC_JPackType  , "JPackType"  , 10 },
	{ CC_JPackStatus, "JPackStatus", 10 },
	{ CC_IpcMsgType , "IpcMsgType" , 50 },
	{ CC_MbcpStatus , "MbcpStatus" , 10 },
	{ -1            , "UNDEF"      , 0  }
};

codemap_t codeMap[NUMOF_CODECATE];

/** ----------------------------------------------------- */
int appLoadCode()
{
	codemap_t *p_codemap;
	char       path[128];
	int        i;

	/* init */
	memset(codeMap, 0x00, sizeof(codeMap));

	/* setup the PATH for CODE */
	comGetConfPath(CODETBL_F, path);
	
	/* load each CODETABLE */
	for (i = 0; CodeCateMap[i].id != -1; i++) {
		if (CodeCateMap[i].id >= NUMOF_CODECATE) {
			comLog(ER, "%s() INVALID CodeCateID(%d) INDEX(%d)", __func__, CodeCateMap[i].id, i);
			return -1;
		}
		/* for shortcut */
		p_codemap = codeMap + CodeCateMap[i].id;

		/* load */
		if (comCodeMapLoad(p_codemap, CodeCateMap[i].maxnum, CodeCateMap[i].name, path) == -1) {
			comLog(ER, "%s() fail to comCodeMapLoad - CATE(%s)", __func__, CodeCateMap[i].name);
			return -1;
		}
	}

	return 0;
}

codemap_t *appCodeMapGet(int codecate)
{
	if (codecate >= NUMOF_CODECATE || codecate < 0) {
		comLog(ER, "%s() INVALID CODECATE(%d)", __func__, codecate);
		return NULL;
	}

	return codeMap + codecate;
}

char *appCodeMap2Str(int codecate, int code)
{
	if (codecate >= NUMOF_CODECATE || codecate < 0) {
		comLog(ER, "%s() INVALID CODECATE(%d)", __func__, codecate);
		return CMAP_UNDEF_STR;
	}

	return comCodeMap2Str(codeMap + codecate, code);
}

void appCodeMapPrint()
{
	int i;

	for (i = 0; i < NUMOF_CODECATE; i++) { comCodeMapPrint(codeMap + i); }

	return;
}





