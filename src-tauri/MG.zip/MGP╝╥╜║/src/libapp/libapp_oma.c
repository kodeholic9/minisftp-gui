/**
 * @date   2012/07/27
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "libapp.h"
#include "jsonpack.h"

#include <mntent.h>
#include <sys/vfs.h>

static char *getLvl(int v)
{
	if      (v == ER) { return "E"; }
	else if (v == WA) { return "W"; }
	else if (v == IN) { return "I"; }
	else if (v == DG) { return "D"; }

	return "V";
}

static raw_netstat_t *lookup_raw_netstat(raw_netstat_arr_t *p, char *name)
{
	int i;
	for (i = 0; i < p->n && i < MAX_NETSTAT_NUM; i++) {
		if (strcmp(p->stat[i].name, name) == 0) {
			comLog(VB, "%s() - %s found", __func__, name);
			return p->stat + i;
		}
	}
	comLog(DG, "%s() - %s not found", __func__, name);

	return NULL;
}

static unsigned long _block2k(int size, int blocksize)
{
	unsigned long size64 = ((unsigned long)size & 0xffffffff);
	int           bshift;

	for (bshift = 0; blocksize > 1; blocksize >>= 1) {
		bshift += 1;
	}
	bshift -= U_LOG1024;

	return (bshift > 0) ? ((size64) << bshift) : ((size64) >> (-1*bshift));
}

static int _calcdelta(int _new, int _old)
{
	int delta;

	if ((delta = _new - _old) < 0) {
		delta  = 0xffffffff - _old;
		delta += _new;
	}

	return delta;
}

static int _calccpu(j_cpustat_t *p_stat, raw_cpustat_t *p_new, raw_cpustat_t *p_old)
{
	double elapsed = p_new->t - p_old->t;
	double total_changes;
	double tmp[4];

	tmp[0] = (double)_calcdelta(p_new->user, p_old->user);
	tmp[1] = (double)_calcdelta(p_new->sys , p_old->sys );
	tmp[2] = (double)_calcdelta(p_new->etc , p_old->etc );
	tmp[3] = (double)_calcdelta(p_new->idle, p_old->idle);

	total_changes = tmp[0] + tmp[1] + tmp[2] + tmp[3];
	if (total_changes <= 0) {
		total_changes = 1;
	}
	p_stat->user = (tmp[0] / (double)total_changes) * 100.0;
	p_stat->sys  = (tmp[1] / (double)total_changes) * 100.0;
	p_stat->etc  = (tmp[2] / (double)total_changes) * 100.0;
	p_stat->idle = (tmp[3] / (double)total_changes) * 100.0;

	comLog(VB, "%s() - elapsed: %f, user: %f, sys: %f, etc: %f, idle: %f", __func__,
			elapsed,
			p_stat->user,
			p_stat->sys,
			p_stat->etc,
			p_stat->idle);

	return 0;
}

static int _calcmem(j_memstat_t *p_stat, raw_memstat_t *p_new)
{
	p_stat->total   = p_new->total;
	p_stat->avail   = p_new->avail;
	p_stat->freed   = p_new->freed;
	p_stat->buffers = p_new->buffers;
	p_stat->cached  = p_new->cached;
	p_stat->usage   = p_new->usage;
	comLog(VB, "%s() - total: %lu, avail: %lu, freed: %lu, buffers: %lu, cached: %lu, usage: %f", __func__,
			p_stat->total,
			p_stat->avail,
			p_stat->freed,
			p_stat->buffers,
			p_stat->cached,
			p_stat->usage);

	return 0;
}

static int _calcfys(j_fsystat_t *p_list, raw_fsystat_arr_t *p_new)
{
	int i = 0;

	for (i = 0; i < p_new->n; i++) {
		sprintf(p_list[i].name, "%s", p_new->stat[i].name);
		p_list[i].total = p_new->stat[i].total;
		p_list[i].freed = p_new->stat[i].freed;
		p_list[i].avail = p_new->stat[i].avail;
		p_list[i].usage = p_new->stat[i].usage;

		comLog(VB, "%s() - name: %s, total: %lu, freed: %lu, avail: %lu, usage: %f", __func__,
				p_list[i].name,
				p_list[i].total,
				p_list[i].freed,
				p_list[i].avail,
				p_list[i].usage);
	}

	return i;
}

static int _calcnet(j_netstat_t *p_list, raw_netstat_arr_t *p_new, raw_netstat_arr_t *p_old)
{
	int i = 0;
	double elapsed = p_new->t - p_old->t;
	raw_netstat_t *p_old_netstat;

	for (i = 0; i < p_new->n; i++) {
		sprintf(p_list[i].name, "%s", p_new->stat[i].name);
		if ((p_old_netstat = lookup_raw_netstat(p_old, p_new->stat[i].name)) != NULL) {
			p_list[i].ipkts = _calcdelta(p_new->stat[i].ipkts, p_old_netstat->ipkts) / elapsed;
			p_list[i].opkts = _calcdelta(p_new->stat[i].opkts, p_old_netstat->opkts) / elapsed;
			p_list[i].iocts = _calcdelta(p_new->stat[i].iocts, p_old_netstat->iocts) / elapsed;
			p_list[i].oocts = _calcdelta(p_new->stat[i].oocts, p_old_netstat->oocts) / elapsed;
			p_list[i].ierrs = _calcdelta(p_new->stat[i].ierrs, p_old_netstat->ierrs) / elapsed;
			p_list[i].oerrs = _calcdelta(p_new->stat[i].oerrs, p_old_netstat->oerrs) / elapsed;
			p_list[i].collisions = _calcdelta(p_new->stat[i].collisions, p_old_netstat->collisions) / elapsed;
		}
		else {
			p_list[i].ipkts = 0;
			p_list[i].opkts = 0;
			p_list[i].iocts = 0;
			p_list[i].oocts = 0;
			p_list[i].ierrs = 0;
			p_list[i].oerrs = 0;
			p_list[i].collisions = 0;
		}
		comLog(VB, "%s() - name: %s, pkts: %f|%f, octs: %f|%f, errs: %f|%f, coll: %f", __func__,
				p_list[i].name,
				p_list[i].ipkts,
				p_list[i].opkts,
				p_list[i].iocts,
				p_list[i].oocts,
				p_list[i].ierrs,
				p_list[i].oerrs,
				p_list[i].collisions);
	}

	return i;
}

/** ----------------------------------------------------- */
int appOmaLoadPsinfo(ext_pstable_t *p_pstable, char *user)
{
	FILE *pipefp;
	char  line[1024];
	ext_psinfo_t psinfo;

	comLog(VB, "%s()", __func__);

	memset(p_pstable, 0x00, sizeof(ext_pstable_t));

	/* load */
	if ((pipefp = popen(_PS_CMD, "r")) == NULL) {
		printf("fail to execute command [%s]", _PS_CMD);
		return -1;
	}
	while (fgets(line, sizeof(line), pipefp) != NULL) {
		memset(&psinfo, 0x00, sizeof(psinfo));
		sscanf(line, "%u %u %s", &psinfo.pid, &psinfo.ppid, psinfo.user);
		if (psinfo.pid > 0 && (user == NULL || strcmp(psinfo.user, user) == 0)) {
			if (p_pstable->n >= MAX_PSINFO_NUM) {
				printf("can't hold too many psinfo [%d]", p_pstable->n);
				pclose(pipefp);
				return -1;
			}
			printf("psinfo: %d, %d, %s\n", psinfo.pid, psinfo.ppid, psinfo.user);
			memcpy(p_pstable->psinfo + p_pstable->n, &psinfo, sizeof(ext_psinfo_t));
			p_pstable->n += 1;
		}

		/* reinit */
		memset(line, 0x00, sizeof(line));
	}
	pclose(pipefp);

	return 0;
}

ext_psinfo_t *appOmaLookupPsinfo(ext_pstable_t *p_pstable, int pid, int ppid)
{
	int i;

	comLog(VB, "%s() - pstable: %p, pid: %d, ppid: %d", __func__, p_pstable, pid, ppid);

	if (p_pstable == NULL) {
		return NULL;
	}

	for (i = 0; i < p_pstable->n; i++) {
		if (p_pstable->psinfo[i].pid == pid) {
			if (ppid == 0 || ppid == p_pstable->psinfo[i].ppid) {
				return p_pstable->psinfo + i;
			}
		}
	}

	return NULL;
}

int appOmaGetJSProcInfo(j_process_t *p_pslist, int size)
{
	j_process_t     jsps;
	ext_pstable_t   pstable;
	ext_psinfo_t   *p_psinfo;

	char user[16], *p_user;
	int  i, ap_id, count = 0;

	comLog(VB, "%s() - proclist: %p, size: %d", __func__, p_pslist, size);

	p_user = comGetUName(user, sizeof(user));

	if (appOmaLoadPsinfo(&pstable, p_user) == -1) {
		return -1;
	}

	/* for PMON */
	memset(&jsps, 0x00, sizeof(j_process_t));
	snprintf(jsps.alias, sizeof(jsps.alias), "%s", appName(PMON));
	if ((p_psinfo = appOmaLookupPsinfo(&pstable, appP->slaveholder.mpid, 0)) != NULL) {
		comLog(VB, "%s() - %s found", __func__, jsps.alias);
		jsps.pid  = p_psinfo->pid;
		jsps.ppid = p_psinfo->ppid;
		snprintf(jsps.status, sizeof(jsps.status), "LIVE");
	}
	else {
		comLog(VB, "%s() - %s not found", __func__, jsps.alias);
		snprintf(jsps.status, sizeof(jsps.status), "DOWN");
	}
	jsps.ipc_send    = appP->ipcdefault[PMON].ipcctl.sendIdx;
	jsps.ipc_recv    = appP->ipcdefault[PMON].ipcctl.recvIdx;
	jsps.debug_point = appP->debugholder.debug[PMON][0][0].pos[0];
	jsps.debug_count = appP->debugholder.debug[PMON][0][0].cnt;
	jsps.start_time       = appP->slaveholder.strttime * 1000;
	jsps.stop_time        = 0;
	jsps.total_down_count = 0;
	jsps.recent_down_count= 0;
	memcpy(p_pslist + count, &jsps, sizeof(j_process_t));
	count += 1;

	/* for REST */
	for (i = 0; i < appP->slaveholder.used; i++) {
		if (!appP->slaveholder.slaveinfo[i].enabled) {
			continue;
		}

		memset(&jsps, 0x00, sizeof(j_process_t));

		ap_id = appId(appP->slaveholder.slaveinfo[i].alias);
		snprintf(jsps.alias , sizeof(jsps.alias) , "%s", appP->slaveholder.slaveinfo[i].alias);

		if ((p_psinfo = appOmaLookupPsinfo(&pstable, 
						appP->slaveholder.slaveinfo[i].pid, 
						appP->slaveholder.mpid)) == NULL)
		{
			p_psinfo = appOmaLookupPsinfo(&pstable, appP->slaveholder.slaveinfo[i].pid, 0);
		}
		if (p_psinfo != NULL) {
			comLog(VB, "%s() - %s found", __func__, jsps.alias);
			jsps.pid  = p_psinfo->pid;
			jsps.ppid = p_psinfo->ppid;
			snprintf(jsps.status, sizeof(jsps.status), "%s%s",
					appCodeMap2Str(CC_SlStatus, appP->slaveholder.slaveinfo[i].status),
					appP->slaveholder.slaveinfo[i].blocked ? "|BLOCKED" : "");
		}
		else {
			comLog(VB, "%s() - %s not found", __func__, jsps.alias);
			snprintf(jsps.status, sizeof(jsps.status), "%s%s",
					"DOWN", appP->slaveholder.slaveinfo[i].blocked ? "|BLOCKED" : "");
		}
		jsps.ipc_send         = appP->ipcdefault[ap_id].ipcctl.sendIdx;
		jsps.ipc_recv         = appP->ipcdefault[ap_id].ipcctl.recvIdx;
		jsps.debug_point      = appP->debugholder.debug[ap_id][0][0].pos[0];
		jsps.debug_count      = appP->debugholder.debug[ap_id][0][0].cnt;
		jsps.start_time       = appP->slaveholder.slaveinfo[i].strttime * 1000;
		jsps.stop_time        = appP->slaveholder.slaveinfo[i].downtime[0] * 1000;
		jsps.total_down_count = appP->slaveholder.slaveinfo[i].downnum;
		jsps.recent_down_count= appP->slaveholder.slaveinfo[i].faultednum;
		if (count <= size) {
			memcpy(p_pslist + count, &jsps, sizeof(j_process_t));
			count += 1;
		}
	}

	return count;
}


int appOmaGetJSConfigInfo(j_config_t *p_cfg)
{

	char acs_addr[64];
	char rms_addr[64];
	char scf_addr[64];

	memset(acs_addr, 0x00, sizeof(acs_addr));
	if (strlen(pProfile->ACSHttpServerHost) != 0) {
		snprintf(acs_addr, sizeof(acs_addr), "http://%s:%d", pProfile->ACSHttpServerHost, pProfile->ACSHttpServerPort);
	}

	memset(rms_addr, 0x00, sizeof(rms_addr));
	if (strlen(pProfile->RMSHttpServerHost) != 0) {
		snprintf(rms_addr, sizeof(rms_addr), "http://%s:%d", pProfile->RMSHttpServerHost, pProfile->RMSHttpServerPort);
	}

	memset(scf_addr, 0x00, sizeof(scf_addr));
	if (strlen(pProfile->SCFTcpServerHost) != 0) {
		snprintf(scf_addr, sizeof(scf_addr), "sock://%s:%d", pProfile->SCFTcpServerHost , pProfile->SCFTcpServerPort);
	}

	/* device */
	snprintf(p_cfg->version , sizeof(p_cfg->version), "%s", VERSION);
	snprintf(p_cfg->e164    , sizeof(p_cfg->e164), "%s", pProfile->E164);
	snprintf(p_cfg->app_type, sizeof(p_cfg->app_type), "%s", pProfile->AppType);
	p_cfg->iuid = pProfile->IUID;
	snprintf(p_cfg->auth_key, sizeof(p_cfg->auth_key), "%s", pProfile->AuthKey);
	/* server */
	snprintf(p_cfg->acs_http_server_addr, sizeof(p_cfg->acs_http_server_addr), "%s", acs_addr);
	snprintf(p_cfg->rms_http_server_addr, sizeof(p_cfg->rms_http_server_addr), "%s", rms_addr);
	snprintf(p_cfg->scf_tcp_server_addr , sizeof(p_cfg->scf_tcp_server_addr) , "%s", scf_addr);
	snprintf(p_cfg->scf_tcp_source_ip   , sizeof(p_cfg->scf_tcp_source_ip), "%s", pProfile->SCFTcpSourceIp);
	snprintf(p_cfg->scf_tcp_status      , sizeof(p_cfg->scf_tcp_status)   , "%s", appCodeMap2Str(CC_TcpStatus, pProfile->SCFTcpStatus));
	p_cfg->scf_tcp_fault_time = pProfile->SCFTcpFaultTime;
	p_cfg->scf_tcp_fault_duration = pProfile->SCFTcpFaultDuration;
	/* webi*/
	p_cfg->webi_listen_port = pProfile->WEBIListenPort;
	/* channel */
	p_cfg->channel_sid = pProfile->ChannelSID;
	p_cfg->channel_status_change_time = pProfile->ChannelChgTime * 1000;
	snprintf(p_cfg->channel_status, sizeof(p_cfg->channel_status), "%s", appCodeMap2Str(CC_ChnlStatus, pProfile->ChannelStatus));
	/* voip */
	p_cfg->voip_audio_volume = pProfile->VoipAudioVolume;
	p_cfg->voip_running      = pProfile->VoipRunning;
	snprintf(p_cfg->voip_dest_ip, sizeof(p_cfg->voip_dest_ip), "%s", pProfile->VoipDestIp);
	p_cfg->voip_dest_audio_port = pProfile->VoipDestAPort;
	p_cfg->voip_dest_mbcp_port  = pProfile->VoipDestMPort;
	snprintf(p_cfg->voip_audio_codec, sizeof(p_cfg->voip_audio_codec), "%s", appAudioCodec2Str(pProfile->VoipAudioCodec));
	snprintf(p_cfg->voip_call_id, sizeof(p_cfg->voip_call_id), "%s", pProfile->VoipCallID);
	/* mbcp */
	snprintf(p_cfg->mbcp_status, sizeof(p_cfg->mbcp_status), "%s",  appCodeMap2Str(CC_MbcpStatus, pProfile->MBCPStatus));
	p_cfg->mbcp_status_change_time = pProfile->MBCPChgTime * 1000;
	p_cfg->mbcp_still_alive_time   = pProfile->MBCPStillAliveTime * 1000;
	/* sound player */
#if 0
	sound_player_path[128];
	sound_clip_path_00[128];
#endif
	/* auto-discovery */
	p_cfg->auto_recovery_period_sec = pProfile->AutoRecoveryPeriodSec;
	p_cfg->firmware_update_enabled  = pProfile->FirmwareUpdateEnabled;
	/* scf idle/lost */
	p_cfg->scf_tcp_idle_sec = pProfile->SCFTcpIdleSec;
	p_cfg->scf_tcp_lost_sec = pProfile->SCFTcpLostSec;
	/* period */
	p_cfg->usering_period_sec = pProfile->UseringPeriodSec;
	p_cfg->rooming_period_sec = pProfile->RoomingPeriodSec;
	p_cfg->joining_period_sec = pProfile->JoiningPeriodSec;
	/* logging */
	p_cfg->logging = pProfile->Logging;
	snprintf(p_cfg->log_level, sizeof(p_cfg->log_level), "%s", getLvl(pProfile->LogLevel));

	return 0;
}

int appOmaGetJSUnameInfo(j_uname_t *p_uname)
{
	struct utsname u;

	if (uname(&u) == -1) {
		comLog(ER, "%s() fail to uname() - error:%d(%s)", __func__, errno, strerror(errno));
		return -1;
	}

	memset(p_uname, 0x00, sizeof(j_uname_t));
	snprintf(p_uname->sysname , sizeof(p_uname->sysname ), "%s", u.sysname);
	snprintf(p_uname->nodename, sizeof(p_uname->nodename), "%s", u.nodename);
	snprintf(p_uname->release , sizeof(p_uname->release ), "%s", u.release );
	snprintf(p_uname->version , sizeof(p_uname->version ), "%s", u.version);
	snprintf(p_uname->machine , sizeof(p_uname->machine ), "%s", u.machine);

	return 0;
}

/********************************************************************/
/* CPU/MEM/FSY/NET STAT */
/********************************************************************/
int appOmaLoadRawCpustat(raw_cpustat_t *p_stat)
{
	FILE *fp;
	char  line[1024];
	unsigned long tmp[4];

	/* init */
	memset(p_stat, 0x00, sizeof(raw_cpustat_t));

	/* U */
	p_stat->t = comTimeGetU();

	/* collect */
	if ((fp = fopen("/proc/stat", "r")) == NULL) {
		comLog(ER, "%s() fail to fopen(/proc/stat) - error:%d(%s)", __func__, errno, strerror(errno));
		return -1;
	}
	while (fgets(line, sizeof(line), fp) != NULL) {
		if (strncmp(line, "cpu ", 4) == 0) {
			sscanf(line, "%*s %lu %lu %lu %lu %*s\n", tmp + 0, tmp + 1, tmp + 2, tmp + 3);
			p_stat->user= (unsigned int)(tmp[0] & 0xffffffff); /* user   */
			p_stat->etc = (unsigned int)(tmp[1] & 0xffffffff); /* nice   */
			p_stat->sys = (unsigned int)(tmp[2] & 0xffffffff); /* system */
			p_stat->idle= (unsigned int)(tmp[3] & 0xffffffff); /* idle   */
			break;
		}
	}
	fclose(fp);

	/* display */
	comLog(VB, "%s() user: %u, etc: %u, sys: %u, idle: %u", __func__,
			p_stat->user,
			p_stat->etc, 
			p_stat->sys, 
			p_stat->idle);

	return 0;
}

int appOmaLoadRawMemstat(raw_memstat_t *p_stat)
{
	FILE *fp;
	char *p, line[1024];

	/* init */
	memset(p_stat, 0x00, sizeof(raw_memstat_t));

	/* U */
	p_stat->t = comTimeGetU();

	/* collect */
	if ((fp = fopen("/proc/meminfo", "r")) == NULL) {
		comLog(ER, "%s() fail to fopen(/proc/meminfo) - error:%d(%s)", __func__, errno, strerror(errno));
		return -1;
	}
	while (fgets(line, sizeof(line), fp) != NULL) {
		if (strncmp(line, "MemTotal:", 9) == 0 && (p = comSkipToken(line)) != NULL) {
			p_stat->total = strtoul(p, &p, 0);
		}
		else if (strncmp(line, "MemAvailable:", 13) == 0 && (p = comSkipToken(line)) != NULL) {
			p_stat->avail = strtoul(p, &p, 0);
		}
		else if (strncmp(line, "MemFree:", 8) == 0 && (p = comSkipToken(line)) != NULL) {
			p_stat->freed = strtoul(p, &p, 0);
		}
		else if (strncmp(line, "Buffers:", 8) == 0 && (p = comSkipToken(line)) != NULL) {
			p_stat->buffers = strtoul(p, &p, 0);
		}
		else if (strncmp(line, "Cached:", 7) == 0 && (p = comSkipToken(line)) != NULL) {
			p_stat->cached = strtoul(p, &p, 0);
		}
	}
	fclose(fp);

	/* calculate the usage(%%) */
	if (p_stat->total > 0) {
		unsigned long used = p_stat->total - p_stat->freed;
		p_stat->usage = (used / (double)p_stat->total) * 100.0;
	}

	/* display */
	comLog(VB, "%s() total: %lu, avail: %lu, freed: %lu, buffers: %lu, cached: %lu, usage: %f", __func__,
			p_stat->total,
			p_stat->avail,
			p_stat->freed,
			p_stat->buffers,
			p_stat->cached,
			p_stat->usage);

	return 0;
}

int appOmaLoadRawFsystat(raw_fsystat_arr_t *p_stat)
{
	FILE  *fp;
	struct mntent *p_mntent;
	struct statfs vfs;
	raw_fsystat_t *p_fsy;
	long total, used;
	int  i;

	/* init */
	memset(p_stat, 0x00, sizeof(raw_fsystat_arr_t));

	/* U */
	p_stat->t = comTimeGetU();

	/* collect */
	if ((fp = setmntent(MOUNTED, "r")) == NULL) {
		comLog(ER, "%s() fail to setmntent (%s) - error:%d(%s)", __func__, MOUNTED, errno, strerror(errno));
		return -1;
	}
	while ((p_mntent = getmntent(fp)) != NULL) {
		if (p_mntent->mnt_fsname[0] != '/' || strcmp(p_mntent->mnt_dir, "/proc") == 0) {
			continue;
		}
		if (statfs(p_mntent->mnt_dir, &vfs) == -1) {
			comLog(ER, "%s() fail to statfs() for %s - error:%d(%s)", __func__, p_mntent->mnt_dir, errno, strerror(errno));
			continue;
		}
		if (p_stat->n >= MAX_FSYSTAT_NUM) {
			comLog(WA, "%s() too many fsystat(%d)", __func__, p_stat->n);
			break;
		}

		/* each stat */
		p_fsy = p_stat->stat + p_stat->n;

		/* calculate the raw */
		snprintf(p_fsy->name, sizeof(p_fsy->name), "%s", p_mntent->mnt_dir);
		p_fsy->total = _block2k(vfs.f_blocks, vfs.f_bsize);
		p_fsy->freed = _block2k(vfs.f_bfree , vfs.f_bsize);
		p_fsy->avail = _block2k(vfs.f_bavail, vfs.f_bsize);

		/* calculate the usage (%%) */
		used  = p_fsy->total - p_fsy->freed;
		total = p_fsy->avail + used;
		if (total > 0) {
			p_fsy->usage = (used / (double)total) * 100.0;
		}
		else {
			p_fsy->usage = 0;
		}

		/* for the next */
		p_stat->n += 1;
	}
	endmntent(fp);

	/* display */
	for (i = 0; i < p_stat->n; i++) {
		p_fsy = p_stat->stat + i;

		comLog(VB, "%s() name: %s, total: %lu, avail: %lu, freed: %lu, usage: %f", __func__,
				p_fsy->name,
				p_fsy->total,
				p_fsy->avail,
				p_fsy->freed,
				p_fsy->usage);
	}

	return 0;
}

int appOmaLoadRawNetstat(raw_netstat_arr_t *p_stat)
{
	FILE *fp;
	char *p, line[1024], name[32];
	unsigned long val[7];
	int i;

	raw_netstat_t *p_net;

	/* init */
	memset(p_stat, 0x00, sizeof(raw_netstat_arr_t));

	/* U */
	p_stat->t = comTimeGetU();

	/* collect */
	if ((fp = fopen("/proc/net/dev", "r")) == NULL) {
		comErr(ER, errno, "%s() fail to fopen(/proc/net/dev)", __func__);
		return -1;
	}
	while (fgets(line, sizeof(line), fp) != NULL) {
		if ((p = strstr(line, ":")) == NULL) {
			continue;
		}
		if (p_stat->n >= MAX_NETSTAT_NUM) {
			comLog(WA, "%s() too many netstat(%d)", __func__, p_stat->n);
			break;
		}

		/* setup the netinfo */
		sscanf(line, "%[^:]:%lu %lu %lu %*s %*s %*s %*s %*s %lu %lu %lu %*s %*s %lu %*s %*s",
				name,
				val + 0, // &p_net->iocts,
				val + 1, // &p_net->ipkts,
				val + 2, // &p_net->ierrs,
				val + 3, // &p_net->oocts,
				val + 4, // &p_net->opkts,
				val + 5, // &p_net->oerrs,
				val + 6  // &p_net->collisions
			  );
		comTrim(name);

		if (strcmp(name, "lo") == 0) {
			continue;
		}

		/* each stat */
		p_net = p_stat->stat + p_stat->n;

		/* setup each values */
		snprintf(p_net->name, sizeof(p_net->name), "%s", name);
		p_net->iocts      = val[0] & 0xffffffff;
		p_net->ipkts      = val[1] & 0xffffffff;
		p_net->ierrs      = val[2] & 0xffffffff;
		p_net->oocts      = val[3] & 0xffffffff;
		p_net->opkts      = val[4] & 0xffffffff;
		p_net->oerrs      = val[5] & 0xffffffff;
		p_net->collisions = val[6] & 0xffffffff;

		/* for the next */
		p_stat->n += 1;
	}
	fclose(fp);

	/* display */
	for (i = 0; i < p_stat->n; i++) {
		p_net = p_stat->stat + i;

		comLog(VB, "%s() name: %s, pkts: %u|%u, octs: %u|%u, errs: %u|%u, collisions: %d", __func__,
				p_net->name,
				p_net->ipkts, p_net->opkts,
				p_net->iocts, p_net->oocts,
				p_net->ierrs, p_net->oerrs,
				p_net->collisions);
	}

	return 0;
}

int appOmaGetJSCpustat(j_cpustat_t *p_stat)
{
	raw_cpustat_t new_cpustat;
	raw_cpustat_t old_cpustat;

	memset(p_stat, 0x00, sizeof(j_cpustat_t));

	/* new */
	appOmaLoadRawCpustat(&new_cpustat);

	/* old */
	/* shm --> old */
	memcpy(&old_cpustat, &appP->statholder.cpu, sizeof(raw_cpustat_t));
	/* new --> shm */
	memcpy(&appP->statholder.cpu, &new_cpustat, sizeof(raw_cpustat_t));

	/* calculate cpu */
	return _calccpu(p_stat, &new_cpustat, &old_cpustat);
}

int appOmaGetJSMemstat(j_memstat_t *p_stat)
{
	raw_memstat_t new_memstat;

	/* init */
	memset(p_stat, 0x00, sizeof(j_memstat_t));

	/* new */
	appOmaLoadRawMemstat(&new_memstat);

	/* calculate mem */
	return _calcmem(p_stat, &new_memstat);
}

int appOmaGetJSFsystat(j_fsystat_t *p_list)
{
	raw_fsystat_arr_t new_fsystat_arr;

	/* init */
	memset(p_list, 0x00, sizeof(j_fsystat_t) * MAX_FSYSTAT_NUM);

	/* new */
	appOmaLoadRawFsystat(&new_fsystat_arr);

	/* calculate fsys */
	return _calcfys(p_list, &new_fsystat_arr);
}

int appOmaGetJSNetstat(j_netstat_t *p_list)
{
	raw_netstat_arr_t new_netstat_arr;
	raw_netstat_arr_t old_netstat_arr;

	/* init */
	memset(p_list, 0x00, sizeof(j_netstat_t) * MAX_NETSTAT_NUM);

	/* new */
	appOmaLoadRawNetstat(&new_netstat_arr);

	/* old */
	/* shm --> old */
	memcpy(&old_netstat_arr, &appP->statholder.net, sizeof(raw_netstat_arr_t));
	/* new --> shm */
	memcpy(&appP->statholder.net, &new_netstat_arr, sizeof(raw_netstat_arr_t));

	/* calculate net */
	return _calcnet(p_list, &new_netstat_arr, &old_netstat_arr);
}

int appOmaGetJSStatInfo(j_statinfo_t *p_stat)
{
	/* init */
	memset(p_stat, 0x00, sizeof(j_statinfo_t));

	appOmaGetJSCpustat(&p_stat->cpustat);
	appOmaGetJSMemstat(&p_stat->memstat);
	p_stat->fsystat_count = appOmaGetJSFsystat(p_stat->fsystat_list);
	p_stat->netstat_count = appOmaGetJSNetstat(p_stat->netstat_list);

	return 0;
}


