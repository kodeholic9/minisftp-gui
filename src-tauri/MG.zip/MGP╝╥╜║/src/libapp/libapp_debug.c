/**
 * @date   2012/07/27
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "libapp.h"

/** ----------------------------------------------------- */
void appDebugSet(int task, int pos)
{
	debugstate_t *p_debug = NULL;
	int i;

	/* for shortcut */
	if (appP != NULL) {
		p_debug = &appP->debugholder.debug[ApId][ApInstId][task];

		for (i = (DEBUG_STATE_NUM-1); i > 0; i--) {
			p_debug->pos[i] = p_debug->pos[i-1];
		}
		p_debug->pos[0] = pos;
		p_debug->cnt   += 1;
	}

	return;
}

void appDebugClear(int task)
{
	debugstate_t *p_debug = NULL;
	
	if (appP != NULL) {
		p_debug = &appP->debugholder.debug[ApId][ApInstId][task];
		memset(p_debug, 0x00, sizeof(debugstate_t));
	}

	return;
}

void appWelcome(char *pname)
{
	debugstate_t *p_debug = NULL;
	int  i, j, n;
	char buff[1024];

	comLog(ER, "=============================================================");
	comLog(ER, "\t\tWelcome to...[%s]", pname);
	comLog(ER, "-------------------------------------------------------------");
	comLog(ER, "\t\tApId     : %d", ApId);
	comLog(ER, "\t\tApInstId : %d", ApInstId);
	comLog(ER, "-------------------------------------------------------------");
	if (appP != NULL) {
		for (i = 0; i < MAX_TASK_NUM; i++) {
			p_debug = &appP->debugholder.debug[ApId][ApInstId][i];
			n = sprintf(buff, "[DEBUG STATE] Task#%d=", i);
			for (j = 0; j < DEBUG_STATE_NUM; j++) {
				n += sprintf(buff+n, "%d,", p_debug->pos[j]);
			}
			comLog(ER, "%s", buff);

			/* clear the state */
			appDebugClear(i);
		}
	}
	comLog(ER, "=============================================================");

	/*appConfigPrint();*/

	return;
}

