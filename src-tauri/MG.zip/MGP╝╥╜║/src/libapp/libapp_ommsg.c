/**
 * @date   2017/01/13
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "libapp.h"

/** ----------------------------------------------------- */
int appOmMesgValid(ommsg_t *p_ommsg)
{
	/* LENGTH */
	if (p_ommsg->h.command_length > MAX_OMDATA_LEN) {
		comLog(WA, "INVALID OMDATA LEN (%d > %d)", p_ommsg->h.command_length, MAX_OMDATA_LEN);
		return -1;
	}

	return 0;
}

void appOmMesgNtohHead(ommsg_t *p_from, ommsg_t *p_ttoo)
{
	p_ttoo->h.command_id     = ntohs(p_from->h.command_id); 
	p_ttoo->h.command_length = ntohs(p_from->h.command_length);
}

void appOmMesgNtohData(ommsg_t *p_from, ommsg_t *p_ttoo)
{
	switch (p_ttoo->h.command_id) {
		case UE_OP_REQUEST:
			p_ttoo->datareq.op_type = ntohl(p_from->datareq.op_type);
			break;

		case UE_OP_RESULT:
			p_ttoo->datares.result = ntohl(p_from->datares.result);
			break;
	}
}

void appOmMesgHtonHead(ommsg_t *p_from, ommsg_t *p_ttoo)
{
	p_ttoo->h.command_id     = htons(p_from->h.command_id); 
	p_ttoo->h.command_length = htons(p_from->h.command_length);
}

void appOmMesgHtonData(ommsg_t *p_from, ommsg_t *p_ttoo)
{
	switch (p_from->h.command_id) {
		case UE_OP_REQUEST:
			p_ttoo->datareq.op_type = htonl(p_from->datareq.op_type);
			break;

		case UE_OP_RESULT:
			p_ttoo->datares.result = htonl(p_from->datares.result);
			break;
	}
}

int appOmMesgRecvTcp(nonbsock_t *p_nonbsock, ommsgwrap_t *p_wrap)
{
	int n = 0;

	/* prepare */
	if (p_wrap->readdone) {
		p_wrap->readdone = FALSE;
		memset(p_wrap, 0x00, sizeof(ommsgwrap_t));
	}

	/* for HEAD PART */
	if (p_wrap->limit < sizeof(omheader_t)) {
		if ((n = appNonbsockRecv(
						p_nonbsock,
						p_wrap->uemsg.data + p_wrap->limit,
						p_wrap->ueraw.data + p_wrap->limit,
						sizeof(omheader_t) - p_wrap->limit)) == -1)
		{
			return -1;
		}

		if ((p_wrap->limit += n) != sizeof(omheader_t)) {
			return 0;
		}

		appOmMesgNtohHead(&p_wrap->ueraw, &p_wrap->uemsg);
	}

	/* for DATA PART */
	if (p_wrap->uemsg.h.command_length > MAX_OMDATA_LEN) {
		comLog(ER, "Too Long (%u)", p_wrap->uemsg.h.command_length);
		return -1;
	}
	if (p_wrap->uemsg.h.command_length > 0) {
		if ((n = appNonbsockRecv(
						p_nonbsock,
						p_wrap->uemsg.data + p_wrap->limit,
						p_wrap->ueraw.data + p_wrap->limit,
						p_wrap->uemsg.h.command_length + sizeof(omheader_t) - p_wrap->limit)) == -1)
		{
			return -1;
		}
		if ((p_wrap->limit += n) != (p_wrap->uemsg.h.command_length + sizeof(omheader_t))) {
			return 0;
		}
		appOmMesgNtohData(&p_wrap->ueraw, &p_wrap->uemsg);
	}

	/* for debug */
	appOmMesgTrace(DG, p_nonbsock->name, ">", p_wrap);

	/* update the limit for the next mesg */
	p_wrap->readdone = TRUE;

	return p_wrap->limit;
}

int appOmMesgSendTcp(nonbsock_t *p_nonbsock, ommsgwrap_t *p_wrap)
{
	int cc;

	/* check */
	if (p_nonbsock->psockfd == 0) {
		comLog(ER, "%s() - not connected!!", __func__);
		return -1;
	}

	/* copy */
	memcpy(p_wrap->ueraw.data, p_wrap->uemsg.data, sizeof(ommsg_t));

	/* byte ordering */
	appOmMesgHtonHead(&p_wrap->uemsg, &p_wrap->ueraw);
	appOmMesgHtonData(&p_wrap->uemsg, &p_wrap->ueraw);
	p_wrap->limit = sizeof(omheader_t) + p_wrap->uemsg.h.command_length;

	/* then send */
	if ((cc = appNonbsockSend(p_nonbsock, p_wrap->ueraw.data, p_wrap->limit)) > 0) {
		appOmMesgTrace(DG, p_nonbsock->name, "<", p_wrap);
	}

	return cc;
}

void appOmMesgTrace(int lg, char *name, char *dir, ommsgwrap_t *p_wrap)
{
	char buff[8192];
	int  n = 0;

#if 0
	if (p_wrap->uemsg.h.command_id == SCM_PING_REQ
			|| p_wrap->uemsg.h.command_id == SCM_PING_RES)
	{
		return;
	}
#endif

	/* HEAD PART */
	n = snprintf(buff, sizeof(buff), "[%s] %s 0x%04x L(%d)",
			name,
			dir,
			p_wrap->uemsg.h.command_id,
			p_wrap->uemsg.h.command_length);

	/* DATA PART */
	switch (p_wrap->uemsg.h.command_id) {
		case UE_OP_REQUEST :
			n = snprintf(buff + n, sizeof(buff), " | %d",
						p_wrap->uemsg.datareq.op_type);
			break;

		case UE_OP_RESULT : 
			n = snprintf(buff + n, sizeof(buff), " %d",
						p_wrap->uemsg.datares.result);
			break;
	}

	comLog    (IN, "%s", buff);
	comDumpRaw(DG, (unsigned char *)&p_wrap->ueraw.data, p_wrap->limit);

	return;
}

void appOmMesgPackDataReq(ommsg_t *p_ommsg, int op_type, char *data)
{
	int cmdlen;

	/* init */
	memset(p_ommsg, 0x00, sizeof(ommsg_t));

	//
	cmdlen = sizeof(omdatareq_t) - sizeof(omheader_t);
	if (data != NULL) {
		cmdlen += strlen(data);
	}

	/* -------- header part */
	p_ommsg->h.command_id     = UE_OP_REQUEST;
	p_ommsg->h.command_length = cmdlen;

	/* -------- data part */
	p_ommsg->datareq.op_type = op_type; 

	/* -------- payload part */
	if (data != NULL && strlen(data) != 0) {
		memcpy(p_ommsg->datareq.data, data, strlen(data));
	}

	return;
}

void appOmMesgPackDataRes(ommsg_t *p_ommsg, int result)
{
	int cmdlen;

	memset(p_ommsg, 0x00, sizeof(ommsg_t));

	//
	cmdlen = sizeof(omdatares_t) - sizeof(omheader_t);

	/* -------- header part */
	p_ommsg->h.command_id     = UE_OP_RESULT;
	p_ommsg->h.command_length = cmdlen;

	/* -------- data part */
	p_ommsg->datares.result = 0;

	return ;
}

void appOmMesgSendDataReq(char *host, int port, int op_type, char *data)
{
	ommsgwrap_t send_wrap;
	ommsgwrap_t recv_wrap;
	int sockfd;

	comLog(IN, "%s() - host: %s, port: %d, op_type: %d, data: %s", __func__,
			host,
			port,
			op_type,
			(data != NULL) ? data : "(null)");

	/* init */
	memset(&send_wrap, 0x00, sizeof(ommsgwrap_t));
	memset(&recv_wrap, 0x00, sizeof(ommsgwrap_t));

	/* pack */
	appOmMesgPackDataReq(&send_wrap.uemsg, op_type, data);

	/* byte ordering */
	memcpy(&send_wrap.ueraw, &send_wrap.uemsg, sizeof(send_wrap.uemsg));
	appOmMesgHtonHead(&send_wrap.uemsg, &send_wrap.ueraw);
	appOmMesgHtonData(&send_wrap.uemsg, &send_wrap.ueraw);
	send_wrap.limit = sizeof(omheader_t) + send_wrap.uemsg.h.command_length;

	comLog(IN, "%s() - limit: %d", __func__, send_wrap.limit);

	/* connect */
	if ((sockfd = comOpenClientSocketTimeout(host, port, MAX_SOCKET_BUFFER_SZ, 10)) == -1) {
		comLog(ER, "%s() fail to comOpenClientSocketTimeout() host=%s, port=%d", __func__, host, port);
		return;
	}

	if (comWriteSocketTimeout(sockfd, (uchar *)&send_wrap.ueraw.data, send_wrap.limit, 10) == -1) {
		close(sockfd);
		return;
	}
	appOmMesgTrace(DG, "OMS", "<", &send_wrap);

	recv_wrap.limit = sizeof(omdatares_t);
	if (comReadSocketTimeout(sockfd, (uchar *)&recv_wrap.ueraw.data, recv_wrap.limit, 10) == -1) {
		close(sockfd);
		return;
	}
	memcpy(&recv_wrap.uemsg, &send_wrap.ueraw, sizeof(send_wrap.uemsg));
	appOmMesgNtohHead(&recv_wrap.ueraw, &recv_wrap.uemsg);
	appOmMesgNtohData(&recv_wrap.ueraw, &recv_wrap.uemsg);

	appOmMesgTrace(DG, "OMS", ">", &recv_wrap);

	close(sockfd);

	return;
}

