/**
 * @date   2012/08/23
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */

#include "libapp.h"
#include <ctype.h>

static char *_fgets(char *line, int linesize, FILE *fp)
{
	int   nread = 0;
	char *p;

	memset(line, 0x00, linesize);

	while (fgets(line + nread, linesize - nread, fp) != NULL) {
		if ((p = strrchr(line, '\\')) == NULL) {
			nread = strlen(line);
			break;
		}
		*p = '\0'; nread = strlen(line);
	}
	if (nread == 0) return NULL;

	return comTrim(line);
}

static char *_value_startp(char *line)
{
	char *p;

	if ((p = strstr(line, "=")) == NULL) {
		return NULL;
	}
	while (*p == '=' || *p == ' ' || *p == '\t' || *p == '\n') {
		p++;
	}

	return (*p != '\0') ? p : NULL;
}

char *_lookup_slave_path(char *cmdpath, char *cmdline)
{
	struct stat sb;
	char   pname[255], *pathenv, *envp, *p;
	int    i;

	/* derive only the name from cmdline */
	snprintf(pname, sizeof(pname), "%s", cmdline);
	for (i = 0; i < sizeof(pname); i++) {
		if (pname[i] == '\0' || pname[i] == ' ' || pname[i] == '\t' || pname[i] == '\n') {
			pname[i] = '\0';
			break;
		}
	}

	/* lookup the PATH env */
	if ((pathenv = getenv("PATH")) == NULL) {
		comLog(ER, "Fail to getenv($PATH).");
		return NULL;
	}

	/* lookup the all the path */
	p    = cmdpath;
	envp = pathenv; 
	while (*envp != '\0') {
		if ((*p = *envp++) == ':') {
			*p = '\0';
			if (p == cmdpath || *(p - 1) == '/') { sprintf(p,  "%s", pname); }
			else                              { sprintf(p, "/%s", pname); }

			/* check excutable? */
			if (stat(cmdpath, &sb) != -1 && sb.st_mode & S_IXUSR) {
				return cmdpath;
			}

			/* reset */
			p = cmdpath; 
		}
		else {
			p++;
		}
	}

	return NULL;
}

int _makeup_slave_path(char *input, char *cmdpath, char *cmdline)
{
	char pname[256], *p;
	unsigned int i, plen = 0;

	/* derive only the name from cmdline */
	snprintf(pname, sizeof(pname), "%s", input);
	for (i = 0; i < sizeof(pname); i++) {
		if (pname[i] == '\0' || pname[i] == ' ' || pname[i] == '\t' || pname[i] == '\n') {
			pname[i] = '\0';
			break;
		}
	}

	/* is absolute path, or pure cmdline */
	if (pname[0] == '/') {
		if ((p = strrchr(pname, '/')) == NULL) {
			comLog(ER, "%s() Can't happen!!", __func__);
			return -1;
		}
		plen = p - pname;
		snprintf(cmdline, 1024, "%s", input + plen + 1);
		snprintf(cmdpath, 255 , "%s", pname);

		return 0;
	}

	/* lookup the path */
	snprintf(cmdline, 1024, "%s", input);
	if (_lookup_slave_path(cmdpath, cmdline) == NULL) {
		return -1;
	}

	return 0;
}

int appSlaveConfigLoad(slaveholder_t *p_slaveholder)
{
	FILE *fp;
	char  path[128], line[4096];
	char *p, *q, *vp;
	int   lineno;

	slaveinfo_t *p_slaveinfo = NULL;

	/* init */
	memset(p_slaveholder, 0x00, sizeof(slaveholder_t));

    /* setup the path */
	comGetConfPath(SLAVE_F, path);

	/* open and load */
	if ((fp = fopen(path, "r")) == NULL) {
		comErr(ER, errno, "%s() Fail to open (%s)", __func__, path);
		return -1;
	}

	/* init Lineno */
	lineno      = 0;
	p_slaveinfo = NULL;
	while ((p = _fgets(line, sizeof(line), fp)) != NULL) {
		lineno++;
		if (*p == '#' || *p == ';') continue;

		/* parse in IDIOTIC manner!! */
		if (*p == '[') {
			if ((q = strchr(p, ']')) == NULL) {
				comLog(ER, "%s() Invalid line:%d (category)", __func__, lineno);
				fclose(fp);
				return -1;
			}
			else {
				*q = '\0';
			}
			if (p_slaveholder->used >= MAX_SLAVEINFO_NUM) {
				comLog(ER, "%s() Too many slave to load. Max(%d)", __func__, MAX_SLAVEINFO_NUM);
				fclose(fp);
				return -1;
			}
			p_slaveinfo = p_slaveholder->slaveinfo + p_slaveholder->used;
			snprintf(p_slaveinfo->alias, sizeof(p_slaveinfo->alias), "%s", p+1);
			p_slaveinfo->stoptimeo = 10;

			/* for the next */
			p_slaveholder->used += 1;
		}
		if (p_slaveinfo != NULL) {
			if (strncmp(line, "alias", 5) == 0) {
				if ((vp = _value_startp(p)) == NULL) {
					comLog(ER, "%s() Invaild line:%d (alias)", __func__, lineno);
					fclose(fp);
					return -1;
				}
				snprintf(p_slaveinfo->alias, sizeof(p_slaveinfo->alias), "%s", vp);
			}
			else if (strncmp(line, "cmdline", 7) == 0) {
				if ((vp = _value_startp(p)) == NULL) {
					comLog(ER, "%s() Invaild line:%d (cmdline)", __func__, lineno);
					fclose(fp);
					return -1;
				}
				if (_makeup_slave_path(vp, p_slaveinfo->cmdpath, p_slaveinfo->cmdline) == -1) {
					comLog(ER, "%s() Fail to makeup cmdpath for(%s)", __func__, p_slaveinfo->cmdline);
					fclose(fp);
					return -1;
				}
			}
			else if (strncmp(line, "runningdir", 10) == 0) {
				if ((vp = _value_startp(p)) == NULL) {
					comLog(ER, "%s() Invaild line:%d (runningdir). but Ignore", __func__, lineno);
				}
				else {
					snprintf(p_slaveinfo->runningdir, sizeof(p_slaveinfo->runningdir), "%s", vp);
				}
			}
			else if (strncmp(line, "key", 3) == 0) {
				if ((vp = _value_startp(p)) == NULL) {
					comLog(ER, "%s() invaild line:%d (key)", __func__, lineno);
					fclose(fp);
					return -1;
				}
				p_slaveinfo->key = comAscii2Int(vp);
			}
			else if (strncmp(line, "enabled", 7) == 0) {
				if ((vp = _value_startp(p)) == NULL) {
					comLog(ER, "%s() invaild line:%d (enabled)", __func__, lineno);
					fclose(fp);
					return -1;
				}
				p_slaveinfo->enabled = (strcmp(vp, "true") == 0) ? TRUE : FALSE;
			}
			else if (strncmp(line, "ecode", 5) == 0) {
				if ((vp = _value_startp(p)) == NULL) {
					comLog(ER, "%s() invaild line:%d (ecode)", __func__, lineno);
					fclose(fp);
					return -1;
				}
				p_slaveinfo->ecode = atoi(vp);
			}
			else if (strncmp(line, "maxtries", 8) == 0) {
				if ((vp = _value_startp(p)) == NULL) {
					comLog(ER, "%s() invaild line:%d (maxtries)", __func__, lineno);
					fclose(fp);
					return -1;
				}
				if ((p_slaveinfo->maxtries = atoi(vp)) < 0 || p_slaveinfo->maxtries > MAX_DOWNTIME_NUM) {
					p_slaveinfo->maxtries = 0;
				}
			}
			else if (strncmp(line, "stoptimeo", 9) == 0) {
				if ((vp = _value_startp(p)) == NULL) {
					comLog(ER, "%s() invaild line:%d (killtimeo)", __func__, lineno);
					fclose(fp);
					return -1;
				}
				if ((p_slaveinfo->stoptimeo = atoi(vp)) < 0) {
					p_slaveinfo->stoptimeo = 3;
				}
			}
			else if (strncmp(line, "stopline", 8) == 0) {
				if ((vp = _value_startp(p)) != NULL && strlen(vp) > 1) {
					if (_makeup_slave_path(vp, p_slaveinfo->stoppath, p_slaveinfo->stopline) == -1) {
						comLog(ER, "%s() Fail to makeup stoppath for(%s)", __func__, p_slaveinfo->stopline);
						fclose(fp);
						return -1;
					}
				}
			}
		}
	}

	/* close this! don't forget!! */
	fclose(fp);

	return p_slaveholder->used;
}

static char *_statLoc2Desc(int statloc, char *s)
{
	if (statloc == 0) {
		sprintf(s, "...");
	}
	else if (WIFEXITED(statloc)) {
		sprintf(s, "EXIT:%d", WEXITSTATUS(statloc));
	}
	else if (WIFSIGNALED(statloc)) {
		sprintf(s, "SIGNO:%d", WTERMSIG(statloc));
	}
	else {
		sprintf(s, "UNK");
	}

	return s;
}

void appSlaveConfigPrint(slaveholder_t *p_slaveholder, int showall)
{
	int  i, j, upnum, downnum, failnum;
	char tmp[32], statdesc[20];

	time_t currtime = comTime();

	printf("==============================================\n");
	printf("----------------------------------------------\n");
	upnum   = 0;
	downnum = 0;
	for (i = 0; i < p_slaveholder->used; i++) {
		if (!showall && !p_slaveholder->slaveinfo[i].enabled) {
			continue;
		}
		if (p_slaveholder->slaveinfo[i].enabled) {
			if (p_slaveholder->slaveinfo[i].pid > 0) { upnum++;   }
			else                                     { downnum++; }
		}

		printf("[%02d] SLAVE    :", i+1);
		if      (p_slaveholder->slaveinfo[i].status == SL_ST_DOWN) { printf("%s", __tty_color[1]); }
		else if (p_slaveholder->slaveinfo[i].status != SL_ST_LIVE) { printf("%s", __tty_color[4]); }
		else                                                       { printf("%s", __tty_color[3]); }
		printf(" %-7s H'%08x %-5d %s%s%s%s|%s\n",
				p_slaveholder->slaveinfo[i].alias,
				p_slaveholder->slaveinfo[i].key,
				p_slaveholder->slaveinfo[i].pid,
				appCodeMap2Str(CC_SlStatus, p_slaveholder->slaveinfo[i].status),
				p_slaveholder->slaveinfo[i].blocked ? "|BLOCKED" : "",
				p_slaveholder->slaveinfo[i].enabled ? ""         : "|DISABLED",
				appSlaveCheckOverload(p_slaveholder->slaveinfo + i) == LC_RES_OVERLOADED ? "|OVERLOADED" : "",
				appCodeMap2Str(CC_TcpStatus, p_slaveholder->slaveinfo[i].nonb.pstatus)
		);
		printf("%s", __tty_color[7]);

		/* CMD LINE/PATH */
		printf("     CMD  PATH: %-64.64s\n", p_slaveholder->slaveinfo[i].cmdpath);
		printf("     CMD  LINE: %-64.64s\n", p_slaveholder->slaveinfo[i].cmdline);

		/* TIME INFO - START */
		printf("     TIME INFO: ");
		if (p_slaveholder->slaveinfo[i].strttime > 0) {
			printf("%s ", comTimeT2Str(tmp, sizeof(tmp), "%m/%d-%H:%M:%S", p_slaveholder->slaveinfo[i].strttime));
		}
		else {
			printf("<UNK> ");
		}
		/* TIME INFO - STOP */
		for (j = 0; j < MAX_DOWNTIME_NUM; j++) {
			if (p_slaveholder->slaveinfo[i].downtime[j] > 0) {
				printf("%s ", comTimeT2Str(tmp, sizeof(tmp), "%m/%d-%H:%M:%S", p_slaveholder->slaveinfo[i].downtime[j]));
			}
			else {
				printf("<UNK> ");
				break;
			}
		}
		printf("\n");

		/* DOWN COUNT */
		failnum = 0;
		for (j = 0; j < MAX_DOWNTIME_NUM; j++) {
			if (p_slaveholder->slaveinfo[i].downtime[0] > 0
					&& p_slaveholder->slaveinfo[i].downtime[j] >= (p_slaveholder->slaveinfo[i].downtime[0] - 60))
			{
				failnum += 1;
			}
		}
		printf("     DOWN INFO: %d <%d/%d per minute>; %d secs wait; %s\n",
				p_slaveholder->slaveinfo[i].downnum,
				failnum,
				p_slaveholder->slaveinfo[i].maxtries,
				p_slaveholder->slaveinfo[i].stoptimeo,
				_statLoc2Desc(p_slaveholder->slaveinfo[i].statloc, statdesc));

		if (showall) {
			printf("     RUN   DIR: %s\n"      , p_slaveholder->slaveinfo[i].runningdir);
			printf("     STOP PATH: %-64.64s\n", p_slaveholder->slaveinfo[i].stoppath);
			printf("     STOP LINE: %-64.64s\n", p_slaveholder->slaveinfo[i].stopline);
			printf("     EVENTCODE: %d\n"      , p_slaveholder->slaveinfo[i].ecode);
		}

		printf("\n");
	}
	if (p_slaveholder->stopflag) {
		printf("----------------------------------------------\n");
		printf("%s", __tty_color[1]);
		printf("stop request is procssing..... (%ld sec passed)\n", currtime - p_slaveholder->stoptime);
		printf("%s", __tty_color[7]);
	}
	printf("----------------------------------------------\n");
	printf("*** MASTER    :");
	if (p_slaveholder->mpid <= 0) {
		printf("%s", __tty_color[1]);
		printf(" %-7s %-5d (DOWN|%s)\n",
				"PMON",
				p_slaveholder->mpid,
				appCodeMap2Str(CC_TcpStatus, p_slaveholder->nonb.pstatus)
		);
	}
	else {
		printf("%s", __tty_color[3]);
		printf(" %-7s %-5d (LIVE|%s)\n",
				"PMON",
				p_slaveholder->mpid,
				appCodeMap2Str(CC_TcpStatus, p_slaveholder->nonb.pstatus)
		);
	}
	printf("%s", __tty_color[7]);
	printf("*** START TIME: %s\n", comTimeT2Str(tmp, sizeof(tmp), "%m/%d-%H:%M:%S", p_slaveholder->strttime));
	printf("*** CURR  TIME: %s\n", comTimeT2Str(tmp, sizeof(tmp), "%m/%d-%H:%M:%S", currtime));
	printf("*** SLAVE LIVE: %d / %d\n", upnum  , p_slaveholder->used);
	printf("*** SLAVE DOWN: %d / %d\n", downnum, p_slaveholder->used);
	printf("\n");

	return;
}

slaveinfo_t *appSlaveSearchByAlias(slaveholder_t *p_slaveholder, char *alias)
{
	int i;

	for (i = 0; i < p_slaveholder->used; i++) {
		if (strcmp(p_slaveholder->slaveinfo[i].alias, alias) == 0) {
			return p_slaveholder->slaveinfo + i;
		}
	}

	return NULL;
}

slaveinfo_t *appSlaveSearchByPid(slaveholder_t *p_slaveholder, int pid)
{
	int i;

	for (i = 0; i < p_slaveholder->used; i++) {
		if (p_slaveholder->slaveinfo[i].pid == pid) {
			return p_slaveholder->slaveinfo + i;
		}
	}

	return NULL;
}

void appSlaveUpdateStatus(slaveinfo_t *p_slaveinfo, int status, int pid, time_t currtime)
{
	int i;

	/* logging */
	comLog(IN, "SLAVE(%s) PID(%d) STATUS(%4s  -->  %4s)",
			p_slaveinfo->alias,
			pid,
			appCodeMap2Str(CC_SlStatus, p_slaveinfo->status),
			appCodeMap2Str(CC_SlStatus, status)
	);

	/* update the dynimic things!! */
	if (status == SL_ST_LIVE) { /* LIVE */
		p_slaveinfo->strttime = currtime;
		p_slaveinfo->pid      = pid;
	}
	else if (status == SL_ST_DOWN) { /* DOWN */
		for (i = (MAX_DOWNTIME_NUM-1); i > 0; i--) {
			p_slaveinfo->downtime[i] = p_slaveinfo->downtime[i-1];
		}
		p_slaveinfo->downtime[0] = currtime;
		p_slaveinfo->pid         = 0;
		p_slaveinfo->downnum    += 1;
		p_slaveinfo->faultednum += 1;
	}
	p_slaveinfo->status  = status;
	p_slaveinfo->chgtime = currtime;

	return ;
}

void appSlaveUpdateStop(slaveholder_t *p_slaveholder, time_t currtime)
{
	p_slaveholder->stopflag = TRUE;
	p_slaveholder->stoptime = currtime;

	return;
}

void appSlaveUpdateBlock(slaveinfo_t *p_slaveinfo, int blocked, time_t currtime)
{
	/* logging */
	comLog(IN, "SLAVE(%s) is %s", p_slaveinfo->alias, blocked ? "BLOCKED" : "UNBLOCKED");
	if ((p_slaveinfo->blocked = blocked) == FALSE) {
		memset(p_slaveinfo->downtime, 0x00, sizeof(p_slaveinfo->downtime));
		p_slaveinfo->faultednum = 0;
	}
	p_slaveinfo->chgtime = currtime;

	return ;
}

void appSlaveUpdateEnable(slaveinfo_t *p_slaveinfo, int enabled, time_t currtime)
{
	/* logging */
	comLog(IN, "SLAVE(%s) is %s", p_slaveinfo->alias, enabled ? "ENABLED" : "DISABLED");
	if ((p_slaveinfo->enabled = enabled) == TRUE) {
		memset(p_slaveinfo->downtime, 0x00, sizeof(p_slaveinfo->downtime));
	}
	p_slaveinfo->chgtime = currtime;

	return ;
}

int appSlaveCheckOverload(slaveinfo_t *p_slaveinfo)
{
	int i, ndown;

	/* check down num */
	if (p_slaveinfo->maxtries != 0) {
		for (ndown = 0, i = 0; i < MAX_DOWNTIME_NUM; i++) {
			if (p_slaveinfo->downtime[0] != 0
					&& p_slaveinfo->downtime[i] >= (p_slaveinfo->downtime[0] - 60))
			{
				ndown++;
			}
		}
		if (ndown >= p_slaveinfo->maxtries) {
			return LC_RES_OVERLOADED;
		}
	}

	return LC_RES_OK;
}

int appSlaveCheckLoad(slaveinfo_t *p_slaveinfo, time_t currtime)
{
	/* is running? */
	if (p_slaveinfo->status == SL_ST_LIVE) {
		return LC_RES_RUNNING;
	}

	/* is arming? */
	if ((currtime - p_slaveinfo->chgtime) <= 3) {
		return LC_RES_ARMING;
	}

#if 0
	if (p_slaveinfo->faultednum <= 5) {
	   	if ((currtime - p_slaveinfo->chgtime) <= 3) {
			return LC_RES_ARMING;
		}
	}
	else {
	   	if ((currtime - p_slaveinfo->chgtime) <= 30) {
			return LC_RES_ARMING;
		}
	}
#endif

	/* check configure */
	if (!p_slaveinfo->enabled) { return LC_RES_DISABLED; }
	if ( p_slaveinfo->blocked) { return LC_RES_BLOCKED ; }

	return LC_RES_OK;
}

int appSlaveCountLive(slaveholder_t *p_slaveholder)
{
	int i, count = 0;

	for (i = 0; i < p_slaveholder->used; i++) {
		if (p_slaveholder->slaveinfo[i].pid > 0) {
			count++;
		}
	}

	return count;
}

