#ifndef __DEBUG_H__
#define __DEBUG_H__

#include "const.h"

/** ----------------------------------------------------- */
/** RUNTIME DEBUG                                         */
/** ----------------------------------------------------- */
typedef enum _func_no {
	FN_MAIN   =  1,
	FN_PROC   =  2,
	FN_MISC   =  3,
	FN_TIMER  =  4,
	FN_SLAVE  =  5,
	FN_COLL   =  6,
	FN_SLOG   =  7,
	FN_RING   =  8,
	FN_LCS    =  9,
	FN_CPS    =  10,
	FN_MRS    =  11,
	FN_OMS    =  12,
	FN_OMA    =  13,
	FN_OMC    =  14,
	FN_TRAC   =  15,
	FN_ONM    =  16,
	FN_BEAT   =  17,
	FN_POLL   =  18,
	FN_UEIF   =  19,
	FN_SOCK   =  20,
	FN_HTTP   =  21,
} func_no_t;

/* for debug */
#define   DEBUG_STATE_NUM  5
#define   DEBUG(task, pos) (appDebugSet(task, pos))
#define   FNBASE        10000
#define __FNDEBUG(T, a, b) (DEBUG(T, FNBASE*(a)+(b))) 

/* ------------------------------------------------------------- */
typedef struct _debugstate {
	unsigned char occupied;
	unsigned int  pos[DEBUG_STATE_NUM];
	unsigned int  cnt;
} debugstate_t;

typedef struct _debugholder {
	debugstate_t debug[NUMOF_AP][MAX_INST_NUM][MAX_TASK_NUM];
} debugholder_t;

/* ------------------------------------------------------------- */
/*                                                               */
/* DEBUG / PROFILE / PAUSE                                       */
/*                                                               */
/* ------------------------------------------------------------- */
#define __PR_DEBUG \
	fprintf(stderr, "(.. )( ..) [DEBUG] thread=%u, file=%s:%d, func=%s()\n", \
	(unsigned)pthread_self(), __FILE__, __LINE__, __func__);

#define __PR_PROFILE \
	{                \
		fprintf(stderr, "( ..)(.. ) [PROFILE] thread=%u, file=%s:%d, func=%s(), elapsed=%f\n", \
		(unsigned)pthread_self(), __FILE__, __LINE__, __func__, comTimeGetUElapsed()); \
	}

#define __PR_PAUSE \
	{              \
		fprintf(stderr, "('' )( '') [PAUSE] thread=%u, file=%s:%d, func=%s() Enter # ",  \
				(unsigned)pthread_self(), __FILE__, __LINE__, __func__);                 \
		fflush(stderr);                                                                  \
		getc(stdin);                                                                     \
	}

#endif
