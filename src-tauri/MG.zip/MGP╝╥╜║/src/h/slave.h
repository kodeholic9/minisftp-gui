/**
 * @date   2012/08/23
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */

#ifndef __SLAVE_H__
#define __SLAVE_H__

#include "const.h"

#define MAX_SLAVEINFO_NUM 36
#define MAX_DOWNTIME_NUM  5

typedef enum {
	LC_RES_OK         = 0,
	LC_RES_DISABLED   = 1,
	LC_RES_BLOCKED    = 2,
	LC_RES_OVERLOADED = 3,
	LC_RES_RUNNING    = 4,
	LC_RES_ARMING     = 5
} LoadCheckResult_t;

typedef enum {
	SL_ST_DOWN  = 0,
	SL_ST_LIVE  = 1,
	SL_ST_STOP  = 2,
	SL_ST_KILL  = 3,
} SlaveStatus_t;

typedef struct _slaveinfo {
	/* static info */
	char alias[36];
	char cmdline[4096];
	char cmdpath[255];
	char runningdir[255];
	char enabled;
	int  key;
	int  ecode;

	/* to stop */
	char stoptimeo;
	char stopline[4096];
	char stoppath[255];

	/* dynamic info */
	int        pid;
	int        status;
	int        blocked;
	time_t     strttime;
	time_t     chgtime;
	int        statloc;
	nonbsock_t nonb;

	time_t downtime[MAX_DOWNTIME_NUM];
	int    downnum;
	int    maxtries;

	int    faultednum;
} slaveinfo_t;

typedef struct _slaveholder {
	slaveinfo_t slaveinfo[MAX_SLAVEINFO_NUM];
	int         used;

	/* to check PMON */
	int         mpid;

	/* to control PMON */
	int         stopflag;
	time_t      stoptime;
	time_t      strttime;

	/* to communication */
	nonbsock_t  nonb;
} slaveholder_t;

#endif

