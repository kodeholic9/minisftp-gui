/**
 * @date   2016/07/26
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 */
#ifndef __MGPP_H__
#define __MGPP_H__

/** includes ----------------------------------------------- */
#include "libcom.h"
#include "libapp.h"
#include "librms.h"

/** constants ---------------------------------------------- */
/* basic */
#define AP_NAME "MGPP"

/** enums  ---------------------------------------------- */

/** data structures ---------------------------------------- */
typedef struct _mgppmagic {
	/* socket */
	int    maxfd;
	fd_set rmask;
	fd_set wmask;

	/* running flag to control... */
	int running;

	/* nonbsock */
	nonbsock_t  ns;
	scmsgwrap_t sendwrap;
	scmsgwrap_t recvwrap;
} mgppmagic_t;

/* for main */
extern mgppmagic_t   Oz;
extern mgppmagic_t *pOz;

/** functions ---------------------------------------------- */
/** main */
int initialize(int argc, char **argv);
int terminate(int code);
int wait_for(fd_set *rset, int usec);
int proc_with(fd_set *rset);
int proc_ipc(ipcmsg_t *p_ipcmsg);
int proc_timer();

/** voip */
void voip_init();
int  voip_start();
void voip_stop();
void voip_setvolume();
void voip_talkreq();
void voip_talkrel();
void voip_talktoggle();

#endif
