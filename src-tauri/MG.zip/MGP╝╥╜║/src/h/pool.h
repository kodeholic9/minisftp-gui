/**
 * @date   2016/08/10
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * @desc   
 * 
 */
#ifndef __POOL_H__
#define __POOL_H__

#define DATA_START     1
#define DATA_NULL      0

typedef enum {
	PST_FREED = 0,
	PST_USING,
	PST_ARMORED, /* RESISTERED */
	PST_PENDING,
	PST_SENDING,
	PST_DELETED,
	NUMOF_PST 
} PST_T;

typedef enum {
	PQNAME_FREE = 0,
	PQNAME_USED,
	PQNAME_TIMR, 
	PQNAME_SEND,
	PQNAME_PEND,
	NUMOF_PQNAME,
} PQNAME_T;

typedef struct _pqlink {
	unsigned int L;
	unsigned int R;
} pqlink_t;

typedef struct _pqueue {
	unsigned int H; /* head */
	unsigned int T; /* tail */
	int          qname;
	int          qnum;
} pqueue_t;

#endif
