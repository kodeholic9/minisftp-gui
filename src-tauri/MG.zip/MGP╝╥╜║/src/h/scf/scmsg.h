/**
 *  @date   2016/07/27
 *  @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 */ 
#ifndef __SCMSG_H__
#define __SCMSG_H__

#include "common.h"
#include "libsec.h"

#define MAX_SCBUFF_LEN    8192 
#define MAX_SCHEAD_LEN    24
#define MAX_SCDATA_LEN    (MAX_SCBUFF_LEN - MAX_SCHEAD_LEN) 

/* constants and macros */
#define SCM_STRT_BIT       0x0f
#define SCM_VVER_BIT       0x06
#define SCM_RESP_BIT       0x4000

/* -- UEMSG.CommandID */
/* Request */
#define SCM_INIT          0x0000
#define SCM_BIND_REQ      0x0001
#define SCM_PING_REQ      0x0002
#define SCM_LEAV_REQ      0x0006
#define SCM_DATA_REQ      0x000a
/* Response */
#define SCM_BIND_RES     (SCM_BIND_REQ    | SCM_RESP_BIT)
#define SCM_PING_RES     (SCM_PING_REQ    | SCM_RESP_BIT)
#define SCM_LEAV_RES     (SCM_LEAV_REQ    | SCM_RESP_BIT)
#define SCM_DATA_RES     (SCM_DATA_REQ    | SCM_RESP_BIT)

#define IS_SCM_BIND(M) ((M)->h.command_id == SCM_BIND_REQ || (M)->h.command_id == SCM_BIND_RES)

/* -- UEMSG.TALK_TYPE */
#define SCM_TT_COMM         0x00
#define SCM_TT_TALK         0x01

/* -- UEMSG.ACCESS_CODE */
#define SCM_AC_3G           0x00
#define SCM_AC_LTE          0x01
#define SCM_AC_WIFI         0x02

/* -- UEMSG.RESULT_CODE */
#define SCM_RC_EOK          0x00
#define SCM_RC_EFAIL        0x01

/* -- FID */
#define SCM_SERVICE_FEATURE_ID  300000

/* Default Header */
typedef struct _scheader {
	unsigned char  start_bit;
	unsigned char  version;
	unsigned short command_id;
	unsigned int   command_length;
	unsigned int   payload_id;
	iuid_t         uid; 
	unsigned char  cryptflag;
	unsigned char  cryptpadding;
	unsigned char  acctype;
	unsigned char  result;
} scheader_t;

/* BIND */
typedef struct _scbindreq {
	scheader_t    h;
	iuid_t        from; 
	char          from_mdn[MAX_MDN_LEN];
	char          app_type[MAX_APPTYPE_LEN];
	char          auth_key[MAX_AUTHKEY_LEN];
	char          region_code[MAX_REGIONCODE_LEN];
	char          app_market;
	char          pad;
	char          encrypt_key[CRYPT_KEY_LEN];
} scbindreq_t;

typedef struct _scbindres {
	scheader_t    h;
} scbindres_t;

/* LEAVE */
typedef struct _scleavereq {
	scheader_t  h;
	iuid_t      from; 
	iuid_t      ttoo; 
	uesid_t     sid;  
} scleavereq_t;

typedef struct _scleaveres {
	scheader_t    h;
} scleaveres_t;

/* PING */
typedef struct _scpingreq {
	scheader_t    h;
} scpingreq_t;

typedef struct _scpingres {
	scheader_t    h;
} scpingres_t;

/* DATA */
typedef struct _scdatareq {
	scheader_t    h;
	iuid_t        from;
	iuid_t        ttoo;
	uesid_t       sid;  
	unsigned int  fid; 
	unsigned int  action; 
	unsigned char comm_flag;
	unsigned char group_flag;
	unsigned char store_flag;
	unsigned char pending_flag;
	datetime_t    incoming_time; 
	char          reserved[20];
	char          data[0];
} scdatareq_t;

typedef struct _scdatares {
	scheader_t    h;
	unsigned int  action_ack;
	unsigned char displayed;
	unsigned char pad[3];
	datetime_t    incoming_time; 
	char          ack_data[0];
} scdatares_t;

/* SCMSG */
typedef union _scmsg {
	char         data[MAX_SCBUFF_LEN]; /* data */
	scheader_t   h;

	/* UE mesg */
	scbindreq_t  bindreq;
	scbindres_t  bindres;
	scpingreq_t  pingreq;
	scpingres_t  pingres;
	scleavereq_t leavereq;
	scleaveres_t leaveres;
	scdatareq_t  datareq;
	scdatares_t  datares;
} scmsg_t;

typedef struct _scmsgwrap {
	int     limit;
	int     readdone;
	scmsg_t uemsg;
	scmsg_t ueraw;
	scmsg_t uecry;
} scmsgwrap_t;

#endif

