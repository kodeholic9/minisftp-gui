/**
 *  @date   2016/08/10
 *  @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 */ 
#ifndef __SCPOOL_H__
#define __SCPOOL_H__

#include "common.h"
#include "pool.h"

#define MAX_SCPOOL_NUM        128
#define MAX_SCRAWDATA_SIZE    1024
#define SCPOOL_EXPTIMEO       9
#define SCPOOL_WINSZ          1

typedef struct _scpooldata {
	int type;

	/* request.raw */
	int    sid;
	int    action;
	char   rawreq[MAX_SCRAWDATA_SIZE];
	time_t sendtime;

	/* request */
	union {
		j_joinreq_t  join;
		j_leavereq_t leave;
	} req;

	/* response */
	union {
		j_datarcv_t datarcv;
	} res;
} scpooldata_t;

typedef struct _scpool {
	int id;
	int status;
	pqlink_t qlink[NUMOF_PQNAME];

	/* for expired */
	time_t nexttime;

	/* data part */
	scpooldata_t _d;
} scpool_t;

typedef struct _scbase {
	scpool_t pool[MAX_SCPOOL_NUM];

	/* -- for Invk Queue */
	pqueue_t freeQ; /* Free  Queue */
	pqueue_t pendQ; 
	pqueue_t sendQ; 
} scbase_t;

typedef int scpoolCallback(scbase_t *, pqueue_t *, scpool_t *, void *);

#endif

