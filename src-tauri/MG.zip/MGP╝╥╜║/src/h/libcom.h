/* This file was auto-generated. Do not edit! */
#ifndef __LIBCOM_H__
#define __LIBCOM_H__

#include "const.h"
#include "common.h"
#define _XOPEN_SOURCE /* glibc2 needs this */
#include <time.h>

#include <sys/types.h>
#include <pwd.h>

/* -------------------------------------------------------------------------- */
/* define constants and macro                                                 */
/* -------------------------------------------------------------------------- */
#define COM_FREE(mem)                   { if (mem) { free(mem); mem = NULL; } }
#define COM_CLOSE(sockfd)               { if (sockfd >= 0) { close(sockfd); sockfd = -1; } }

/* -------------------------------------------------------------------------- */
/* log configuration */
/* -------------------------------------------------------------------------- */
#define comLog(l, args...)           (comLogFunc(l, __FILE__, __LINE__, 0    , args))
#define comErr(l, error, args...)    (comLogFunc(l, __FILE__, __LINE__, error, args))

/* for ceiling */
#define CEILING_POS(X) ((X-(int)(X)) > 0 ? (int)(X+1) : (int)(X))
#define CEILING_NEG(X) ((X-(int)(X)) < 0 ? (int)(X-1) : (int)(X))
#define CEILING(X)     (((X) > 0)        ? CEILING_POS(X) : CEILING_NEG(X))

/* -------------------------------------------------------------------------- */
/* declare enums                                                              */
/* -------------------------------------------------------------------------- */

typedef enum _comLog_t{
        ER, /* ER */
        WA, /* WA */
        IN, /* IN */
        DG, /* DEBUG */
        VB, /* VERBOSE */
        NUM_OF_LOG_LEVEL
}_comLog_t;

extern int Loglevel;

typedef enum sockState_t {
        SOCK_NORMAL,
        SOCK_BLOCK,
        SOCK_ERROR,
        SOCK_STANDBY,
        SOCK_CONNECTED,
        SOCK_BINDED,
        SOCK_DISCONNECT,
        NUM_OF_SOCK_STAT
} sockState_t;

typedef void Sigfunc(int );

/* global|extern variables */
extern int           gLogLevel;
extern unsigned int  ApId;
extern unsigned int  ApInstId;
extern char *__tty_color[];

/* -------------------------------------------------------------------------- */
/* function prototypes                                                        */
/* -------------------------------------------------------------------------- */

/** libcom_log.c ***********************************************************/
int  comLogLevelSet(int lv);
int  comLogLevelGet();
void comWelcome(char *pname);
void comGoodbye(int code);
void comLogFunc(int lv, const char *f, const int l, int error, char *format, ...);
char *comLogLevel2Str(int lv);

int comLogTraceUntilSet(time_t sec);
int comLogTraceInit();
int comLogTraceCreate();
int comLogFifoWrite(char *buff);
int comLogRedirect(const char *path, const char *opt, int nonb);

/** libcom_misc.c ***********************************************************/
uint     comHashFuncJenkins(char *key, int klen);
Sigfunc *comInstallSignal(int signo, Sigfunc *func);
void     comIgnoreFunc(int signo);
int      comAscii2Int(char *s);
void     comDumpRaw(int lv, unsigned char *msg, int len);
int      comDumpRaw2Buff(unsigned char *msg, int len, char *buff, int buflen);
char    *comTrim(char *str);
char    *comSkipToken(const char *p);
char    *comSkipWS(const char *p);
int      comHexLine2Bin(char *from, char *to, int limit);

/**  libcom_time.c *********************************************************/
time_t comTime();
double comTimeGetU();
long   comTimeGetMillis();
double comTimeGetUElapsed();
char  *comTimeU2Str(time_t up, char *str);
char  *comTimeT2Str(char *S, size_t MAXSIZE, const char* FORMAT, time_t T);
time_t comTimeStr2T(char *S, const char* FORMAT);
char  *comTimeTraceFormat(char *s);

/**  libcom_thread.c *********************************************************/
/* Thread Create Function */
int  comThreadCreate(pthread_t *thread_id, void *(*func)(void *), void *arg);
int  comThreadCreateSystemScope(pthread_t *thread_id, void *(*func)(void *), void *arg);
int  comThreadCancel(pthread_t thread_id);
void comThreadExit(void);

/* Resource Recover Functions */
int comMutexInit(pthread_mutex_t *p_mutex);
int comMutexConsistentNp(pthread_mutex_t *p_mutex);

int comMutexLock(pthread_mutex_t *p_mutex);
int comMutexUnlock(pthread_mutex_t *p_mutex);

/* Cond Function */
int comCondInit(pthread_cond_t *p_cond);
int comCondSignal(pthread_cond_t *p_cond);
int comCondWaitTimeo(pthread_cond_t *p_cond, pthread_mutex_t *p_mutex, int msec);

/*- libcom_socket.c ---------------------------------------------------------------------------*/
int  comOpenServerSocket(uchar *host ,uint port, uint buf_size, uint BMode);
int  comOpenUDPSocket(uchar *host, uint port, uint buff_size);
int  comOpenClientSocket(uchar *lhost, uchar *host, uint port, uint buff_size, uint BMode);
int  comOpenClientSocketTimeout(uchar *host, uint port, uint buff_size,int timeoutSec);
int  comOpenUDPClientSocket(uchar *host, uint port, sockaddr_in_t *serv_addr);
int  comAccept(uint fd, sockaddr_in_t *addr, uchar **r_host, uint mod, uint linger);
int  comReadSocket(uint fd, char *buff, int len);
int  comReadSocketNB(uint fd, uchar *buff, uint len);
int  comReadSocketNLine(uint fd, uchar *buff);
int  comReadSocketTimeout(uint fd, uchar *buff, uint len, uint timeout_sec);
int  comReadUDPSocket(uint fd, uchar *buff, uint len, sockaddr_in_t *addr);
int  comReadUDPSocketNB(uint fd, uchar *buff, uint len, sockaddr_in_t *addr);
int  comSatusSocketCheckWrite (uint fd, char *buff, uint len);
int  comStatusSocketWriteTimeout (uint fd, char *buff, uint len, uint timeout_sec);

int  comWriteSocket (uint fd, char *buff, uint len);
int  comWriteSocketNB (uint fd, char *buff, uint len);
int  comWriteSocketTimeout (uint fd, char *buff, uint len, uint timeout_sec);
int  comWriteSocketNL (uint fd, char *buff);
int  comWriteUDPSocket (uint fd, sockaddr_in_t *addr, uchar *buff, sint len);
int  comStatusSocketUDPWrite(uint fd, sockaddr_in_t *addr, uchar *buff, sint len);
int  comStatusSocket (uint fd);

int  comMoreDataSocket (uint fd, sint wait_sec);
char *comGetIPAddressByName (uchar *address);
void comCloseSocket (uint fd);
void comSetSelectMask (sint *max_fd, fd_set *mask, sint fd);
void comUnsetSelectMask (sint *max_fd, fd_set *mask, sint fd);
int  comGetHostAddr (char *host, sint port, sockaddr_in_t *serv_addr);
int  comOpenServerSokcket(uchar *host ,uint port, uint buf_size, uint BMode);

int comNonblockRead(int sockfd, char *buff, int maxlen);
int comNonblockWrite(int sockfd, char *buff, int len);

void get_host_by_addr(sockaddr_in_t *addr, uchar **r_host);

int comReadableTimeo(int fd, int timeo);
int comWritableTimeo(int fd, int timeo);

long long comNtohll(long long n);
long long comHtonll(long long n);

int comGetSockName(int sockfd, char *name, int namelen);
int comGetPeerName(int sockfd, char *name, int namelen);

/*- libcom_ring.c ---------------------------------------------------------------------------*/
int  comRingBufferInit(variable_ringbuffer_t *p_rb, char *p_data, int datalen);
int  comRingBufferEnqueue(variable_ringbuffer_t *p_rb, char *p_data, int datalen);
int  comRingBufferDequeue(variable_ringbuffer_t *p_rb, char *p_data, int maxlen);
void comRingBufferDebug(variable_ringbuffer_t *p_rb, const char *f);

/*- libcom_code.c ---------------------------------------------------------------------------*/
int   comCodeMapLoad(codemap_t *p_codemap, int maxnum, char *cate, char *f);
char *comCodeMap2Str(codemap_t *p_codemap, int code);
void  comCodeMapPrint(codemap_t *p_codemap);

/*- libcom_app.c ---------------------------------------------------------------------------*/
char *comGetHome();
int   comGetIndex();
char *comGetPath(char *p1, char *p2, char *path);
char *comGetBinPath(char *p, char *path);
char *comGetCmdPath(char *p, char *path);
char *comGetTmpPath(char *p, char *path);
char *comGetLogPath(char *p, char *path);
char *comGetPidPath(char *p, char *path);
char *comGetConfPath(char *p, char *path);
char *comGetScriptPath(char *p, char *path);
char *comGetCmdlogPath(char *p, char *path);
char *comGetUName(char *name, int len);
int   comPidFileLock (char *pcmd, int index, int pid);
int   comPidFileCheck(char *pcmd, int index);

int FILE_LOCK(int fd, const char *f, int l);
int FILE_LOCKW(int fd, const char *f, int l);
int FILE_UNLOCK(int fd, const char *f, int l);

char *appName(int ap_id);
int   appId(char *apname);

/*- libcom_process.c ---------------------------------------------------------------------------*/
int    lp_count(char *cmdline);
char **lp_alloc(char *cmdline, int *argc);
void   lp_release(char **argv);
void   lp_print(int argc, char **argv);
int    lp_load(char *cmdpath, char *cmdline, char *runningdir, char *logfile);

int    lp_input2split(const char *input, char *cmdpath, char *cmdline, int n);
int    lp_input2path (const char *input, char *cmdpath);
int    load_shell(char *cmdline);

/*- libcom_proto.c ---------------------------------------------------------------------------*/
long        comProtoI642Long(i64_t *p_i64);
long        comProtoLong2I64(long l, i64_t *p_i64);
char       *comProtoStr2Iuaddr(char *s, iuaddr_t *p_iuaddr);
char       *comProtoIuaddr2Str(iuaddr_t *p_iuaddr, char *s);
long        comProtoSid2Long(uesid_t *p_sid);
long        comProtoLong2Sid(long l, uesid_t *p_sid);
long        comProtoIuid2Long(iuid_t *p_iuid);
long        comProtoLong2Iuid(long l, iuid_t *p_iuid);
char       *comProtoIpaddr2Str(ueipaddr_t *p_ipaddr, char *s);
ueipaddr_t *comProtoStr2Ipaddr(char *s, ueipaddr_t *p_ipaddr);
long        comProtoDatetime2Long(datetime_t *p_datetime);
long        comProtoLong2Datetime(long l, datetime_t *p_datetime);

#endif  /* __LIBCOM_H__ */
