/**
 * @date   2016/12/23
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 */
#ifndef __HOOK_H__
#define __HOOK_H__

/** includes ----------------------------------------------- */
#include "libcom.h"
#include "libapp.h"
#include "librms.h"

/** constants ---------------------------------------------- */
/* basic */
#define AP_NAME "HOOK"
#define MAX_HOOKFD_NUM 10

/** enums  ---------------------------------------------- */

/** data structures ---------------------------------------- */
typedef struct _hookmagic {
	/* fd */
	int    maxfd;
	fd_set rmask;
	fd_set wmask;

	int hookfds[MAX_HOOKFD_NUM];

	/* hook fds update time */
	time_t hook_update_time;

	/* running flag to control... */
	int running;
} hookmagic_t;

/* for main */
extern hookmagic_t   Oz;
extern hookmagic_t *pOz;

/** functions ---------------------------------------------- */
/** main */
int initialize(int argc, char **argv);
int terminate(int code);
int wait_for(fd_set *rset, int usec);
int proc_ipc(ipcmsg_t *p_ipcmsg);
int proc_file(fd_set *rset);
int proc_timer();

void hook_update(time_t current);
int  hook_open (char *dev_name);
int  hook_read (int fd);
int  hook_close(int *fd);



/** hook */

#endif
