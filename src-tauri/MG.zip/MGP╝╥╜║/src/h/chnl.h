/**
 * @date   2016/07/26
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 */
#ifndef __CHNL_H__
#define __CHNL_H__

/** includes ----------------------------------------------- */
#include "libcom.h"
#include "libapp.h"
#include "librms.h"

/** constants ---------------------------------------------- */
/* basic */
#define AP_NAME "CHNL"

/** enums  ---------------------------------------------- */

/** data structures ---------------------------------------- */
typedef struct _omsdata {
	char host[32];
	int  port;
	int  op_type;
	char data[8192];
} omsdata_t;

#define MAX_CHNLPACK_NUM 32

typedef struct _chnlmagic {
	/* socket */
	int    maxfd;
	fd_set rmask;
	fd_set wmask;

	/* running flag to control... */
	int running;

	/* nonbsock */
	nonbsock_t  ns;
	scmsgwrap_t sendwrap;
	scmsgwrap_t recvwrap;

	/* pipe */
	nonbpipe_t  np;

	/* http request/response */
	jsonpack_t chnlpack[MAX_CHNLPACK_NUM];

	/* tcp request/response */
	scbase_t scbase;

	//
	time_t last_device_time;
	time_t last_usering_time;
	time_t last_rooming_time;
	time_t last_joining_time;
} chnlmagic_t;

/* for main */
extern chnlmagic_t   Oz;
extern chnlmagic_t *pOz;

/* for mobile number */
extern char MobileNumber[MAX_MDN_LEN];

/** functions ---------------------------------------------- */
/** main */
int initialize(int argc, char **argv);
int terminate(int code);
int wait_for(fd_set *rset, int usec);
int proc_sock(fd_set *rset);
int proc_ipc(ipcmsg_t *p_ipcmsg);
int proc_timer();
int proc_child();
int READY1();
int READY2();

/** sock */
void scf_sock_init();

int scf_sock_next_payload_id();
int scf_sock_curr_payload_id();

int scf_sock_send_bindreq();
int scf_sock_send_pingreq();
int scf_sock_send_pingres(int pid, int result);
int scf_sock_send_datareq(int pid, long ttoo, long sid, int action, char *data);
int scf_sock_send_datares(int pid, int result, char *ack_data);
int scf_sock_send_leavreq(int pid);

int scf_sock_check();
int scf_sock_check_expired (time_t current);
int scf_sock_check_outgoing();
int scf_sock_check_bound   ();

int scf_sock_proc(fd_set *rset);

int scf_sock_request_join();
int scf_sock_request_leave();

/** misc */
jsonpack_t *CHNLPACK_PTR(int id, const char *f);

void        chnlpack_init();
jsonpack_t *chnlpack_alloc  (const char *f);
void        chnlpack_release(jsonpack_t *p_pack, const char *f);
void        chnlpack_update_status(jsonpack_t *p_pack, int status, const char *f);
void        chnlpack_update_type(jsonpack_t *p_pack, int type, const char *f);

int mgp_signal_strt_req();
int mgp_signal_stop_req();

void channel_status_update(long sid, int status, const char *f);

/** http */
int  start_http_deviceinfo_req();
int  start_http_showmylist_req();

/** timer */
void timer_check_chnlpack(time_t current);
void timer_check_status(time_t current);

void timer_proc_device_unknown();
void timer_proc_user_unknown();

void timer_proc_channel_idle();
void timer_proc_channel_roomed();
void timer_proc_channel_joined();

/** oma */
int  oma_get_board_info(j_board_t *p_board, char *request_key);
//
void om_response(j_datarcv_t *p_datarcv, int op_type, char *data);
void om_response_result(j_datarcv_t *p_datarcv, int op_type, int result);


#endif
