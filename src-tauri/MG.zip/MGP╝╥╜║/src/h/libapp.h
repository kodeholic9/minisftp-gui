/**
 * @date   2012/07/27
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * @desc   
 * 
 */
#ifndef __LIBAPP_H__
#define __LIBAPP_H__

#include "libcom.h"
#include "app.h"
#include "pool.h"
#include "profile.h"
#include "slave.h"
#include "oma.h"
#include "jsonpack.h"

/* -------------------------------------------------------------------------- */
/* define constants and macro                                                 */
/* -------------------------------------------------------------------------- */
typedef struct _appshm {
	debugholder_t     debugholder;
	slaveholder_t     slaveholder;
	statholder_t      statholder;

	/* for config */
	profile_t profile;

	/* for ipc */
	ipc_t ipcdefault[NUMOF_AP];
} appshm_t;

extern appshm_t  *appP;
extern profile_t *pProfile;

/* -------------------------------------------------------------------------- */
/* log configuration */
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */
/* declare enums                                                              */
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */
/* function prototypes                                                        */
/* -------------------------------------------------------------------------- */

/** libapp_app.c ***********************************************************/
int appCreate(int shm_key);
int appInitialize(int shm_key, unsigned int ap_id, unsigned int inst_id);

/* utilities */
unsigned int calcDelta(char *name, uint newvalue, uint *p_oldvalue);
unsigned int calcTps  (char *name, uint newvalue, uint *p_oldvalue, double elapsed);

int   appDaemonInit(char *apname, int bgflag);
#if 0
char *appName(int ap_id);
int   appId(char *apname);
#endif

int appVersionCheck(char *version);

char *appAudioCodec2Str(int codec);
int   appAudioCodec2Pid(int codec);
int   appAudioCodec2Int(char *s);

int   appPlaySoundClip(int clip_id);

int appCLI_mplayer(int clip_id);
int appCLI_reboot();
int appCLI_fwupdate(char *installer, char *url);
int appLoadCmdline(const char *cmdline);

/** libapp_debug.c ***********************************************************/
void appWelcome(char *pname);
void appDebugSet(int task, int pos);
void appDebugClear(int task);

/** libapp_code.c ***********************************************************/
int        appLoadCode();
codemap_t *appCodeMapGet (int codecate);
char      *appCodeMap2Str(int codecate, int code);
void       appCodeMapPrint();

/** libapp_slave.c ***********************************************************/
int  appSlaveConfigLoad(slaveholder_t *p_slaveholder);
void appSlaveConfigPrint(slaveholder_t *p_slaveholder, int showall);

slaveinfo_t *appSlaveSearchByAlias(slaveholder_t *p_slaveholder, char *alias);
slaveinfo_t *appSlaveSearchByPid(slaveholder_t *p_slaveholder, int pid);

void appSlaveUpdateStatus(slaveinfo_t *p_slaveinfo, int status, int pid, time_t currtime);
void appSlaveUpdateBlock(slaveinfo_t *p_slaveinfo, int blocked, time_t currtime);
void appSlaveUpdateEnable(slaveinfo_t *p_slaveinfo, int enabled, time_t currtime);
void appSlaveUpdateStop(slaveholder_t *p_slaveholder, time_t currtime);

int  appSlaveCountLive(slaveholder_t *p_slaveholder);
int  appSlaveCheckOverload(slaveinfo_t *p_slaveinfo);
int  appSlaveCheckLoad(slaveinfo_t *p_slaveinfo, time_t currtime);

int _makeup_slave_path(char *input, char *cmdpath, char *cmdline);

/* utilities */
char **lp_alloc(char *s, int *argc);
void lp_release(char **argv);
void lp_print(int argc, char **argv);

/** libapp_nonbsock.c ***********************************************************/
void appNonbsockInit(nonbsock_t *p_nonb, char *name, int *maxfd, fd_set *rset, fd_set *wset);
void appNonbsockUpdate(nonbsock_t *p_nonb, int status);
int  appNonbsockConnect(nonbsock_t *p_nonb, char *host, int port);
int  appNonbsockListen(char *host, int port);
int  appNonbsockAccept(int lsnrfd, nonbsock_t *p_nonb);
int  appNonbsockRecv (nonbsock_t *p_nonb, char *data, char *raw, int dlen);
int  appNonbsockSend (nonbsock_t *p_nonb, char *data, int dlen);
int  appNonbsockClose(nonbsock_t *p_nonb);
int  appNonbsockFlush(nonbsock_t *p_nonb);
int  appNonbsockCheckCurrW(nonbsock_t *p_nonb);
int  appNonbsockCheckCurrR(nonbsock_t *p_nonb);

/** libapp_timer.c ***********************************************************/
void *Timer(void *arg);
void  appTimerLoop(timerproc_t *p_timerproc);
int   appTimerStart(timerproc_t *p_timerproc, tmCallback *proc, int persec);

/** libapp_profile.c ***********************************************************/
int appProfileSave();
int appProfileShow();
int appProfileSet(char *line, int hasSet);
int appProfileLoad();
int appProfileGetFaultDuration();

void appProfileUpdateChannelInfo(long sid, int status);
void appProfileUpdateVoipInfo(char *dst_ip, int dst_aport, int dst_mport, char *codec, char *call_id);

/** libapp_ipc.c ***********************************************************/
void appIpcCreate();
int  appIpcResetAp();
int  appIpcReadyMsg();
int  appIpcRecvMsg(ipcmsg_t **p_msg, int msec);
int  appIpcSendMsg(uint ttoo, uint mtype, uchar *data, uint len);
int  appIpcSendArgs(uint ttoo, uint mtype, int arg1, unsigned int arg2, unsigned long arg3);

/** libapp_pipe.c ***********************************************************/
int appPipeOpen (nonbpipe_t *p_nonb, char *name, int *maxfd, fd_set *rset, fd_set *wset);
int appPipeClose(nonbpipe_t *p_nonb);
int appPipeReadTimeo (nonbpipe_t *p_nonb, unsigned char *data, size_t dlen, int timeo);
int appPipeWriteTimeo(nonbpipe_t *p_nonb, unsigned char *data, size_t dlen, int timeo);

int appPipeSignal   (nonbpipe_t *p_nonb);
int appPipeSignalled(nonbpipe_t *p_nonb);

/** libapp_oma.c ***********************************************************/
int appOmaLoadPsinfo(ext_pstable_t *p_pstable, char *user);
ext_psinfo_t *appOmaLookupPsinfo(ext_pstable_t *p_pstable, int pid, int ppid);
int appOmaGetJSProcInfo  (j_process_t *p_pslist, int size);
int appOmaGetJSConfigInfo(j_config_t *p_cfg);

int appOmaGetJSCpustat(j_cpustat_t *p_stat);
int appOmaGetJSMemstat(j_memstat_t *p_stat);
int appOmaGetJSFsystat(j_fsystat_t *p_list);
int appOmaGetJSNetstat(j_netstat_t *p_list);
int appOmaGetJSStatInfo(j_statinfo_t *p_stat);
int appOmaGetJSUnameInfo(j_uname_t *p_uname);

/** libapp_ommsg.c ***********************************************************/
int  appOmMesgValid(ommsg_t *p_ommsg);
void appOmMesgNtohHead(ommsg_t *p_from, ommsg_t *p_ttoo);
void appOmMesgNtohData(ommsg_t *p_from, ommsg_t *p_ttoo);
void appOmMesgHtonHead(ommsg_t *p_from, ommsg_t *p_ttoo);
void appOmMesgHtonData(ommsg_t *p_from, ommsg_t *p_ttoo);

int  appOmMesgRecvTcp(nonbsock_t *p_nonbsock, ommsgwrap_t *p_wrap);
int  appOmMesgSendTcp(nonbsock_t *p_nonbsock, ommsgwrap_t *p_wrap);
void appOmMesgTrace(int lg, char *name, char *dir, ommsgwrap_t *p_wrap);

void appOmMesgPackDataReq(ommsg_t *p_ommsg, int op_type, char *data);
void appOmMesgPackDataRes(ommsg_t *p_ommsg, int result);

void appOmMesgSendDataReq(char *host, int port, int op_type, char *data);


#endif



