/**
 * @date   2013/08/19
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */

#ifndef __CONTENT_H__
#define __CONTENT_H__

/** ----------------------------------------------------- */
/** constants                                             */
/** ----------------------------------------------------- */
#define MAX_CONTENT_ID_LEN 20
#define MAX_CONTENT_NUM    100000
#define CONTENT_START      1

typedef struct _content {
	/* for link */
	int          next;
	
	/* for data */
	char         id[MAX_CONTENT_ID_LEN];
	unsigned int comm;
	unsigned int talk;
} content_t;

typedef struct _contentmap {
	pthread_mutex_t mutex;
	content_t       data[MAX_CONTENT_NUM];
	unsigned  int   slot[MAX_CONTENT_NUM];
	unsigned  int   used;
} contentmap_t;


#endif
