/**
 * @date   2012/07/30
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */

#ifndef __APP_H__
#define __APP_H__

#include "const.h"

/* task */
#define TASK_MAIN    0
#define TASK_TIMER   1
#define TASK_OMA     2
#define TASK_SLOG    3
#define TASK_BEAT    4

/* timer */
#define TA_PHASH_LOST     1
#define TA_PHASH_IDLE     2
#define TA_PHASH_BUSY     3
#define TA_PHASH_ORPH     4
#define TA_RHASH_LOST     5
#define TA_SPOOL_EXPIRED  6
#define TA_PHASH_REFRESH  7

/* Timer --> App */
typedef struct _timerarg {
	int  mtype;
	long sid;
	long uid;
	int  rid;
} timerarg_t;

/* func prototype */
typedef int tmCallback(double usec);

typedef struct _timerproc {
	pthread_t   thread;
	int         running;
	int         persec;
	int         prev;
	int         done;
	tmCallback *proc;
} timerproc_t;

/* IPC */
#define MAX_IPC_MSG_LEN 1024
#define MAX_IPC_MSG_NUM 512

typedef struct _ipcmsg {
	unsigned char occupied;
	unsigned char filler[3];
	unsigned int  from;
	unsigned int  ttoo;
	unsigned int  mtype;
	timeval_t time; /* this is 12 byte */
	unsigned char reserved[4];
	unsigned int  len;
	unsigned char data[MAX_IPC_MSG_LEN];
} ipcmsg_t;

typedef struct _ipcctl {
	pthread_mutex_t lock;
	pthread_cond_t  cond;
	unsigned int    sendIdx;
	unsigned int    recvIdx;
	unsigned int    maxnum;
	unsigned int    offset;
} ipcctl_t;

typedef struct _ipc {
	ipcctl_t ipcctl;
	ipcmsg_t ipcmsg[MAX_IPC_MSG_NUM];
} ipc_t;

typedef struct _ipcdata {
	int           arg1;
	unsigned int  arg2;
	unsigned long arg3;
} ipcdata_t;

/* NONB PIPE */
typedef struct _nonbpipe {
	/* name */
	char   name[16];
	int    pipefd[2];

	/* framework specific */
	int    *maxfd;
	fd_set *rset;
	fd_set *wset;
} nonbpipe_t;

/* NONB SOCK */
#define MAX_SOCKBUFF_LEN  32768

typedef struct _sockbuffer {
	int  pos;
	int  limit;
	char data[MAX_SOCKBUFF_LEN];
} sockbuffer_t;

typedef struct _nonbsock {
	/* name */
	char   name[16];

	/* framework specific */
	int    *maxfd;
	fd_set *rset;
	fd_set *wset;

	/* dynamic info */
	int    psockfd;
	int    pstatus;
	time_t chgtime;
	time_t sndtime;
	time_t rcvtime;
	time_t pngtime;

	/* buffer */
	sockbuffer_t sendbuff;
	sockbuffer_t recvbuff;
} nonbsock_t;


#endif

