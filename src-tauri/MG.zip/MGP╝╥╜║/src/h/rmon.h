/**
 * @date   2012/08/27
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 */
#ifndef __RMON_H__
#define __RMON_H__

/** includes ----------------------------------------------- */
#include "libcom.h"
#include "libapp.h"
#include "liboma.h"

/** constants ---------------------------------------------- */
/* basic */
#define AP_NAME "RMON"

/* Task Id */
#define RMON_TASK_MAIN  0

/** enums  ---------------------------------------------- */

/** data structures ---------------------------------------- */
typedef struct _sst_snapshot {
	/* CPS */
	sst_invoke_t  invoke[3];
	sst_error_t   error;
	sst_user_t    user;
	sst_bytes_t   bytes;
	sst_service_t service;
	sst_service_t commsvc;
	sst_service_t talksvc;

	/* MRS */
	sst_resource_t resource;
	sst_bytes_t    relay;
} sst_snapshot_t;

typedef struct _sst_contents {
	unsigned int comm[MAX_CONTENT_NUM];
	unsigned int talk[MAX_CONTENT_NUM];
} sst_contents_t;

typedef struct _rmonmagic {
	/* socket things */
	int    maxfd;
	fd_set rmask;
	fd_set wmask;

	/* running flag to control... */
	int running;

	/* for server key */
	unsigned int serverKey;

	/* for oma */
	omaproc_t   omaproc;

	/* for ring */
	variable_ringbuffer_t rb;
	char                  rbdata[MAX_RBDATA_SIZE];

	/* for collect */
	sysbundle_t poller_status;
	sysbundle_t poller_resstat;
	time_t      ltime_status;
	time_t      ltime_resstat;
	time_t      ltime_svcstat;

	/* for svclog */
	svclogvector_t slvector;

	/* for sst */
	sst_snapshot_t snapshot[2];
	sst_contents_t contents[2];
} rmonmagic_t;

/* for PHUB main */
extern rmonmagic_t   Oz;
extern rmonmagic_t *pOz;

/** functions ---------------------------------------------- */
/** main */
int initialize(int argc, char **argv);
int terminate(int code);
int wait_for(fd_set *rset, fd_set *wset, int usec);
int proc_with(fd_set *rset, fd_set *wset, time_t currtime);
int proc_timer(time_t currtime);

/** proc */
int proc_inline_sock (fd_set *rset, time_t currtime);
int proc_inline_timer(time_t currtime);
int proc_poll_resource(sysbundle_t *p_sysbundle, time_t currtime, int status_check);
int proc_poll_service (time_t currtime);

int proc_status_cpu(sysbundle_t *p_sysbundle);
int proc_status_mem(sysbundle_t *p_sysbundle);
int proc_status_fsy(sysbundle_t *p_sysbundle);
int proc_status_net(sysbundle_t *p_sysbundle);
int proc_status_nas(sysbundle_t *p_sysbundle);
int proc_status_odb(sysbundle_t *p_sysbundle);
int proc_status_tdb(sysbundle_t *p_sysbundle);
int proc_status_ydb(sysbundle_t *p_sysbundle);

int proc_statistic_sys(sysbundle_t *p_sysbundle, time_t currtime, char *yyyymmdd, char *hh, char *mi);
int proc_statistic_fsy(sysbundle_t *p_sysbundle, time_t currtime, char *yyyymmdd, char *hh, char *mi);
int proc_statistic_net(sysbundle_t *p_sysbundle, time_t currtime, char *yyyymmdd, char *hh, char *mi);
int proc_statistic_nas(sysbundle_t *p_sysbundle, time_t currtime, char *yyyymmdd, char *hh, char *mi);
int proc_statistic_odb(sysbundle_t *p_sysbundle, time_t currtime, char *yyyymmdd, char *hh, char *mi);
int proc_statistic_tdb(sysbundle_t *p_sysbundle, time_t currtime, char *yyyymmdd, char *hh, char *mi);

int proc_statistic_cps_invk   (sst_snapshot_t *p_snapshot, time_t currtime, char *yyyymmdd, char *hh, char *mi);
int proc_statistic_cps_stat   (sst_snapshot_t *p_snapshot, time_t currtime, char *yyyymmdd, char *hh, char *mi);
int proc_statistic_cps_svc    (sst_snapshot_t *p_snapshot, time_t currtime, char *yyyymmdd, char *hh, char *mi);
int proc_statistic_cps_user   (sst_snapshot_t *p_snapshot, time_t currtime, char *yyyymmdd, char *hh, char *mi);
int proc_statistic_cps_uerr   (sst_snapshot_t *p_snapshot, time_t currtime, char *yyyymmdd, char *hh, char *mi);
int proc_statistic_cps_perr   (sst_snapshot_t *p_snapshot, time_t currtime, char *yyyymmdd, char *hh, char *mi);
int proc_statistic_cps_tries  (sst_snapshot_t *p_snapshot, time_t currtime, char *yyyymmdd, char *hh, char *mi);
int proc_statistic_cps_bytes  (sst_snapshot_t *p_snapshot, time_t currtime, char *yyyymmdd, char *hh, char *mi);
int proc_statistic_cps_content(sst_contents_t *p_contents, time_t currtime, char *yyyymmdd, char *hh, char *mi);

int proc_statistic_mrs_resource(sst_snapshot_t *p_snapshot, time_t currtime, char *yyyymmdd, char *hh, char *mi);
int proc_statistic_mrs_relay   (sst_snapshot_t *p_snapshot, time_t currtime, char *yyyymmdd, char *hh, char *mi);

int check_threshold(resource_t *p_resource, int usage);
int check_livedown(resource_t *p_resource, int flag);

void snapshot_refresh_cps(sst_t *p_sst, sst_snapshot_t *p_delta);
void snapshot_refresh_mrs(sst_t *p_sst, sst_snapshot_t *p_delta);
void snapshot_refresh_content(contentmap_t *p_cmap, sst_contents_t *p_delta);
void send_event(int code, int clear, char *keyparam, int usage, int threshold);

#endif
