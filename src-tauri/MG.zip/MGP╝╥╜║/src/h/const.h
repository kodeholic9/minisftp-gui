/**
 * @date   2012/07/25
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */

#ifndef __CONST_H__
#define __CONST_H__

#define VERSION "1.0.0" 

/** ----------------------------------------------------- */
/** basic directories                                     */
/** ----------------------------------------------------- */
#define BIN_D           "/bin"
#define CMD_D           "/cmd"
#define LOG_D           "/log"
#define CONF_D          "/conf"
#define SCRIPT_D        "/script"
#define LIB_D           "/lib"
#define TMP_D           "/tmp"
#define CMDLOG_D        "/cmdlog"
#define PID_D           "/tmp/pid"

/** ----------------------------------------------------- */
/** config                                                */
/** ----------------------------------------------------- */
#define CODETBL_F       "CODETBL"
#define EXPTBL_F        "EXPTBL"
#define NODETBL_F       "NODETBL"
#define LCSTBL_F        "LCSTBL"
#define CPSTBL_F        "CPSTBL"
#define MRSTBL_F        "MRSTBL"
#define MRSPORTTBL_F    "MRSPORTTBL"
#define SYSTEM_F        "system.conf"
#define SLAVE_F         "slave.conf"
#define RESOURCE_F      "resource.conf"
#define THRESHOLD_F     "threshold.conf"

#define COMMON_F        "common.conf"
#define INIT_F        	"init.conf"
#define CPS_F           "cps.conf"
#define MRS_F           "mrs.conf"
#define OMA_F           "oma.conf"
#define TRACE_F         "trace.fifo"

/** ----------------------------------------------------- */
/** MAX                                                   */
/** ----------------------------------------------------- */
#define MAX_LCS_NUM      (48+1)
#define MAX_CPS_INST_NUM (32+1)
#define MAX_MRS_INST_NUM (32+1)
#define MAX_PROC_NUM     (64+1)

#define MAX_NODETBL_NUM  (256+1)
#define MAX_LCSTBL_NUM   (128+1)
#define MAX_CPSTBL_NUM   (128+1)
#define MAX_MRSTBL_NUM   (128+1)

#define MAX_EXPTBL_NUM   (32+1)

/** ----------------------------------------------------- */
/** PORT                                                  */
/** ----------------------------------------------------- */
#define PHUB_UDP_PORT_PFX  12550
#define PATH_UDP_PORT_PFX  12550
#define PATH_CPS_PORT_PFX  12550
#define PATH_MRS_PORT_PFX  14550
#define PMON_UDP_PORT      17930
#define PMON_TCP_PORT      17930

#define TRAS_UDP_HOST      "127.0.0.1"
#define TRAS_UDP_PORT      17931

/** ----------------------------------------------------- */
/** LIMITATION                                            */
/** ----------------------------------------------------- */
#define _USHORT_MAX   65535           /* max of "unsigned short int" */
#define _INT_MIN      (-2147483647-1) /* min value of an "int" */
#define _SHORT_MIN    (-32768)        /* min value of  a "short int" */
#define _SHORT_MAX    32767           /* max value of  a "short int" */
#define _INT_MAX      2147483647      /* max value of an "int" */
#define _UINT_MAX     4294967295U     /* max value of an "unsigned int" */

/** ----------------------------------------------------- */
/** SHARED MEMORY                                         */
/** ----------------------------------------------------- */
#define SYS_SHM_KEY  0x10000
#define TBL_SHM_KEY  0x20000
#define APP_SHM_KEY  0x30000
#define OMA_SHM_KEY  0x40000
#define MRS_SHM_KEY  0x50000
#define PATH_SHM_KEY 0x60000

/* for DEBUG */
typedef enum {
	CC_LogLevel       = 0,
	CC_CmCmdId,
	CC_CmResCode,
	CC_CmEvtCode,
	CC_CmDirCode,
	CC_CmAccType,
	CC_MpStatus,
	CC_MpQName,
	CC_MpMsgType,
	CC_MpEntType,
	CC_LmType,
	CC_LmResCode,
	CC_LmEvtCode,
	CC_LmDirCode,
	CC_LmN2N,
	CC_LmTalkType,
	CC_LmNotiFlag,
	CC_OmType,
	CC_HaType,
	CC_TcpStatus,
	CC_EvLevel,
	CC_EvCode,
	CC_SlStatus,
	CC_TnSvcCode,
	CC_ChnlStatus,
	CC_JPackType,
	CC_JPackStatus,
	CC_IpcMsgType,
	CC_MbcpStatus,
	NUMOF_CODECATE,
} CodeCateId_t;

/** ----------------------------------------------------- */
/** AP                                                    */
/** ----------------------------------------------------- */
typedef enum {
	MMIM     = 0,
	PMON     = 1,
	CHNL     = 2,
	MGPP     = 3,
	WEBI     = 4,
	HOOK     = 5,
	NUMOF_AP
} ap_t;

typedef enum {
	TST_CLOSED     = 0,
	TST_CONNECTING,
	TST_CONNECTED,
	TST_BINDING,
	TST_ACCEPTED,
	TST_KIN,
	TST_LISTEN,
} TcpSt_t;

/* Number of Thread */
#define MAX_TASK_NUM  10
#define MAX_INST_NUM  16

/** ----------------------------------------------------- */
/** MTYPE                                                 */
/** ----------------------------------------------------- */
#define IMT_RESP_BIT 0x8000

typedef enum {
	IMT_PROC_CHNL_STRT = 0x1001,
	IMT_PROC_MGPP_STRT = 0x1002,
	IMT_PROC_WEBI_STRT = 0x1003,

	/* MGPP CONTROL MESSAGE */
	IMT_MGP_STRT_REQ    = 0x0001,
	IMT_MGP_STRT_RES    = 0x8001,
	IMT_MGP_STOP_REQ    = 0x0002,
	IMT_MGP_STOP_RES    = 0x8002,
	IMT_MGP_RESTRT_REQ  = 0x0003,
	IMT_MGP_RESTRT_RES  = 0x8003,

	IMT_MGP_SET_VOLUME_REQ = 0x0005,
	IMT_MGP_SET_VOLUME_RES = 0x8005,

	/* CONTROL MESSAGE */
	IMT_CTL_PLAY_SOUND    = 0x0101,
	IMT_CTL_REBOOT        = 0x0102,
	IMT_CTL_UPGRADE       = 0x0103,
	IMT_CTL_COLLECT_LOG   = 0x0104,
	IMT_CTL_SHOW_BOARD    = 0x0105,
	IMT_CTL_HOOK_PRESSED  = 0x0106,
} IpcMsgType_t;

#define TO_UE(R)  (R == UE_INVK_REQ  || R == UE_EVNT_REQ)

/* Channel Status */
typedef enum {
	CST_IDLE       = 0,
	CST_ROOMING    = 1,
	CST_ROOMED     = 2,
	CST_JOINING    = 3,
	CST_JOINED     = 4,
	CST_ACTIVATING = 5,
	CST_ACTIVE     = 6,
	CST_LEAVING    = 7,
	CST_INACTIVE   = 8,
} ChannelStatus_t;

typedef enum {
	JPT_NONE       = 0,
	JPT_DEVICEINFO = 1,
	JPT_SHOWMYLIST = 2,
	JPT_JOIN       = 3,
	JPT_LEAVE      = 4,
} JPackType_t;

typedef enum {
	JPS_FREE       = 0,
	JPS_USING      = 1,
	JPS_REQUESTING = 2,
	JPS_SUCCESS    = 3,
	JPS_FAIL       = 4,
} JPackStatus_t;

typedef enum {
	MBCP_IDLE    = 0,
	MBCP_GRANTED = 1,
	MBCP_TAKEN   = 2,
} MbcpState_t;

/* AUDIO CODEC */
#define S_AMR_NB_OA "amr-nb-oa"
#define S_AMR_NB_BE "amr-nb-be"
#define S_AMR_WB_OA "arm-wb-oa"
#define S_AMR_WB_BE "arm-wb-be"
#define S_PCMA      "pcma"
#define S_PCMU      "pcmu"
#define S_OPUS_NB   "opus-nb"
#define S_OPUS_WB   "opus-wb"
#define S_OPUS_FB   "opus-fb"


#endif


