/**
 * @date   2012/08/23
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 */
#ifndef __PMON_H__
#define __PMON_H__

/** includes ----------------------------------------------- */
#include "libcom.h"
#include "libapp.h"

/** constants ---------------------------------------------- */
/* basic */
#define AP_NAME "PMON"

/** enums  ---------------------------------------------- */

/** data structures ---------------------------------------- */
typedef struct _pmonmagic {
	/* socket things */
	int    maxfd;
	fd_set rmask;
	fd_set wmask;

	/* running flag to control... */
	int running;

	/* pipe */
	nonbpipe_t  np;
} pmonmagic_t;

/* for PHUB main */
extern pmonmagic_t   Oz;
extern pmonmagic_t *pOz;

/** functions ---------------------------------------------- */
/** main */
int initialize(int argc, char **argv);
int terminate(int code);
int wait_for(fd_set *rset, int usec);
int proc_with(fd_set *rset, time_t currtime);
int proc_timer(time_t currtime);

/** proc */
int proc_slave_check(time_t currtime);

/** slave */
int slave_load    (slaveinfo_t *p_slaveinfo, time_t currtime);
int slave_stop    (slaveinfo_t *p_slaveinfo, time_t currtime);
int slave_kill    (slaveinfo_t *p_slaveinfo, time_t currtime);
int slave_wait    (slaveholder_t *p_slaveholder, time_t currtime);
int slave_watchout(slaveholder_t *p_slaveholder, time_t currtime);

#endif
