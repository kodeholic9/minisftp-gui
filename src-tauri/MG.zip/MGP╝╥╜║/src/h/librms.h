/**
 * @date   2016/07/25
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * @desc   
 * 
 */
#ifndef __LIBRMS_H__
#define __LIBRMS_H__

#include <string.h>
#include <jansson.h>

#include "libcom.h"
#include "libapp.h"

#include "httpconn.h"
#include "jsonpack.h"
#include "scf/scmsg.h"
#include "scf/scpool.h"

/* -------------------------------------------------------------------------- */
/* define constants and macro                                                 */
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */
/* log configuration */
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */
/* declare enums                                                              */
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */
/* function prototypes                                                        */
/* -------------------------------------------------------------------------- */

/** librms_rms.c ***********************************************************/
char *rmsGetISO8601  (char *s, size_t len);
char *rmsGetTimestamp(char *s, size_t len);
char *rmsGetUUID(char *s, size_t len);

char *rmsAudioCodec2Str(int codec);
int   rmsAudioCodec2Int(char *s);

/** librms_http.c ***********************************************************/
void rmsHttpInit(httpconn_t *p_httpconn, char *host, int port);

int         rmsHttpRequest (httpconn_t *p_httpconn, char *method, char *url, char *data, int timeo);
httpresp_t *rmsHttpResponse(httpconn_t *p_httpconn, int timeo);

void rmsHttpHeaderInit(httpconn_t *p_httpconn);
void rmsHttpHeaderPut (httpconn_t *p_httpconn, char *s);

void rmsHttpHeaderPut_S (httpconn_t *p_httpconn, char *name, char *value);
void rmsHttpHeaderPut_D (httpconn_t *p_httpconn, char *name, int   value);
void rmsHttpHeaderPut_U (httpconn_t *p_httpconn, char *name, int   value);
void rmsHttpHeaderPut_LU(httpconn_t *p_httpconn, char *name, long  value);

json_t *rmsHttpText2Json(const char *text);
char   *rmsHttpJson2Text(const json_t *json, char *text, size_t len);
void    rmsHttpFreeJson(json_t **json);

void   rmsHttpPrintJ(json_t *root, const char *func);
int    rmsHttpCheckJ(json_t *root, int expected);

int    rmsHttpGetJChar(json_t *json, char *name, char *text, size_t len);
int    rmsHttpGetJInt (json_t *json, char *name);
long   rmsHttpGetJLong(json_t *json, char *name);
double rmsHttpGetJReal(json_t *json, char *name);

/** librms_scmsg.c ***********************************************************/
int rmsScMesgValid(scmsg_t *p_scmsg); 

void rmsScMesgNtohHead(scmsg_t *p_from, scmsg_t *p_ttoo);
void rmsScMesgHtonHead(scmsg_t *p_from, scmsg_t *p_ttoo);
void rmsScMesgNtohData(scmsg_t *p_from, scmsg_t *p_ttoo);
void rmsScMesgHtonData(scmsg_t *p_from, scmsg_t *p_ttoo);

void rmsScMesgPackPingReq(scmsg_t *p_scmsg, long uid, int pid);
void rmsScMesgPackPingRes(scmsg_t *p_scmsg, long uid, int pid, int result);
void rmsScMesgPackBindReq(scmsg_t *p_scmsg, long uid, int pid, char *from_mdn, char *app_type, char *auth_key);
void rmsScMesgPackBindRes(scmsg_t *p_scmsg, long uid, int pid, int status, int result);
void rmsScMesgPackLeavReq(scmsg_t *p_scmsg, long uid, int pid);
void rmsScMesgPackLeavRes(scmsg_t *p_scmsg, long uid, int pid, int result);
void rmsScMesgPackDataReq(scmsg_t *p_scmsg, long uid, int pid, long ttoo, long sid, int action, char *data);
void rmsScMesgPackDataRes(scmsg_t *p_scmsg, long uid, int pid, int result, char *ack_data);

void rmsScMesgTrace(int lg, char *name, char *dir, scmsgwrap_t *p_wrap);

int rmsScMesgSendTcp(nonbsock_t *p_nonbsock, scmsgwrap_t *p_wrap);
int rmsScMesgRecvTcp(nonbsock_t *p_nonbsock, scmsgwrap_t *p_wrap);


/** librms_json.c ***********************************************************/
json_t *rmsJsonPack_phone(j_phone_t *obj);
int     rmsJsonUnpack_phone(json_t *json, j_phone_t *obj);
json_t *rmsJsonPack_contact(j_contact_t *obj);
int     rmsJsonUnpack_contact(json_t *json, j_contact_t *obj);
json_t *rmsJsonPack_contact_array(j_contact_t *obj, int size);
int     rmsJsonUnpack_contact_array(json_t *json, j_contact_t *obj, int size);
json_t *rmsJsonPack_user(j_user_t *obj);
int     rmsJsonUnpack_user(json_t *json, j_user_t *obj);
json_t *rmsJsonPack_joinreq(j_joinreq_t *obj);
int     rmsJsonUnpack_joinreq(json_t *json, j_joinreq_t *obj);
json_t *rmsJsonPack_profile(j_profile_t *obj);
int     rmsJsonUnpack_profile(json_t *json, j_profile_t *obj);
json_t *rmsJsonPack_leavereq(j_leavereq_t *obj);
int     rmsJsonUnpack_leavereq(json_t *json, j_leavereq_t *obj);
json_t *rmsJsonPack_roomlistvalue(j_roomlistvalue_t *obj);
int     rmsJsonUnpack_roomlistvalue(json_t *json, j_roomlistvalue_t *obj);
json_t *rmsJsonPack_roomlistvalue_array(j_roomlistvalue_t *obj, int size);
int     rmsJsonUnpack_roomlistvalue_array(json_t *json, j_roomlistvalue_t *obj, int size);
json_t *rmsJsonPack_showmylistreq(j_room_showmylistreq_t *obj);
int     rmsJsonUnpack_showmylistreq(json_t *json, j_room_showmylistreq_t *obj);
json_t *rmsJsonPack_showmylistres(j_room_showmylistres_t *obj);
int     rmsJsonUnpack_showmylistres(json_t *json, j_room_showmylistres_t *obj);

json_t *rmsJsonPack_deviceinfo(j_deviceinfo_t *obj);
int     rmsJsonUnpack_deviceinfo(json_t *json, j_deviceinfo_t *obj);

json_t *rmsJsonPack_datarcv(j_datarcv_t *obj);
int     rmsJsonUnpack_datarcv(json_t *json, j_datarcv_t *obj);

json_t *rmsJsonPack_board(j_board_t *obj);
int     rmsJsonUnpack_board(json_t *json, j_board_t *obj);

json_t *rmsJsonPack_statinfo(j_statinfo_t *obj);
int     rmsJsonUnpack_statinfo(json_t *json, j_statinfo_t *obj);

json_t *rmsJsonPack_omsres(j_omsres_t *obj);
int     rmsJsonUnpack_omsres(json_t *json, j_omsres_t *obj);

/** librms_scpool.c ***********************************************************/
void rmsScpoolInit(scbase_t *p_base);

scpool_t *rmsScpoolAlloc  (scbase_t *p_base);
scpool_t *rmsScpoolRelease(scbase_t *p_base, scpool_t *p_pool);
scpool_t *rmsScpoolPutPending(scbase_t *p_base, scpool_t *p_pool, time_t exprtime);
scpool_t *rmsScpoolPutSending(scbase_t *p_base, int winsz);
//
scpool_t *rmsScpoolGetResponsed(scbase_t *p_base, int pid);
scpool_t *rmsScpoolGetExpired  (scbase_t *p_base, time_t currtime);

scpool_t **rmsScpoolAllocArray  (scbase_t *p_base, pqueue_t *p_mqueue);
int        rmsScpoolReleaseArray(scpool_t **pp_pool);

/** librms_xxx.c ***********************************************************/

#endif
