/**
 * @date   2016/12/19
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 */
#ifndef __WEBI_H__
#define __WEBI_H__

/** includes ----------------------------------------------- */
#include "libcom.h"
#include "libapp.h"
#include "librms.h"

/** constants ---------------------------------------------- */
/* basic */
#define AP_NAME "WEBI"
#define MAX_WEBI_CLI_NUM 10

/** enums  ---------------------------------------------- */

/** data structures ---------------------------------------- */
typedef struct _webipmagic {
	/* socket */
	int    maxfd;
	fd_set rmask;
	fd_set wmask;

	/* http */
	int lsnrfd;
	httpconn_t httpconns[MAX_WEBI_CLI_NUM];

	/* running flag to control... */
	int running;
} webimagic_t;

/* for main */
extern webimagic_t   Oz;
extern webimagic_t *pOz;

/** functions ---------------------------------------------- */
/** main */
int initialize(int argc, char **argv);
int terminate(int code);
int wait_for(fd_set *rset, int usec);
int proc_sock(fd_set *rset);
int proc_ipc(ipcmsg_t *p_ipcmsg);
int proc_timer();

/** http */
int http_server_init();
int proc_http_accept();
int proc_http_read_request  (httpconn_t *p_hc);
int proc_http_write_response(httpconn_t *p_hc);

#endif
