/**
 * @date   2016/07/25
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 */
#ifndef __HTTPCONN_H__
#define __HTTPCONN_H__

#include "common.h"

#define MAX_HTTP_HEAD_LINE_LEN 1024
#define MAX_HTTP_HEAD_NUM      10

/** HTTP HEADER */
#define HH_CONTENT_LENGTH "CONTENT-LENGTH"
#define HH_TN_IUID        "tn-iuid"
#define HH_TN_AUTH_KEY    "tn-auth-key"
#define HH_TN_APP_TYPE    "tn-app-type"
#define HH_TN_REQ_USER    "tn-req-user"

/** HTTP METHOD */
#define HM_GET  "GET"
#define HM_POST "POST"
#define HM_PUT  "PUT"

/** HTTP HEADER VALUE */
#define HHV_USER_AGENT "Kodeholic/1.0"

/** HTTP CR LF */
#define CRLF "\r\n"
#define CR__ "\r"
#define __LF "\n"

typedef struct _httpheader {
	int  count;
	char h[MAX_HTTP_HEAD_NUM][MAX_HTTP_HEAD_LINE_LEN]; 
} httpheader_t;

typedef struct _httpresp {
	int   code;  //status code
	int   clen;  //content length
	char *content; //content
} httpresp_t;

typedef struct _httpreqt {
	char  uri[MAX_HTTP_HEAD_LINE_LEN];
	int   clen;    //content length
	char *content; //content
} httpreqt_t;

typedef struct _httpconn {
	int sockfd;
	int status;

	/* buffer */
	sockbuffer_t sendbuff;
	sockbuffer_t recvbuff;

	//header
	httpheader_t header;

	//host:port
	char host[128];
	int  port;

	//received request|response
	httpreqt_t request;
	httpresp_t response;

	//
	int    maxfd;
	fd_set rmask;
	fd_set wmask;
} httpconn_t;

#endif


