/**
 * @date   2012/07/23
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 */
#ifndef __SIMUL_H__
#define __SIMUL_H__

/** includes ----------------------------------------------- */
#include "libcom.h"
#include "libcps.h"

/** constants ---------------------------------------------- */
#define CPS_UDP_PORT    12551
#define CPS_BUFFER_SIZE 1500

/** data structures ---------------------------------------- */

/** functions ---------------------------------------------- */
/** main */

/** proc */

/** misc */

#endif
