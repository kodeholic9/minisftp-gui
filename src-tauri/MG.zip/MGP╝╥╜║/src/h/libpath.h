/**
 * @date   2012/11/01
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * @desc   
 * 
 */
#ifndef __LIBPATH_H__
#define __LIBPATH_H__

#include "libcom.h"
#include "libapp.h"
#include "cps/uemsg.h"
#include "cps/lcmsg.h"
#include "cps/pathapi.h"
#include "cps/pathsock.h"

/* -------------------------------------------------------------------------- */
/* define constants and macro                                                 */
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */
/* define data struct                                                         */
/* -------------------------------------------------------------------------- */
typedef struct _pathshm {
	phashmagic_t  phashmagic;
} pathshm_t;

/* -------------------------------------------------------------------------- */
/* define externs                                                             */
/* -------------------------------------------------------------------------- */
extern pathshm_t *pathP;
extern int        gBufferUsed;

/* -------------------------------------------------------------------------- */
/* function prototypes                                                        */
/* -------------------------------------------------------------------------- */
typedef int mpoolCallback(phashmagic_t *, pqueue_t *, mpool_t *, void *);
typedef int spoolCallback(phashmagic_t *, pqueue_t *, spool_t *, void *);
typedef int rpoolCallback(phashmagic_t *, pqueue_t *, rpool_t *, void *);
typedef int phashCallback(phashmagic_t *, pqueue_t *, phash_t *, void *);

/** libpath_path.c ***********************************************************/
int pathCreate(int shm_key);
int pathInitialize(int shm_key);

/** libpath_misc.c ***********************************************************/
int   pathCodeLcs2Ue(int code);
int   pathCodeUe2Lcs(int code);
void  pathSeqCntlInit(seqcntl_t *p_seqcntl);
int   pathSeqCntlPut (seqcntl_t *p_seqcntl, unsigned int n);
char *pathSeqCntlDump(seqcntl_t *p_seqcntl, char *s);
unsigned int pathSeqCntlExpected(seqcntl_t *p_seqcntl);

/** libpath_uemsg.c ***********************************************************/
void  pathUeMesg2UeLeg(uemsg_t *p_uemsg, ueleg_t *p_ueleg);

/* Send/Recv */
int  pathUeMesgRecvUdp(int ufd, udpaddr_t *p_udpaddr, uemsgwrap_t *p_wrap);
int  pathUeMesgSendUdp(int ufd, udpaddr_t *p_udpaddr, uemsgwrap_t *p_wrap);
int  pathUeMesgRecvTcp(psock_t *p_psock, uemsgwrap_t *p_wrap);
int  pathUeMesgSendTcp(psockctl_t *p_psockctl, psock_t *p_psock, uemsgwrap_t *p_wrap);
int  pathUeMesgValid(uemsg_t *p_uemsg);
void pathUeMesgNtohHead(uemsg_t *p_from, uemsg_t *p_ttoo);
void pathUeMesgNtohData(uemsg_t *p_from, uemsg_t *p_ttoo);
void pathUeMesgHtonHead(uemsg_t *p_from, uemsg_t *p_ttoo);
void pathUeMesgHtonData(uemsg_t *p_from, uemsg_t *p_ttoo);

/* Pack */
void pathUeMesgPackPingReq (uemsg_t *p_uemsg, unsigned char version, long uid, int pid, int acctype);
void pathUeMesgPackPingRes (uemsg_t *p_uemsg, unsigned char version, long uid, int pid, int result);
void pathUeMesgPackBindReq (uemsg_t *p_uemsg, unsigned char version, long uid, int pid, 
		ueaddr_t *from,ueaddr_t *ttoo, long sid, int dir, int answered, char *cryptkey);
void pathUeMesgPackBindRes (uemsg_t *p_uemsg, unsigned char version, long uid, int pid, int status, int result);
void pathUeMesgPackLeaveReq(uemsg_t *p_uemsg, unsigned char version, long uid, int pid, ueaddr_t *from, ueaddr_t *ttoo, long sid);
void pathUeMesgPackLeaveRes(uemsg_t *p_uemsg, unsigned char version, long uid, int pid, int result);
void pathUeMesgPackEventReq(uemsg_t *p_uemsg, unsigned char version, mpool_t *p_mpool);
void pathUeMesgPackEventRes(uemsg_t *p_uemsg, unsigned char version, long uid, int pid, int result);
void pathUeMesgPackInvkReq (uemsg_t *p_uemsg, unsigned char version, long uid, mpool_t *p_mpool);
void pathUeMesgPackInvkRes (uemsg_t *p_uemsg, unsigned char version, long uid, int pid, int order, int tries, int result, int displayed);
void pathUeMesgPackReptReq (uemsg_t *p_uemsg, unsigned char version, long uid, mpool_t *p_mpool);
void pathUeMesgPackReptRes (uemsg_t *p_uemsg, unsigned char version, long uid, int pid, int order, int result);
void pathUeMesgPackAllocReq(uemsg_t *p_uemsg, unsigned char version, long uid, mpool_t *p_mpool);
void pathUeMesgPackAllocRes(uemsg_t *p_uemsg, unsigned char version, long uid, int pid,
		char *mrsip, int mrsid, int nports, int *portlist, int result);
void pathUeMesgPackReleaseReq(uemsg_t *p_uemsg, unsigned char version, long uid, mpool_t *p_mpool);
void pathUeMesgPackReleaseRes(uemsg_t *p_uemsg, unsigned char version, long uid, int pid, int result);
void pathUeMesgPackShutdownReq(uemsg_t *p_uemsg, unsigned char version, long uid);

void pathUeMesgPackPeBindReq(uemsg_t *p_uemsg, unsigned char version, long uid, int pid, int svrkey, int avail);
void pathUeMesgPackPeBindRes(uemsg_t *p_uemsg, unsigned char version, long uid, int pid, int result);
void pathUeMesgPackPePingReq(uemsg_t *p_uemsg, unsigned char version, long uid, int pid, int avail);
void pathUeMesgPackPePingRes(uemsg_t *p_uemsg, unsigned char version, long uid, int pid, int result);

void pathUeMesgPackDataReq(uemsg_t *p_uemsg, unsigned char version, long uid, mpool_t *p_mpool);
void pathUeMesgPackDataRes(uemsg_t *p_uemsg, unsigned char version, long uid, int pid, int order, int tries, long incoming_time, int result, int displayed);

void pathUeMesgPackAuditRes(uemsg_t *p_uemsg, unsigned char version, long uid, int pid, int status, int answered, int result);

/* Unpack */
void pathUeMesgUnpackHeader  (uemsg_t *p_uemsg, mpool_t *p_mpool);
void pathUeMesgUnpackBindReq (uemsg_t *p_uemsg, mpool_t *p_mpool);
void pathUeMesgUnpackInvkReq (uemsg_t *p_uemsg, mpool_t *p_mpool);
void pathUeMesgUnpackReptReq (uemsg_t *p_uemsg, mpool_t *p_mpool);
void pathUeMesgUnpackEventReq(uemsg_t *p_uemsg, mpool_t *p_mpool);
void pathUeMesgUnpackDataReq (uemsg_t *p_uemsg, mpool_t *p_mpool);

void pathUeMesgUnpackAllocReq  (uemsg_t *p_uemsg, mpool_t *p_mpool);
void pathUeMesgUnpackAllocRes  (uemsg_t *p_uemsg, mpool_t *p_mpool);
void pathUeMesgUnpackReleaseReq(uemsg_t *p_uemsg, mpool_t *p_mpool);

void pathUeMesgUnpackAuditReq(uemsg_t *p_uemsg, mpool_t *p_mpool);

/* for TR */
int  pathUeMesg2TRStart(char *dir, mroute_t *lr, mroute_t *rr, uemsgwrap_t *p_wrap, char *tr, int trlen, int trflag);
int  pathUeMesg2TRBody(uemsgwrap_t *p_wrap, char *tr, int trlen);
void pathUeMesgTrace(int lg, char *dir, mroute_t *rr, uemsgwrap_t *p_wrap);

/* for misc */
char *pathUeMesgContent2Readable(uecontent_t *p_content, char *s);

/** libpath_lcmsg.c ***********************************************************/
int  pathLcMesgValid(lcmsg_t *p_lcmsg);
void pathLcMesgNtohHead(lcmsg_t *p_from, lcmsg_t *p_ttoo);
void pathLcMesgNtohData(lcmsg_t *p_from, lcmsg_t *p_ttoo);
void pathLcMesgHtonHead(lcmsg_t *p_from, lcmsg_t *p_ttoo);
void pathLcMesgHtonData(lcmsg_t *p_from, lcmsg_t *p_ttoo);

int  pathLcMesgRecvTcp(psock_t *p_nonbsock, lcmsgwrap_t *p_wrap);
int  pathLcMesgSendTcp(psockctl_t *p_psockctl, psock_t *p_nonbsock, lcmsgwrap_t *p_wrap);

void pathLcMesgPackLinkReq(lcmsg_t *p_lcmsg, int pid, int cpsid, char *cpsip, int cpsport);
void pathLcMesgPackLinkRes(lcmsg_t *p_lcmsg, int pid, int result);
void pathLcMesgPackPingReq(lcmsg_t *p_lcmsg, int pid);
void pathLcMesgPackPingRes(lcmsg_t *p_lcmsg, int pid, int result);
void pathLcMesgPackBindReq(lcmsg_t *p_lcmsg, mpool_t *p_mpool);
void pathLcMesgPackBindRes(lcmsg_t *p_lcmsg, int pid, int result);
void pathLcMesgPackPathReq(lcmsg_t *p_lcmsg, mpool_t *p_mpool);
void pathLcMesgPackPathRes(lcmsg_t *p_lcmsg, int pid, int result, int cpsid);
void pathLcMesgPackBothReq(lcmsg_t *p_lcmsg, mpool_t *p_mpool);
void pathLcMesgPackBothRes(lcmsg_t *p_lcmsg, int pid, int result, int cpsid);
void pathLcMesgPackSendReq(lcmsg_t *p_lcmsg, mpool_t *p_mpool);
void pathLcMesgPackSendRes(lcmsg_t *p_lcmsg, int pid, int result, int displayed);
void pathLcMesgUnpackSendReq(lcmsg_t *p_lcmsg, mpool_t *p_mpool);

int  pathLcMesg2TRStart(char *dir, int lkey, int rkey, lcmsgwrap_t *p_wrap, char *tr, int trlen, int trflag);
int  pathLcMesg2TRHead(lcmsgwrap_t *p_wrap, char *tr, int trlen);
int  pathLcMesg2TRBody(lcmsgwrap_t *p_wrap, char *tr, int trlen);
void pathLcMesgTrace(int lg, char *dir, int svrkey, lcmsgwrap_t *p_wrap);

/** libpath_mpool.c ***********************************************************/
mpool_t *MPOOL_PTR(phashmagic_t *p_magic, int mpool_id, const char *f, int l);
int      _mpool_init (phashmagic_t *p_magic);
mpool_t *_mpool_rmque(phashmagic_t *p_magic, pqueue_t *p_pqueue, int mpool_id, const char *f, int l);
mpool_t *_mpool_enque(phashmagic_t *p_magic, pqueue_t *p_pqueue, mpool_t *p_mpool, const char *f, int l);
mpool_t *_mpool_deque(phashmagic_t *p_magic, pqueue_t *p_pqueue, const char *f, int l);
mpool_t *_mpool_qscan(phashmagic_t *p_magic, pqueue_t *p_pqueue, int Rflag, mpoolCallback *proc, void *p_args);
int      _mpool_update_status(mpool_t *p_mpool, int status, const char *f, int l);

/** libpath_spool.c ***********************************************************/
spool_t *SPOOL_PTR(phashmagic_t *p_magic, int spool_id, const char *f, int l);
int      _spool_init (phashmagic_t *p_magic);
spool_t *_spool_rmque(phashmagic_t *p_magic, pqueue_t *p_pqueue, int spool_id, const char *f, int l);
spool_t *_spool_enque(phashmagic_t *p_magic, pqueue_t *p_pqueue, spool_t *p_spool, const char *f, int l);
spool_t *_spool_deque(phashmagic_t *p_magic, pqueue_t *p_pqueue, const char *f, int l);
spool_t *_spool_qscan(phashmagic_t *p_magic, pqueue_t *p_pqueue, int Rflag, spoolCallback *proc, void *p_args);
int      _spool_update_status(spool_t *p_spool, int status, const char *f, int l);

/** libpath_rpool.c ***********************************************************/
rpool_t *RPOOL_PTR(phashmagic_t *p_magic, int rpool_id, const char *f, int l);
int      _rpool_init (phashmagic_t *p_magic);
rpool_t *_rpool_rmque(phashmagic_t *p_magic, pqueue_t *p_pqueue, int rpool_id, const char *f, int l);
rpool_t *_rpool_enque(phashmagic_t *p_magic, pqueue_t *p_pqueue, rpool_t *p_rpool, const char *f, int l);
rpool_t *_rpool_deque(phashmagic_t *p_magic, pqueue_t *p_pqueue, const char *f, int l);
rpool_t *_rpool_qscan(phashmagic_t *p_magic, pqueue_t *p_pqueue, int Rflag, rpoolCallback *proc, void *p_args);
int      _rpool_update_status(rpool_t *p_rpool, int status, const char *f, int l);

/** libpath_phash.c ***********************************************************/
phash_t *PHASHDATA_PTR(phashmagic_t *p_magic, int hashdata_id, const char *f, int l);
int      _phashdata_init (phashmagic_t *p_magic);
phash_t *_phashdata_rmque(phashmagic_t *p_magic, pqueue_t *p_pqueue, int hashdata_id, const char *f, int l);
phash_t *_phashdata_enque(phashmagic_t *p_magic, pqueue_t *p_pqueue, phash_t *p_hashdata, const char *f, int l);
phash_t *_phashdata_deque(phashmagic_t *p_magic, pqueue_t *p_pqueue, const char *f, int l);
phash_t *_phashdata_qscan(phashmagic_t *p_magic, pqueue_t *p_pqueue, int Rflag, phashCallback *proc, void *p_args);
int      _phashdata_update_status(phash_t *p_hash, int status, const char *f, int l);

/** libpath_pathapi.c ***********************************************************/
/* API init */
int pathApiInit(phashmagic_t *p_magic);

/* for lock... */
int  PHASH_LOCK  (phashmagic_t *p_magic, long uid, int *loff);
int  PHASH_UNLOCK(phashmagic_t *p_magic, long uid, int  loff);
void PHASHDATA_LOCK  (phashmagic_t *p_magic);
void PHASHDATA_UNLOCK(phashmagic_t *p_magic);

void MESGDATA_LOCK  (phashmagic_t *p_magic);
void MESGDATA_UNLOCK(phashmagic_t *p_magic);
void SESSDATA_LOCK  (phashmagic_t *p_magic);
void SESSDATA_UNLOCK(phashmagic_t *p_magic);
void RESODATA_LOCK  (phashmagic_t *p_magic);
void RESODATA_UNLOCK(phashmagic_t *p_magic);

/* CPATH(path) operation ------------------------------- */
phash_t *pathApiGetPathFree(phashmagic_t *p_magic);
phash_t *pathApiPutPathFree(phashmagic_t *p_magic, phash_t *p_hash);
phash_t *pathApiAddPath(phashmagic_t *p_magic, ueaddr_t *p_ueaddr, udpaddr_t *p_udpaddr, iuaddr_t *p_iuaddr);
phash_t *pathApiDelPath(phashmagic_t *p_magic, long uid);
phash_t *pathApiGetPath(phashmagic_t *p_magic, long uid, udpaddr_t *p_udpaddr);
phash_t *pathApiGetPathByMPool(phashmagic_t *p_magic, mpool_t *p_mpool);

/* SPOOL(session) operation ---------------------------- */
spool_t *pathApiGetSPoolFree(phashmagic_t *p_magic);
spool_t *pathApiPutSPoolFree(phashmagic_t *p_magic, spool_t *p_spool);
spool_t *pathApiAddSPool(phashmagic_t *p_magic, phash_t *p_hash, ueleg_t *p_ueleg);
spool_t *pathApiDelSPool(phashmagic_t *p_magic, phash_t *p_hash, long sid, int firstflag);
spool_t *pathApiGetSPool(phashmagic_t *p_magic, phash_t *p_hash, long sid);
spool_t *pathApiGetSPoolByIndex(phashmagic_t *p_magic, phash_t *p_phash, int index);

/* RPOOL(resource) operation ---------------------------- */
rpool_t *pathApiGetRPoolFree(phashmagic_t *p_magic);
rpool_t *pathApiPutRPoolFree(phashmagic_t *p_magic, rpool_t *p_rpool);
rpool_t *pathApiAddRPool(phashmagic_t *p_magic, phash_t *p_hash, int rid, long uid, long sid);
rpool_t *pathApiDelRPool(phashmagic_t *p_magic, phash_t *p_hash, int rid, long sid, int firstflag);
rpool_t *pathApiGetRPool(phashmagic_t *p_magic, phash_t *p_hash, int rid, long sid);
rpool_t *pathApiFirstRPool(phashmagic_t *p_magic, phash_t *p_hash);

/* MPOOL operation ------------------------------------- */
mpool_t *pathApiGetMPoolFree(phashmagic_t *p_magic);
mpool_t *pathApiPutMPoolFree(phashmagic_t *p_magic, mpool_t *p_mpool);

/* timer */
mpool_t *pathApiStrtTimer(phashmagic_t *p_magic, mpool_t *p_mpool);
mpool_t *pathApiStopTimer(phashmagic_t *p_magic, mpool_t *p_mpool);
mpool_t *pathApiGetExpired(phashmagic_t *p_magic, int timeridx, double currtime);

/* pending */
mpool_t *pathApiPutPending(phashmagic_t *p_magic, phash_t *p_hash, mpool_t *p_mpool, time_t timerexpr, double timrtime);
mpool_t *pathApiDelPending(phashmagic_t *p_magic, phash_t *p_hash);

/* sending */
mpool_t *pathApiDelSending(phashmagic_t *p_magic, phash_t *p_hash);
mpool_t *pathApiPutSending(phashmagic_t *p_magic, phash_t *p_hash);
mpool_t *pathApiGetSending(phashmagic_t *p_magic, phash_t *p_hash, int mtype, int pid);

/* event */
void pathApiCheckPHashEvent(phashmagic_t *p_magic);
void pathApiCheckSPoolEvent(phashmagic_t *p_magic);
void pathApiCheckMPoolEvent(phashmagic_t *p_magic);

/* route */
void pathApiSetRoute(mroute_t *p_route, int type, int pid, long uid);

/* timer */
void pathApiSetInvkTimer(double timer); 
void pathApiSetEvntTimer(double timer); 

char *pathApiRoute2Desc(mroute_t *p_route, char *s);

/** libpath_code.c ***********************************************************/
int pathLcResult2Ue(int code);
int pathUeResult2Lc(int code);

/** libpath_psock.c ***********************************************************/
psockctl_t *pathPSockCtlInit(psockctl_t *p_psockctl);
void        pathPSockCtlDestroy(psockctl_t *p_psockctl);
void        pathPSockStatusUpdate(psock_t *p_psock, int status, const char *f, const int l);
psock_t    *pathPSockPtr(psockctl_t *p_psockctl, int fd, const char *f, const int l);

psockevent_t *pathPSockEPollWait(psockctl_t *p_psockctl, int timeo);

psock_t *pathPSockBindUDP(psockctl_t *p_psockctl, PSockType_T type, char *host, int port);
psock_t *pathPSockBindTCP(psockctl_t *p_psockctl, PSockType_T type, char *host, int port);
psock_t *pathPSockConnect(psockctl_t *p_psockctl, PSockType_T type, int index, char *host, int port);
psock_t *pathPSockAccept (psockctl_t *p_psockctl, psock_t *p_lsnrsock, PSockType_T type);
void     pathPSockClose  (psockctl_t *p_psockctl, psock_t *p_psock, const char *f, const int l);

psockbuffer_t *pathPSockAllocBuffer  (psock_t *p_psock, int incoming, const char *f, const int l);
int            pathPSockReleaseBuffer(psock_t *p_psock, int incoming, const char *f, const int l);
int            pathPSockCompactBuffer(psockbuffer_t *p_psbuffer);

typedef int PSockDecode(psockbuffer_t *, void *);
int pathPSockBufferedRead (psock_t *p_psock, PSockDecode *decode, void *data);
int pathPSockBufferedWrite(psockctl_t *p_psockctl, psock_t *p_psock, void *data, int dlen);
int pathPSockFlush        (psockctl_t *p_psockctl, psock_t *p_psock);

#endif 
