#ifndef __LIBSEC_H__
#define __LIBSEC_H__

#include "common.h"
#include <math.h>
#include <ctype.h>

#include "sec/config.h"
#include "sec/aes.h"
#include "sec/md5.h"

#if 0
#include "sec/arc4.h"
#include "sec/base64.h"
#include "sec/bn_mul.h"
#include "sec/bignum.h"
#include "sec/certs.h"
#include "sec/des.h"
#include "sec/dhm.h"
#include "sec/havege.h"
#include "sec/md2.h"
#include "sec/md4.h"
#include "sec/net.h"
#include "sec/padlock.h"
#include "sec/rsa.h"
#include "sec/sha1.h"
#include "sec/sha2.h"
#include "sec/sha4.h"
#include "sec/timing.h"
#include "sec/x509.h"
#include "sec/xtea.h"
#include "sec/camellia.h"
#endif

#define CRYPT_KEY_LEN 16

extern unsigned char defaultIV [CRYPT_KEY_LEN]; 
extern unsigned char defaultSUM[CRYPT_KEY_LEN];

/* libsec_util.c -------------------------------------------------- */
void secUtilMd5(char *s, unsigned char *sum);
int  secUtilAesCbc128Enc  (unsigned char *sum, unsigned char *iv, unsigned char *in, unsigned char *out, int len);
int  secUtilAesCbc128Dec  (unsigned char *sum, unsigned char *iv, unsigned char *in, unsigned char *out, int len);
int  secUtilAesCbc128EncIV(unsigned char *sum, unsigned char *in, unsigned char *out, int len);
int  secUtilAesCbc128DecIV(unsigned char *sum, unsigned char *in, unsigned char *out, int len);
void secUtilDumpRaw(char *name, char *s, int len);

#endif
