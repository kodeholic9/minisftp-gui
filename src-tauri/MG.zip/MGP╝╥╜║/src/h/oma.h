/**
 * @date   2016/11/14
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */

#ifndef __OMA_H__
#define __OMA_H__

#include "const.h"

#define MAX_FSYSTAT_NUM 16
#define MAX_NETSTAT_NUM 8
#define MAX_PSINFO_NUM  1024

#define U_LOG1024 10 /* (== 2^10) */

#define _PS_CMD  "ps -eo pid,ppid,user"

typedef struct _raw_cpustat {
	unsigned int user;
	unsigned int sys;
	unsigned int etc;
	unsigned int idle;
	double  t; /* time of collecting */
} raw_cpustat_t;

typedef struct _raw_memstat {
	unsigned long total;
	unsigned long avail;
	unsigned long freed;
	unsigned long buffers;
	unsigned long cached;
	double  usage;
	double  t; /* time of collecting */
} raw_memstat_t;

typedef struct _raw_fsystat {
	char name[32];
	unsigned long total;
	unsigned long freed;
	unsigned long avail;
	double   usage;
} raw_fsystat_t;

typedef struct _raw_fsystat_arr {
	raw_fsystat_t stat[MAX_FSYSTAT_NUM];
	int     n; /* number of entries */
	double  t; /* time of collecting */
} raw_fsystat_arr_t;

typedef struct _raw_netstat {
	char name[32];
	unsigned int ipkts;
	unsigned int opkts;
	unsigned int iocts;
	unsigned int oocts;
	unsigned int ierrs;
	unsigned int oerrs;
	unsigned int collisions;
} raw_netstat_t;

typedef struct _raw_netstat_arr {
	raw_netstat_t stat[MAX_NETSTAT_NUM];
	int     n; /* number of entries */
	double  t; /* time of collecting */
} raw_netstat_arr_t;

typedef struct _statholder {
	raw_cpustat_t     cpu;
	raw_netstat_arr_t net;
} statholder_t;

typedef struct _ext_psinfo {
	unsigned int pid;
	unsigned int ppid;
	char         user[32];
	char         comm[100];
	char         pcpu[32];
	char         pmem[32];
} ext_psinfo_t;

typedef struct _ext_pstable {
	ext_psinfo_t psinfo[MAX_PSINFO_NUM];
	int          n;
} ext_pstable_t;

/** OMS I/F ****/
#define MAX_OMBUFF_LEN  8192
#define MAX_OMHEAD_LEN  4
#define MAX_OMDATA_LEN  (MAX_OMBUFF_LEN - MAX_OMHEAD_LEN)

#define UE_OP_REQUEST 0x1031
#define UE_OP_RESULT  0x9031

#define OPT_BOARD_STATUS     1
#define OPT_CONTROL_VOLUME   2
#define OPT_CONTROL_REBOOT   3
#define OPT_CONTROL_FWUPDATE 4
#define OPT_SHOW_LOG         5


typedef struct _omheader {
	unsigned short command_id;
	unsigned short command_length;
} omheader_t;

typedef struct _omdatareq {
	omheader_t    h;
	unsigned int  op_type;
	unsigned char data[0];
} omdatareq_t;

typedef struct _omdatares {
	omheader_t    h;
	unsigned int  result;
} omdatares_t;

typedef union _ommsg {
	char         data[MAX_OMBUFF_LEN]; /* data */
	omheader_t   h;

	/* UE mesg */
	omdatareq_t  datareq;
	omdatares_t  datares;
} ommsg_t;

typedef struct _ommsgwrap {
	int     limit;
	int     readdone;
	ommsg_t uemsg;
	ommsg_t ueraw;
} ommsgwrap_t;





#endif

