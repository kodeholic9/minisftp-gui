/**
 * @date   2012/11/09
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */

#ifndef __TABLE_H__
#define __TABLE_H__

/** ----------------------------------------------------- */
/** constants                                             */
/** ----------------------------------------------------- */
#define TABLE_START    1
#define TABLE_NULL     0

/** ----------------------------------------------------- */
/** for table                                             */
/** ----------------------------------------------------- */
/* for SUB */
typedef struct _subent {
	unsigned char occupied;
	unsigned int  key;
	char          host[MAX_HOST_SIZE];
	int           port;

	char          _2ndhost[MAX_HOST_SIZE];
} subent_t;

typedef struct _subtbl {
	subent_t sub[MAX_NODETBL_NUM];
	int      maxidx;
} subtbl_t;

/* for NODE */
typedef struct _nodeent {
	unsigned char occupied;
	unsigned int  nodekey;

	/* for SERVICE */
	char          sc_host  [MAX_HOST_SIZE];
	int           sc_port;

	/* for P2P */
	char          p2p_host[MAX_HOST_SIZE];
	int           p2p_port_1;
	int           p2p_port_2;

	/* for HEARTBEAT */
	char          hbt_host_1[MAX_HOST_SIZE];
	char          hbt_host_2[MAX_HOST_SIZE];
	int           hbt_port;

} nodeent_t;

typedef struct _nodetbl {
	nodeent_t node[MAX_NODETBL_NUM];
	int       maxidx;

	/* inline table */
	subtbl_t u2ctbl;
	subtbl_t c2ctbl;
	subtbl_t m2ctbl;
	subtbl_t l2ctbl;
	subtbl_t hbttbl;
} nodetbl_t;

/* for MRS PORT */
typedef struct _mrsportent {
	unsigned char occupied;
	int  from;
	int  ttoo;
} mrsportent_t;

typedef struct _mrsporttbl {
	mrsportent_t mrsport[MAX_MRSTBL_NUM];
	int          maxidx;
} mrsporttbl_t;

/* for EXP */
#define EXP_DEFAULT_IDLE ( 2.0)
#define EXP_DEFAULT_LOST (12.0)
typedef struct _expent {
	unsigned char occupied;
	int    code;
	double idle;
	double lost;
} expent_t;

typedef struct _exptbl {
	expent_t exp[MAX_EXPTBL_NUM];
	int      maxidx;
} exptbl_t;

/** ----------------------------------------------------- */
/** for process context                                   */
/** ----------------------------------------------------- */

#endif
