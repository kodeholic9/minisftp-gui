/**
 * @date   2016/07/28
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 *
 */
#ifndef __JSONPACK_H__
#define __JSONPACK_H__

/** includes ----------------------------------------------- */
#include "libcom.h"

#define MAX_MY_CHANNEL_NUM  5
#define MAX_SERVERINFO_NUM  5
#define MAX_SERVERCONN_NUM  2
#define MAX_SLAVE_PROC_NUM  10 

#define TELECOM_CODE     "45008"
#define VOIP_CODEC       "opus-wb"
#define VOIP_APORT       31820
#define VOIP_MPORT       31824

/////////////////////////////////////////////////////////////////////////////	
#define ACTION_CHANNEL_JOIN      120
#define CTYPE_CHANNEL_JOIN       "room/channel/join"
#define CTYPE_CHANNEL_ACTIVE     "room/channel/active"

/////////////////////////////////////////////////////////////////////////////	
#define ACTION_CHANNEL_LEAVE     121
#define CTYPE_CHANNEL_LEAVE      "room/channel/leave"
#define CTYPE_CHANNEL_RELEASE    "room/channel/release"
#define CTYPE_CHANNEL_DISCONNECT "room/channel/disconnect"
#define CTYPE_CHANNEL_INACTIVATE "room/channel/inactivate"

/////////////////////////////////////////////////////////////////////////////	
#define ACTION_CONTROL_EVENT            213
#define CTYPE_CONTROL_EVENT_INACTIVATE  "room/control/event/inactivate-channel"

/////////////////////////////////////////////////////////////////////////////	
#define ACTION_STATUS_EVENT              214
#define CTYPE_STATUS_EVENT_USER_ENTER    "room/status/event/user/enter"
#define CTYPE_STATUS_EVENT_USER_LEAVE    "room/status/event/user/leave"
#define CTYPE_STATUS_EVENT_USER_RELEASE  "room/status/event/user/release"

/////////////////////////////////////////////////////////////////////////////	
#define ACTION_FLOOR_EVENT               206
#define CTYPE_FLOOR_EVENT_GRANT			 "room/floor/event/grant"
#define CTYPE_FLOOR_EVENT_RELEASE		 "room/floor/event/release"

/////////////////////////////////////////////////////////////////////////////	
#define ACTION_EMS_EVENT               216
#define CTYPE_EMS_BOARD_STATUS         "ope/board/status"
#define CTYPE_EMS_BOARD_CONTROL_VOLUME "ope/board/control/volume"
#define CTYPE_EMS_BOARD_CONTROL_REBOOT "ope/board/control/reboot"
#define CTYPE_EMS_FIRMWARE_UPDATE      "ope/firmware/update"
#define CTYPE_EMS_LOG_UPLOAD           "ope/log/upload"

/////////////////////////////////////////////////////////////////////////////	
#define CTYPE_CONTROL_INVITE             "room/control/invite"
#define CTYPE_CONTROL_BAN                "room/control/ban"

/////////////////////////////////////////////////////////////////////////////	
#define CTYPE_ROOM_SHOW          "room/show"
#define CTYPE_ROOM_SHOW_LIST     "room/show-list"
#define CTYPE_ROOM_SHOW_MY_LIST  "room/show-my-list"

/////////////////////////////////////////////////////////////////////////////	
#define URL_RMS             "/httpenabler/TRM/1.0/"
#define URL_ACS_DEVICEINFO  "/mcs/deviceinfo/"

/////////////////////////////////////////////////////////////////////////////	
#define SEARCH_TYPE_INVITED  0; 
#define SEARCH_TYPE_OPENED   1;
#define SEARCH_TYPE_JOINED   2;
#define SEARCH_TYPE_MY       3;

/** phone */
typedef struct _j_phone {
	char mobile[24];
	char home[24];
	char office[24];
} j_phone_t;

/** contact */
typedef struct _j_contact {
	char id[24];
	char name[24];
	char email[64];
	char address[128];
	char gender[10];
	j_phone_t phone;
} j_contact_t;

/** profile */
typedef struct _j_profile {
	int  type;
	long iuid;
	char phone_no[24];
	char e164[24];
	char nickname[20];
	char message[64];
	char email[60];
	int  din;
	int  dcn;
	int  pic_type;
	char image[256];
	char thumbnail[256];
} j_profile_t;

/** result */
typedef struct _j_result {
	int  code;
	char desc[32];
} j_result_t;

/** user */
typedef struct _j_user {
	long iuid;
	char mdn [20];
	char name[20];
} j_user_t;

/** scfcause */
typedef struct _j_scfcause {
	int  code;
	char message[128];
} j_scfcause_t;

/** joinreq */
typedef struct _j_joinreq {
	char     datetime[36];
	char     ctype[64];
	char     mesg_id[128];
	j_user_t from;
	long     sid;
	char     telecom_code[10];
	char     password[10];
	char     timestamp[24];
	char     src_ip[64];
	int      src_port;
	int      src_tbcp_port;
	char     codec[64];
	char     roaming[10];
} j_joinreq_t;

/** leavereq */
typedef struct _j_leavereq {
	char         datetime[36];
	char         ctype[64];
	char         mesg_id[128];
	long         sid;
	j_user_t     from;
	j_scfcause_t cause;
	char         roaming[10];
	char         call_id[256];
} j_leavereq_t;

/** room_showreq */
typedef struct _j_room_showreq {
	char ctype[128];
	long sid;
} j_room_showreq_t;

/** room_showlistreq */
typedef struct _j_room_showlistreq {
	char ctype[128];
	int  search_type;
	int  expose;
	int  sort;
} j_room_showlistreq_t;

/** room_showmylistreq */
typedef struct _j_room_showmylistreq {
	char ctype[128];
	int  search_type;
	int  start_row; /* 1   */
	int  end_row;   /* 1+1 */
} j_room_showmylistreq_t;

/** room_showmylistres */
typedef struct _j_roomlistvalue {
	long sid;
	char room_no[10];
	char text[64]; 
	char create_time[24]; 
	char change_time[24];
	char start_time[24];
	char stop_time[24];
	int  nr_member; 
	int  status; 
	int  member_limit; 
	int  room_type;
	int  expose;
	char password[10];
	int  password_required;
	char notice[64];
	j_user_t owner;
	int      invited;
	char     invited_time[24];
	j_user_t inviter;
	int      connect_member;
	char     last_floor_time[24];
	int      banned;
	char thumbnail[128];
	char image[128];
	char desc[64];
	int  color_type;
	char tags[36];
} j_roomlistvalue_t;

/** room_showmylistres */
typedef struct _j_room_showmylistres {
	char ctype[128];
	int  total_count;
	j_roomlistvalue_t room_list[MAX_MY_CHANNEL_NUM];
	int  avail_count;
} j_room_showmylistres_t;

/** connection */
typedef struct _j_connection {
	char protocol[10];
	char ip[24];
	int  port;
} j_connection_t;

/** serverinfo */
typedef struct _j_serverinfo {
	char id[16];
	char name[16];
	j_connection_t connections[MAX_SERVERCONN_NUM];
	int            connection_count;
} j_serverinfo_t;

/** deviceinfores */
typedef struct _j_deviceinfo {
	long iuid;
	char auth_key[MAX_AUTHKEY_LEN];
	int  subs_type;

	j_serverinfo_t servers[MAX_SERVERINFO_NUM];
	int            server_count;
} j_deviceinfo_t;

typedef struct _j_addinfo {
	//Volume
	int volume; 
	//FWUpdate
	char version[16];
	char installer_url[256];
	char download_file_url[256];
	//Request
	char request_key[20];
	char method[16];
	char dst_ip[32];
	int  dst_port;
	char dst_url[64];
} j_addinfo_t;

/** datarcv */
typedef struct _j_datarcv {
	char        ctype[128];
	long        sid;
	char        datetime[36];
	char        timestamp[24];
	char        mesg_id[128];
	j_user_t    from;
	char        text[1024];

	/* for addinfo */
	j_addinfo_t addinfo;

	/* for joinres */
	j_profile_t profile;
	j_roomlistvalue_t room;
	int         pay;
	char        dst_ip[64];
	int         dst_port;
	int         dst_tbcp_port;
	char        codec[64];
	int         ptype;
	char        old_call_id[256];
	char        call_id[256];
	long        conf_id;

	j_result_t  result;
} j_datarcv_t;

/** boardinfo */
typedef struct _j_process {
	char  alias[10];
	int   pid;
	int   ppid;
	int   ipc_send;
	int   ipc_recv;
	int   debug_point;
	int   debug_count;
	long  start_time;
	long  stop_time;
	int   total_down_count;
	int   recent_down_count;
	char  status[36];
} j_process_t;

typedef struct _j_config {
	/* device */
	char version[16];
	char e164[24];
	char app_type[16];
	long iuid;
	char auth_key[32];
	/* server */
	char acs_http_server_addr[64];
	char rms_http_server_addr[64];
	char scf_tcp_server_addr[64];
	char scf_tcp_source_ip[32];
	char scf_tcp_status[16];
	long scf_tcp_fault_time;
	int  scf_tcp_fault_duration;
	/* webi */
	int  webi_listen_port;
	/* channel */
	long channel_sid;
	long channel_status_change_time;
	char channel_status[16];
	/* voip */
	int  voip_audio_volume;
	int  voip_running;
	char voip_dest_ip[32];
	int  voip_dest_audio_port;
	int  voip_dest_mbcp_port;
	char voip_audio_codec[32];
	char voip_call_id[128];
	/* mbcp */
	char mbcp_status[16];
	long mbcp_status_change_time;
	long mbcp_still_alive_time;
	/* sound player */
#if 0
	char sound_player_path[128];
	char sound_clip_path_00[128];
#endif
	int auto_recovery_period_sec;
	int firmware_update_enabled;
	/* scf idle/lost */
	int  scf_tcp_idle_sec;
	int  scf_tcp_lost_sec;
	/* period */
	int  usering_period_sec;
	int  rooming_period_sec;
	int  joining_period_sec;
	/* logging */
	int  logging;
	char log_level[8];
} j_config_t;

typedef struct _j_modem {
	char imei[64];
	char cnum[24];
	char nsi[64];
	int  csq;
	char cgdcont[64];
	char cgpaddr[64];
} j_modem_t;

typedef struct _j_uname {
	char sysname[64];
	char nodename[64];
	char release[64];
	char version[64];
	char machine[64];
} j_uname_t;

/** statinfo */
typedef struct _j_cpustat {
	double user;
	double sys;
	double etc;
	double idle;
} j_cpustat_t;

typedef struct _j_memstat {
	unsigned long total;
	unsigned long avail;
	unsigned long freed;
	unsigned long buffers;
	unsigned long cached;
	double usage;
} j_memstat_t;

typedef struct _j_fsystat {
	char name[32];
	unsigned long total;
	unsigned long freed;
	unsigned long avail;
	double   usage;
} j_fsystat_t;

typedef struct _j_netstat {
	char name[32];
	double ipkts;
	double opkts;
	double iocts;
	double oocts;
	double ierrs;
	double oerrs;
	double collisions;
} j_netstat_t;

typedef struct _j_statinfo {
	j_cpustat_t cpustat;
	j_memstat_t memstat;
	j_fsystat_t fsystat_list[MAX_FSYSTAT_NUM];
	int         fsystat_count;
	j_netstat_t netstat_list[MAX_NETSTAT_NUM];
	int         netstat_count;
} j_statinfo_t;

typedef struct _j_board {
	char request_key[20];
	j_process_t process_list[MAX_SLAVE_PROC_NUM];
	int         process_count;
	j_config_t  config;
	j_modem_t   modem;
	j_uname_t   uname;
	j_cpustat_t cpustat;
	j_memstat_t memstat;
	j_fsystat_t fsystat_list[MAX_FSYSTAT_NUM];
	int         fsystat_count;
	j_netstat_t netstat_list[MAX_NETSTAT_NUM];
	int         netstat_count;
} j_board_t;

typedef struct _j_omsres {
	char request_key[20];
	int  result;
	int  volume;
} j_omsres_t;

/****************************************************************/
/*                                                              */
/* jsonpack response                                            */
/*                                                              */
/****************************************************************/
typedef struct jsonpack {
	int    status;
	int    id;
	int    type;
	time_t using_time;

	union {
		j_joinreq_t            join;
		j_leavereq_t           leave;
		j_room_showmylistreq_t showmylist;
	} req;

	union {
		j_datarcv_t            datarcv;
		j_deviceinfo_t         deviceinfo;
		j_room_showmylistres_t showmylist;
	} res;
} jsonpack_t;

#endif



