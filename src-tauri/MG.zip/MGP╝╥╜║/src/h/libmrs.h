/**
 * @date   2012/11/30
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * @desc   
 * 
 */
#ifndef __LIBMRS_H__
#define __LIBMRS_H__

#include "libcom.h"
#include "libapp.h"
#include "libpath.h"
#include "mrs/mrsrtp.h"
#include "mrs/mrsapi.h"

/* -------------------------------------------------------------------------- */
/* define constants and macro                                                 */
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */
/* define data struct                                                         */
/* -------------------------------------------------------------------------- */
typedef struct _mrsshm {
	rhashmagic_t rhashmagic;
} mrsshm_t;

/* -------------------------------------------------------------------------- */
/* define externs                                                             */
/* -------------------------------------------------------------------------- */
extern mrsshm_t *mrsP;

/* -------------------------------------------------------------------------- */
/* function prototypes                                                        */
/* -------------------------------------------------------------------------- */
typedef int rhashCallback(rhashmagic_t *, pqueue_t *, rhash_t *, void *);

/** libmrs_mrs.c ***********************************************************/
int mrsCreate(int shm_key);
int mrsInitialize(int shm_key);

/** libmrs_rhash.c ***********************************************************/
rhash_t *RHASHDATA_PTR(rhashmagic_t *p_magic, int hashdata_id, const char *f, int l);
int      _rhashdata_init (rhashmagic_t *p_magic);
rhash_t *_rhashdata_rmque(rhashmagic_t *p_magic, pqueue_t *p_pqueue, int hashdata_id, const char *f, int l);
rhash_t *_rhashdata_enque(rhashmagic_t *p_magic, pqueue_t *p_pqueue, rhash_t *p_hashdata, const char *f, int l);
rhash_t *_rhashdata_deque(rhashmagic_t *p_magic, pqueue_t *p_pqueue, const char *f, int l);
rhash_t *_rhashdata_qscan(rhashmagic_t *p_magic, pqueue_t *p_pqueue, int Rflag, rhashCallback *proc, void *p_args);
int      _rhashdata_update_status(rhash_t *p_hash, int status, const char *f, int l);

/** libmrs_api.c ***********************************************************/
/* API init */
int mrsApiInit(rhashmagic_t *p_magic, int from, int ttoo);

/* for lock... */
int  RHASH_LOCK  (rhashmagic_t *p_magic, long uid, int *loff);
int  RHASH_UNLOCK(rhashmagic_t *p_magic, long uid, int  loff);
void RHASHDATA_LOCK  (rhashmagic_t *p_magic);
void RHASHDATA_UNLOCK(rhashmagic_t *p_magic);

/* MRS operation ------------------------------- */
rhash_t *mrsApiGetResFree(rhashmagic_t *p_magic);
rhash_t *mrsApiPutResFree(rhashmagic_t *p_magic, rhash_t *p_rhash);
rhash_t *mrsApiAddRes(rhashmagic_t *p_magic, rhashdata_t *p_data);
rhash_t *mrsApiDelRes(rhashmagic_t *p_magic, rhashdata_t *p_data);
rhash_t *mrsApiGetRes(rhashmagic_t *p_magic, rhashdata_t *p_data);
rhash_t *mrsApiReleaseRes(rhashmagic_t *p_magic, rhashdata_t *p_data);

/** libmrs_cntl.c ***********************************************************/
int mrsCntlInit(mrscntl_t *p_mrscntl, int from, int ttoo);
int mrsCntlPortNext(mrscntl_t *p_mrscntl);
int mrsCntlPortAvailCount(mrscntl_t *p_mrscntl);
int mrsCntlStrtPort(mrscntl_t *p_mrscntl, mrsport_t *p_mrsport);
int mrsCntlStopPort(mrscntl_t *p_mrscntl, mrsport_t *p_mrsport);
int mrsCntlAllocPorts  (mrscntl_t *p_mrscntl, rhash_t *p_rhash);
int mrsCntlReleasePorts(mrscntl_t *p_mrscntl, rhash_t *p_rhash);
int mrsCntlWait(mrscntl_t *p_mrscntl, int msec);
int mrsCntlSearchByFd(mrscntl_t *p_mrscntl, rhash_t *p_rhash, int fd);
int mrsCntlRelay(mrscntl_t *p_mrscntl, rhash_t *p_rhash, int rcvidx, mrsrtpwrap_t *p_wrap);

#if 0
int mrsCntlPortRangeInit(portrange_t *p_portrange, int from, int ttoo);
int mrsCntlPortRangeNext(portrange_t *p_portrange);
int mrsCntlAvailPort(portrange_t *p_portrange);
int mrsCntlStartPort(portrange_t *p_portrange, int *port);
int mrsCntlStopPort (portrange_t *p_portrange, int port, int fd);

int mrsCntlAllocPorts  (portrange_t *p_portrange, mrsport_t *p_mrsports, int nports);
int mrsCntlReleasePorts(portrange_t *p_portrange, mrsport_t *p_mrsports, int nports);
#endif

/** libmrs_rtp.c ***********************************************************/
int mrsRtpMesgRecv(int fd, udpaddr_t *p_udpaddr, mrsrtpwrap_t *p_wrap);
int mrsRtpMesgSend(int fd, udpaddr_t *p_udpaddr, mrsrtpwrap_t *p_wrap, int sndlen);

#endif 


