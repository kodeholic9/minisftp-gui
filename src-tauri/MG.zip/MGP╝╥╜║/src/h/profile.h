/**
 * @date   2012/12/13
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */

#ifndef __PROFILE_H__
#define __PROFILE_H__

#include "const.h"

/** ----------------------------------------------------- */
/** constants                                             */
/** ----------------------------------------------------- */

/** ----------------------------------------------------- */
/** Config Util                                           */
/** ----------------------------------------------------- */
typedef int buff2valuep(char *s , void *vp);
typedef int valuep2buff(void *vp, char *s );

/* parameter table for loading */
typedef struct _profileload {
	char         name[32];
	void        *vptr;
	buff2valuep *buff2vp;
	valuep2buff *vp2buff;
	int          loaded;
	char         desc[64];
} profileload_t;

typedef struct _profilecart {
	char          *filename;
	profileload_t *p_clroot;
	void          *data_shared;
	void          *data_local;
	int            datalen;
} profilecart_t;

/** ----------------------------------------------------- */
/** Config To load                                        */
/** ----------------------------------------------------- */

typedef struct _profile {
	//for USER
	char E164[MAX_MDN_LEN];
	char AppType[MAX_APPTYPE_LEN];
	long IUID;
	char AuthKey[MAX_AUTHKEY_LEN];

	//for SERVER
	char ACSHttpServerHost[MAX_HOST_SIZE];
	int  ACSHttpServerPort;
	char RMSHttpServerHost[MAX_HOST_SIZE];
	int  RMSHttpServerPort;
	char SCFTcpServerHost[MAX_HOST_SIZE];
	int  SCFTcpServerPort;

	//for SCFTcp
	char   SCFTcpSourceIp[MAX_HOST_SIZE];
	int    SCFTcpStatus;
	time_t SCFTcpFaultTime;
	int    SCFTcpFaultDuration;

	//for WEBI
	int  WEBIListenPort;

	//for CHANNEL
	long   ChannelSID;
	time_t ChannelChgTime;
	int    ChannelStatus;

	//for VOIP
	int    VoipAudioVolume;
	int    VoipRunning;
	char   VoipDestIp[MAX_HOST_SIZE];
	int    VoipDestAPort;
	int    VoipDestMPort;
	int    VoipAudioCodec;
	char   VoipCallID[256];

	//for MBCP
	int    MBCPStatus;
	time_t MBCPChgTime;
	time_t MBCPStillAliveTime;

	//for SoundPlayerPath
	char  SoundClipPTTStart[128];
	char  SoundClipPTTStop[128];
	//for SoundPlayerPath
	char  SoundClipPath_00[128];
	char  SoundClipPath_01[128];
	char  SoundClipPath_02[128];
	char  SoundClipPath_03[128];
	char  SoundClipPath_04[128];
	char  SoundClipPath_05[128];
	char  SoundClipPath_06[128];
	char  SoundClipPath_07[128];
	char  SoundClipPath_08[128];
	char  SoundClipPath_09[128];

	//for CLI (command line interface) */
	char  CLI_mplayer[128];
	char  CLI_reboot[128];
	char  CLI_fwupdate[128];

	//for AutoRecovery
	int AutoRecoveryPeriodSec;
	int FirmwareUpdateEnabled;

	//for SCF ping
	int SCFTcpIdleSec;
	int SCFTcpLostSec;

	//for Periodic job
	int UseringPeriodSec;
	int RoomingPeriodSec;
	int JoiningPeriodSec;

	//
	time_t LogTraceUntil;
	int    Logging;
	int    LogLevel;
} profile_t;

#endif

