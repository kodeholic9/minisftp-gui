/**
 * @date   2012/08/28
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */

#ifndef __COLLECT_H__
#define __COLLECT_H__

#include <mntent.h>
#include <sys/vfs.h>

/** ----------------------------------------------------- */
/** constant                                              */
/** ----------------------------------------------------- */
#define MAX_FSYINFO_NUM  128
#define MAX_NETINFO_NUM  64
#define MAX_ODBINFO_NUM  64

#define U_LOG1024 10 /* (== 2^10) */

/** ----------------------------------------------------- */
/** data struct                                           */
/** ----------------------------------------------------- */
typedef enum {
	V_CPUSTAT_USR  = 0,
	V_CPUSTAT_SYS  = 1,
	V_CPUSTAT_ETC  = 2,
	V_CPUSTAT_IDLE = 3,
	NUMOF_CPUSTAT,
} CpuStat_t;

typedef struct _timeinfo {
	double prev;
	double delta;
} timeinfo_t;

typedef struct _cpuinfo {
	timeinfo_t   timeinfo;

	unsigned int curr[NUMOF_CPUSTAT]; 
	unsigned int prev[NUMOF_CPUSTAT]; 

	/* calculated value */
	double       usr;
	double       sys;
	double       etc;
	double       idle;
} cpuinfo_t;

typedef struct _meminfo {
	timeinfo_t   timeinfo;

	unsigned long total; 
	unsigned long freed; 
	unsigned long buffers; 
	unsigned long cached; 

	double   usage;
} meminfo_t;

typedef struct _fsyinfo {
	timeinfo_t   timeinfo;

	char          name[32];
	unsigned long total; 
	unsigned long freed; 
	unsigned long avail; 

	double   usage;
} fsyinfo_t;

typedef struct _netraw {
	unsigned int ipkts; 
	unsigned int opkts; 
	unsigned int iocts; 
	unsigned int oocts; 
	unsigned int ierrs; 
	unsigned int oerrs; 
	unsigned int collisions;
} netraw_t;

typedef struct _netinfo {
	char     name[32];
	netraw_t curr;
	netraw_t prev;
	netraw_t delta;

	double   iusage;
	double   ousage;
} netinfo_t;

typedef struct _tdbinfo {
	unsigned long perm_size;
	unsigned long perm_used;
	unsigned long temp_size;
	unsigned long temp_used;
	unsigned long bookmark;

	double   perm_usage;
	double   temp_usage;
} tdbinfo_t;

typedef struct _odbinfo {
	char          name[32];
	unsigned long total;
	unsigned long used;
	unsigned long freed;

	double   usage;
} odbinfo_t;

typedef struct _livedown {
	/* for ODB */
	int odbflag;
	int odblsnrflag;

	/* for TDB */
	int tdbflag;
	int tdblrepflag;
	int tdbprepflag;

	/* for YDB */
	int ydbflag;
} livedown_t;

typedef struct _sysbundle {
	cpuinfo_t cpuinfo;
	meminfo_t meminfo;
	fsyinfo_t fsyinfo[MAX_FSYINFO_NUM];
	netinfo_t netinfo[MAX_NETINFO_NUM];
	tdbinfo_t tdbinfo;
	odbinfo_t odbinfo[MAX_ODBINFO_NUM];

	/* the number of... */
	int netnum;
	int fsynum;
	int odbnum;

	/* up/down status [TRUE=live, FALSE=down] */
	livedown_t livedown;

	/* timeinfo of... */
	timeinfo_t ticpu;
	timeinfo_t timem;
	timeinfo_t tifsy;
	timeinfo_t tinet;
} sysbundle_t;	

/** ----------------------------------------------------- */
/** table                                                 */
/** ----------------------------------------------------- */

#endif
