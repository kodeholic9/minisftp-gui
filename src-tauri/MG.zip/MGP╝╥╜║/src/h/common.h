#ifndef	__COMMON_H__
#define	__COMMON_H__

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdarg.h>
#include <strings.h>
#include <signal.h>
#include <libgen.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/param.h>
#include <sys/file.h>
#include <sys/uio.h>
#include <sys/timeb.h>
#include <net/if.h>
#include <netinet/in.h>
#include <sys/poll.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <dirent.h>

#define __USE_GNU
#include <pthread.h>
#include <sys/types.h>
#include <string.h>
#include <sys/utsname.h>
#include <sys/msg.h>
#include <sys/un.h>
#include <assert.h>

/* private.. */
#include "debug.h"

/* -------------------------------------------------------------------------- */
/* constants, size and length definition                                      */
/* -------------------------------------------------------------------------- */
#define TRUE            1
#define FALSE           0
#define ON              TRUE
#define OFF             FALSE
#define OCCUPIED        TRUE
#define UNOCCUPIED      FALSE

#define SUCCESS         0
#define FAIL            -1

#define NONE            -1

#define STX             0x02
#define ETX             0x03
#define CTX             0x04

#define RET_ERROR      -1
#define RET_FOUND       0
#define RET_NOTFOUND    1
#define RET_CONTINUE    2

#define SHM_FAILED    (void *)-1L

typedef int                 sint;
typedef struct sockaddr     sockaddr_t;
typedef struct sockaddr_in  sockaddr_in_t;
typedef struct sockaddr_un  sockaddr_un_t;
typedef struct hostent      hostent_t;
typedef struct timeval      timeval_t;
typedef unsigned char       uchar;

#define DEFINE_SYMBOLIC_LINK	0
#define DEFINE_HARD_LINK		1

/* Socket Define - gab */
#define DO_SELECT_AGAIN         1
#define L3_LAYER_TCP            0
#define L3_LAYER_UDP            1
#define L3_LAYER_SCTP           2
#define SERVER_SOCKET           0
#define CLIENT_SOCKET           1
#define BMODE_NONBLOCK          1
#define BMODE_BLOCK             0
#define ACCEPT_NONBLOCK         1
#define ACCEPT_BLOCK            0

//
#define MAX_MDN_LEN            16
#define MAX_APPTYPE_LEN        16
#define MAX_AUTHKEY_LEN        32
#define MAX_REGIONCODE_LEN     2

#define MAX_ADDRESS_LEN        24
#define MAX_FNAME_LEN          256
#define PERM                   0666
#define MAX_THREAD_STACK_SZ    2097152
#define MAX_SOCKET_BUFFER_SZ   2097152

#define MAX_LINE_SIZE          256
#define MAX_PATH_SIZE          512
#define MAX_HOST_SIZE          20

/* RingBuffer related definition */
#define RINGBUFF_MAGIC         0x41731793 
#define MAX_RBDATA_SIZE        (2*1024*1024)
typedef struct _variable_ringbuffer {
	int   r; /* read  offset */
	int   w; /* write offset */
	char *data;
	int   datalen;

	int   count;

	/* thread specifics */
	pthread_mutex_t mutex;
} variable_ringbuffer_t;

typedef struct _ringbuffer_item {
	unsigned int magic;   /* == for validity check */
	unsigned int length;
} ringbuffer_item_t;

/* RingBuffer related definition */
#define CMAP_UNDEF_STR "UNDEF"
#define CMAP_STR_LEN   64
typedef struct _codeent {
	unsigned int code;
	char         s[CMAP_STR_LEN];
} codeent_t;

typedef struct _codemap {
	int        maxnum;
	int        curnum;
	codeent_t *p_codelist;
} codemap_t;

/* Protocol related definition */
#define MAX_IPADDRSTR_LEN 4
#define MAX_I64_LEN       8
#define MAX_SIDSTR_LEN    MAX_I64_LEN
#define MAX_UIDSTR_LEN    MAX_I64_LEN
#define MAX_DTMSTR_LEN    MAX_I64_LEN
typedef sockaddr_in_t udpaddr_t;

typedef struct _i64 {
	unsigned char s[MAX_I64_LEN];
} i64_t;

typedef struct _i64 uesid_t;
typedef struct _i64 iuid_t;
typedef struct _i64 datetime_t;

typedef struct _iuaddr {
	unsigned char d[MAX_ADDRESS_LEN/2];
} iuaddr_t;

typedef struct _ueipaddr {
	unsigned char d[MAX_IPADDRSTR_LEN];
} ueipaddr_t;

typedef struct _ueaddr {
	unsigned char  is_group; /* true(1), false(0) */
	unsigned char  is_lcs;   /* true(1), false(0) */
	iuid_t         uid;
	char           pad[2];
} ueaddr_t;

typedef struct _ipport {
	ueipaddr_t     ipaddr;
	unsigned short port;
	char           pad[2];
} ipport_t;

/* -------------------------------------------------------------------------- */
/* size definition                                                            */
/* -------------------------------------------------------------------------- */

#endif	/* __COMMON_H__ */
