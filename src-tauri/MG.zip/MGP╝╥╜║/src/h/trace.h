/**
 * @date   2012/08/16
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */

#ifndef __TRACE_H__
#define __TRACE_H__

#include "const.h"
#include "oma/ommsg.h"

#define MAX_TRACEINFO_NUM  36
#define MAX_TRACEARGS_NUM  10

typedef struct _traceargs {
	long target[MAX_TRACEARGS_NUM];
	int  n;
} traceargs_t;

typedef struct _traceinfo {
	char occupied;
	long trace_id;
	int  detailed;

	/* condition */
	long iuid;
	char mdn   [MAX_ADDRESS_LEN];
	char block [MAX_TRBLOCK_LEN];
	char source[MAX_TRSOURCE_LEN];

	/* dynamic */
	time_t strttime;
	time_t stoptime;
} traceinfo_t;

typedef struct _tracelist {
	traceinfo_t traceinfo[MAX_TRACEINFO_NUM];
	int         used;
} tracelist_t;

#endif

