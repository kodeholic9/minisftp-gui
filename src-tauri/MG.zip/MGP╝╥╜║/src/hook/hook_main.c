/**
 * @date   2016/07/26
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */
#include "hook.h"
#include <linux/input.h>

/* for debug */
#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_MAIN, __LINE__)

/* for main */
hookmagic_t   Oz;
hookmagic_t *pOz = &Oz;

time_t Current;

/* main.. */
int main(int argc, char **argv)
{
	ipcmsg_t *p_ipcmsg;
	int ipc_num = 0, file_num = 0;
	int usec;

	fd_set rset;

	/* init LogLevel */
	comLogLevelSet(IN);

	/* INITIALIZE */
	if (initialize(argc, argv) == -1) {
		comLog(ER, "fail to initialize.");
		terminate(2);
	}

	/* NEVER DIE!! */
	FNDEBUG(TASK_MAIN);
	while (Oz.running) {
		FNDEBUG(TASK_MAIN);
		if (getppid() == 1) {
			comLog(ER, "the parent process is down!");
			Oz.running = FALSE;
			break;
		}

		FNDEBUG(TASK_MAIN);
		if ((ipc_num + file_num) > 0) { usec = 10   * 1000; }
		else                          { usec = 1000 * 1000; }

		FNDEBUG(TASK_MAIN);
		Current = comTime();

		FNDEBUG(TASK_MAIN);
		file_num = 0;
		if (wait_for(&rset, usec) > 0) {
			FNDEBUG(TASK_MAIN);
			file_num = proc_file(&rset);
		}

		FNDEBUG(TASK_MAIN);
		ipc_num = 0;
		if (appIpcRecvMsg(&p_ipcmsg, 0) != -1) {
			comLog(DG, "process something with ipc!!");
			ipc_num = proc_ipc(p_ipcmsg);
		}

		FNDEBUG(TASK_MAIN);
		proc_timer();

		usleep(10000);
	}

	/* TERMINATE */
	FNDEBUG(TASK_MAIN);
	terminate(99);

	return 0;
}

int wait_for(fd_set *rset, int usec)
{
	struct timeval timeo;
	int    cc;

	/* CHECK INPUT EVENT */
	FNDEBUG(TASK_MAIN);
	timeo.tv_sec  = 0;
	timeo.tv_usec = usec;
	memcpy(rset, &pOz->rmask, sizeof(fd_set));

	FNDEBUG(TASK_MAIN);
	if ((cc = select(pOz->maxfd, rset, NULL, NULL, &timeo)) == -1) {
		FNDEBUG(TASK_MAIN);
		if (errno != EINTR) {
			FNDEBUG(TASK_MAIN);
			comErr(ER, errno, "fail to select.");
			terminate(98);
		}
	}

	FNDEBUG(TASK_MAIN);
	return cc;
}

int proc_file(fd_set *rset)
{
	int num = 0;
	int i;

	FNDEBUG(TASK_MAIN);
	for (i = 0; i < MAX_HOOKFD_NUM; i++) {
		if (pOz->hookfds[i] > 0 && FD_ISSET(pOz->hookfds[i], rset)) {
			hook_read(pOz->hookfds[i]);
			num += 1;
		}
	}

	return num;
}

int proc_ipc(ipcmsg_t *p_ipcmsg)
{
	FNDEBUG(TASK_MAIN);
	switch (p_ipcmsg->mtype) {
		case IMT_MGP_STRT_REQ:
			FNDEBUG(TASK_MAIN);
			break;
	}

	return 0;
}

int proc_timer()
{
	time_t current = comTime();

	comLog(VB, "process something with timer!!");

	FNDEBUG(TASK_MAIN);
	comLogLevelSet(pProfile->LogLevel);

	FNDEBUG(TASK_MAIN);
	if ((current - pOz->hook_update_time) >= 5) {
		hook_update(current);
	}

	FNDEBUG(TASK_MAIN);
	return 0;
}

void sighandler(int signo)
{
	pOz->running = FALSE;
}

int initialize(int argc, char **argv)
{
	/* parse args */
	memset(pOz, 0x00, sizeof(hookmagic_t));

	/* initialize */
	if (appInitialize(APP_SHM_KEY, HOOK, 0) == -1) {
		comErr(ER, errno, "fail to appInitialize.");
		return -1;
	}

	if (appDaemonInit("HOOK", FALSE) == -1) {
		comErr(ER, errno, "fail to appDaemonInit.");
		return -1;
	}

	/* attach the globla hashmagic */
	pOz->running = TRUE;

	/* install signal */
	comInstallSignal(SIGINT , sighandler);
	comInstallSignal(SIGTERM, sighandler);

	/* init my IPC */
	appIpcResetAp();

	/* welcome... */
	appWelcome(argv[0]);

	/* init hook */
	hook_update(comTime());
	
	return 0;
}

int terminate(int code)
{
	int i;

	for (i = 0; i < 3; i++) {
		comLog(WA, "wait....[%d]", i);
		sleep(1);
	}

	/* terminate self.. */
	comGoodbye(code);
	exit(code);

	return 0;
}

void hook_update(time_t current)
{
	struct stat sb;
	char   dev_name[128];
	int i, fd;

	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	for (i = 0; i < MAX_HOOKFD_NUM; i++) {
		snprintf(dev_name, sizeof(dev_name), "/dev/input/event%d", i);
		if (pOz->hookfds[i] == 0
				&& (stat(dev_name, &sb) != -1)
				&& (fd = hook_open(dev_name)) > 0)
		{
			pOz->hookfds[i] = fd;
		}
	}

	pOz->hook_update_time = current;

	return;
}

int hook_open(char *dev_name)
{
	int fd, saved = 0;

	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if ((fd = open(dev_name, O_RDONLY)) == -1) {
		comLog(ER, "%s() fail to open(%s) - error:%d(%s)", __func__, dev_name, errno, strerror(errno));
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	saved = fcntl(fd, F_GETFL, 0);
	if (fcntl(fd, F_SETFL, saved | O_NONBLOCK)<0) {
		comLog(ER,"fcntl failed. %s(%d)", strerror(errno), errno);
		close(fd);
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	comSetSelectMask(&pOz->maxfd, &pOz->rmask, fd);

	return fd;
}

int hook_read(int fd)
{
	struct input_event ev;
	int n;

	FNDEBUG(TASK_MAIN);
	if (fd <= 0) {
		comLog(WA, "%s() - not opened! - fd: %d", __func__, fd);
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	if ((n = read(fd, &ev, sizeof(ev))) != sizeof(ev)) {
		comLog(WA, "%s() - fail to read() - n: %d, error:%d(%s)", __func__, n, errno, strerror(errno));
		hook_close(&fd);
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s() - nread: %d", __func__, n);

	FNDEBUG(TASK_MAIN);
	switch (ev.type) {
		case EV_SYN: 
			comLog(VB, "%s() - EV_SYN(%d)", __func__, ev.type);
			break;

		case EV_MSC: 
			comLog(VB, "%s() - EV_MSC(%d)", __func__, ev.type);
			break;

		case EV_KEY: 
			switch (ev.code) {
				case BTN_TOUCH:
					comLog(IN, "%s() - EV_KEY(%d), BTN_TOUCH(%d), %d", __func__, ev.type, ev.code, ev.value);
					break;
				case BTN_STYLUS:
					comLog(IN, "%s() - EV_KEY(%d), BTN_STYLUS(%d), %d", __func__, ev.type, ev.code, ev.value);
					break;
				default:
					comLog(IN, "%s() - EV_KEY(%d), UNK(%d), %d", __func__, ev.type, ev.code, ev.value);
					break;
			}
			if (ev.value == 1) {
				appIpcSendArgs(MGPP, IMT_CTL_HOOK_PRESSED, 0, 0, 0);
			}
			break;

		case EV_ABS: 
			switch (ev.code) {
				case ABS_X:
					comLog(VB, "%s() - EV_KEY(%d), ABS_X(%d), %d", __func__, ev.type, ev.code, ev.value);
					break;
				case ABS_Y:
					comLog(VB, "%s() - EV_KEY(%d), ABS_Y(%d), %d", __func__, ev.type, ev.code, ev.value);
					break;
				case ABS_PRESSURE:
					comLog(VB, "%s() - EV_KEY(%d), ABS_PRESSURE(%d), %d", __func__, ev.type, ev.code, ev.value);
					break;
				default:
					comLog(VB, "%s() - EV_ABS(%d), UNK(%d), %d", __func__, ev.type, ev.code, ev.value);
					break;
			}
			break;

		case EV_REL: 
			comLog(VB, "%s() - EV_REL(%d), UNK(%d), %d", __func__, ev.type, ev.code, ev.value);
			break;

		default:
			comLog(VB, "%s() - UNK(%d), UNK(%d), %d", __func__, ev.type, ev.code, ev.value);
			break;
	}

	return 0;
}

int hook_close(int *fd)
{
	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (fd == NULL || *fd <= 0) {
		comLog(WA, "%s() - already closed! - fd: %d", __func__, *fd);
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	comUnsetSelectMask(&pOz->maxfd, &pOz->rmask, *fd);
	close(*fd);
	*fd = 0;

	return 0;
}

