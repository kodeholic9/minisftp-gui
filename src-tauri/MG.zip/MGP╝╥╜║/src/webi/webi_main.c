/**
 * @date   2016/07/26
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */
#include "webi.h"

/* for debug */
#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_MAIN, __LINE__)

/* for main */
webimagic_t   Oz;
webimagic_t *pOz = &Oz;

time_t Current;

/* main.. */
int main(int argc, char **argv)
{
	ipcmsg_t *p_ipcmsg;
	int ipc_num = 0, sock_num = 0;
	int usec;

	fd_set rset;

	/* init LogLevel */
	comLogLevelSet(IN);

	/* INITIALIZE */
	if (initialize(argc, argv) == -1) {
		comLog(ER, "fail to initialize.");
		terminate(2);
	}

	/* NEVER DIE!! */
	FNDEBUG(TASK_MAIN);
	while (Oz.running) {
		FNDEBUG(TASK_MAIN);
		if (getppid() == 1) {
			comLog(ER, "the parent process is down!");
			Oz.running = FALSE;
			break;
		}

		FNDEBUG(TASK_MAIN);
		if ((ipc_num + sock_num) > 0) { usec = 10   * 1000; }
		else                          { usec = 1000 * 1000; }

		FNDEBUG(TASK_MAIN);
		Current = comTime();

		FNDEBUG(TASK_MAIN);
		sock_num = 0;
		if (wait_for(&rset, usec) > 0) {
			FNDEBUG(TASK_MAIN);
			sock_num = proc_sock(&rset);
		}

		FNDEBUG(TASK_MAIN);
		ipc_num = 0;
		if (appIpcRecvMsg(&p_ipcmsg, 0) != -1) {
			comLog(DG, "process something with ipc!!");
			ipc_num = proc_ipc(p_ipcmsg);
		}

		FNDEBUG(TASK_MAIN);
		proc_timer();

		usleep(10000);
	}

	/* TERMINATE */
	FNDEBUG(TASK_MAIN);
	terminate(99);

	return 0;
}

int wait_for(fd_set *rset, int usec)
{
	struct timeval timeo;
	int    cc;

	/* CHECK INPUT EVENT */
	FNDEBUG(TASK_MAIN);
	timeo.tv_sec  = 0;
	timeo.tv_usec = usec;
	memcpy(rset, &pOz->rmask, sizeof(fd_set));

	FNDEBUG(TASK_MAIN);
	if ((cc = select(pOz->maxfd, rset, NULL, NULL, &timeo)) == -1) {
		FNDEBUG(TASK_MAIN);
		if (errno != EINTR) {
			FNDEBUG(TASK_MAIN);
			comErr(ER, errno, "fail to select.");
			terminate(98);
		}
	}

	FNDEBUG(TASK_MAIN);
	return cc;
}

int proc_sock(fd_set *rset)
{
	int i;
	int num = 0;

	FNDEBUG(TASK_MAIN);
	if (FD_ISSET(pOz->lsnrfd, rset)) {
		proc_http_accept();
		num += 1;
	}

	FNDEBUG(TASK_MAIN);
	for (i = 0; i < MAX_WEBI_CLI_NUM; i++) {
		if (pOz->httpconns[i].sockfd > 0
				&& FD_ISSET(pOz->httpconns[i].sockfd, rset))
		{
			proc_http_read_request(pOz->httpconns + i);
			num += 1;
		}
	}

	return num;
}

int proc_ipc(ipcmsg_t *p_ipcmsg)
{
	switch (p_ipcmsg->mtype) {
		case IMT_MGP_STRT_REQ:
			FNDEBUG(TASK_MAIN);
			break;
	}

	return 0;
}

int proc_timer()
{
	comLog(VB, "process something with timer!!");

	FNDEBUG(TASK_MAIN);
	comLogLevelSet(pProfile->LogLevel);

	return 0;
}

void sighandler(int signo)
{
	pOz->running = FALSE;
}

int initialize(int argc, char **argv)
{
	/* parse args */
	memset(pOz, 0x00, sizeof(webimagic_t));

	/* initialize */
	if (appInitialize(APP_SHM_KEY, WEBI, 0) == -1) {
		comErr(ER, errno, "fail to appInitialize.");
		return -1;
	}

	if (appDaemonInit("WEBI", FALSE) == -1) {
		comErr(ER, errno, "fail to appDaemonInit.");
		return -1;
	}

	/* attach the globla hashmagic */
	pOz->running = TRUE;

	/* install signal */
	comInstallSignal(SIGINT , sighandler);
	comInstallSignal(SIGTERM, sighandler);

	/* init my IPC */
	appIpcResetAp();

	/* welcome... */
	appWelcome(argv[0]);

	/* init */
	http_server_init();

	return 0;
}

int terminate(int code)
{
	int i;

	for (i = 0; i < 3; i++) {
		comLog(WA, "wait....[%d]", i);
		sleep(1);
	}

	/* terminate self.. */
	comGoodbye(code);
	exit(code);

	return 0;
}

