/**
 * @date   2016/12/19
 * @author Kang Tae Goo (tgkang@tisquare.com,r9i9c9@gmail.com)
 * 
 */
#include "webi.h"

/* http://192.168.102.52:8080/mgp/light-bar?audio=0.mp3&type=start */

/* for debug */
#define FNDEBUG(TASK) __FNDEBUG(TASK, FN_MISC, __LINE__)

static char *http_date(char *buf, int buflen)
{
	time_t now = time(0);
    struct tm *p_tm = gmtime(&now);
	strftime(buf, buflen, "%a, %d %b %Y %H:%M:%S %Z", p_tm);

	return buf;
}

static char *skip_token(char *p)
{
	while (*p != '\0' &&  isspace((int)(*p))) { p++; }
	while (*p != '\0' && !isspace((int)(*p))) { p++; }
	while (*p != '\0' &&  isspace((int)(*p))) { p++; }

	return p;
}

static char *next_token(char *p, char *token, int tklen)
{
	int i = 0;

	memset(token, 0x00, tklen);

	/* tokenize.. */
	while (*p &&  isspace((int)(*p))) { p++; }
	while (*p && !isspace((int)(*p))) {
		if (i >= tklen) {
			break;
		}
		token[i] = *p;
		p++;
		i++;
	}

	return p;
}

int http_server_init()
{
	comLog(VB, "%s() - lsnrfd: %d", __func__, pOz->lsnrfd);

	FNDEBUG(TASK_MAIN);
	if ((pOz->lsnrfd = appNonbsockListen(NULL, pProfile->WEBIListenPort)) == -1) {
		comLog(ER, "%s() fail to appNonbsockListen. error=%d(%s)", __func__, errno, strerror(errno));
		return -1;
	}
	comSetSelectMask(&pOz->maxfd, &pOz->rmask, pOz->lsnrfd);

	return 0;
}

int http_accept(int lsnrfd)
{
	sockaddr_in_t addr;
	socklen_t     addrlen = 0;
	int           saved, connfd;
#if 0
	struct linger lng;
#endif

	FNDEBUG(TASK_MAIN);
	comLog(VB, "%s() - lsnrfd: %d", __func__, lsnrfd);

	/* set NONBLOCK */
	FNDEBUG(TASK_MAIN);
	saved = fcntl(lsnrfd, F_GETFL, 0);
	fcntl(lsnrfd, F_SETFL, saved | O_NONBLOCK);

L_ACCEPT_AGAIN:

	FNDEBUG(TASK_MAIN);
	if ((connfd = accept(lsnrfd, (sockaddr_t *)&addr, &addrlen)) == -1) {
		switch (errno) {
			case EINTR:
				goto L_ACCEPT_AGAIN;
				break;

			case EWOULDBLOCK:   /* for Berkeley-derived, when the client aborts the connection before accept() */
			case ECONNABORTED:  /* for Posix.1g, when the client aborts the connection before accept() */
			case EPROTO:        /* for SVR4, when the client aborts the connection before accept() */
				comLog(ER, "accept(%d, ...) failed. Connection request has DISAPPEARED.", lsnrfd);
				return -1;

			case ENOBUFS:       /* for HP-UX 11.xx */
				comLog(ER, "accept(%d, ...) failed. The queued socket connect request is aborted.", lsnrfd);
				return -1;

			default:
				comLog(ER, "accept(%d, ...) failed. %s(%d)", lsnrfd, strerror(errno), errno);
				return -1;
		}
	}

	/* for linger option */
#if 0
	lng.l_onoff = 1; lng.l_linger = 0;
	if (setsockopt(connfd, SOL_SOCKET, SO_LINGER, (char *)&lng, sizeof(lng)) < 0) {
		comLog(ER, "setsockopt(%d, ...) failed. %s(%d) - error:%d(%s)", connfd, errno, strerror(errno));
		close(connfd);
		return -1;
	}
#endif

	/* set NONBLOCK */
	FNDEBUG(TASK_MAIN);
	saved = fcntl(connfd, F_GETFL, 0);
	fcntl(connfd, F_SETFL, saved | O_NONBLOCK);

	FNDEBUG(TASK_MAIN);
	return connfd;
}

static void httpconn_init(httpconn_t *p_hc, int connfd)
{
	comLog(IN, "%s() - connfd: %d", __func__, connfd);

	FNDEBUG(TASK_MAIN);
	p_hc->sockfd = connfd;
	comSetSelectMask(&pOz->maxfd, &pOz->rmask, p_hc->sockfd);

	FNDEBUG(TASK_MAIN);
	memset(&p_hc->sendbuff, 0x00, sizeof(sockbuffer_t));
	memset(&p_hc->recvbuff, 0x00, sizeof(sockbuffer_t));

	return;
}

static void httpconn_close(httpconn_t *p_hc)
{
	comLog(IN, "%s() - connfd: %d", __func__, p_hc->sockfd);

	FNDEBUG(TASK_MAIN);
	if (p_hc->sockfd == 0) {
		comLog(WA, "%s() - already closed! - connfd: %d", __func__, p_hc->sockfd);
		return;
	}

	FNDEBUG(TASK_MAIN);
	comUnsetSelectMask(&pOz->maxfd, &pOz->rmask, p_hc->sockfd);
	close(p_hc->sockfd);
	p_hc->sockfd = 0;

	return;
}

static int httpconn_read(httpconn_t *p_hc)
{
	sockbuffer_t *p_buffer = &p_hc->recvbuff;
	int n, dlen;

	comLog(IN, "%s()", __func__);

L_READ_AGAIN:

	FNDEBUG(TASK_MAIN);
	if ((dlen = MAX_SOCKBUFF_LEN - p_buffer->limit) > 0) {
		comLog(DG, "%s() - connfd: %s - limit: %d, dlen: %d", __func__, p_hc->sockfd, p_buffer->limit, dlen);
		if ((n = read(p_hc->sockfd, p_buffer->data + p_buffer->limit, dlen)) == -1) {
			if (errno == EINTR || errno == EAGAIN) {
				goto L_READ_AGAIN;
			}
			comLog(ER, "%s() - connfd: %d - fail to read() error=%d(%s)", __func__,
					p_hc->sockfd, errno, strerror(errno));
			return -1;
		}
		else if (n == 0) { /* EOF */
			comLog(DG, "%s() - connfd: %d - read() meats EOF - error=%d(%s)", __func__,
					p_hc->sockfd, errno, strerror(errno));
			return -1;
		}

		p_buffer->limit += n;
	}

	return p_buffer->limit;
}

static char *http_next_line(char *p, char *line, int size)
{
	char *sp  = p;
	int   len = 0;

	memset(line, 0x00, size);

	comLog(DG, "%s() - p: %p, line: %p", __func__, p, line);

	if ((p = strstr(p, CRLF)) != NULL) {
		if ((len = p - sp) >= size) {
			len = size - 1;
		}
		if (len > 0) {
			strncpy(line, sp, len);
		}

		p += 2;
	}

	return p;
}

static int http_parse_uri(char *line, char *uri, int uri_len)
{
	char *cp = line;

	cp = skip_token(cp);
	cp = next_token(cp, uri, uri_len);
	cp = skip_token(cp);

	return 0;
}

static httpreqt_t *http_parse_request(httpconn_t *p_hc)
{
	char  line[MAX_HTTP_HEAD_LINE_LEN];
	char *cp = p_hc->recvbuff.data;
	char *tmp;
	int   i, clen;

	comLog(DG, "%s() - connfd: %d\n%s", __func__, p_hc->sockfd, cp);

	FNDEBUG(TASK_MAIN);
	memset(&p_hc->request, 0x00, sizeof(httpreqt_t));

	FNDEBUG(TASK_MAIN);
	i = 0;
	while ((cp = http_next_line(cp, line, MAX_HTTP_HEAD_LINE_LEN)) != NULL) {
		FNDEBUG(TASK_MAIN);
		comLog(DG, "[HEAD, %ld, %s]", strlen(line), line);
		/* START LINE */
		if (i == 0) {
			FNDEBUG(TASK_MAIN);
			http_parse_uri(line, p_hc->request.uri, sizeof(p_hc->request.uri));
			comLog(IN, "[REQUEST-URI, %s]", p_hc->request.uri);
		}
		/* CONTENT-LENGTH */
		else if (strncasecmp(HH_CONTENT_LENGTH, line, strlen(HH_CONTENT_LENGTH)) == 0) {
			FNDEBUG(TASK_MAIN);
			if ((tmp = strstr(line, ":")) != NULL) {
				FNDEBUG(TASK_MAIN);
				clen = 0;
				tmp  = skip_token(tmp);
				while (*tmp != '\0' && isdigit(*tmp)) {
					clen *= 10;
					clen += ((int)(*tmp - 0x30));
					tmp++;
				}
				comLog(IN, "[%s, %d]", HH_CONTENT_LENGTH, clen);

				p_hc->request.clen = clen;
			}
		}
		/* END OF HEAD */
		else if (strlen(line) == 0) {
			FNDEBUG(TASK_MAIN);
			if (*cp != '\0' && p_hc->request.clen > strlen(cp)) {
				return NULL;
			}

			FNDEBUG(TASK_MAIN);
			p_hc->request.content = cp;

			FNDEBUG(TASK_MAIN);
			comLog(IN, "[REQUEST]\n%s", p_hc->recvbuff.data);
			comLog(IN, "%s() - uri: %s, clen: %d, content: 0x%08x(%d)", __func__,
					p_hc->request.uri,
					p_hc->request.clen,
					p_hc->request.content,
					strlen(p_hc->request.content));

			return &p_hc->request;
		}
		i++;
	}

	return NULL;
}

int proc_http_accept()
{
	int i, empty;
	int connfd = 0;

	comLog(DG, "%s()", __func__);

	/* accept */
	FNDEBUG(TASK_MAIN);
	if ((connfd = http_accept(pOz->lsnrfd)) == -1) {
		comLog(ER, "%s() fail to http_accept() - errno:%d(%s)", __func__, errno, strerror(errno));
		return -1;
	}

	/* lookup the empty slot! */
	FNDEBUG(TASK_MAIN);
	empty = -1;
	for (i = 0; i < MAX_WEBI_CLI_NUM; i++) {
		if (pOz->httpconns[i].sockfd == 0) {
			empty = i;
			break;
		}
	}
	FNDEBUG(TASK_MAIN);
	if (empty == -1) {
		comLog(ER, "%s() there is no empty slot. close new connfd: %d", __func__, connfd);
		close(connfd);
		return -1;
	}

	/* already?? close the new sockfd */
	FNDEBUG(TASK_MAIN);
	comLog(IN, "%s() add client httpconn[%d] connfd: %d", __func__, empty, connfd);

	/* initialize... */
	FNDEBUG(TASK_MAIN);
	httpconn_init(pOz->httpconns + empty, connfd);

	return 0;
}

void http_send_response(httpconn_t *p_hc, int code, int clen)
{
	sockbuffer_t *p_buffer = &p_hc->sendbuff;
	char date[100];
	int  n = 0;

	comLog(DG, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	memset(p_buffer, 0x00, sizeof(sockbuffer_t));

	//pack http-response
	FNDEBUG(TASK_MAIN);
	n = snprintf(p_buffer->data, MAX_SOCKBUFF_LEN,
			"HTTP/1.1 %d %s\r\n"
			"Server: %s\r\n"
			"Date: %s\r\n"
			"Connection: close\r\n"
			"Content-Type: application/json;charset=utf-8\r\n"
			"Content-Length: %d\r\n"
			"\r\n",
			code,
			"OK",
			HHV_USER_AGENT,
			http_date(date, sizeof(date)),
			clen);

	FNDEBUG(TASK_MAIN);
	if (write(p_hc->sockfd, p_buffer->data, n) == -1) {
		comLog(ER, "%s() fail to write()", __func__);
	}

	FNDEBUG(TASK_MAIN);
	comLog(IN, "[RESPONSE]\n%s", p_buffer->data);

	httpconn_close(p_hc);

	return;
}

int proc_http_read_request(httpconn_t *p_hc)
{
	httpreqt_t *p_reqt;

	comLog(DG, "%s()", __func__);

	FNDEBUG(TASK_MAIN);
	if (p_hc->sockfd <= 0) {
		comLog(ER, "%s() not Established! - connfd: %d", __func__, p_hc->sockfd);
		return -1;
	}

	FNDEBUG(TASK_MAIN);
	if (httpconn_read(p_hc) == -1) {
		comLog(ER, "%s() fail to httpconn_read() - connfd: %d", __func__, p_hc->sockfd);
		httpconn_close(p_hc);
		return -1;
	}

	FNDEBUG(TASK_MAIN);
 	if ((p_reqt = http_parse_request(p_hc)) != NULL) {
		http_send_response(p_hc, 200, 0);
	}

	return 0;
}




