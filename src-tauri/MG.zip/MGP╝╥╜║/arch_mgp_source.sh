#!/bin/sh

DATE=`/bin/date +"%Y%m%d_%H"`
TARGET="mgp_source_$DATE.tar"

echo "TARGET: $TARGET"

tar cvf $TARGET README src _3rd* script conf arch_mgp_source.sh jansson-2.7.tar

mv $TARGET backup

exit 0;
